#!/usr/bin/env node
/**
 * flow-banderas — copia a la carpeta pública del producto las banderas de los
 * países en los que opera (RFC 0012, flg-3).
 *
 *   npx flow-banderas --codigos mx,us,br --destino public/flags
 *   import { copiarBanderas } from '@er-mobility-mx/design-system/banderas'
 *
 * Por qué el consumidor pone los archivos y no el paquete: el catálogo completo
 * son 271 banderas y 1,9 MB, y un producto pinta las de sus países. Meterlas en
 * el tarball se lo cobraría también a quien no monta ninguna bandera, y
 * subsetear por uso DENTRO del paquete es el error que ya se revirtió con los
 * iconos —un design system es de mundo abierto—. Qué códigos son lo sabe el
 * producto, y no puede saberlo el sistema.
 *
 * Es un script y no un plugin de empaquetador a propósito: un plugin cubriría
 * dev y build en una línea, pero ataría el sistema a Vite. Un script lo llama
 * cualquiera desde un `prebuild`.
 *
 * El tramo es 1x1 porque es el único que el sistema usa: `Flag` es cuadrada.
 */
import { copyFileSync, existsSync, mkdirSync, readdirSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const TRAMOS = ['1x1', '4x3']

/** La carpeta de SVG de flag-icons, resuelta desde donde esté instalada. */
function origenDeBanderas(tramo) {
  const require = createRequire(import.meta.url)
  let raiz
  try {
    /* Por el package.json y no por el .svg: los subpaths de un paquete pueden
       no estar exportados, y su manifiesto siempre lo está. */
    raiz = dirname(require.resolve('flag-icons/package.json'))
  } catch {
    throw new Error(
      'flow-banderas: no encuentro `flag-icons`. Es un peer OPCIONAL: instálalo como dependencia de ' +
        'desarrollo (`npm i -D flag-icons`) para copiar los archivos una vez, o pasa --origen con tu propia carpeta.',
    )
  }
  return join(raiz, 'flags', tramo)
}

/**
 * Copia las banderas pedidas. Devuelve lo que hizo, para que quien lo llame
 * pueda decirlo o fallar: `{ copiados, faltantes, bytes, destino }`.
 */
export function copiarBanderas({ codigos, destino, origen, tramo = '1x1' }) {
  if (!TRAMOS.includes(tramo)) throw new Error(`flow-banderas: tramo desconocido «${tramo}» (${TRAMOS.join(' | ')}).`)
  const lista = (Array.isArray(codigos) ? codigos : String(codigos || '').split(','))
    .map((c) => String(c).trim().toLowerCase())
    .filter(Boolean)
  if (!lista.length) throw new Error('flow-banderas: no me diste ningún código (--codigos mx,us).')
  if (!destino) throw new Error('flow-banderas: no me diste destino (--destino public/flags).')

  const dir = origen ? resolve(origen) : origenDeBanderas(tramo)
  const salida = resolve(destino)
  mkdirSync(salida, { recursive: true })

  const copiados = []
  const faltantes = []
  for (const cc of lista) {
    const archivo = join(dir, `${cc}.svg`)
    if (!existsSync(archivo)) {
      faltantes.push(cc)
      continue
    }
    copyFileSync(archivo, join(salida, `${cc}.svg`))
    copiados.push(cc)
  }
  return { copiados, faltantes, destino: salida, disponibles: () => readdirSync(dir).length }
}

function cli(argv) {
  const arg = (nombre) => {
    const i = argv.indexOf(`--${nombre}`)
    return i >= 0 ? argv[i + 1] : undefined
  }
  const r = copiarBanderas({
    codigos: arg('codigos'),
    destino: arg('destino'),
    origen: arg('origen'),
    tramo: arg('tramo') ?? '1x1',
  })
  console.log(`flow-banderas: ${r.copiados.length} copiadas en ${r.destino} — ${r.copiados.join(', ')}`)
  if (r.faltantes.length) {
    /* Un código que no existe es un error y no un aviso: el producto cree que
       pinta esa bandera y en el navegador saldría un hueco. */
    console.error(`flow-banderas: estos códigos no están en el catálogo: ${r.faltantes.join(', ')}`)
    process.exit(1)
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) cli(process.argv.slice(2))

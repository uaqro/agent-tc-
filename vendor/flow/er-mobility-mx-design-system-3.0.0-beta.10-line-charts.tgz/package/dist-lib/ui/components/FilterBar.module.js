//#region src/ui/components/FilterBar.module.css
var e = "_24slxq_root", t = { root: e };
//#endregion
export { t as default, e as root };

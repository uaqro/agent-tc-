//#region src/ui/components/Sidebar.module.css
var e = "xpQ4va_badge", t = "xpQ4va_badgeCollapsed", n = "xpQ4va_caption", r = "xpQ4va_captionGroup", i = "xpQ4va_captionRule", a = "xpQ4va_chevron", o = "xpQ4va_drawerHeading", s = "xpQ4va_footer", c = "xpQ4va_header", l = "xpQ4va_item", u = "xpQ4va_itemIcon", d = "xpQ4va_itemLabel", f = "xpQ4va_nav", p = "xpQ4va_root", m = "xpQ4va_sectionChildren", h = "xpQ4va_tooltip", g = {
	badge: e,
	badgeCollapsed: t,
	caption: n,
	captionGroup: r,
	captionRule: i,
	chevron: a,
	drawerHeading: o,
	footer: s,
	header: c,
	item: l,
	itemIcon: u,
	itemLabel: d,
	nav: f,
	root: p,
	sectionChildren: m,
	tooltip: h
};
//#endregion
export { e as badge, t as badgeCollapsed, n as caption, r as captionGroup, i as captionRule, a as chevron, g as default, o as drawerHeading, s as footer, c as header, l as item, u as itemIcon, d as itemLabel, f as nav, p as root, m as sectionChildren, h as tooltip };

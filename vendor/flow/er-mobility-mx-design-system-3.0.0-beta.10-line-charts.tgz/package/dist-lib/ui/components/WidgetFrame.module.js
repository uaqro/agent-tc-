//#region src/ui/components/WidgetFrame.module.css
var e = "OlYDXq_actions", t = "OlYDXq_body", n = "OlYDXq_header", r = "OlYDXq_root", i = {
	actions: e,
	body: t,
	header: n,
	root: r
};
//#endregion
export { e as actions, t as body, i as default, n as header, r as root };

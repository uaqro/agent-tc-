"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Checkbox as t } from "../primitives/Checkbox.js";
import { EmptyState as n } from "../primitives/EmptyState.js";
import r from "./DataGrid.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import { useCallback as o, useState as s } from "react";
//#region src/ui/components/DataGrid.tsx
var c = (e, t) => e[t], l = (e) => {
	let t = e.children;
	return Array.isArray(t) ? t : void 0;
}, u = "button, a[href], input, select, textarea, label, [role=\"button\"], [role=\"menuitem\"], [contenteditable=\"true\"]", d = (e, t) => e instanceof Element ? !t.contains(e) || !!e.closest(u) : !1;
function ee(e, t, n) {
	for (let n of t) {
		let t = c(e, n.key);
		if (typeof t == "string" && t.trim()) return t;
		if (typeof t == "number") return String(t);
	}
	return String(n);
}
function f({ columns: u = [], rows: f = [], rowKey: p, selectedKey: m, selectable: h, selectedKeys: g, defaultSelectedKeys: te, onSelectionChange: _, selectAllLabel: v, attachedTop: ne, surface: re = "card", onRowClick: y, sortable: b = !0, sort: x, onSortChange: S, density: C = "default", caption: w, zebraToken: T = "var(--surface-sunken)", skin: ie, tree: E, expandedKeys: D, defaultExpandedKeys: O, onExpandedChange: k, expandLabel: ae = "Expandir", collapseLabel: A = "Colapsar", style: oe }) {
	let j = (e) => ie?.[e] ?? r[e], M = e(), N = g !== void 0, [se, ce] = s(te ?? []), P = N ? g : se, F = (e) => P.includes(e), I = o((e) => {
		N || ce(e), _?.(e);
	}, [N, _]), L = D !== void 0, [R, z] = s(O ?? []), B = L ? D : R, V = o((e) => {
		let t = B.includes(e) ? B.filter((t) => t !== e) : [...B, e];
		L || z(t), k?.(t);
	}, [
		B,
		L,
		k
	]), H = x !== void 0, [U, W] = s(null), G = H ? x : U, K = G?.key ?? null, q = G?.dir ?? "asc", le = o((e) => {
		if (!b) return;
		let t = K === e ? {
			key: e,
			dir: q === "asc" ? "desc" : "asc"
		} : {
			key: e,
			dir: "asc"
		};
		H || W(t), S?.(t);
	}, [
		b,
		K,
		q,
		H,
		S
	]), ue = (e, t) => {
		let n = c(e, K), r = c(t, K), i = typeof n == "number" && typeof r == "number" ? n - r : String(n).localeCompare(String(r));
		return q === "asc" ? i : -i;
	}, J = (e) => {
		if (H || !K) return e;
		let t = [...e].sort(ue);
		return E ? t.map((e) => l(e) ? {
			...e,
			children: J(l(e))
		} : e) : t;
	}, Y = J(f), X = (e, t, n) => (e.forEach((e, r) => {
		let i = p ? c(e, p) : `${t}-${r}`, a = l(e), o = !!a?.length, s = o && B.includes(i);
		n.push({
			row: e,
			key: i,
			nivel: t,
			conHijos: o,
			abierta: s
		}), s && X(a, t + 1, n);
	}), n), Z = E ? X(Y, 0, []) : Y.map((e, t) => ({
		row: e,
		key: p ? c(e, p) : t,
		nivel: 0,
		conHijos: !1,
		abierta: !1
	})), Q = Z.map((e) => e.key), $ = Q.length > 0 && Q.every(F), de = !$ && Q.some(F);
	return /* @__PURE__ */ i("div", {
		className: [
			j("root"),
			re === "card" ? r.superficie : r.sinSuperficie,
			ne ? r.attachedTop : ""
		].filter(Boolean).join(" "),
		"data-density": C === "default" ? void 0 : C,
		style: {
			"--_zebra": T,
			...oe
		},
		children: /* @__PURE__ */ a("table", {
			className: j("table"),
			role: E ? "treegrid" : void 0,
			children: [
				w && /* @__PURE__ */ i("caption", {
					"data-sr-only": "",
					children: w
				}),
				/* @__PURE__ */ i("thead", { children: /* @__PURE__ */ a("tr", { children: [h && /* @__PURE__ */ i("th", {
					"data-overline": "",
					className: `${j("th")} ${r.celdaSeleccion}`,
					"data-select": "",
					children: /* @__PURE__ */ i(t, {
						checked: $,
						indeterminate: de,
						onChange: () => I($ ? [] : Q),
						ariaLabel: v ?? w ?? "Seleccionar todo"
					})
				}), u.map((e) => /* @__PURE__ */ i("th", {
					"data-overline": "",
					className: j("th"),
					"data-sortable": b || void 0,
					"data-priority": e.priority && e.priority > 1 ? e.priority : void 0,
					"aria-sort": K === e.key ? q === "asc" ? "ascending" : "descending" : void 0,
					style: { textAlign: e.align || "left" },
					children: b ? /* @__PURE__ */ a("button", {
						type: "button",
						"data-bare": "",
						className: j("thButton"),
						onClick: () => le(e.key),
						children: [e.label, K === e.key && /* @__PURE__ */ i("span", {
							className: "flow-symbol flow-symbol--sm",
							"aria-hidden": "true",
							children: q === "asc" ? "arrow_upward" : "arrow_downward"
						})]
					}) : e.label
				}, e.key))] }) }),
				/* @__PURE__ */ a("tbody", { children: [Z.length === 0 && /* @__PURE__ */ i("tr", { children: /* @__PURE__ */ i("td", {
					className: r.vacio,
					colSpan: Math.max(1, u.length + +!!h),
					children: /* @__PURE__ */ i(n, {
						icon: "search_off",
						title: M("datagrid.empty", "No hay datos que mostrar")
					})
				}) }), Z.map(({ row: e, key: n, nivel: o, conHijos: s, abierta: l }) => {
					let f = m != null && n === m || !!h && F(n);
					return /* @__PURE__ */ a("tr", {
						className: `${j("row")} ${r.fila}`,
						"data-selected": f || void 0,
						"data-clickable": y ? "" : void 0,
						tabIndex: y ? 0 : void 0,
						"aria-level": E ? o + 1 : void 0,
						"aria-expanded": E && s ? l : void 0,
						onKeyDown: y ? (t) => {
							(t.key === "Enter" || t.key === " ") && (d(t.target, t.currentTarget) || (t.preventDefault(), y(e)));
						} : void 0,
						onClick: (t) => {
							d(t.target, t.currentTarget) || y?.(e);
						},
						children: [h && /* @__PURE__ */ i("td", {
							className: `${j("td")} ${r.celdaSeleccion}`,
							"data-select": "",
							children: /* @__PURE__ */ i(t, {
								checked: F(n),
								onChange: () => I(F(n) ? P.filter((e) => e !== n) : [...P, n]),
								ariaLabel: M("datagrid.selectRow", "Seleccionar {fila}", { fila: ee(e, u, n) })
							})
						}), u.map((t, u) => {
							let d = t.render ? t.render(e) : c(e, t.key);
							return /* @__PURE__ */ i("td", {
								className: j("td"),
								"data-mono": t.mono || void 0,
								"data-priority": t.priority && t.priority > 1 ? t.priority : void 0,
								style: { textAlign: t.align || "left" },
								children: E && u === 0 ? /* @__PURE__ */ a("div", {
									className: r.celdaArbol,
									children: [
										/* @__PURE__ */ i("span", {
											className: r.sangria,
											style: { width: o * 20 }
										}),
										s ? /* @__PURE__ */ i("button", {
											type: "button",
											"data-bare": "",
											className: r.chevron,
											"data-open": l || void 0,
											"aria-label": l ? A : ae,
											onClick: () => V(n),
											children: /* @__PURE__ */ i("span", {
												className: "flow-symbol flow-symbol--sm",
												"aria-hidden": "true",
												children: "chevron_right"
											})
										}) : /* @__PURE__ */ i("span", {
											className: r.sangria,
											style: { width: 20 }
										}),
										d
									]
								}) : d
							}, t.key);
						})]
					}, n);
				})] })
			]
		})
	});
}
//#endregion
export { f as DataGrid };

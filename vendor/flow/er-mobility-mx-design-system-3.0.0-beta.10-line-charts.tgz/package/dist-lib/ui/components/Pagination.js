import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import { Select as n } from "../primitives/Select.js";
import r from "./Pagination.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/components/Pagination.tsx
function o({ page: o = 1, pages: s = 1, onChange: c, total: l, pageSize: u, pageSizeOptions: d, onPageSizeChange: f, style: p }) {
	let m = e(), h = (e, t) => Array.from({ length: t - e + 1 }, (t, n) => e + n), g = () => s <= 15 ? h(1, s) : o <= 8 ? [
		...h(1, 9),
		"...",
		...h(s - 4, s)
	] : o >= s - 7 ? [
		...h(1, 5),
		"...",
		...h(s - 8, s)
	] : [
		...h(1, 5),
		"...",
		o - 1,
		o,
		o + 1,
		"...",
		...h(s - 4, s)
	], _ = s > 15, v = l != null && u != null ? Math.min((o - 1) * u + 1, l) : null, y = l != null && u != null ? Math.min(o * u, l) : null;
	return /* @__PURE__ */ a("nav", {
		"aria-label": m("flow.pagination.label", "Paginación"),
		className: r.root,
		style: p,
		children: [
			v != null && /* @__PURE__ */ i("span", {
				className: r.range,
				children: m("flow.pagination.range", "{a}–{b} de {n}", {
					a: v,
					b: y ?? v,
					n: l ?? v
				})
			}),
			_ && /* @__PURE__ */ i(t, {
				icon: "first_page",
				onClick: () => o > 1 && c?.(1),
				disabled: o <= 1,
				ariaLabel: m("flow.pagination.first", "Primera página")
			}),
			/* @__PURE__ */ i(t, {
				icon: "chevron_left",
				onClick: () => o > 1 && c?.(o - 1),
				disabled: o <= 1,
				ariaLabel: m("flow.pagination.prev", "Anterior")
			}),
			g().map((e, t) => {
				let n = e === o;
				return e === "..." ? /* @__PURE__ */ i("span", {
					"data-bare": "",
					className: r.page,
					"data-ellipsis": "",
					"aria-hidden": "true",
					children: "…"
				}, "gap-" + t) : /* @__PURE__ */ i("button", {
					"data-bare": "",
					className: r.page,
					"data-active": n || void 0,
					onClick: () => e !== o && c?.(e),
					disabled: n,
					"aria-current": n ? "page" : void 0,
					children: String(e)
				}, String(e) + "-" + t);
			}),
			/* @__PURE__ */ i(t, {
				icon: "chevron_right",
				onClick: () => o < s && c?.(o + 1),
				disabled: o >= s,
				ariaLabel: m("flow.pagination.next", "Siguiente")
			}),
			_ && /* @__PURE__ */ i(t, {
				icon: "last_page",
				onClick: () => o < s && c?.(s),
				disabled: o >= s,
				ariaLabel: m("flow.pagination.last", "Última página")
			}),
			d && d.length > 0 && /* @__PURE__ */ i("span", {
				className: r.sizer,
				children: /* @__PURE__ */ i(n, {
					size: "sm",
					insetLabel: m("flow.pagination.pageSize", "Por página"),
					options: d.map(String),
					value: u == null ? void 0 : String(u),
					onChange: (e) => {
						let t = Number(e);
						f?.(t), c?.(1);
					}
				})
			})
		]
	});
}
//#endregion
export { o as Pagination };

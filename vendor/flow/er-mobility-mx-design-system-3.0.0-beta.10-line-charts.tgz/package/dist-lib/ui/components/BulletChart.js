import { useT as e } from "../../i18n/useSafeIntl.js";
import { ChartLegend as t } from "../primitives/ChartLegend.js";
import { EmptyState as n } from "../primitives/EmptyState.js";
import r from "./BulletChart.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/components/BulletChart.tsx
function o(o) {
	let s = e(), { rows: c, color: l, format: u, style: d } = o, f = l || "var(--viz-1)";
	if (!c || !c.length) return /* @__PURE__ */ i(n, {
		icon: "bar_chart",
		title: s("common.empty", "Sin datos"),
		description: s("common.emptyDescription", "No hay datos para este periodo."),
		style: d
	});
	let p = Math.max(...c.map((e) => e.max || Math.max(e.value, e.target) * 1.2), 1);
	return /* @__PURE__ */ a("div", {
		className: r.root,
		style: d,
		children: [c.map((e, t) => {
			let n = e.value > e.target, o = Math.min(100, e.value / p * 100), s = Math.min(100, e.target / p * 100), c = e.prev == null ? null : Math.min(100, e.prev / p * 100), l = e.color || f;
			return /* @__PURE__ */ a("div", {
				className: r.row,
				children: [
					/* @__PURE__ */ a("span", {
						"data-truncate": "",
						className: r.label,
						children: [e.icon && /* @__PURE__ */ i("span", {
							className: "flow-symbol flow-symbol--sm",
							"aria-hidden": "true",
							style: { color: l },
							children: e.icon
						}), e.label]
					}),
					/* @__PURE__ */ a("div", {
						className: r.track,
						children: [
							c != null && /* @__PURE__ */ i("span", {
								className: r.prev,
								"aria-hidden": "true",
								style: { width: `${c}%` }
							}),
							/* @__PURE__ */ i("span", {
								className: r.bar,
								"aria-hidden": "true",
								"data-over": n || void 0,
								style: {
									width: `${o}%`,
									background: n ? void 0 : l
								}
							}),
							/* @__PURE__ */ i("span", {
								className: r.target,
								"aria-hidden": "true",
								style: { left: `${s}%` }
							})
						]
					}),
					/* @__PURE__ */ i("span", {
						className: r.value,
						"data-over": n || void 0,
						children: u ? u(e.value) : e.value
					})
				]
			}, t);
		}), /* @__PURE__ */ i(t, { items: [
			{
				label: s("chart.actual", "Real"),
				color: f,
				shape: "square"
			},
			{
				label: s("chart.target", "Meta"),
				color: "var(--text-primary)",
				shape: "line"
			},
			{
				label: s("chart.previousPeriod", "Periodo anterior"),
				color: "var(--border-strong)"
			}
		] })]
	});
}
//#endregion
export { o as BulletChart };

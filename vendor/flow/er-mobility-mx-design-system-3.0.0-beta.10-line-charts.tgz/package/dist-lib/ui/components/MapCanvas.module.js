//#region src/ui/components/MapCanvas.module.css
var e = "AfLFwa_canvas", t = "AfLFwa_controls", n = "AfLFwa_pinLayer", r = "AfLFwa_pinTarget", i = "AfLFwa_root", a = "AfLFwa_tooltip", o = "AfLFwa_tooltipAnchor", s = "AfLFwa_tooltipDetail", c = "AfLFwa_tooltipLabel", l = {
	canvas: e,
	controls: t,
	pinLayer: n,
	pinTarget: r,
	root: i,
	tooltip: a,
	tooltipAnchor: o,
	tooltipDetail: s,
	tooltipLabel: c
};
//#endregion
export { e as canvas, t as controls, l as default, n as pinLayer, r as pinTarget, i as root, a as tooltip, o as tooltipAnchor, s as tooltipDetail, c as tooltipLabel };

//#region src/ui/components/Table.module.css
var e = "bWHy7a_root", t = "bWHy7a_td", n = "bWHy7a_th", r = "bWHy7a_wrap", i = {
	root: e,
	td: t,
	th: n,
	wrap: r
};
//#endregion
export { i as default, e as root, t as td, n as th, r as wrap };

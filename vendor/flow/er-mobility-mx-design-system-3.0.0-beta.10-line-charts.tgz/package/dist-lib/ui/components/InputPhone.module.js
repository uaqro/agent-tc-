//#region src/ui/components/InputPhone.module.css
var e = "Cv3yhq_input", t = "Cv3yhq_prefix", n = {
	input: e,
	prefix: t
};
//#endregion
export { n as default, e as input, t as prefix };

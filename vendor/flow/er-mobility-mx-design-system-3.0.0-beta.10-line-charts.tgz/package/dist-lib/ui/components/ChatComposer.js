"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { ControlShell as t } from "../primitives/ControlShell.js";
import { IconButton as n } from "../primitives/IconButton.js";
import r from "./ChatComposer.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import { useEffect as o, useRef as s } from "react";
//#region src/ui/components/ChatComposer.tsx
function c({ value: c = "", onChange: l, onSend: u, placeholder: d, suggestions: f = [], disabled: p = !1, style: m }) {
	let h = e(), g = d ?? h("chat.placeholder", "Pregunta sobre tu flota…"), _ = s(null);
	o(() => {
		_.current && (_.current.style.height = "auto", _.current.style.height = Math.min(120, _.current.scrollHeight) + "px");
	}, [c]);
	let v = () => {
		c.trim() && !p && u?.(c.trim());
	}, y = (e) => {
		e.key === "Enter" && !e.shiftKey && (e.preventDefault(), v());
	}, b = !!c.trim() && !p;
	return /* @__PURE__ */ a("div", {
		className: r.root,
		style: m,
		children: [f.length > 0 && !c && /* @__PURE__ */ i("div", {
			className: r.suggestions,
			children: f.map((e, t) => /* @__PURE__ */ i("button", {
				type: "button",
				"data-bare": "",
				className: r.suggestion,
				onClick: () => u?.(e),
				disabled: p,
				children: e
			}, t))
		}), /* @__PURE__ */ i(t, {
			disabled: p,
			trailing: /* @__PURE__ */ i(n, {
				icon: "arrow_upward",
				ariaLabel: h("chat.send", "Enviar"),
				variant: b ? "primary" : "tonal",
				disabled: !b,
				onClick: v
			}),
			children: /* @__PURE__ */ i("textarea", {
				ref: _,
				"data-field": "",
				className: r.textarea,
				value: c,
				disabled: p,
				rows: 1,
				placeholder: g,
				"aria-label": g,
				"aria-disabled": p,
				onChange: (e) => l?.(e.target.value),
				onKeyDown: y
			})
		})]
	});
}
//#endregion
export { c as ChatComposer };

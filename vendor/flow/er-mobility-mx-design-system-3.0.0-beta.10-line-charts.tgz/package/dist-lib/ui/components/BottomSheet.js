import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import { OverlayShell as n } from "../primitives/OverlayShell.js";
import r from "./BottomSheet.module.js";
import { Fragment as i, jsx as a, jsxs as o } from "react/jsx-runtime";
import { useId as s } from "react";
//#region src/ui/components/BottomSheet.tsx
function c({ open: c, onClose: l, onOpenChange: u, title: d, children: f, height: p, fixed: m = !0, fullscreen: h, onBack: g, headerActions: _, style: v }) {
	let y = () => {
		u?.(!1), l?.();
	}, b = e(), x = s();
	return /* @__PURE__ */ a(n, {
		open: c,
		onClose: y,
		alignment: "bottom",
		labelledBy: x,
		children: /* @__PURE__ */ o("div", {
			className: r.root,
			"data-fixed": m || void 0,
			"data-fullscreen": h || void 0,
			style: {
				...p != null && !h ? { height: p } : {},
				...v
			},
			children: [h ? /* @__PURE__ */ o("div", {
				className: r.header,
				children: [
					(g || !_) && /* @__PURE__ */ a(t, {
						icon: "arrow_back",
						ariaLabel: b("common.back", "Volver"),
						onClick: g ?? y
					}),
					d ? /* @__PURE__ */ a("div", {
						className: r.headerTitle,
						id: x,
						children: d
					}) : /* @__PURE__ */ a("span", {
						"data-sr-only": "",
						id: x,
						children: b("bottomsheet.label", "Hoja de opciones")
					}),
					_ && /* @__PURE__ */ a("div", {
						className: r.headerActions,
						children: _
					})
				]
			}) : /* @__PURE__ */ o(i, { children: [/* @__PURE__ */ a("button", {
				"data-bare": "",
				className: r.handle,
				onClick: y,
				"aria-label": b("common.close", "Cerrar"),
				type: "button",
				children: /* @__PURE__ */ a("span", { className: r.bar })
			}), d ? /* @__PURE__ */ o("div", {
				className: r.titleRow,
				children: [/* @__PURE__ */ a("div", {
					className: r.title,
					id: x,
					children: d
				}), _ && /* @__PURE__ */ a("div", {
					className: r.headerActions,
					children: _
				})]
			}) : /* @__PURE__ */ a("span", {
				"data-sr-only": "",
				id: x,
				children: b("bottomsheet.label", "Hoja de opciones")
			})] }), /* @__PURE__ */ a("div", {
				className: r.body,
				children: f
			})]
		})
	});
}
//#endregion
export { c as BottomSheet };

import { ControlShell as e } from "../primitives/ControlShell.js";
import { Flag as t } from "../primitives/Flag.js";
import n from "./InputPhone.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { forwardRef as a } from "react";
//#region src/ui/components/InputPhone.tsx
function o(e) {
	return e.length <= 2 ? e : e.length <= 5 ? `${e.slice(0, 2)} ${e.slice(2)}` : e.length <= 9 ? `${e.slice(0, 2)} ${e.slice(2, 6)} ${e.slice(6)}` : `${e.slice(0, 2)} ${e.slice(2, 6)} ${e.slice(6, 10)}`;
}
var s = a(function({ name: a, required: s, onBlur: c, id: l, value: u = "", onChange: d, placeholder: f = "55 1234 5678", prefix: p = "+52", country: m, size: h = "md", disabled: g, invalid: _, style: v, "aria-labelledby": y, "aria-describedby": b, "aria-invalid": x, "aria-required": S }, C) {
	let w = o(u.replace(/\D/g, "").slice(0, 10)), T = (e) => {
		let t = e.replace(/\D/g, "").slice(0, 10);
		d?.(t);
	};
	return /* @__PURE__ */ r(e, {
		size: h,
		disabled: g,
		invalid: _,
		leading: /* @__PURE__ */ i("span", {
			className: n.prefix,
			children: [m ? /* @__PURE__ */ r(t, {
				country: m,
				size: 18
			}) : null, p]
		}),
		style: v,
		children: /* @__PURE__ */ r("input", {
			ref: C,
			name: a,
			required: s,
			onBlur: c,
			"aria-labelledby": y,
			"aria-describedby": b,
			"aria-required": S,
			id: l,
			"data-field": "",
			className: n.input,
			type: "tel",
			inputMode: "tel",
			autoComplete: "tel-national",
			value: w,
			onChange: (e) => T(e.target.value),
			placeholder: f,
			disabled: g,
			"aria-invalid": _ || x || void 0
		})
	});
});
//#endregion
export { s as InputPhone };

//#region src/ui/components/BalanceDisplay.module.css
var e = "JmdIfG_root", t = "JmdIfG_row", n = "JmdIfG_value", r = {
	root: e,
	row: t,
	value: n
};
//#endregion
export { r as default, e as root, t as row, n as value };

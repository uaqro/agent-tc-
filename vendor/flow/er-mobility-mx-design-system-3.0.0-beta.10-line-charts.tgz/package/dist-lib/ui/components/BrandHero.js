import { BrandCanvas as e } from "../primitives/BrandCanvas.js";
import { FlowLogo as t } from "../primitives/FlowLogo.js";
import n from "./BrandHero.module.js";
import { Fragment as r, jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/components/BrandHero.tsx
function o({ eyebrow: o, title: s, accent: c, description: l, footer: u, signals: d, scene: f = !0, paused: p = !1, style: m }) {
	return /* @__PURE__ */ a("section", {
		className: n.root,
		"aria-hidden": "true",
		style: m,
		children: [
			f && /* @__PURE__ */ i("div", {
				className: n.arte,
				children: /* @__PURE__ */ i(e, {
					signals: d,
					paused: p
				})
			}),
			/* @__PURE__ */ i("div", {
				className: n.marca,
				children: /* @__PURE__ */ i(t, { height: 36 })
			}),
			/* @__PURE__ */ a("div", {
				className: n.claim,
				children: [
					o && /* @__PURE__ */ i("p", {
						className: n.overline,
						"data-overline": !0,
						children: o
					}),
					/* @__PURE__ */ a("h2", {
						className: n.titular,
						children: [s, c && /* @__PURE__ */ a(r, { children: [/* @__PURE__ */ i("br", {}), /* @__PURE__ */ i("span", {
							className: n.acento,
							children: c
						})] })]
					}),
					l && /* @__PURE__ */ i("p", {
						className: n.bajada,
						children: l
					})
				]
			}),
			u && /* @__PURE__ */ i("div", {
				className: n.pie,
				children: u
			})
		]
	});
}
//#endregion
export { o as BrandHero };

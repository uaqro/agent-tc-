import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { IconButton as n } from "../primitives/IconButton.js";
import r from "./BulkBar.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/components/BulkBar.tsx
function o({ rest: o, count: s, actions: c = [], onAction: l, onClear: u, extendLabel: d, onExtend: f, style: p }) {
	let m = e(), h = s > 0;
	return /* @__PURE__ */ a("div", {
		className: r.root,
		"data-estado": h ? "seleccion" : "reposo",
		style: p,
		children: [/* @__PURE__ */ i("div", {
			className: r.herramientas,
			children: o
		}), h && /* @__PURE__ */ a("div", {
			className: r.lote,
			role: "toolbar",
			"aria-label": m("bulk.actions", "Acciones sobre la selección"),
			children: [
				/* @__PURE__ */ i("span", {
					"aria-live": "polite",
					className: r.recuento,
					children: s === 1 ? m("bulk.selectedOne", "1 seleccionado") : m("bulk.selectedMany", "{n} seleccionados", { n: s })
				}),
				d && f && /* @__PURE__ */ i(t, {
					variant: "ghost",
					size: "sm",
					onClick: f,
					children: d
				}),
				c.map((e) => /* @__PURE__ */ i(t, {
					variant: e.danger ? "danger" : "secondary",
					size: "sm",
					icon: e.icon,
					onClick: () => l?.(e.id),
					children: e.label
				}, e.id)),
				u && /* @__PURE__ */ i(n, {
					icon: "close",
					ariaLabel: m("bulk.clear", "Limpiar selección"),
					variant: "ghost",
					onClick: u
				})
			]
		})]
	});
}
//#endregion
export { o as BulkBar };

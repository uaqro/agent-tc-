"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import { OverlayShell as n } from "../primitives/OverlayShell.js";
import { useBreakpoint as r } from "../../hooks/useBreakpoint.js";
import i from "./Sidebar.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
import { useId as s, useState as c } from "react";
import { createPortal as l } from "react-dom";
//#region src/ui/components/Sidebar.tsx
function u({ items: u, activeId: d = "", collapsed: f = !1, responsive: p = !1, open: m = !1, onOpenChange: h, expandedKeys: g, onExpandedChange: _, expandedSections: v, onNavigate: y, onToggleSection: b, headerContent: x, footerActions: S, width: C, style: w }) {
	let T = e(), E = r(), D = s(), O = p && E === "compact", k = p ? E === "medium" : f, A = () => h?.(!1), [j, M] = c({
		left: 0,
		top: 0
	}), [N, P] = c(null), [F, I] = c(() => new Set(g ?? (v ? [...v] : []))), L = g ? new Set(g) : v ?? F, R = (e) => {
		let t = new Set(L);
		t.has(e) ? t.delete(e) : t.add(e), g === void 0 && v === void 0 && I(t), _?.([...t]), b?.(e);
	}, z = (e, t) => {
		if (e.caption) return /* @__PURE__ */ o("div", {
			className: i.captionGroup,
			children: [k ? /* @__PURE__ */ a("hr", {
				className: i.captionRule,
				"aria-hidden": "true"
			}) : /* @__PURE__ */ a("div", {
				"data-overline": "",
				className: i.caption,
				children: e.label
			}), e.children?.map((e) => z(e, t))]
		}, e.id);
		let n = !!(e.children && e.children.length), r = L.has(e.id), s = e.id === d, c = N === e.id, u = `calc(var(--pad-control-x) + ${t} * var(--gap-inline))`;
		return /* @__PURE__ */ o("div", { children: [/* @__PURE__ */ o("button", {
			type: "button",
			"data-bare": "",
			className: i.item,
			"aria-label": k ? typeof e.badge == "number" ? `${e.label} (${e.badge})` : e.label : void 0,
			"aria-current": s && !n ? "page" : void 0,
			"aria-expanded": n ? r : void 0,
			"data-active": s || void 0,
			onClick: () => {
				n ? R(e.id) : (y?.(e.id, e.href), O && A());
			},
			onMouseEnter: (t) => {
				let n = t.currentTarget.getBoundingClientRect();
				M({
					left: n.right,
					top: n.top + n.height / 2
				}), P(e.id);
			},
			onFocus: (t) => {
				let n = t.currentTarget.getBoundingClientRect();
				M({
					left: n.right,
					top: n.top + n.height / 2
				}), P(e.id);
			},
			onBlur: () => P(null),
			onMouseLeave: () => P(null),
			style: { "--sangria": u },
			children: [
				e.icon && /* @__PURE__ */ a("span", {
					className: `flow-symbol${s ? " flow-symbol--fill" : ""} ${i.itemIcon}`,
					"aria-hidden": "true",
					children: e.icon
				}),
				!k && /* @__PURE__ */ a("span", {
					className: i.itemLabel,
					children: e.label
				}),
				!k && e.badge != null && e.badge !== !1 && /* @__PURE__ */ a("span", {
					"data-count": "",
					className: i.badge,
					"aria-hidden": e.badge === !0 || void 0,
					children: typeof e.badge == "number" ? e.badge > 99 ? "99+" : e.badge : ""
				}),
				k && e.badge ? /* @__PURE__ */ a("span", {
					"data-count": "",
					className: i.badgeCollapsed,
					"aria-hidden": "true"
				}) : null,
				!k && n && /* @__PURE__ */ a("span", {
					className: `flow-symbol ${i.chevron}`,
					"aria-hidden": "true",
					"data-open": r || void 0,
					children: "expand_more"
				}),
				k && c && typeof document < "u" && l(/* @__PURE__ */ a("span", {
					className: i.tooltip,
					style: j,
					"aria-hidden": "true",
					children: e.label
				}), document.body)
			]
		}), n && r && !k && /* @__PURE__ */ a("div", {
			className: i.sectionChildren,
			children: e.children.map((e) => z(e, t + 1))
		})] }, e.id);
	}, B = /* @__PURE__ */ o("aside", {
		className: i.root,
		"data-collapsed": k || void 0,
		"data-drawer": O || void 0,
		style: k ? w : {
			width: C,
			...w
		},
		children: [
			O && /* @__PURE__ */ o("div", {
				className: i.drawerHeading,
				children: [/* @__PURE__ */ a("span", {
					"data-sr-only": "",
					id: D,
					children: T("nav.main", "Navegación principal")
				}), /* @__PURE__ */ a(t, {
					icon: "close",
					ariaLabel: T("common.close", "Cerrar"),
					onClick: A
				})]
			}),
			x && /* @__PURE__ */ a("div", {
				className: i.header,
				children: x
			}),
			/* @__PURE__ */ a("nav", {
				className: i.nav,
				"aria-label": T("nav.main", "Navegación principal"),
				children: u.map((e) => z(e, 0))
			}),
			S && /* @__PURE__ */ a("div", {
				className: i.footer,
				children: S
			})
		]
	});
	return O ? /* @__PURE__ */ a(n, {
		open: m,
		onClose: A,
		alignment: "start",
		labelledBy: D,
		children: B
	}) : B;
}
//#endregion
export { u as Sidebar };

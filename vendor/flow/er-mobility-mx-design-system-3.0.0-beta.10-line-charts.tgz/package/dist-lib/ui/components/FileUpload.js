"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import n from "./FileUpload.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useRef as a, useState as o } from "react";
//#region src/ui/components/FileUpload.tsx
function s(e) {
	return e < 1024 ? e + " B" : e < 1048576 ? (e / 1024).toFixed(0) + " KB" : (e / 1048576).toFixed(1) + " MB";
}
function c({ files: c = [], onChange: l, accept: u, label: d, hint: f, maxSize: p, maxFiles: m, onReject: h, multiple: g = !0, disabled: _ = !1, style: v }) {
	let y = e(), b = a(null), [x, S] = o(!1), C = (e) => {
		if (!u) return !0;
		let t = e.name.toLowerCase(), n = (e.type || "").toLowerCase();
		return u.split(",").map((e) => e.trim().toLowerCase()).filter(Boolean).some((e) => e.startsWith(".") ? t.endsWith(e) : e.endsWith("/*") ? n.startsWith(e.slice(0, -1)) : n === e);
	}, w = (e) => {
		if (!e || _) return;
		let t = Array.from(e), n = [], r = [], i = g ? m ?? Infinity : 1, a = g ? c.length : 0;
		for (let e of t) C(e) ? p != null && e.size > p ? r.push({
			file: e,
			reason: "maxSize"
		}) : a + n.length >= i ? r.push({
			file: e,
			reason: "maxFiles"
		}) : n.push(e) : r.push({
			file: e,
			reason: "accept"
		});
		if (r.length && h?.(r), !n.length) return;
		let o = n.map((e) => ({
			name: e.name,
			size: e.size,
			file: e
		}));
		l?.(g ? [...c, ...o] : o.slice(0, 1));
	};
	return /* @__PURE__ */ i("div", {
		className: n.root,
		"data-disabled": _ || void 0,
		style: v,
		children: [
			/* @__PURE__ */ i("button", {
				type: "button",
				"data-bare": "",
				className: n.dropzone,
				"data-drag-over": x || void 0,
				disabled: _,
				onClick: () => b.current?.click(),
				onDragOver: (e) => {
					e.preventDefault(), _ || S(!0);
				},
				onDragLeave: () => S(!1),
				onDrop: (e) => {
					e.preventDefault(), S(!1), w(e.dataTransfer.files);
				},
				children: [
					/* @__PURE__ */ r("span", {
						className: `flow-symbol ${n.dropzoneIcon}`,
						"aria-hidden": "true",
						children: "cloud_upload"
					}),
					d && /* @__PURE__ */ r("div", {
						className: n.dropzoneLabel,
						children: d
					}),
					f && /* @__PURE__ */ r("div", {
						className: n.dropzoneHint,
						children: f
					})
				]
			}),
			/* @__PURE__ */ r("input", {
				ref: b,
				type: "file",
				accept: u,
				multiple: g,
				disabled: _,
				onChange: (e) => {
					w(e.target.files), e.target.value = "";
				},
				style: { display: "none" }
			}),
			c.length > 0 && /* @__PURE__ */ r("div", {
				className: n.fileList,
				children: c.map((e, a) => /* @__PURE__ */ i("div", {
					className: n.fileItem,
					children: [
						/* @__PURE__ */ r("span", {
							className: `flow-symbol ${n.fileIcon}`,
							"aria-hidden": "true",
							children: "description"
						}),
						/* @__PURE__ */ r("span", {
							"data-truncate": "",
							className: n.fileName,
							children: e.name
						}),
						/* @__PURE__ */ r("span", {
							className: n.fileSize,
							children: s(e.size)
						}),
						/* @__PURE__ */ r(t, {
							icon: "close",
							ariaLabel: y("common.remove", "Quitar {name}", { name: e.name }),
							onClick: (e) => {
								e.stopPropagation(), l?.(c.filter((e, t) => t !== a));
							}
						})
					]
				}, a))
			})
		]
	});
}
//#endregion
export { c as FileUpload };

"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { EmptyState as t } from "../primitives/EmptyState.js";
import n from "./Bars.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useState as a } from "react";
//#region src/ui/components/Bars.tsx
function o({ data: o = [], height: s = 200, color: c, highlightMax: l = !1, format: u, style: d }) {
	let f = e(), p = Math.max(...o.map((e) => e.value), 1), [m, h] = a(-1), [g, _] = a(-1), v = c || "var(--viz-1)", y = u || ((e) => e);
	if (!o.length) return /* @__PURE__ */ r(t, {
		icon: "bar_chart",
		title: f("common.empty", "Sin datos"),
		description: f("common.emptyDescription", "No hay datos para este periodo.")
	});
	let b = o.filter((e) => e.value === p).length;
	return /* @__PURE__ */ r("div", {
		className: n.root,
		"data-fill": s === "fill" || void 0,
		style: {
			height: s === "fill" ? void 0 : s,
			...d
		},
		children: o.map((e, t) => {
			let a = e.value / p * 100, o = e.value === p, s = l && o && b === 1;
			return /* @__PURE__ */ i("div", {
				className: n.column,
				onMouseEnter: (e) => {
					let n = e.currentTarget.querySelector("[data-bar]"), r = e.currentTarget.querySelector("[data-bar-value]");
					_(r.offsetHeight > n.clientHeight ? t : -1), h(t);
				},
				onMouseLeave: () => h(-1),
				children: [/* @__PURE__ */ r("div", {
					className: n.plot,
					children: /* @__PURE__ */ r("div", {
						className: n.bar,
						"data-bar": "",
						"data-max": s || void 0,
						style: {
							height: `${a}%`,
							background: s ? "var(--viz-accent)" : e.color || v,
							opacity: m === t || o ? 1 : .65
						},
						children: /* @__PURE__ */ r("span", {
							"data-bar-value": "",
							className: n.tooltip,
							"data-visible": m === t || void 0,
							"data-outside": g === t || void 0,
							children: y(e.value)
						})
					})
				}), /* @__PURE__ */ r("div", {
					className: n.label,
					children: e.label
				})]
			}, e.label);
		})
	});
}
//#endregion
export { o as Bars };

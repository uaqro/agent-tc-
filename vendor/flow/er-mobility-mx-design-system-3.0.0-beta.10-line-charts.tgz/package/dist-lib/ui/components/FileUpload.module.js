//#region src/ui/components/FileUpload.module.css
var e = "_1AXa2G_dropzone", t = "_1AXa2G_dropzoneHint", n = "_1AXa2G_dropzoneIcon", r = "_1AXa2G_dropzoneLabel", i = "_1AXa2G_fileIcon", a = "_1AXa2G_fileItem", o = "_1AXa2G_fileList", s = "_1AXa2G_fileName", c = "_1AXa2G_fileSize", l = "_1AXa2G_root", u = {
	dropzone: e,
	dropzoneHint: t,
	dropzoneIcon: n,
	dropzoneLabel: r,
	fileIcon: i,
	fileItem: a,
	fileList: o,
	fileName: s,
	fileSize: c,
	root: l
};
//#endregion
export { u as default, e as dropzone, t as dropzoneHint, n as dropzoneIcon, r as dropzoneLabel, i as fileIcon, a as fileItem, o as fileList, s as fileName, c as fileSize, l as root };

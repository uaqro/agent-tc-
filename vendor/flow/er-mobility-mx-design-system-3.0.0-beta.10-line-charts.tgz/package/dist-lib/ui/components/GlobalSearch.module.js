//#region src/ui/components/GlobalSearch.module.css
var e = "kCYVQG_clearRecentsBtn", t = "kCYVQG_footer", n = "kCYVQG_groupLabel", r = "kCYVQG_highlight", i = "kCYVQG_inlineDrop", a = "kCYVQG_inlineField", o = "kCYVQG_inlineRoot", s = "kCYVQG_input", c = "kCYVQG_list", l = "kCYVQG_loadingState", u = "kCYVQG_option", d = "kCYVQG_optionBody", f = "kCYVQG_optionIcon", p = "kCYVQG_optionLabel", m = "kCYVQG_optionMeta", h = "kCYVQG_optionReturn", g = "kCYVQG_optionTrailing", _ = "kCYVQG_paletteCard", v = "kCYVQG_searchBar", y = "kCYVQG_searchIcon", b = "kCYVQG_suggestions", x = {
	clearRecentsBtn: e,
	footer: t,
	groupLabel: n,
	highlight: r,
	inlineDrop: i,
	inlineField: a,
	inlineRoot: o,
	input: s,
	list: c,
	loadingState: l,
	option: u,
	optionBody: d,
	optionIcon: f,
	optionLabel: p,
	optionMeta: m,
	optionReturn: h,
	optionTrailing: g,
	paletteCard: _,
	searchBar: v,
	searchIcon: y,
	suggestions: b
};
//#endregion
export { e as clearRecentsBtn, x as default, t as footer, n as groupLabel, r as highlight, i as inlineDrop, a as inlineField, o as inlineRoot, s as input, c as list, l as loadingState, u as option, d as optionBody, f as optionIcon, p as optionLabel, m as optionMeta, h as optionReturn, g as optionTrailing, _ as paletteCard, v as searchBar, y as searchIcon, b as suggestions };

//#region src/ui/components/DataFreshness.module.css
var e = "ohTZkW_meta", t = "ohTZkW_root", n = {
	meta: e,
	root: t
};
//#endregion
export { n as default, e as meta, t as root };

import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import n from "./DataFreshness.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/components/DataFreshness.tsx
function a({ updatedLabel: a, cadence: o, nextRefresh: s, onRefresh: c, refreshing: l, refreshLabel: u, style: d }) {
	let f = e(), p = u ?? f("common.refresh", "Actualizar"), m = [
		a,
		o,
		s
	].filter(Boolean).join(" · ");
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: d,
		children: [/* @__PURE__ */ r("span", {
			"data-truncate": "",
			className: n.meta,
			"aria-live": "polite",
			children: m
		}), c && /* @__PURE__ */ r(t, {
			variant: "ghost",
			size: "sm",
			icon: "refresh",
			loading: l,
			onClick: c,
			children: p
		})]
	});
}
//#endregion
export { a as DataFreshness };

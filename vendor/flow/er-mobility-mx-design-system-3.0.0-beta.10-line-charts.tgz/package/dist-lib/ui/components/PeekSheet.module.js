//#region src/ui/components/PeekSheet.module.css
var e = "fxWFMq_handle", t = "fxWFMq_list", n = "fxWFMq_root", r = "fxWFMq_title", i = {
	handle: e,
	list: t,
	root: n,
	title: r
};
//#endregion
export { i as default, e as handle, t as list, n as root, r as title };

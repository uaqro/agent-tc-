//#region src/ui/components/QuickActionBar.module.css
var e = "dYIVFq_root", t = { root: e };
//#endregion
export { t as default, e as root };

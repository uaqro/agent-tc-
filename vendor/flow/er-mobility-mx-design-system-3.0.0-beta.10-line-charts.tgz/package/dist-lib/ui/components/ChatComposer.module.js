//#region src/ui/components/ChatComposer.module.css
var e = "bYpXLG_root", t = "bYpXLG_suggestion", n = "bYpXLG_suggestions", r = "bYpXLG_textarea", i = {
	root: e,
	suggestion: t,
	suggestions: n,
	textarea: r
};
//#endregion
export { i as default, e as root, t as suggestion, n as suggestions, r as textarea };

import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import n from "./NavBar.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/components/NavBar.tsx
function a({ title: a, onBack: o, trailing: s, style: c }) {
	let l = e();
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: c,
		children: [
			/* @__PURE__ */ r(t, {
				icon: "arrow_back",
				ariaLabel: l("nav.back", "Volver"),
				variant: "tonal",
				size: "sm",
				onClick: o
			}),
			/* @__PURE__ */ r("span", {
				className: n.title,
				children: a
			}),
			s
		]
	});
}
//#endregion
export { a as NavBar };

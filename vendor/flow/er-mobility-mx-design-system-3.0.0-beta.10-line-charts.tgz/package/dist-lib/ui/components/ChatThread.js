"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { ChatMessage as t } from "../primitives/ChatMessage.js";
import { EmptyState as n } from "../primitives/EmptyState.js";
import r from "./ChatThread.module.js";
import { Fragment as i, jsx as a } from "react/jsx-runtime";
import { useEffect as o, useRef as s } from "react";
//#region src/ui/components/ChatThread.tsx
function c({ messages: c = [], emptyState: l, style: u }) {
	let d = e(), f = s(null), p = s(!1);
	return o(() => {
		let e = f.current;
		if (!e) return;
		let t = () => {
			let t = e.scrollHeight - e.scrollTop - e.clientHeight < 40;
			p.current = !t;
		};
		return e.addEventListener("scroll", t, { passive: !0 }), () => e.removeEventListener("scroll", t);
	}, []), o(() => {
		f.current && !p.current && (f.current.scrollTop = f.current.scrollHeight);
	}, [c.length, c[c.length - 1]?.text]), c.length === 0 ? /* @__PURE__ */ a(i, { children: l ?? /* @__PURE__ */ a(n, {
		icon: "forum",
		title: d("chat.empty", "Sin mensajes"),
		description: d("chat.emptyDescription", "Escribe abajo para empezar.")
	}) }) : /* @__PURE__ */ a("div", {
		ref: f,
		className: r.root,
		style: u,
		"aria-live": "polite",
		"aria-relevant": "additions",
		children: c.map((e) => /* @__PURE__ */ a(t, {
			role: e.role,
			text: e.text,
			tool: e.tool,
			streaming: e.streaming,
			timestamp: e.timestamp,
			children: e.content
		}, e.id))
	});
}
//#endregion
export { c as ChatThread };

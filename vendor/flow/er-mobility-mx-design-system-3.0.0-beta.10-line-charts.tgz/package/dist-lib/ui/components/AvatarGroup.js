import { Avatar as e } from "../primitives/Avatar.js";
import { useT as t } from "../../i18n/useSafeIntl.js";
import n from "./AvatarGroup.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/components/AvatarGroup.tsx
function a({ people: a, max: o = 4, size: s = "md", style: c }) {
	let l = t();
	if (a.length === 0) return null;
	let u = a.slice(0, o), d = a.length - u.length, f = a.map((e) => e.name).filter(Boolean).join(", ");
	return /* @__PURE__ */ i("div", {
		className: n.root,
		"data-size": s,
		role: "img",
		"aria-label": l("avatarGroup.label", "{total} personas: {nombres}", {
			total: a.length,
			nombres: f
		}),
		style: c,
		children: [u.map((t, i) => /* @__PURE__ */ r("span", {
			className: n.item,
			"aria-hidden": "true",
			children: /* @__PURE__ */ r(e, {
				...t,
				size: s
			})
		}, `${t.name ?? ""}-${i}`)), d > 0 && /* @__PURE__ */ r("span", {
			className: n.resto,
			"aria-hidden": "true",
			children: l("avatarGroup.overflow", "+{n}", { n: d })
		})]
	});
}
//#endregion
export { a as AvatarGroup };

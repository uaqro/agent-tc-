import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./BiometricPrompt.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/components/BiometricPrompt.tsx
var i = {
	face: "face",
	fingerprint: "fingerprint"
};
function a(e, t) {
	switch (t) {
		case "scanning": return e("biometric.scanning", "Verificando...");
		case "success": return e("biometric.success", "Verificado");
		case "error": return e("biometric.error", "No reconocido");
		default: return "";
	}
}
function o({ method: o = "face", state: s = "idle", title: c, description: l, onUse: u, onFallback: d, fallbackLabel: f, style: p }) {
	let m = e(), h = f ?? m("biometric.fallback", "Usar passcode"), g = o === "face" ? m("biometric.faceId", "Reconocimiento facial") : m("biometric.fingerprint", "Huella digital"), _ = a(m, s);
	return /* @__PURE__ */ r("div", {
		className: t.root,
		style: p,
		children: [
			c && /* @__PURE__ */ n("div", {
				className: t.title,
				children: c
			}),
			l && /* @__PURE__ */ n("div", {
				className: t.description,
				children: l
			}),
			/* @__PURE__ */ n("button", {
				"data-bare": "",
				className: t.biometric,
				"data-state": s,
				onClick: u,
				type: "button",
				"aria-label": `${g}${_ ? ` — ${_}` : ""}`,
				disabled: s === "scanning" || s === "success",
				children: /* @__PURE__ */ n("span", {
					className: `flow-symbol ${t.icon}`,
					"aria-hidden": "true",
					children: s === "success" ? "check_circle" : s === "error" ? "error" : i[o]
				})
			}),
			s !== "idle" && /* @__PURE__ */ n("div", {
				className: t.stateLabel,
				"data-state": s,
				role: s === "error" ? "alert" : "status",
				"aria-live": "polite",
				children: _
			}),
			/* @__PURE__ */ n("button", {
				"data-bare": "",
				className: t.fallback,
				onClick: d,
				type: "button",
				children: h
			})
		]
	});
}
//#endregion
export { o as BiometricPrompt };

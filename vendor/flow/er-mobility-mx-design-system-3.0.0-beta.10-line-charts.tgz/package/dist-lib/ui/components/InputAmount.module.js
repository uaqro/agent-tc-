//#region src/ui/components/InputAmount.module.css
var e = "I7WyHa_currency", t = "I7WyHa_input", n = {
	currency: e,
	input: t
};
//#endregion
export { e as currency, n as default, t as input };

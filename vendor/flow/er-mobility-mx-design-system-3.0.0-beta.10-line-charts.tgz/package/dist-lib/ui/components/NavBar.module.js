//#region src/ui/components/NavBar.module.css
var e = "CbYwTq_root", t = "CbYwTq_title", n = {
	root: e,
	title: t
};
//#endregion
export { n as default, e as root, t as title };

//#region src/ui/components/Donut.module.css
var e = "_2vLhFa_center", t = "_2vLhFa_centerLabel", n = "_2vLhFa_centerValue", r = "_2vLhFa_legend", i = "_2vLhFa_ring", a = "_2vLhFa_root", o = {
	center: e,
	centerLabel: t,
	centerValue: n,
	legend: r,
	ring: i,
	root: a
};
//#endregion
export { e as center, t as centerLabel, n as centerValue, o as default, r as legend, i as ring, a as root };

//#region src/ui/components/CardCarousel.module.css
var e = "LGN8pa_dot", t = "LGN8pa_dots", n = "LGN8pa_root", r = "LGN8pa_slide", i = "LGN8pa_track", a = {
	dot: e,
	dots: t,
	root: n,
	slide: r,
	track: i
};
//#endregion
export { a as default, e as dot, t as dots, n as root, r as slide, i as track };

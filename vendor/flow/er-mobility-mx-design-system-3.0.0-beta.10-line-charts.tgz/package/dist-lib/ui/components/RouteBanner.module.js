//#region src/ui/components/RouteBanner.module.css
var e = "_0ZrBiG_content", t = "_0ZrBiG_icon", n = "_0ZrBiG_info", r = "_0ZrBiG_root", i = "_0ZrBiG_subtitle", a = "_0ZrBiG_title", o = {
	content: e,
	icon: t,
	info: n,
	root: r,
	subtitle: i,
	title: a
};
//#endregion
export { e as content, o as default, t as icon, n as info, r as root, i as subtitle, a as title };

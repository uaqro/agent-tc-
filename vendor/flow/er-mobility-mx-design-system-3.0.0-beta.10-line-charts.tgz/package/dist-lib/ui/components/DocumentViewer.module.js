//#region src/ui/components/DocumentViewer.module.css
var e = "_6Pe-_W_actions", t = "_6Pe-_W_body", n = "_6Pe-_W_frame", r = "_6Pe-_W_fullscreen", i = "_6Pe-_W_header", a = "_6Pe-_W_title", o = {
	actions: e,
	body: t,
	frame: n,
	fullscreen: r,
	header: i,
	title: a
};
//#endregion
export { e as actions, t as body, o as default, n as frame, r as fullscreen, i as header, a as title };

"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { useRovingTabs as t } from "../../hooks/useRovingTabs.js";
import { useListaViva as n } from "../../hooks/useListaViva.js";
import { desgarra as r } from "../../hooks/useDesgarro.js";
import i from "./CardCarousel.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
import { Children as s, useCallback as c, useEffect as l, useRef as u, useState as d } from "react";
//#region src/ui/components/CardCarousel.tsx
function f({ children: f, activeIndex: p, onChange: m, style: h }) {
	let g = e(), _ = s.toArray(f), v = n(_, (e) => String(e.key ?? "")), y = u(/* @__PURE__ */ new Map()), b = u(/* @__PURE__ */ new Set()), [x, S] = d([]), C = v.filter((e) => e.saliendo).map((e) => e.clave).join("\0");
	l(() => {
		for (let e of v) {
			if (!e.saliendo || b.current.has(e.clave)) continue;
			b.current.add(e.clave);
			let t = y.current.get(e.clave);
			r(t?.firstElementChild ?? t) && S((t) => [...t, e.clave]);
		}
	}, [C]);
	let [w, T] = d(0), E = p ?? w, D = u(null), O = u(!1), k = c((e) => {
		T(e), m?.(e);
	}, [m]), { alTeclado: A, pestana: j } = t(_.map((e, t) => String(t)), String(E), (e) => k(Number(e)));
	l(() => {
		let e = D.current;
		if (!e) return;
		let t = e.children[E];
		if (!t) return;
		O.current = !0;
		let n = t.offsetLeft - (e.clientWidth - t.offsetWidth) / 2;
		e.scrollTo?.({
			left: n,
			behavior: "smooth"
		});
		let r = setTimeout(() => {
			O.current = !1;
		}, 350);
		return () => clearTimeout(r);
	}, [E]);
	let M = c(() => {
		if (O.current) return;
		let e = D.current;
		if (!e) return;
		let t = e.scrollLeft + e.clientWidth / 2, n = 0, r = Infinity;
		for (let i = 0; i < e.children.length; i++) {
			let a = e.children[i], o = a.offsetLeft + a.offsetWidth / 2, s = Math.abs(t - o);
			s < r && (r = s, n = i);
		}
		n !== E && k(n);
	}, [E, k]);
	return /* @__PURE__ */ o("div", {
		className: i.root,
		style: h,
		children: [/* @__PURE__ */ a("div", {
			ref: D,
			className: i.track,
			onScroll: M,
			children: v.map(({ clave: e, item: t, saliendo: n, entrando: r, ref: o }, s) => /* @__PURE__ */ a("div", {
				ref: (t) => {
					o(t), t ? y.current.set(e, t) : y.current.delete(e);
				},
				className: i.slide,
				"data-active": !n && s === E || void 0,
				"data-saliendo": n || void 0,
				"data-desgarrada": n && x.includes(e) || void 0,
				"data-entrando": r || void 0,
				"aria-hidden": n || void 0,
				children: t
			}, e))
		}), _.length > 1 && /* @__PURE__ */ a("div", {
			className: i.dots,
			role: "tablist",
			onKeyDown: A,
			children: _.map((e, t) => /* @__PURE__ */ a("button", {
				...j(String(t)),
				type: "button",
				"data-bare": "",
				className: i.dot,
				"data-active": t === E || void 0,
				role: "tab",
				"aria-selected": t === E,
				"aria-label": g("carousel.card", "Tarjeta {n}", { n: t + 1 }),
				onClick: () => k(t)
			}, t))
		})]
	});
}
//#endregion
export { f as CardCarousel };

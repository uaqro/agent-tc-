import { OverlayShell as e } from "../primitives/OverlayShell.js";
import t from "./Dialog.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { useId as i } from "react";
//#region src/ui/components/Dialog.tsx
function a({ open: a, onClose: o, onOpenChange: s, title: c, description: l, actions: u, tone: d, width: f, children: p }) {
	let m = () => {
		s?.(!1), o?.();
	}, h = i();
	return /* @__PURE__ */ n(e, {
		open: a,
		onClose: m,
		labelledBy: h,
		children: /* @__PURE__ */ r("div", {
			className: t.root,
			style: f === void 0 ? void 0 : {
				width: f,
				maxWidth: "90vw"
			},
			children: [
				/* @__PURE__ */ n("div", {
					id: h,
					className: t.title,
					"data-tone": d || void 0,
					children: c
				}),
				l && /* @__PURE__ */ n("div", {
					className: t.description,
					children: l
				}),
				p,
				u && /* @__PURE__ */ n("div", {
					className: t.actions,
					children: u
				})
			]
		})
	});
}
//#endregion
export { a as Dialog };

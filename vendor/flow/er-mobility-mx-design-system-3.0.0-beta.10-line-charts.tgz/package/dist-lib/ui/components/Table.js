import { DataGrid as e } from "./DataGrid.js";
import t from "./Table.module.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/ui/components/Table.tsx
function r(r) {
	return /* @__PURE__ */ n(e, {
		...r,
		skin: {
			root: t.wrap,
			table: t.root,
			th: t.th,
			td: t.td
		}
	});
}
//#endregion
export { r as Table };

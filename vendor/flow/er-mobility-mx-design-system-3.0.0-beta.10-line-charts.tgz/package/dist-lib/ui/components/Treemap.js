"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { EmptyState as t } from "../primitives/EmptyState.js";
import { FlowChart as n } from "../primitives/FlowChart.js";
import { Fragment as r, jsx as i, jsxs as a } from "react/jsx-runtime";
import { useId as o, useState as s } from "react";
//#region src/ui/components/Treemap.tsx
var c = {
	position: "absolute",
	width: 1,
	height: 1,
	margin: -1,
	padding: 0,
	overflow: "hidden",
	clip: "rect(0 0 0 0)",
	whiteSpace: "nowrap",
	border: 0
};
function l(e, t, n) {
	if (e != null) {
		if (e > .1) return "var(--viz-negative)";
		if (e < -.05) return "var(--viz-positive)";
	}
	return n[t % n.length];
}
var u = [
	"var(--viz-1)",
	"var(--viz-4)",
	"var(--viz-5)",
	"var(--viz-3)",
	"var(--viz-6)",
	"var(--viz-2)"
];
function d({ nodes: d = [], height: f = 280, format: p, onDrill: m, style: h }) {
	let g = e(), _ = o(), [v, y] = s(0);
	if (!d.length) return /* @__PURE__ */ i(t, {
		icon: "grid_view",
		title: g("common.empty", "Sin datos"),
		description: g("common.emptyDescription", "No hay datos para este periodo.")
	});
	let b = d.map((e, t) => ({
		label: e.label,
		value: e.value,
		color: e.color || l(e.deviation, t, u)
	}));
	return /* @__PURE__ */ a(r, { children: [/* @__PURE__ */ i(n, {
		type: "treemap",
		height: f,
		format: p,
		style: h,
		series: [{
			label: "Treemap",
			data: b
		}],
		onSelect: m ? (e) => {
			let t = e, n = d.find((e) => e.label === t.name);
			n && m(n);
		} : void 0,
		ariaLabel: g("treemap.chart", "Gasto por región, tamaño por valor y color por desvío vs presupuesto")
	}), m && /* @__PURE__ */ i("div", {
		role: "listbox",
		tabIndex: 0,
		"aria-label": g("treemap.regions", "Regiones del treemap"),
		"aria-activedescendant": `${_}-opt-${v}`,
		style: c,
		onKeyDown: (e) => {
			e.key === "ArrowDown" || e.key === "ArrowRight" ? (e.preventDefault(), y((e) => Math.min(d.length - 1, e + 1))) : e.key === "ArrowUp" || e.key === "ArrowLeft" ? (e.preventDefault(), y((e) => Math.max(0, e - 1))) : e.key === "Home" ? (e.preventDefault(), y(0)) : e.key === "End" ? (e.preventDefault(), y(d.length - 1)) : (e.key === "Enter" || e.key === " ") && (e.preventDefault(), d[v] && m?.(d[v]));
		},
		children: d.map((e, t) => /* @__PURE__ */ i("div", {
			id: `${_}-opt-${t}`,
			role: "option",
			"aria-selected": t === v,
			children: `${e.label}: ${p ? p(e.value) : e.value}`
		}, e.label))
	})] });
}
//#endregion
export { d as Treemap };

"use client";
import { Badge as e } from "../primitives/Badge.js";
import { useT as t } from "../../i18n/useSafeIntl.js";
import { IconButton as n } from "../primitives/IconButton.js";
import { Input as r } from "../primitives/Input.js";
import { Popover as i } from "../primitives/Popover.js";
import a from "./TopBar.module.js";
import { Fragment as o, jsx as s, jsxs as c } from "react/jsx-runtime";
import { useState as l } from "react";
//#region src/ui/components/TopBar.tsx
function u({ variant: u = "standard", logo: d, navItems: f = [], breadcrumb: p = [], searchValue: m = "", onSearchChange: h, avatar: g, notificationCount: _ = 0, onNotifications: v, entities: y = [], currentEntity: b = "", onEntityChange: x, onToggleSidebar: S, leading: C, trailing: w, surface: T = "card", navSize: E = "md", sticky: D, version: O, style: k }) {
	let A = t(), [j, M] = l(!1);
	if (u === "fullscreen") return null;
	let N = y.find((e) => e.id === b), P = w || g, F = () => /* @__PURE__ */ c(o, { children: [
		S && /* @__PURE__ */ s("div", {
			className: a.menuBtn,
			children: /* @__PURE__ */ s(n, {
				icon: "menu",
				ariaLabel: A("nav.open", "Abrir navegación"),
				onClick: S
			})
		}),
		C || d && /* @__PURE__ */ s("div", {
			className: a.logoWrap,
			children: d
		}),
		/* @__PURE__ */ s("nav", {
			"aria-label": A("topbar.sections", "Secciones"),
			className: a.navWrap,
			children: f.map((e) => /* @__PURE__ */ s("a", {
				"data-link": "",
				href: e.href || "#",
				className: a.navLink,
				"data-active": e.active || void 0,
				"data-size": E === "md" ? void 0 : E,
				"aria-current": e.active ? "page" : void 0,
				children: e.label
			}, e.id))
		}),
		/* @__PURE__ */ c("div", {
			className: a.trailingWrap,
			children: [P, O && /* @__PURE__ */ s("span", {
				className: a.versionBadge,
				children: O
			})]
		})
	] }), I = {
		standard: F,
		minimal: () => /* @__PURE__ */ c(o, { children: [
			C,
			p.length > 0 && /* @__PURE__ */ s("nav", {
				"aria-label": A("topbar.breadcrumb", "Ruta"),
				className: a.breadcrumbNav,
				children: p.map((e, t) => {
					let n = t === p.length - 1;
					return /* @__PURE__ */ c("span", { children: [t > 0 && /* @__PURE__ */ s("span", {
						className: a.breadcrumbSep,
						"aria-hidden": "true",
						children: "/"
					}), n ? /* @__PURE__ */ s("span", {
						className: a.breadcrumbCurrent,
						"aria-current": "page",
						children: e.label
					}) : /* @__PURE__ */ s("a", {
						"data-link": "",
						href: e.href || "#",
						className: a.breadcrumbLink,
						children: e.label
					})] }, t);
				})
			}),
			/* @__PURE__ */ s("div", { className: a.spacer }),
			P
		] }),
		admin: () => /* @__PURE__ */ c(o, { children: [
			C || /* @__PURE__ */ s(r, {
				filled: !0,
				value: m,
				onChange: h,
				placeholder: A("topbar.search", "Buscar unidades, conductores…"),
				ariaLabel: A("topbar.search", "Buscar unidades, conductores…"),
				icon: "search",
				style: { flex: 1 }
			}),
			_ > 0 && /* @__PURE__ */ c("div", {
				className: a.notifWrap,
				children: [/* @__PURE__ */ s(n, {
					icon: "notifications",
					ariaLabel: A("topbar.unread", "{n} notificaciones sin leer", { n: _ }),
					onClick: v
				}), /* @__PURE__ */ s("span", {
					className: a.notifCount,
					children: /* @__PURE__ */ s(e, {
						tone: "danger",
						children: _ > 9 ? "9+" : _
					})
				})]
			}),
			P
		] }),
		multientity: () => /* @__PURE__ */ c(o, { children: [
			C || /* @__PURE__ */ s(i, {
				open: j,
				onOpenChange: M,
				trigger: /* @__PURE__ */ c("button", {
					type: "button",
					"data-bare": "",
					className: a.entityBtn,
					"aria-haspopup": "menu",
					"aria-expanded": j,
					children: [N?.label || A("common.selectEntity", "Selecciona…"), /* @__PURE__ */ s("span", {
						className: "flow-symbol",
						"aria-hidden": "true",
						children: "expand_more"
					})]
				}),
				children: ({ close: e }) => /* @__PURE__ */ s("div", {
					role: "menu",
					children: y.map((t) => /* @__PURE__ */ s("button", {
						type: "button",
						role: "menuitem",
						"data-bare": "",
						className: a.entityOption,
						"data-active": t.id === b || void 0,
						"aria-current": t.id === b ? "true" : void 0,
						onClick: () => {
							x?.(t.id), e();
						},
						children: t.label
					}, t.id))
				})
			}),
			/* @__PURE__ */ s("div", { className: a.spacer }),
			P
		] }),
		mobile: () => /* @__PURE__ */ c(o, { children: [
			/* @__PURE__ */ s("div", {
				className: a.mobileLeading,
				children: C ?? (S ? /* @__PURE__ */ s(n, {
					icon: "menu",
					ariaLabel: A("nav.open", "Abrir navegación"),
					onClick: S
				}) : null)
			}),
			/* @__PURE__ */ s("div", {
				className: a.logoCenter,
				children: d
			}),
			/* @__PURE__ */ s("div", {
				className: a.mobileTrailing,
				children: P
			})
		] })
	};
	return /* @__PURE__ */ s("header", {
		className: a.root,
		"data-variant": u,
		"data-surface": T,
		"data-sticky": D || void 0,
		style: k,
		children: /* @__PURE__ */ s("div", {
			className: a.inner,
			children: (I[u] || F)()
		})
	});
}
//#endregion
export { u as TopBar };

import e from "./QuickAction.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/components/QuickAction.tsx
function r({ icon: r, label: i, active: a, disabled: o, onClick: s, style: c }) {
	return /* @__PURE__ */ n("button", {
		"data-bare": "",
		className: e.root,
		"data-active": a || void 0,
		disabled: o,
		onClick: s,
		style: c,
		children: [/* @__PURE__ */ t("span", {
			className: e.circle,
			children: /* @__PURE__ */ t("span", {
				className: `flow-symbol${a ? " flow-symbol--fill" : ""} ${e.icon}`,
				"aria-hidden": "true",
				children: r
			})
		}), /* @__PURE__ */ t("span", {
			className: e.label,
			children: i
		})]
	});
}
//#endregion
export { r as QuickAction };

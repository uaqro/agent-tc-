"use client";
import { useRovingTabs as e } from "../../hooks/useRovingTabs.js";
import t from "./Tabs.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { useEffect as i, useId as a, useRef as o, useState as s } from "react";
//#region src/ui/components/Tabs.tsx
function c(e, t) {
	return {
		tab: `${e}-tab-${t}`,
		panel: `${e}-panel-${t}`
	};
}
function l({ items: l = [], value: u, onChange: d, variant: f = "pill", ariaLabel: p, "aria-labelledby": m, id: h, style: g }) {
	let _ = a(), v = h ?? _, y = o(null), [b, x] = s({
		left: 0,
		width: 0
	});
	i(() => {
		if (!y.current) return;
		let e = y.current.querySelector("[data-active]");
		e && x({
			left: e.offsetLeft,
			width: e.offsetWidth
		});
	}, [u, l]);
	let { alTeclado: S, pestana: C } = e(l.map((e) => e.value), u, d);
	return /* @__PURE__ */ r("div", {
		ref: y,
		role: "tablist",
		"aria-label": p,
		"aria-labelledby": m,
		className: t.root,
		"data-variant": f,
		style: g,
		onKeyDown: S,
		children: [/* @__PURE__ */ n("div", {
			className: t.indicator,
			"aria-hidden": "true",
			"data-variant": f,
			style: {
				left: b.left,
				width: b.width
			}
		}), l.map((e) => {
			let i = e.value === u, a = c(v, e.value);
			return /* @__PURE__ */ r("button", {
				...C(e.value),
				role: "tab",
				type: "button",
				id: a.tab,
				"aria-controls": h && i ? a.panel : void 0,
				"aria-selected": i,
				"data-active": i || void 0,
				"data-bare": "",
				className: t.tab,
				onClick: () => d?.(e.value),
				children: [
					e.icon && /* @__PURE__ */ n("span", {
						className: `flow-symbol${i ? " flow-symbol--fill" : ""} ${t.tabIcon}`,
						"aria-hidden": "true",
						children: e.icon
					}),
					e.label,
					e.count != null && /* @__PURE__ */ n("span", {
						className: t.tabCount,
						children: e.count
					})
				]
			}, e.value);
		})]
	});
}
function u({ tabsId: e, value: t, active: r, children: i, style: a }) {
	let o = c(e, t);
	return r ? /* @__PURE__ */ n("div", {
		id: o.panel,
		role: "tabpanel",
		"aria-labelledby": o.tab,
		tabIndex: 0,
		style: a,
		children: i
	}) : null;
}
//#endregion
export { u as TabPanel, l as Tabs, c as tabIds };

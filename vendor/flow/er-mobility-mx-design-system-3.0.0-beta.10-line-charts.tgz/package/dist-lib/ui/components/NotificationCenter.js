import { useT as e } from "../../i18n/useSafeIntl.js";
import { EmptyState as t } from "../primitives/EmptyState.js";
import { IconButton as n } from "../primitives/IconButton.js";
import { Popover as r } from "../primitives/Popover.js";
import { SheetHeader as i } from "../primitives/SheetHeader.js";
import { TextAction as a } from "../primitives/TextAction.js";
import o from "./NotificationCenter.module.js";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/ui/components/NotificationCenter.tsx
var l = {
	warning: {
		icon: "warning",
		color: "var(--status-warning-text)"
	},
	danger: {
		icon: "error",
		color: "var(--status-danger-text)"
	},
	success: {
		icon: "check_circle",
		color: "var(--status-success-text)"
	},
	info: {
		icon: "info",
		color: "var(--status-info-text)"
	}
};
function u({ items: u = [], align: d = "right", onItemClick: f, onMarkAllRead: p, open: m, onOpenChange: h }) {
	let g = e(), _ = u.filter((e) => !e.read).length, v = g("notifications.label", "Notificaciones"), y = _ ? `, ${g("notifications.unread", "{count} sin leer", { count: _ })}` : "";
	return /* @__PURE__ */ s(r, {
		open: m,
		onOpenChange: h,
		trigger: /* @__PURE__ */ s(n, {
			icon: "notifications",
			ariaLabel: v + y,
			badge: _ > 0 || void 0
		}),
		placement: d === "right" ? "bottom-end" : "bottom-start",
		children: ({ close: e }) => /* @__PURE__ */ c("div", {
			className: o.root,
			children: [/* @__PURE__ */ s(i, {
				size: "sm",
				title: v,
				trailing: _ > 0 ? /* @__PURE__ */ s(a, {
					onClick: () => p?.(),
					children: g("notifications.markAll", "Marcar todo como leído")
				}) : void 0
			}), /* @__PURE__ */ c("div", {
				className: o.list,
				children: [u.length === 0 && /* @__PURE__ */ s(t, {
					icon: "notifications_off",
					title: g("notifications.empty", "Sin notificaciones"),
					description: g("notifications.emptyDescription", "Todo al día.")
				}), u.map((t) => {
					let n = l[t.tone] || l.info;
					return /* @__PURE__ */ c("button", {
						"data-bare": "",
						className: o.notifItem,
						"data-unread": !t.read || void 0,
						onClick: () => {
							f?.(t), e();
						},
						children: [/* @__PURE__ */ s("span", {
							className: `flow-symbol flow-symbol--fill ${o.notifIcon}`,
							style: { color: n.color },
							"aria-hidden": "true",
							children: n.icon
						}), /* @__PURE__ */ c("div", {
							className: o.notifBody,
							children: [
								/* @__PURE__ */ s("div", {
									className: o.notifTitle,
									"data-unread": !t.read || void 0,
									children: t.title
								}),
								t.desc && /* @__PURE__ */ s("div", {
									className: o.notifDesc,
									children: t.desc
								}),
								/* @__PURE__ */ s("div", {
									className: o.notifTime,
									children: t.time
								})
							]
						})]
					}, t.id);
				})]
			})]
		})
	});
}
//#endregion
export { u as NotificationCenter };

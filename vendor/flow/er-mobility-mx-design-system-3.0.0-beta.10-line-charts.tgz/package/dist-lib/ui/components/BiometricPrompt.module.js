//#region src/ui/components/BiometricPrompt.module.css
var e = "b0XS7a_biometric", t = "b0XS7a_description", n = "b0XS7a_fallback", r = "b0XS7a_icon", i = "b0XS7a_root", a = "b0XS7a_stateLabel", o = "b0XS7a_title", s = {
	biometric: e,
	description: t,
	fallback: n,
	icon: r,
	root: i,
	stateLabel: a,
	title: o
};
//#endregion
export { e as biometric, s as default, t as description, n as fallback, r as icon, i as root, a as stateLabel, o as title };

"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { IconButton as n } from "../primitives/IconButton.js";
import { Input as r } from "../primitives/Input.js";
import { Popover as i } from "../primitives/Popover.js";
import a from "./SavedViews.module.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
import { useState as c } from "react";
//#region src/ui/components/SavedViews.tsx
function l({ views: l, activeId: u, onApply: d, onSave: f, onDelete: p, max: m = 12, style: h }) {
	let g = e(), [_, v] = c(""), y = l.length >= m, b = !y && _.trim().length > 0, x = () => {
		b && (f(_.trim()), v(""));
	};
	return /* @__PURE__ */ o(i, {
		trigger: /* @__PURE__ */ o(t, {
			variant: "ghost",
			size: "sm",
			icon: "bookmark",
			children: g("savedViews.trigger", "Vistas")
		}),
		children: () => /* @__PURE__ */ s("div", {
			className: a.panel,
			style: h,
			children: [
				/* @__PURE__ */ o("ul", {
					"data-list": "",
					className: a.list,
					children: l.map((e) => /* @__PURE__ */ s("li", {
						className: a.row,
						children: [/* @__PURE__ */ o("button", {
							type: "button",
							"data-bare": "",
							className: a.apply,
							"aria-current": e.id === u ? "true" : void 0,
							onClick: () => d(e.id),
							children: e.name
						}), /* @__PURE__ */ o(n, {
							icon: "delete",
							ariaLabel: `${g("savedViews.delete", "Eliminar vista")}: ${e.name}`,
							onClick: () => p(e.id)
						})]
					}, e.id))
				}),
				/* @__PURE__ */ s("div", {
					className: a.footer,
					children: [/* @__PURE__ */ o(r, {
						size: "sm",
						value: _,
						ariaLabel: g("savedViews.name", "Nombre de la vista"),
						placeholder: g("savedViews.name", "Nombre de la vista"),
						disabled: y,
						onChange: v,
						onKeyDown: (e) => {
							e.key === "Enter" && x();
						}
					}), /* @__PURE__ */ o(t, {
						size: "sm",
						onClick: x,
						disabled: !b,
						children: g("savedViews.save", "Guardar vista")
					})]
				}),
				/* @__PURE__ */ s("div", {
					className: a.count,
					"aria-live": "polite",
					children: [
						l.length,
						"/",
						m,
						y && ` · ${g("savedViews.full", "cupo lleno: borra una vista para guardar otra")}`
					]
				})
			]
		})
	});
}
//#endregion
export { l as SavedViews };

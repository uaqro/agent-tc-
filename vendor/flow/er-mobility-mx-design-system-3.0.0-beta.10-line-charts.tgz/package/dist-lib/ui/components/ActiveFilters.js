import { useT as e } from "../../i18n/useSafeIntl.js";
import { Chip as t } from "../primitives/Chip.js";
import n from "./ActiveFilters.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/components/ActiveFilters.tsx
function a({ filters: a, period: o, onRemove: s, onClearAll: c, clearLabel: l, style: u }) {
	let d = e();
	if (a.length === 0 && !o) return null;
	let f = l ?? d("common.clearFilters", "Limpiar filtros");
	return /* @__PURE__ */ r("div", {
		className: n.root,
		role: "region",
		"aria-label": d("activeFilters.region", "Filtros activos"),
		style: u,
		children: /* @__PURE__ */ i("ul", {
			"data-list": "",
			className: n.list,
			children: [
				o && /* @__PURE__ */ r("li", {
					className: n.item,
					children: /* @__PURE__ */ r(t, {
						label: o,
						size: "sm",
						variant: "ghost"
					})
				}),
				a.map((e) => /* @__PURE__ */ r("li", {
					className: n.item,
					children: /* @__PURE__ */ r(t, {
						label: `${e.dimension}: ${e.label}`,
						size: "sm",
						onRemove: () => s(e.id)
					})
				}, e.id)),
				c && a.length >= 2 && /* @__PURE__ */ r("li", {
					className: n.item,
					children: /* @__PURE__ */ r("button", {
						type: "button",
						"data-bare": "",
						className: n.clear,
						onClick: c,
						children: f
					})
				})
			]
		})
	});
}
//#endregion
export { a as ActiveFilters };

"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Input as t } from "../primitives/Input.js";
import n from "./HelpCenter.module.js";
import { Fragment as r, jsx as i, jsxs as a } from "react/jsx-runtime";
import { useMemo as o, useState as s } from "react";
//#region src/ui/components/HelpCenter.tsx
function c({ articles: c, style: l }) {
	let u = e(), d = u("common.general", "General"), [f, p] = s(""), [m, h] = s(c[0]?.id || null), [g, _] = s(/* @__PURE__ */ new Set()), v = o(() => {
		let e = new Set(c.map((e) => e.category || d));
		return Array.from(e).sort();
	}, [c]), y = o(() => {
		if (!f) return c;
		let e = f.toLowerCase();
		return c.filter((t) => t.title.toLowerCase().includes(e) || (t.category || "").toLowerCase().includes(e) || t.keywords?.some((t) => t.toLowerCase().includes(e)) || (t.content || "").toLowerCase().includes(e));
	}, [c, f]), b = (e) => {
		_((t) => {
			let n = new Set(t);
			return n.has(e) ? n.delete(e) : n.add(e), n;
		});
	}, x = c.find((e) => e.id === m);
	return /* @__PURE__ */ a("div", {
		className: n.root,
		style: l,
		children: [/* @__PURE__ */ a("div", {
			className: n.sidebar,
			children: [/* @__PURE__ */ i("div", {
				className: n.searchWrap,
				children: /* @__PURE__ */ i(t, {
					size: "sm",
					icon: "search",
					ariaLabel: u("help.search", "Buscar artículos de ayuda"),
					placeholder: u("help.searchPlaceholder", "Busca…"),
					value: f,
					onChange: p
				})
			}), /* @__PURE__ */ i("div", {
				className: n.articleList,
				children: f ? /* @__PURE__ */ a(r, { children: [/* @__PURE__ */ i("div", {
					className: n.resultCount,
					"aria-live": "polite",
					children: y.length === 1 ? u("help.resultOne", "{n} resultado", { n: y.length }) : u("help.resultMany", "{n} resultados", { n: y.length })
				}), y.length > 0 ? /* @__PURE__ */ i("div", {
					className: n.listaResultados,
					children: y.map((e) => /* @__PURE__ */ a("button", {
						type: "button",
						"data-bare": "",
						className: n.searchResult,
						"data-active": m === e.id || void 0,
						onClick: () => h(e.id),
						children: [/* @__PURE__ */ i("div", {
							className: n.resultTitle,
							children: e.title
						}), /* @__PURE__ */ i("div", {
							className: n.resultCat,
							children: e.category
						})]
					}, e.id))
				}) : /* @__PURE__ */ i("div", {
					className: n.noResults,
					children: u("help.noResults", "Sin resultados. Intenta con otro término o contacta soporte.")
				})] }) : /* @__PURE__ */ i("div", {
					className: n.listaCategorias,
					children: v.map((e) => {
						let t = c.filter((t) => (t.category || d) === e), r = g.has(e);
						return /* @__PURE__ */ a("div", { children: [/* @__PURE__ */ a("button", {
							type: "button",
							"data-bare": "",
							className: n.catToggle,
							"aria-expanded": r,
							onClick: () => b(e),
							children: [/* @__PURE__ */ i("span", {
								className: `flow-symbol ${n.catChevron}`,
								"data-open": r || void 0,
								"aria-hidden": "true",
								children: "chevron_right"
							}), e]
						}), r && /* @__PURE__ */ i("div", {
							className: n.catChildren,
							children: t.map((e) => /* @__PURE__ */ i("button", {
								type: "button",
								"data-bare": "",
								className: n.articleBtn,
								"data-active": m === e.id || void 0,
								onClick: () => h(e.id),
								children: e.title
							}, e.id))
						})] }, e);
					})
				})
			})]
		}), /* @__PURE__ */ i("div", {
			className: n.content,
			children: x ? /* @__PURE__ */ a("section", {
				"aria-labelledby": `hlp-art-${x.id}`,
				children: [
					/* @__PURE__ */ i("span", {
						"data-overline": "",
						children: x.category
					}),
					/* @__PURE__ */ i("h2", {
						id: `hlp-art-${x.id}`,
						className: n.contentTitle,
						children: x.title
					}),
					x.content && /* @__PURE__ */ i("div", {
						className: n.contentBody,
						children: x.content.split("\n").filter((e) => e.trim()).map((e, t) => /* @__PURE__ */ i("p", { children: e }, t))
					}),
					x.keywords && x.keywords.length > 0 && /* @__PURE__ */ a("div", {
						className: n.tags,
						children: [/* @__PURE__ */ i("span", {
							className: n.tagLabel,
							children: u("help.tags", "Etiquetas:")
						}), x.keywords.map((e) => /* @__PURE__ */ i("span", {
							className: n.tag,
							children: e
						}, e))]
					})
				]
			}) : /* @__PURE__ */ i("div", {
				className: n.emptyContent,
				children: u("help.pickArticle", "Selecciona un artículo")
			})
		})]
	});
}
//#endregion
export { c as HelpCenter };

//#region src/ui/components/CodeBlock.module.css
var e = "NSwGXa_code", t = "NSwGXa_filename", n = "NSwGXa_header", r = "NSwGXa_heading", i = "NSwGXa_pre", a = "NSwGXa_root", o = "NSwGXa_snippetText", s = "NSwGXa_spacer", c = {
	code: e,
	filename: t,
	header: n,
	heading: r,
	pre: i,
	root: a,
	snippetText: o,
	spacer: s
};
//#endregion
export { e as code, c as default, t as filename, n as header, r as heading, i as pre, a as root, o as snippetText, s as spacer };

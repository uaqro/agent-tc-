//#region src/ui/components/TopBar.module.css
var e = "w4gM8G_breadcrumbCurrent", t = "w4gM8G_breadcrumbLink", n = "w4gM8G_breadcrumbNav", r = "w4gM8G_breadcrumbSep", i = "w4gM8G_entityBtn", a = "w4gM8G_entityOption", o = "w4gM8G_inner", s = "w4gM8G_logoCenter", c = "w4gM8G_logoWrap", l = "w4gM8G_menuBtn", u = "w4gM8G_mobileLeading", d = "w4gM8G_mobileTrailing", f = "w4gM8G_navLink", p = "w4gM8G_navWrap", m = "w4gM8G_notifCount", h = "w4gM8G_notifWrap", g = "w4gM8G_root", _ = "w4gM8G_spacer", v = "w4gM8G_trailingWrap", y = "w4gM8G_versionBadge", b = {
	breadcrumbCurrent: e,
	breadcrumbLink: t,
	breadcrumbNav: n,
	breadcrumbSep: r,
	entityBtn: i,
	entityOption: a,
	inner: o,
	logoCenter: s,
	logoWrap: c,
	menuBtn: l,
	mobileLeading: u,
	mobileTrailing: d,
	navLink: f,
	navWrap: p,
	notifCount: m,
	notifWrap: h,
	root: g,
	spacer: _,
	trailingWrap: v,
	versionBadge: y
};
//#endregion
export { e as breadcrumbCurrent, t as breadcrumbLink, n as breadcrumbNav, r as breadcrumbSep, b as default, i as entityBtn, a as entityOption, o as inner, s as logoCenter, c as logoWrap, l as menuBtn, u as mobileLeading, d as mobileTrailing, f as navLink, p as navWrap, m as notifCount, h as notifWrap, g as root, _ as spacer, v as trailingWrap, y as versionBadge };

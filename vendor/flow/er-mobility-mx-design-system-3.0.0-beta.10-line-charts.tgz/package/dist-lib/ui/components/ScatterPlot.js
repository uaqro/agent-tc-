"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { EmptyState as t } from "../primitives/EmptyState.js";
import { FlowChart as n } from "../primitives/FlowChart.js";
import { Fragment as r, jsx as i, jsxs as a } from "react/jsx-runtime";
import { useId as o, useState as s } from "react";
//#region src/ui/components/ScatterPlot.tsx
var c = {
	position: "absolute",
	width: 1,
	height: 1,
	margin: -1,
	padding: 0,
	overflow: "hidden",
	clip: "rect(0 0 0 0)",
	whiteSpace: "nowrap",
	border: 0
};
function l({ points: l = [], xLabel: u, yLabel: d, xThreshold: f, yThreshold: p, color: m, format: h = {}, height: g = 260, selectedId: _, onSelect: v, style: y }) {
	let b = e(), x = o(), [S, C] = s(0);
	if (!l.length) return /* @__PURE__ */ i(t, {
		icon: "scatter_plot",
		title: b("common.empty", "Sin datos"),
		description: b("common.emptyDescription", "No hay datos para este periodo.")
	});
	let w = b("scatter.yDefault", "Unidades"), T = l.map((e) => e.id === _ ? {
		value: [
			e.x,
			e.y,
			e.label,
			e.id
		],
		symbol: "diamond",
		symbolSize: 16
	} : [
		e.x,
		e.y,
		e.label,
		e.id
	]), E = h.y || h.x || ((e) => String(e)), D = (e) => {
		e.key === "ArrowDown" || e.key === "ArrowRight" ? (e.preventDefault(), C((e) => Math.min(l.length - 1, e + 1))) : e.key === "ArrowUp" || e.key === "ArrowLeft" ? (e.preventDefault(), C((e) => Math.max(0, e - 1))) : e.key === "Home" ? (e.preventDefault(), C(0)) : e.key === "End" ? (e.preventDefault(), C(l.length - 1)) : (e.key === "Enter" || e.key === " ") && (e.preventDefault(), l[S] && v?.(l[S]));
	}, O = [].concat(f == null ? [] : [{ xAxis: f }], p == null ? [] : [{ yAxis: p }]);
	return /* @__PURE__ */ a(r, { children: [/* @__PURE__ */ i(n, {
		type: "scatter",
		plotSurface: "canvas",
		height: g,
		format: E,
		style: y,
		series: [{
			label: d || w,
			values: T,
			color: m,
			markLine: O.length ? {
				silent: !0,
				symbol: "none",
				lineStyle: {
					color: "var(--viz-label)",
					type: "dashed",
					width: 1.25
				},
				label: { show: !1 },
				data: O
			} : void 0
		}],
		onSelect: v ? (e) => {
			let t = e, n = l.find((e) => e.id === (t.value && t.value[3]));
			n && v(n);
		} : void 0,
		axisLabels: {
			x: u,
			y: d
		},
		ariaLabel: b("scatter.summary", "{y} contra {x}, {n} unidades", {
			y: d || "Y",
			x: u || "X",
			n: l.length
		})
	}), v && /* @__PURE__ */ i("div", {
		role: "listbox",
		tabIndex: 0,
		"aria-label": b("scatter.points", "Puntos: {y} contra {x}", {
			y: d || "Y",
			x: u || "X"
		}),
		"aria-activedescendant": `${x}-opt-${S}`,
		style: c,
		onKeyDown: D,
		children: l.map((e, t) => /* @__PURE__ */ i("div", {
			id: `${x}-opt-${t}`,
			role: "option",
			"aria-selected": e.id === _,
			children: `${e.label ?? e.id}: ${E(e.x)}, ${E(e.y)}`
		}, e.id))
	})] });
}
//#endregion
export { l as ScatterPlot };

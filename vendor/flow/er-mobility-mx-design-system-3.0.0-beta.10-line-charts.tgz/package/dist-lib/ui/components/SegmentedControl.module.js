//#region src/ui/components/SegmentedControl.module.css
var e = "aCvGZG_indicator", t = "aCvGZG_root", n = "aCvGZG_segment", r = "aCvGZG_segmentIcon", i = {
	indicator: e,
	root: t,
	segment: n,
	segmentIcon: r
};
//#endregion
export { i as default, e as indicator, t as root, n as segment, r as segmentIcon };

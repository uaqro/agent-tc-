//#region src/ui/components/Bars.module.css
var e = "rLlcjG_bar", t = "rLlcjG_column", n = "rLlcjG_label", r = "rLlcjG_plot", i = "rLlcjG_root", a = "rLlcjG_tooltip", o = {
	bar: e,
	column: t,
	label: n,
	plot: r,
	root: i,
	tooltip: a
};
//#endregion
export { e as bar, t as column, o as default, n as label, r as plot, i as root, a as tooltip };

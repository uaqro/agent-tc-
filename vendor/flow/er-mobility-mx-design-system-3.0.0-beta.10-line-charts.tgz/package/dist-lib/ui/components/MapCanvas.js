"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { leerFuenteSimbolos as t, leerToken as n } from "../../tokens/leerToken.js";
import { IconButton as r } from "../primitives/IconButton.js";
import { Popover as i } from "../primitives/Popover.js";
import a from "./MapCanvas.module.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
import { useCallback as c, useEffect as l, useMemo as u, useRef as d, useState as f } from "react";
//#region src/ui/components/MapCanvas.tsx
function p(e) {
	return !e || e.length === 0 ? [] : Array.isArray(e[0][0]) ? e : [e];
}
var m = 256;
function h(e, t) {
	return (e + 180) / 360 * 2 ** t;
}
function g(e, t) {
	let n = e * Math.PI / 180;
	return (1 - Math.log(Math.tan(n) + 1 / Math.cos(n)) / Math.PI) / 2 * 2 ** t;
}
function _(e, t) {
	for (; e.size > t;) {
		let t = e.keys().next().value;
		if (t === void 0) break;
		e.delete(t);
	}
	return e;
}
function v(e, t) {
	let n = e.get(t);
	if (n !== void 0) return e.delete(t), e.set(t, n), n;
}
function y(e, t) {
	return e / 2 ** t * 360 - 180;
}
function ee(e, t) {
	let n = Math.PI - 2 * Math.PI * e / 2 ** t;
	return 180 / Math.PI * Math.atan(.5 * (Math.exp(n) - Math.exp(-n)));
}
function te(e) {
	return /^var\(/.test(e) && n(e.slice(4, -1)) || e;
}
var b = {
	scale: 1,
	shadowBlur: 4,
	shadowY: 1,
	glowAlpha: 0
}, ne = {
	scale: 1.08,
	shadowBlur: 14,
	shadowY: 4,
	glowAlpha: .12
}, x = {
	scale: 1.18,
	shadowBlur: 22,
	shadowY: 6,
	glowAlpha: .25
}, re = 24, ie = 20, S = 28, ae = 3.5, oe = 10, C = .14, w = .01;
function T(e, t) {
	let n = t - e;
	return Math.abs(n) < w ? t : e + n * C;
}
function se(e, t) {
	let n = {
		scale: T(e.scale, t.scale),
		shadowBlur: T(e.shadowBlur, t.shadowBlur),
		shadowY: T(e.shadowY, t.shadowY),
		glowAlpha: T(e.glowAlpha, t.glowAlpha)
	};
	return {
		val: n,
		done: n.scale === t.scale && n.shadowBlur === t.shadowBlur && n.shadowY === t.shadowY && n.glowAlpha === t.glowAlpha
	};
}
function ce(e, t) {
	let n = [];
	for (let r of e) {
		if (r.size != null) {
			n.push([r]);
			continue;
		}
		let e = n.find((e) => e[0].size == null && e.some((e) => Math.hypot((h(e.lon, t) - h(r.lon, t)) * m, (g(e.lat, t) - g(r.lat, t)) * m) < 48));
		e ? e.push(r) : n.push([r]);
	}
	return n;
}
function le() {
	let [e, t] = f(() => typeof document > "u" ? "" : document.documentElement.dataset.mode ?? "");
	return l(() => {
		let e = new MutationObserver(() => t(document.documentElement.dataset.mode ?? ""));
		return e.observe(document.documentElement, {
			attributes: !0,
			attributeFilter: ["data-mode"]
		}), () => e.disconnect();
	}, []), e;
}
function E({ surface: C = "card", center: w, zoom: T = 13, pins: E = [], cluster: ue = !1, selectedPin: D, onPinClick: de, route: fe, routeColor: O, fitBounds: k, style: pe, tone: me = "mono", tileUrl: he = "https://tile.openstreetmap.org/{z}/{x}/{y}.png", attribution: ge = "© OpenStreetMap contributors", onViewportChange: A, tileCacheMax: _e = 256 }) {
	let j = e(), ve = le(), M = d(null), N = d(null), [P, ye] = f({
		w: 600,
		h: 400
	}), [F, I] = f(T), be = u(() => ue ? ce(E, F) : E.map((e) => [e]), [
		E,
		ue,
		F
	]), L = u(() => be.map((e) => e.length === 1 ? e[0] : {
		id: `cluster:${e.map((e) => e.id).join(",")}`,
		lat: e.reduce((e, t) => e + t.lat, 0) / e.length,
		lon: e.reduce((e, t) => e + t.lon, 0) / e.length,
		label: j("map.cluster", "{n} puntos · acercar para explorar", { n: e.length }),
		details: e.map((e) => e.label || e.id)
	}), [be, j]), [R, xe] = f({
		x: 0,
		y: 0
	}), [Se, Ce] = f(!1), [z, B] = f(null), V = d(null), H = d({
		x: 0,
		y: 0
	}), U = c((e) => {
		H.current = e, xe(e);
	}, []), we = d(/* @__PURE__ */ new Map()), W = d(/* @__PURE__ */ new Map()), Te = d(0), G = d(void 0);
	l(() => {
		let e = N.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = new ResizeObserver((e) => {
			let { width: t, height: n } = e[0].contentRect;
			ye({
				w: Math.round(t),
				h: Math.round(n)
			});
		});
		return t.observe(e), () => t.disconnect();
	}, []);
	let K = h(w[1], F) * m + R.x, q = g(w[0], F) * m + R.y, Ee = `${w[0]},${w[1]}`;
	l(() => {
		U({
			x: 0,
			y: 0
		});
	}, [Ee, U]);
	let De = d(P);
	De.current = P;
	let Oe = (() => {
		if (!k || k.length === 0) return "";
		let e = Infinity, t = -Infinity, n = Infinity, r = -Infinity;
		for (let [i, a] of k) i < e && (e = i), i > t && (t = i), a < n && (n = a), a > r && (r = a);
		return `${k.length}|${e.toFixed(4)},${n.toFixed(4)},${t.toFixed(4)},${r.toFixed(4)}`;
	})(), J = d(k);
	J.current = k;
	let ke = d(w);
	ke.current = w;
	let Ae = c(() => {
		let e = J.current;
		if (!e || e.length === 0) {
			let e = {
				x: 0,
				y: 0
			};
			return I(T), U(e), {
				z: T,
				off: e
			};
		}
		let t = Infinity, n = -Infinity, r = Infinity, i = -Infinity;
		for (let [a, o] of e) a < t && (t = a), a > n && (n = a), o < r && (r = o), o > i && (i = o);
		let { w: a, h: o } = De.current, s = 18;
		for (; s > 2; s--) {
			let e = (h(i, s) - h(r, s)) * m, c = (g(t, s) - g(n, s)) * m;
			if (e <= a - 96 && c <= o - 96) break;
		}
		let c = (t + n) / 2, l = (r + i) / 2, [u, d] = ke.current;
		I(s);
		let f = {
			x: (h(l, s) - h(d, s)) * m,
			y: (g(c, s) - g(u, s)) * m
		};
		return U(f), {
			z: s,
			off: f
		};
	}, [T]);
	l(() => {
		Oe && Ae();
	}, [Oe]);
	let je = c((e, t) => {
		let n = we.current, r = v(n, e);
		if (r) return r.complete ? r : null;
		let i = new Image();
		return i.crossOrigin = "anonymous", i.src = t, i.onload = () => G.current?.(), n.set(e, i), _(n, _e), null;
	}, [_e]);
	l(() => {
		let e = !0, r = N.current ? t(N.current) : "", i = !1, a = `${ie}px ${r}`;
		r && document.fonts && (i = document.fonts.check(a), document.fonts.load(a).then(() => {
			e && (i = !0, G.current?.());
		}).catch(() => {}));
		let o = () => {
			let e = M.current;
			if (!e) return;
			let t = e.getContext("2d");
			if (!t) return;
			let a = window.devicePixelRatio || 1;
			e.width = P.w * a, e.height = P.h * a, t.scale(a, a);
			let o = P.w / 2 - K, s = P.h / 2 - q, c = document.documentElement.dataset.mode === "dark", l = 2 ** F, u = Math.max(0, Math.floor(-o / m)), d = Math.min(l - 1, Math.floor((-o + P.w) / m)), f = Math.max(0, Math.floor(-s / m)), _ = Math.min(l - 1, Math.floor((-s + P.h) / m));
			t.fillStyle = n("--surface-canvas"), t.fillRect(0, 0, P.w, P.h);
			let v = he;
			t.filter = {
				mono: c ? "grayscale(1) invert(1) brightness(0.85) contrast(0.95)" : "grayscale(1) contrast(0.95) brightness(1.03)",
				color: c ? "invert(1) hue-rotate(180deg) brightness(0.92) contrast(0.9)" : "none"
			}[me];
			for (let e = u; e <= d; e++) for (let n = f; n <= _; n++) {
				let r = `osm/${F}/${e}/${n}`, i = v.replace("{z}", String(F)).replace("{x}", String(e)).replace("{y}", String(n)), a = je(r, i);
				a && t.drawImage(a, o + e * m, s + n * m, m, m);
			}
			t.filter = "none";
			let y = n("--surface-card"), ee = n("--text-primary");
			n("--border-subtle");
			let ne = n("--viz-accent"), x = n("--viz-1"), S = n("--font-body");
			n("--font-mono");
			let C = p(fe);
			for (let e of C) e.length < 2 || (t.beginPath(), e.forEach(([e, n], r) => {
				let i = o + h(n, F) * m, a = s + g(e, F) * m;
				r === 0 ? t.moveTo(i, a) : t.lineTo(i, a);
			}), t.strokeStyle = O ? te(O) : x, t.lineWidth = 4, t.lineJoin = "round", t.lineCap = "round", t.stroke(), t.setLineDash([8, 6]), t.strokeStyle = n("--map-route"), t.lineWidth = 4, t.stroke(), t.setLineDash([]));
			[...L].sort((e, t) => (e.id === D ? 2 : +(e.id === z)) - (t.id === D ? 2 : +(t.id === z))).forEach((e) => {
				let a = o + h(e.lon, F) * m, c = s + g(e.lat, F) * m, l = D === e.id, u = te(e.color || (l ? ne : x)), d = W.current.get(e.id) || { ...b };
				if (e.size != null) {
					let o = l || z === e.id, s = o ? e.size * 1.8 : e.size;
					t.save(), t.beginPath(), t.arc(a, c, s, 0, Math.PI * 2), t.fillStyle = u, t.globalAlpha = .88, t.fill(), t.globalAlpha = 1, t.lineWidth = o ? 2 : 1, t.strokeStyle = o ? ee : y, t.stroke(), e.icon && i && (t.font = `${Math.round(s * 1.35)}px ${r}`, t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = n("--text-on-accent"), t.fillText(e.icon, a, c)), t.restore();
					return;
				}
				let f = re * d.scale, p = c - oe * d.scale - f, _ = (e) => {
					t.beginPath(), t.arc(a, p, e, Math.PI * .65, Math.PI * .35, !1), t.lineTo(a, c), t.closePath();
				};
				if (t.save(), d.glowAlpha > .005) {
					t.beginPath(), t.arc(a, p, f + 10, 0, Math.PI * 2);
					let e = Math.round(d.glowAlpha * 255).toString(16).padStart(2, "0");
					t.fillStyle = u + e, t.fill();
				}
				if (t.shadowColor = n("--map-pin-shadow"), t.shadowBlur = d.shadowBlur, t.shadowOffsetY = d.shadowY, _(f), t.fillStyle = u, t.fill(), t.shadowColor = "transparent", t.shadowBlur = 0, t.shadowOffsetY = 0, t.strokeStyle = y, t.lineWidth = ae, t.stroke(), e.id.startsWith("cluster:") && (t.font = n("--type-data-md"), t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = n("--text-on-accent"), t.fillText(String(e.details?.length || 0), a, p)), e.icon && i) {
					let i = Math.round(ie * d.scale);
					t.font = `${i}px ${r}`, t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = n("--text-on-accent"), t.fillText(e.icon, a, p);
				}
				t.restore();
			}), t.font = `500 9px ${S}`, t.fillStyle = n("--map-attribution"), t.textAlign = "right", t.fillText(ge, P.w - 6, P.h - 6);
		};
		G.current = o;
		let s = new Set(L.map((e) => e.id));
		for (let e of W.current.keys()) s.has(e) || W.current.delete(e);
		let c = () => {
			if (!e) return;
			let t = !1;
			L.forEach((e) => {
				let n = D === e.id, r = z === e.id, i = n ? x : r ? ne : b, { val: a, done: o } = se(W.current.get(e.id) || { ...b }, i);
				W.current.set(e.id, a), o || (t = !0);
			}), o(), t && (Te.current = requestAnimationFrame(c));
		};
		return c(), () => {
			e = !1, cancelAnimationFrame(Te.current);
		};
	}, [
		K,
		q,
		F,
		P,
		L,
		D,
		z,
		fe,
		O,
		je,
		ve,
		me
	]);
	let Y = (e) => {
		let t = Math.max(2, Math.min(18, e));
		if (t === F) return;
		let n = 2 ** (t - F), r = {
			x: H.current.x * n,
			y: H.current.y * n
		};
		U(r), I(t), X(t, r);
	}, Me = (e) => {
		e.preventDefault(), Y(F + (e.deltaY < 0 ? 1 : -1));
	}, Ne = (e) => {
		V.current = {
			sx: e.clientX,
			sy: e.clientY,
			ox: R.x,
			oy: R.y
		}, Ce(!0), e.currentTarget.setPointerCapture?.(e.pointerId), M.current && (M.current.style.cursor = "");
	}, Pe = (e) => {
		if (V.current) {
			let t = {
				x: V.current.ox + (e.clientX - V.current.sx),
				y: V.current.oy + (e.clientY - V.current.sy)
			};
			U(t);
			return;
		}
		let t = M.current;
		if (!t || E.length === 0) {
			z && B(null);
			return;
		}
		let n = t.getBoundingClientRect(), r = e.clientX - n.left, i = e.clientY - n.top, a = P.w / 2 - K, o = P.h / 2 - q, s = null, c = S;
		for (let e of L) {
			let t = a + h(e.lon, F) * m, n = o + g(e.lat, F) * m - (e.size == null ? 34 : 0), l = Math.hypot(r - t, i - n);
			l < c && (c = l, s = e.id);
		}
		s !== z && B(s), t.style.cursor = s ? "pointer" : "";
	}, X = c((e, t) => {
		if (!A) return;
		let n = h(w[1], e) * m - t.x;
		A({
			center: [ee((g(w[0], e) * m - t.y) / m, e), y(n / m, e)],
			zoom: e
		});
	}, [A, w]), Fe = () => {
		V.current = null, Ce(!1), X(F, H.current);
	}, Ie = () => {
		z && B(null);
	}, Le = (e) => {
		if (!e.id.startsWith("cluster:")) {
			B(null), de?.(e.id);
			return;
		}
		let t = Math.min(18, F + 1), n = {
			x: (h(e.lon, t) - h(w[1], t)) * m,
			y: (g(e.lat, t) - g(w[0], t)) * m
		};
		U(n), I(t), B(null), A?.({
			center: [e.lat, e.lon],
			zoom: t
		});
	}, Re = (e) => {
		if (L.length === 0) return;
		let t = M.current;
		if (!t) return;
		let n = t.getBoundingClientRect(), r = e.clientX - n.left, i = e.clientY - n.top, a = P.w / 2 - K, o = P.h / 2 - q, s = null, c = S;
		for (let e of L) {
			let t = a + h(e.lon, F) * m, n = o + g(e.lat, F) * m - (e.size == null ? 34 : 0), l = Math.hypot(r - t, i - n);
			l < c && (c = l, s = e);
		}
		s && Le(s);
	}, ze = d(null), Z = L.find((e) => e.id === (z ?? D) && e.label), Q = Z ? P.w / 2 - K + h(Z.lon, F) * m : 0, $ = Z ? P.h / 2 - q + g(Z.lat, F) * m : 0, Be = !!Z && !Se && Q >= 0 && Q <= P.w && $ >= 0 && $ <= P.h;
	return /* @__PURE__ */ s("div", {
		ref: N,
		className: a.root,
		"data-surface": C,
		"data-dragging": Se || void 0,
		style: pe,
		children: [
			/* @__PURE__ */ o("canvas", {
				ref: M,
				className: a.canvas,
				onWheel: Me,
				onPointerDown: Ne,
				onPointerMove: Pe,
				onPointerUp: Fe,
				onPointerCancel: Fe,
				onPointerLeave: Ie,
				onClick: Re
			}),
			/* @__PURE__ */ o("span", {
				ref: ze,
				className: a.tooltipAnchor,
				style: {
					left: Q,
					top: $ - (Z?.size ?? 61.5)
				}
			}),
			/* @__PURE__ */ o(i, {
				open: Be,
				onOpenChange: (e) => {
					e || B(null);
				},
				anchorRef: ze,
				placement: "top-center",
				offset: 8,
				surface: "none",
				layer: "tooltip",
				interactive: !1,
				children: Z && /* @__PURE__ */ s("div", {
					role: "tooltip",
					className: a.tooltip,
					children: [/* @__PURE__ */ s("div", {
						className: a.tooltipLabel,
						children: [Z.icon && /* @__PURE__ */ o("span", {
							className: "flow-symbol",
							"aria-hidden": "true",
							children: Z.icon
						}), Z.label]
					}), (Z.details ?? (Z.subtitle ? [Z.subtitle] : [])).map((e, t) => /* @__PURE__ */ o("div", {
						className: a.tooltipDetail,
						children: e
					}, t))]
				})
			}, `${Z?.id}:${Q}:${$}`),
			L.some((e) => e.size == null) && /* @__PURE__ */ o("div", {
				className: a.pinLayer,
				"aria-label": j("map.pins", "Puntos en el mapa"),
				role: "group",
				children: L.filter((e) => e.size == null).map((e) => {
					let t = P.w / 2 - K + h(e.lon, F) * m, n = P.h / 2 - q + g(e.lat, F) * m;
					return t < -22 || n < -22 || t > P.w + 22 || n > P.h + 22 ? null : /* @__PURE__ */ o("button", {
						type: "button",
						"data-bare": "",
						className: a.pinTarget,
						style: {
							left: t,
							top: n - oe - re
						},
						"aria-label": `${e.label ?? e.id}${e.subtitle ? `, ${e.subtitle}` : ""}`,
						"aria-pressed": D == null ? void 0 : e.id === D,
						onClick: () => Le(e),
						onFocus: () => B(e.id),
						onBlur: () => B((t) => t === e.id ? null : t)
					}, e.id);
				})
			}),
			/* @__PURE__ */ s("div", {
				className: a.controls,
				children: [
					/* @__PURE__ */ o(r, {
						variant: "secondary",
						icon: "add",
						ariaLabel: j("map.zoomIn", "Acercar"),
						onClick: () => Y(F + 1)
					}),
					/* @__PURE__ */ o(r, {
						variant: "secondary",
						icon: "remove",
						ariaLabel: j("map.zoomOut", "Alejar"),
						onClick: () => Y(F - 1)
					}),
					/* @__PURE__ */ o(r, {
						variant: "secondary",
						icon: "recenter",
						ariaLabel: j("map.recenter", "Centrar el mapa"),
						onClick: () => {
							let { z: e, off: t } = Ae();
							X(e, t);
						}
					})
				]
			})
		]
	});
}
//#endregion
export { E as MapCanvas, ce as agruparPins, _ as podarCache, v as tocarCache };

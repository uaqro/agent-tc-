"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import n from "./NipReveal.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useCallback as a, useState as o } from "react";
//#region src/ui/components/NipReveal.tsx
function s({ digits: s, blurLast: c = !0, duration: l = 5e3, warning: u, style: d }) {
	let f = e(), [p, m] = o(!1), h = a(() => {
		m(!0), setTimeout(() => m(!1), l);
	}, [l]);
	if (!p) return /* @__PURE__ */ i("div", {
		className: n.root,
		style: d,
		children: [u && /* @__PURE__ */ r("span", {
			className: n.warning,
			children: u
		}), /* @__PURE__ */ r(t, {
			variant: "primary",
			onClick: h,
			children: f("nip.show", "Mostrar NIP")
		})]
	});
	let g = s.split(""), _ = g.length - 1;
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: d,
		children: [/* @__PURE__ */ r("span", {
			className: n.value,
			children: g.map((e, t) => c && t === _ ? /* @__PURE__ */ r("span", {
				className: n.blur,
				children: e
			}, t) : /* @__PURE__ */ r("span", { children: e }, t))
		}), /* @__PURE__ */ r("span", {
			className: n.hint,
			children: f("nip.hint", "Se ocultará automáticamente")
		})]
	});
}
//#endregion
export { s as NipReveal };

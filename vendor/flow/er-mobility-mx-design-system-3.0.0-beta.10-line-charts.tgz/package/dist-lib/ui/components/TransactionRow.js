import { useLocale as e, useT as t } from "../../i18n/useSafeIntl.js";
import { ListRow as n } from "./ListRow.js";
import r from "./TransactionRow.module.js";
import { Fragment as i, jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/ui/components/TransactionRow.tsx
var s = {
	transfer: "swap_horiz",
	fuel: "local_gas_station",
	toll: "toll",
	service: "build",
	payment: "payments",
	ev: "bolt",
	maintenance: "build"
};
function c(e, t, n) {
	return `${e < 0 ? "−" : "+"}${t}${Math.abs(e).toLocaleString(n, {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
}
function l({ category: l = "transfer", title: u, subtitle: d, amount: f = 0, currency: p = "$", pending: m, status: h, onClick: g, style: _ }) {
	let v = t(), y = e(), b = h ?? (m ? "pending" : void 0), x = {
		completed: v("transaction.completed", "Completado"),
		pending: v("transaction.pending", "Pendiente"),
		rejected: v("transaction.rejected", "Rechazado"),
		failed: v("transaction.failed", "Fallido")
	}, S = b ? x[b] : void 0, C = b ? {
		completed: "check_circle",
		pending: "schedule",
		rejected: "block",
		failed: "error"
	}[b] : void 0, w = `${f < 0 ? "cargo" : "abono"} ${p}${Math.abs(f).toFixed(2)}`, T = g ? [
		u,
		d,
		S,
		w
	].filter(Boolean).join(", ") : void 0;
	return /* @__PURE__ */ a(n, {
		leading: /* @__PURE__ */ a("span", {
			className: r.icon,
			"data-category": l,
			"data-product": [
				"fuel",
				"toll",
				"ev",
				"maintenance"
			].includes(l) ? l : void 0,
			children: /* @__PURE__ */ a("span", {
				className: "flow-symbol",
				"aria-hidden": "true",
				children: s[l]
			})
		}),
		title: /* @__PURE__ */ a("span", {
			className: r.title,
			children: u
		}),
		subtitle: d || b ? /* @__PURE__ */ o(i, { children: [d, b && b !== "completed" && /* @__PURE__ */ o("span", {
			className: r.status,
			"data-status": b,
			children: [/* @__PURE__ */ a("span", {
				className: "flow-symbol",
				"aria-hidden": "true",
				children: C
			}), S]
		})] }) : void 0,
		trailing: /* @__PURE__ */ a("span", {
			className: r.amount,
			"data-negative": f < 0 || void 0,
			"data-status": b === "rejected" ? "rejected" : void 0,
			"aria-label": w,
			children: c(f, p, y)
		}),
		ariaLabel: T,
		onClick: g,
		style: _
	});
}
//#endregion
export { l as TransactionRow };

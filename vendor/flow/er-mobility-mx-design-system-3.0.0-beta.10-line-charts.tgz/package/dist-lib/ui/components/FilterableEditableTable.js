"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Input as t } from "../primitives/Input.js";
import { DataGrid as n } from "./DataGrid.js";
import r from "./FilterableEditableTable.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import { useEffect as o, useMemo as s, useRef as c, useState as l } from "react";
//#region src/ui/components/FilterableEditableTable.tsx
function u({ columns: u, rows: d, rowKey: f, onUpdate: p, onFilter: m, style: h }) {
	let g = e(), [_, v] = l({}), [y, b] = l(null), [x, S] = l(""), C = (e, t) => {
		let n = {
			..._,
			[e]: t
		};
		v(n), m?.(n);
	}, w = s(() => d.filter((e) => Object.keys(_).every((t) => {
		let n = _[t];
		return !n || String(e[t] ?? "").toLowerCase().includes(n.toLowerCase());
	})), [d, _]), T = Object.values(_).some((e) => e), E = c(null), D = c(null);
	o(() => {
		if (y || !D.current) return;
		let { row: e, col: t } = D.current;
		D.current = null, E.current?.querySelector(`[data-cell="${e}|${t}"]`)?.focus();
	}, [y]);
	let O = (e, t, n) => {
		D.current = {
			row: e,
			col: t
		}, b({
			row: e,
			col: t
		}), S(String(n ?? ""));
	}, k = () => {
		y && (p?.(y.row, y.col, x), b(null));
	}, A = u.map((e) => e.editable ? {
		...e,
		render: (n) => {
			let o = String(n[f]);
			return y?.row === o && y?.col === e.key ? /* @__PURE__ */ i(t, {
				size: "sm",
				mono: !0,
				value: x,
				onChange: S,
				autoFocus: !0,
				onBlur: k,
				onKeyDown: (e) => {
					e.key === "Enter" && k(), e.key === "Escape" && b(null);
				},
				style: { minWidth: 80 }
			}) : /* @__PURE__ */ a("span", {
				role: "button",
				tabIndex: 0,
				"data-cell": `${o}|${e.key}`,
				className: r.editableCell,
				onClick: () => O(o, e.key, n[e.key]),
				onKeyDown: (t) => {
					(t.key === "Enter" || t.key === " ") && (t.preventDefault(), O(o, e.key, n[e.key]));
				},
				children: [e.render ? e.render(n) : String(n[e.key] ?? ""), /* @__PURE__ */ i("span", {
					className: `flow-symbol ${r.editIcon}`,
					"aria-hidden": "true",
					children: "edit"
				})]
			});
		}
	} : e);
	return /* @__PURE__ */ a("div", {
		ref: E,
		style: h,
		children: [/* @__PURE__ */ a("div", {
			className: r.barraFiltros,
			children: [
				/* @__PURE__ */ i("span", {
					"data-overline": "",
					children: g("filter.label", "Filtrar:")
				}),
				u.filter((e) => e.filterable).map((e) => /* @__PURE__ */ i(t, {
					size: "sm",
					"aria-label": g("filter.by", "Filtrar por {col}", { col: e.label }),
					placeholder: `${e.label}…`,
					value: _[e.key] || "",
					onChange: (t) => C(e.key, t),
					style: { minWidth: 140 }
				}, e.key)),
				T && /* @__PURE__ */ a("span", {
					"aria-live": "polite",
					className: r.resultCount,
					children: [
						w.length,
						" ",
						w.length === 1 ? g("filter.rowOne", "fila") : g("filter.rowMany", "filas")
					]
				}),
				T && /* @__PURE__ */ i("button", {
					type: "button",
					onClick: () => {
						v({}), m?.({});
					},
					"data-bare": "",
					className: r.clearBtn,
					children: g("common.clear", "Limpiar")
				})
			]
		}), w.length === 0 ? /* @__PURE__ */ i("div", {
			className: r.emptyState,
			children: T ? g("common.noResults", "Ningún registro coincide con el filtro") : g("common.empty", "Sin datos")
		}) : /* @__PURE__ */ i(n, {
			columns: A,
			rows: w,
			rowKey: f,
			density: "compact",
			attachedTop: !0
		})]
	});
}
//#endregion
export { u as FilterableEditableTable };

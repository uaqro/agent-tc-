//#region src/ui/components/ChatThread.module.css
var e = "Hpfo7W_root", t = { root: e };
//#endregion
export { t as default, e as root };

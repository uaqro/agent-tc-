//#region src/ui/components/DatePicker.module.css
var e = "hbftCW_display", t = "hbftCW_presets", n = "hbftCW_root", r = {
	display: e,
	presets: t,
	root: n
};
//#endregion
export { r as default, e as display, t as presets, n as root };

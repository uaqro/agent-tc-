import { ListRow as e } from "./ListRow.js";
import t from "./StationRow.module.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/ui/components/StationRow.tsx
var r = {
	gas: "local_gas_station",
	ev: "bolt",
	toll: "toll",
	service: "build"
};
function i({ kind: i = "gas", title: a, subtitle: o, value: s, icon: c, selected: l, onClick: u, style: d }) {
	let f = [
		a,
		o,
		s
	].filter(Boolean).join(", ");
	return /* @__PURE__ */ n(e, {
		ariaLabel: u ? f : void 0,
		leading: /* @__PURE__ */ n("span", {
			className: t.icon,
			"data-kind": i,
			children: /* @__PURE__ */ n("span", {
				className: "flow-symbol",
				"aria-hidden": "true",
				children: c ?? r[i]
			})
		}),
		title: a,
		subtitle: o,
		trailing: s ? /* @__PURE__ */ n("span", {
			className: t.value,
			children: s
		}) : void 0,
		selected: l,
		onClick: u,
		style: d
	});
}
//#endregion
export { i as StationRow };

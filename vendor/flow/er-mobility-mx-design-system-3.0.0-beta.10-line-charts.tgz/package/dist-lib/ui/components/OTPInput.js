"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./OTPInput.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { forwardRef as i, useRef as a, useState as o } from "react";
//#region src/ui/components/OTPInput.tsx
var s = i(function({ name: i, required: s, onBlur: c, id: l, length: u = 6, value: d = "", onChange: f, onComplete: p, invalid: m = !1, disabled: h = !1, autoFocus: g = !1, style: _, "aria-labelledby": v, "aria-describedby": y, "aria-invalid": b, "aria-required": x }, S) {
	let C = a(null), w = e(), [T, E] = o(!1), D = d.slice(0, u).split(""), O = Math.min(d.length, u - 1), k = (e) => {
		let t = e.replace(/\D/g, "").slice(0, u);
		f?.(t), t.length === u && p?.(t);
	};
	return /* @__PURE__ */ r("div", {
		className: t.root,
		"data-invalid": m || void 0,
		"data-disabled": h || void 0,
		onClick: () => C.current?.focus(),
		style: _,
		children: [Array.from({ length: u }, (e, r) => {
			let i = D[r] != null, a = T && r === O && !h;
			return /* @__PURE__ */ n("div", {
				"aria-hidden": "true",
				className: t.box,
				"data-filled": i || void 0,
				"data-active": a || void 0,
				"data-invalid": m || void 0,
				children: i ? /* @__PURE__ */ n("span", {
					className: t.digit,
					children: D[r]
				}) : a ? /* @__PURE__ */ n("span", { className: t.caret }) : null
			}, r);
		}), /* @__PURE__ */ n("input", {
			name: i,
			required: s,
			id: l,
			"aria-labelledby": v,
			"aria-describedby": y,
			"aria-required": x,
			ref: (e) => {
				C.current = e, typeof S == "function" ? S(e) : S && (S.current = e);
			},
			type: "text",
			inputMode: "numeric",
			autoComplete: "one-time-code",
			pattern: "[0-9]*",
			"aria-label": w("otp.label", "Código de {n} dígitos", { n: u }),
			"aria-invalid": m || b || void 0,
			value: d,
			disabled: h,
			autoFocus: g,
			onChange: (e) => k(e.target.value),
			onFocus: () => E(!0),
			onBlur: (e) => {
				E(!1), c?.(e);
			},
			className: t.input
		})]
	});
});
//#endregion
export { s as OTPInput };

import { Divider as e } from "../primitives/Divider.js";
import t from "./SectionRule.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/components/SectionRule.tsx
function i({ label: i, meta: a, style: o }) {
	return /* @__PURE__ */ r("div", {
		className: t.root,
		style: o,
		children: [
			/* @__PURE__ */ n("span", {
				"data-overline": "",
				className: t.label,
				children: i
			}),
			/* @__PURE__ */ n(e, {}),
			a && /* @__PURE__ */ n("span", {
				className: t.meta,
				children: a
			})
		]
	});
}
//#endregion
export { i as SectionRule };

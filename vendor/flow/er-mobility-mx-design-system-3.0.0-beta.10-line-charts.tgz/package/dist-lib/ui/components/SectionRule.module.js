//#region src/ui/components/SectionRule.module.css
var e = "QSU0Qa_label", t = "QSU0Qa_meta", n = "QSU0Qa_root", r = {
	label: e,
	meta: t,
	root: n
};
//#endregion
export { r as default, e as label, t as meta, n as root };

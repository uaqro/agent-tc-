"use client";
import { useLocale as e, useT as t } from "../../i18n/useSafeIntl.js";
import { Calendar as n } from "../primitives/Calendar.js";
import { Chip as r } from "../primitives/Chip.js";
import { ControlShell as i } from "../primitives/ControlShell.js";
import { Popover as a } from "../primitives/Popover.js";
import o from "./DatePicker.module.js";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
import { forwardRef as l, useState as u } from "react";
//#region src/ui/components/DatePicker.tsx
function d(e, t) {
	return (/* @__PURE__ */ new Date(e + "T00:00:00")).toLocaleDateString(t, {
		day: "numeric",
		month: "short"
	});
}
function f(e, t) {
	return (/* @__PURE__ */ new Date(e + "T00:00:00")).toLocaleDateString(t, {
		day: "numeric",
		month: "short",
		year: "numeric"
	});
}
function p() {
	let e = /* @__PURE__ */ new Date();
	return `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`;
}
function m(e) {
	if (!e?.includes("|")) return [null, null];
	let [t, n] = e.split("|");
	return [t || null, n || null];
}
var h = l(function({ "aria-labelledby": l, "aria-describedby": h, "aria-invalid": g, "aria-required": _, open: v, onOpenChange: y, value: b, onChange: x, mode: S = "single", min: C, max: w, month: T, onMonthChange: E, presets: D, disabled: O, invalid: k, id: A, placeholder: j }, M) {
	let N = t(), P = e(), [F, I] = u(!1), L = v ?? F, R = (e) => {
		v === void 0 && I(e), y?.(e);
	}, [z, B] = u(null), V = j ?? (S === "range" ? N("common.selectRange", "Seleccionar rango") : N("common.selectDate", "Seleccionar fecha")), [H, U] = S === "range" ? m(b) : [null, null], W = "";
	S === "range" ? H && U && (W = `${d(H, P)} – ${f(U, P)}`) : b && (W = f(b, P));
	let G = [];
	S === "range" ? (z && G.push(z), H && G.push(H), U && G.push(U)) : b && G.push(b);
	let K = S === "range" && z ? `${d(z, P)} – …` : void 0, q = (e, t) => {
		if (S === "single") {
			x?.(e), t();
			return;
		}
		if (!z) B(e);
		else {
			let [n, r] = e < z ? [e, z] : [z, e];
			x?.(`${n}|${r}`), B(null), t();
		}
	}, J = /* @__PURE__ */ s(i, {
		disabled: O,
		invalid: k,
		leading: /* @__PURE__ */ s("span", {
			className: "flow-symbol",
			"aria-hidden": "true",
			children: S === "range" ? "date_range" : "calendar_today"
		}),
		children: /* @__PURE__ */ s("span", {
			id: A,
			className: o.display,
			ref: M,
			role: "button",
			"aria-labelledby": l,
			"aria-describedby": h,
			"aria-invalid": g,
			"aria-required": _,
			tabIndex: O ? -1 : 0,
			"aria-haspopup": "dialog",
			"aria-expanded": L,
			"data-empty": !W || void 0,
			onKeyDown: (e) => {
				(e.key === "Enter" || e.key === " ") && (e.preventDefault(), R(!L));
			},
			children: W || V
		})
	});
	return /* @__PURE__ */ s("div", {
		className: o.root,
		children: /* @__PURE__ */ s(a, {
			trigger: J,
			placement: "bottom-start",
			open: L,
			onOpenChange: (e) => {
				O || R(e);
			},
			children: ({ close: e }) => /* @__PURE__ */ c("div", { children: [D && D.length > 0 && /* @__PURE__ */ s("div", {
				className: o.presets,
				children: D.map((t) => /* @__PURE__ */ s(r, {
					label: t.label,
					size: "sm",
					selected: b === t.value,
					onClick: () => {
						x?.(t.value), B(null), e();
					}
				}, t.label))
			}), /* @__PURE__ */ s(n, {
				selected: G,
				rangeStart: H ?? void 0,
				rangeEnd: U ?? void 0,
				min: C,
				max: w,
				month: T,
				onMonthChange: E,
				hint: K,
				onSelect: (t) => q(t, e),
				onClear: () => {
					x?.(""), B(null), e();
				},
				onToday: S === "single" ? () => {
					x?.(p()), e();
				} : void 0
			})] })
		})
	});
});
function g({ value: e, onChange: t, placeholder: n }) {
	return /* @__PURE__ */ s(h, {
		mode: "range",
		value: e,
		onChange: t,
		placeholder: n
	});
}
//#endregion
export { h as DatePicker, g as DateRangePicker };

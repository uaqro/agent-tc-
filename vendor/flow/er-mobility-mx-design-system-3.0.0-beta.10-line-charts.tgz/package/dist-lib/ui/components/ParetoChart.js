import { useT as e } from "../../i18n/useSafeIntl.js";
import { EmptyState as t } from "../primitives/EmptyState.js";
import { FlowChart as n } from "../primitives/FlowChart.js";
import { jsx as r } from "react/jsx-runtime";
import { useMemo as i } from "react";
//#region src/ui/components/ParetoChart.tsx
function a({ data: a = [], height: o = 240, format: s, threshold: c = .8, style: l }) {
	let u = e(), d = i(() => [...a].sort((e, t) => t.value - e.value), [a]), f = d.reduce((e, t) => e + t.value, 0) || 1, p = i(() => {
		let e = 0;
		return d.map((t) => {
			let n = e / f;
			return e += t.value, n < c ? "var(--viz-accent)" : "var(--viz-neutral)";
		});
	}, [
		d,
		f,
		c
	]);
	return a.length ? /* @__PURE__ */ r(n, {
		type: "pareto",
		height: o,
		format: s,
		style: l,
		itemColors: p,
		threshold: c,
		labels: d.map((e) => e.label),
		series: [{
			label: "Valor",
			values: d.map((e) => e.value)
		}],
		ariaLabel: u("pareto.summary", "Pareto: pocas causas concentran el {pct}% del total", { pct: Math.round(c * 100) })
	}) : /* @__PURE__ */ r(t, {
		icon: "bar_chart",
		title: u("common.empty", "Sin datos"),
		description: u("common.emptyDescription", "No hay datos para este periodo.")
	});
}
//#endregion
export { a as ParetoChart };

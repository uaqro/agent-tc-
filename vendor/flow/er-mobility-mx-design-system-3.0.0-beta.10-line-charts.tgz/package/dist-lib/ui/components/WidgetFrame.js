import { useT as e } from "../../i18n/useSafeIntl.js";
import { Card as t } from "../primitives/Card.js";
import { IconButton as n } from "../primitives/IconButton.js";
import { SectionHeader as r } from "../primitives/SectionHeader.js";
import { Skeleton as i } from "../primitives/Skeleton.js";
import a from "./WidgetFrame.module.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
//#region src/ui/components/WidgetFrame.tsx
function c({ title: c, description: l, children: u, hidden: d, customizing: f, loading: p, onToggle: m, actions: h, style: g }) {
	let _ = e();
	return d && !f ? null : /* @__PURE__ */ o(t, {
		padding: "none",
		style: g,
		children: /* @__PURE__ */ s("section", {
			className: a.root,
			"data-hidden": d || void 0,
			"aria-label": c,
			"aria-busy": p || void 0,
			children: [/* @__PURE__ */ o("div", {
				className: a.header,
				children: /* @__PURE__ */ o(r, {
					size: "md",
					level: 2,
					description: l,
					trailing: /* @__PURE__ */ s("div", {
						className: a.actions,
						children: [h, f && m && /* @__PURE__ */ o(n, {
							icon: d ? "visibility" : "visibility_off",
							ariaLabel: `${d ? _("common.show", "Mostrar") : _("common.hide", "Ocultar")}: ${c}`,
							onClick: m
						})]
					}),
					children: c
				})
			}), /* @__PURE__ */ o("div", {
				className: a.body,
				children: p ? /* @__PURE__ */ o(i, {
					variant: "card",
					style: {
						width: "100%",
						height: "100%",
						minHeight: 120
					}
				}) : u
			})]
		})
	});
}
//#endregion
export { c as WidgetFrame };

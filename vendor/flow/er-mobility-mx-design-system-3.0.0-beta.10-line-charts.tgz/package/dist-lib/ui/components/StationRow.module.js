//#region src/ui/components/StationRow.module.css
var e = "VM6HkW_icon", t = "VM6HkW_root", n = "VM6HkW_value", r = {
	icon: e,
	root: t,
	value: n
};
//#endregion
export { r as default, e as icon, t as root, n as value };

//#region src/ui/components/Menu.module.css
var e = "_4DqIFq_divider", t = "_4DqIFq_menuItem", n = "_4DqIFq_menuItemIcon", r = {
	divider: e,
	menuItem: t,
	menuItemIcon: n
};
//#endregion
export { r as default, e as divider, t as menuItem, n as menuItemIcon };

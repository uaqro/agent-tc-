"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./RoleMatrix.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { useRef as i, useState as a } from "react";
//#region src/ui/components/RoleMatrix.tsx
function o({ roles: o, permissions: s, values: c, onChange: l, style: u }) {
	let d = e(), f = i({}), [p, m] = a({
		fila: 0,
		col: 0
	}), h = (e, t) => {
		if (!l) return;
		let n = {};
		for (let e of Object.keys(c)) n[e] = { ...c[e] };
		n[e] = n[e] || {}, n[e][t] = !n[e][t], l(n, e, t);
	}, g = [], _ = /* @__PURE__ */ new Set();
	for (let e of s) {
		let t = e.group || "";
		t && !_.has(t) && (_.add(t), g.push({
			type: "group",
			label: t
		})), g.push({
			type: "perm",
			perm: e
		});
	}
	let v = g.filter((e) => e.type === "perm").map((e) => e.perm), y = (e, t) => {
		m(({ fila: n, col: r }) => {
			let i = Math.max(0, Math.min(v.length - 1, n + e)), a = Math.max(0, Math.min(o.length - 1, r + t));
			return (v[i] && o[a] ? f.current[`${v[i].id}:${o[a].id}`] : null)?.focus(), {
				fila: i,
				col: a
			};
		});
	};
	return /* @__PURE__ */ n("div", {
		className: t.root,
		style: u,
		children: /* @__PURE__ */ r("table", {
			className: t.table,
			role: "grid",
			onKeyDown: (e) => {
				let t = {
					ArrowRight: [0, 1],
					ArrowLeft: [0, -1],
					ArrowDown: [1, 0],
					ArrowUp: [-1, 0]
				};
				e.key in t ? (e.preventDefault(), y(t[e.key][0], t[e.key][1])) : e.key === "Home" ? (e.preventDefault(), y(0, -o.length)) : e.key === "End" && (e.preventDefault(), y(0, o.length));
			},
			children: [/* @__PURE__ */ n("thead", { children: /* @__PURE__ */ r("tr", { children: [/* @__PURE__ */ n("th", { children: d("roleMatrix.permission", "Permiso") }), o.map((e) => /* @__PURE__ */ r("th", { children: [e.label, e.locked && /* @__PURE__ */ n("span", {
				className: `flow-symbol ${t.lockIcon}`,
				"aria-hidden": "true",
				children: "lock"
			})] }, e.id))] }) }), /* @__PURE__ */ n("tbody", { children: g.map((e, i) => {
				if (e.type === "group") return /* @__PURE__ */ n("tr", {
					className: t.groupRow,
					"aria-hidden": "true",
					children: /* @__PURE__ */ n("td", {
						colSpan: o.length + 1,
						children: e.label
					})
				}, `g-${e.label}`);
				let a = e.perm;
				return /* @__PURE__ */ r("tr", {
					className: t.permRow,
					children: [/* @__PURE__ */ n("td", { children: a.hint ? /* @__PURE__ */ r("span", {
						className: t.permLabel,
						children: [a.label, /* @__PURE__ */ n("span", {
							className: t.permHint,
							children: a.hint
						})]
					}) : a.label }), o.map((e) => {
						let r = !!c[a.id]?.[e.id];
						return /* @__PURE__ */ n("td", {
							className: t.cell,
							children: /* @__PURE__ */ n("button", {
								type: "button",
								ref: (t) => {
									f.current[`${a.id}:${e.id}`] = t;
								},
								"data-bare": "",
								className: t.toggle,
								"data-on": r ? "" : void 0,
								disabled: e.locked,
								"aria-label": `${a.label} — ${e.label}${r ? ": permitido" : ": no permitido"}`,
								"aria-pressed": r,
								tabIndex: v[p.fila]?.id === a.id && o[p.col]?.id === e.id ? 0 : -1,
								onFocus: () => {
									let t = v.findIndex((e) => e.id === a.id), n = o.findIndex((t) => t.id === e.id);
									t >= 0 && n >= 0 && m({
										fila: t,
										col: n
									});
								},
								onClick: () => h(a.id, e.id),
								children: r && /* @__PURE__ */ n("span", {
									className: `flow-symbol flow-symbol--fill ${t.checkIcon}`,
									"aria-hidden": "true",
									children: "check"
								})
							})
						}, e.id);
					})]
				}, a.id);
			}) })]
		})
	});
}
//#endregion
export { o as RoleMatrix };

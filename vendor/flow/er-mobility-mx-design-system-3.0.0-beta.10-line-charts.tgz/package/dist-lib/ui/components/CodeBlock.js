"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import n from "./CodeBlock.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useState as a } from "react";
//#region src/ui/components/CodeBlock.tsx
function o({ code: o, filename: s, heading: c, trailing: l, copyable: u = !0, variant: d = "default", children: f, style: p }) {
	let m = e(), [h, g] = a(!1), _ = () => {
		let e = o ?? "", t = navigator.clipboard?.writeText(e);
		t && t.then(() => {
			g(!0), setTimeout(() => g(!1), 2e3);
		}, () => g(!1));
	};
	return d === "inline" ? /* @__PURE__ */ i("div", {
		className: n.root,
		"data-variant": "inline",
		style: p,
		children: [/* @__PURE__ */ r("span", {
			className: n.snippetText,
			children: f ?? o
		}), u && o && /* @__PURE__ */ r(t, {
			icon: h ? "check" : "content_copy",
			ariaLabel: m("common.copyCode", "Copiar código"),
			variant: "ghost",
			size: "sm",
			onClick: _
		})]
	}) : /* @__PURE__ */ i("div", {
		className: n.root,
		style: p,
		children: [(s || c || l || u) && /* @__PURE__ */ i("div", {
			className: n.header,
			children: [
				s && /* @__PURE__ */ r("span", {
					"data-overline": "",
					className: n.filename,
					children: s
				}),
				c && /* @__PURE__ */ r("span", {
					className: n.heading,
					children: c
				}),
				/* @__PURE__ */ r("span", { className: n.spacer }),
				l,
				u && o && /* @__PURE__ */ r(t, {
					icon: h ? "check" : "content_copy",
					ariaLabel: m("common.copyCode", "Copiar código"),
					variant: "ghost",
					size: "sm",
					onClick: _
				})
			]
		}), /* @__PURE__ */ r("pre", {
			className: n.pre,
			children: /* @__PURE__ */ r("code", {
				className: n.code,
				children: f ?? o
			})
		})]
	});
}
//#endregion
export { o as CodeBlock };

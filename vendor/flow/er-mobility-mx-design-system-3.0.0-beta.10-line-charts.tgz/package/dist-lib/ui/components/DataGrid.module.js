//#region src/ui/components/DataGrid.module.css
var e = "wBstYa_attachedTop", t = "wBstYa_celdaArbol", n = "wBstYa_celdaSeleccion", r = "wBstYa_chevron", i = "wBstYa_fila", a = "wBstYa_root", o = "wBstYa_row", s = "wBstYa_sangria", c = "wBstYa_sinSuperficie", l = "wBstYa_superficie", u = "wBstYa_table", d = "wBstYa_td", f = "wBstYa_th", p = "wBstYa_thButton", m = "wBstYa_vacio", h = {
	attachedTop: e,
	celdaArbol: t,
	celdaSeleccion: n,
	chevron: r,
	fila: i,
	root: a,
	row: o,
	sangria: s,
	sinSuperficie: c,
	superficie: l,
	table: u,
	td: d,
	th: f,
	thButton: p,
	vacio: m
};
//#endregion
export { e as attachedTop, t as celdaArbol, n as celdaSeleccion, r as chevron, h as default, i as fila, a as root, o as row, s as sangria, c as sinSuperficie, l as superficie, u as table, d as td, f as th, p as thButton, m as vacio };

"use client";
import { useSafeIntl as e } from "../../i18n/useSafeIntl.js";
import { ControlShell as t } from "../primitives/ControlShell.js";
import n from "./InputAmount.module.js";
import { jsx as r } from "react/jsx-runtime";
import { forwardRef as i, useRef as a } from "react";
//#region src/ui/components/InputAmount.tsx
function o(e, t) {
	let n = e.replace(/[^\d.]/g, "").split("."), r = n[0] || "", i = n.length > 1 ? n[1] : void 0;
	if (!r && i === void 0) return "";
	t.startsWith("en");
	let a = r.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	return i === void 0 ? a : `${a}.${i}`;
}
var s = i(function({ name: i, required: s, onBlur: c, id: l, value: u = "", onChange: d, placeholder: f = "0.00", currency: p = "$", locale: m, size: h = "md", disabled: g, invalid: _, style: v, "aria-labelledby": y, "aria-describedby": b, "aria-invalid": x, "aria-required": S }, C) {
	let w = e(), T = m ?? w?.locale ?? "es-MX", E = a(null), D = o(u, T), O = (e) => {
		let t = e.replace(/[^\d.,]/g, "").replace(/,/g, ""), n = t.split(".");
		n.length > 2 || n[1] && n[1].length > 2 || d?.(t);
	};
	return /* @__PURE__ */ r(t, {
		size: h,
		disabled: g,
		invalid: _,
		leading: /* @__PURE__ */ r("span", {
			className: n.currency,
			children: p
		}),
		style: v,
		children: /* @__PURE__ */ r("input", {
			name: i,
			required: s,
			onBlur: c,
			"aria-labelledby": y,
			"aria-describedby": b,
			"aria-required": S,
			ref: (e) => {
				E.current = e, typeof C == "function" ? C(e) : C && (C.current = e);
			},
			id: l,
			"data-field": "",
			className: n.input,
			inputMode: "decimal",
			value: D,
			onChange: (e) => O(e.target.value),
			placeholder: f,
			disabled: g,
			"aria-invalid": _ || x || void 0
		})
	});
});
//#endregion
export { s as InputAmount };

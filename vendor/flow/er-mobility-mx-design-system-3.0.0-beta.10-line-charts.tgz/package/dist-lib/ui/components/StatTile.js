import { Card as e } from "../primitives/Card.js";
import { Skeleton as t } from "../primitives/Skeleton.js";
import { Sparkline as n } from "../primitives/Sparkline.js";
import r from "./StatTile.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/components/StatTile.tsx
function o({ label: e, value: o, delta: c, trend: l, icon: u, tone: d = "neutral", deltaTone: f, deltaArrow: p = !0, action: m, bare: h, description: g, loading: _, style: v }) {
	let y = d === "success" ? "var(--status-success-text)" : d === "danger" ? "var(--status-danger-text)" : d === "warning" ? "var(--status-warning-text)" : "var(--text-muted)", b = c && (c.startsWith("+") || c.startsWith("↑")), x = c && (c.startsWith("-") || c.startsWith("−") || c.startsWith("↓")), S = f ?? (b ? "success" : x ? "danger" : "neutral"), C = S === "success" ? "var(--status-success-text)" : S === "danger" ? "var(--status-danger-text)" : "var(--text-muted)", w = b ? "trending_up" : x ? "trending_down" : "trending_flat";
	return _ ? s(h, v, /* @__PURE__ */ a("div", {
		className: r.root,
		"aria-busy": "true",
		children: [
			/* @__PURE__ */ i("div", {
				className: r.header,
				children: /* @__PURE__ */ i("span", {
					"data-overline": "",
					children: e
				})
			}),
			/* @__PURE__ */ i("div", {
				className: r.body,
				children: /* @__PURE__ */ i(t, {
					variant: "title",
					width: 96,
					height: 28
				})
			}),
			/* @__PURE__ */ i(t, {
				variant: "text",
				width: 64
			})
		]
	})) : s(h, v, /* @__PURE__ */ a("div", {
		className: r.root,
		children: [
			/* @__PURE__ */ a("div", {
				className: r.header,
				children: [
					u && /* @__PURE__ */ i("span", {
						className: `flow-symbol flow-symbol--md ${r.toneIcon}`,
						"aria-hidden": "true",
						style: { color: y },
						children: u
					}),
					/* @__PURE__ */ i("span", {
						"data-overline": "",
						children: e
					}),
					m && /* @__PURE__ */ i("span", {
						className: r.action,
						children: m
					})
				]
			}),
			/* @__PURE__ */ a("div", {
				className: r.body,
				children: [/* @__PURE__ */ i("div", {
					className: r.value,
					children: o
				}), l && /* @__PURE__ */ i(n, {
					values: l,
					width: 88,
					height: 32,
					showDot: !1,
					color: C,
					"aria-hidden": "true"
				})]
			}),
			c && /* @__PURE__ */ a("div", {
				className: r.delta,
				style: { color: C },
				children: [p && /* @__PURE__ */ i("span", {
					className: `flow-symbol flow-symbol--xs ${r.deltaIcon}`,
					"aria-hidden": "true",
					children: w
				}), c]
			}),
			g && /* @__PURE__ */ i("p", {
				className: r.description,
				children: g
			})
		]
	}));
}
function s(t, n, r) {
	return t ? /* @__PURE__ */ i("div", {
		style: n,
		children: r
	}) : /* @__PURE__ */ i(e, {
		padding: "md",
		style: n,
		children: r
	});
}
//#endregion
export { o as StatTile };

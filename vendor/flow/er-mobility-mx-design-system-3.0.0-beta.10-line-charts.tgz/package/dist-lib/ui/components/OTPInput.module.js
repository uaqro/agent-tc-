//#region src/ui/components/OTPInput.module.css
var e = "wdjfUa_box", t = "wdjfUa_caret", n = "wdjfUa_digit", r = "wdjfUa_input", i = "wdjfUa_root", a = {
	box: e,
	caret: t,
	digit: n,
	input: r,
	root: i
};
//#endregion
export { e as box, t as caret, a as default, n as digit, r as input, i as root };

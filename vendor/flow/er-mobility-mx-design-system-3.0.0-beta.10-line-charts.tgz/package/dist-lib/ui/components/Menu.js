"use client";
import "../primitives/avisoControlado.js";
import { Popover as e } from "../primitives/Popover.js";
import t from "./Menu.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { cloneElement as i, isValidElement as a, useRef as o, useState as s } from "react";
//#region src/ui/components/Menu.tsx
function c({ open: c, onOpenChange: l, trigger: u, items: d = [], align: f = "left", style: p }) {
	let [m, h] = s(!1), g = c ?? m, _ = (e) => {
		c === void 0 && h(e), l?.(e);
	}, v = o(null), y = () => v.current ? Array.from(v.current.querySelectorAll("[role=\"menuitem\"]:not(:disabled)")) : [], b = (e, t) => {
		let n = y();
		n.length && n[((t ? n.indexOf(t) : e === 1 ? -1 : 0) + e + n.length) % n.length].focus();
	}, x = (e) => {
		let t = y();
		t[e === "first" ? 0 : t.length - 1]?.focus();
	}, S = (e) => {
		let t = document.activeElement;
		e.key === "ArrowDown" ? (e.preventDefault(), b(1, t)) : e.key === "ArrowUp" ? (e.preventDefault(), b(-1, t)) : e.key === "Home" ? (e.preventDefault(), x("first")) : e.key === "End" && (e.preventDefault(), x("last"));
	}, C = a(u) ? i(u, {
		"aria-haspopup": "menu",
		"aria-expanded": g
	}) : u;
	return /* @__PURE__ */ n(e, {
		trigger: C,
		placement: f === "right" ? "bottom-end" : "bottom-start",
		open: g,
		onOpenChange: _,
		selfAlign: "center",
		children: ({ close: e }) => /* @__PURE__ */ n("div", {
			role: "menu",
			ref: (e) => {
				v.current = e, e && !e.contains(document.activeElement) && b(1, null);
			},
			onKeyDown: S,
			style: {
				minWidth: 180,
				...p
			},
			children: d.map((i, a) => i === "divider" ? /* @__PURE__ */ n("div", {
				role: "separator",
				className: t.divider
			}, "d" + a) : /* @__PURE__ */ r("button", {
				role: "menuitem",
				"data-bare": "",
				className: t.menuItem,
				"data-danger": i.danger || void 0,
				disabled: i.disabled,
				onClick: () => {
					i.onClick?.(), e();
				},
				children: [i.icon && /* @__PURE__ */ n("span", {
					className: `flow-symbol ${t.menuItemIcon}`,
					"aria-hidden": "true",
					children: i.icon
				}), i.label]
			}, i.label))
		})
	});
}
//#endregion
export { c as Menu };

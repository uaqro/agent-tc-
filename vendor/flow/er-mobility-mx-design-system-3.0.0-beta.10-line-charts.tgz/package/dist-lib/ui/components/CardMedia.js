import { Card as e } from "../primitives/Card.js";
import t from "./CardMedia.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/components/CardMedia.tsx
function i({ image: i, media: a, title: o, description: s, interactive: c, onClick: l, style: u, children: d }) {
	let f = a ?? (i ? /* @__PURE__ */ n("div", {
		className: t.image,
		style: { backgroundImage: `url(${i})` }
	}) : null);
	return /* @__PURE__ */ n(e, {
		padding: "none",
		interactive: c,
		onClick: c ? l : void 0,
		style: u,
		children: /* @__PURE__ */ r("div", {
			className: t.root,
			children: [f && /* @__PURE__ */ n("div", {
				className: t.media,
				children: f
			}), (o || s || d) && /* @__PURE__ */ r("div", {
				className: t.body,
				children: [
					o && /* @__PURE__ */ n("h3", {
						className: t.title,
						children: o
					}),
					s && /* @__PURE__ */ n("p", {
						className: t.description,
						children: s
					}),
					d
				]
			})]
		})
	});
}
//#endregion
export { i as CardMedia };

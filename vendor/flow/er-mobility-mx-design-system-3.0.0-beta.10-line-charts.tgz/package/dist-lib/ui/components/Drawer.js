import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import { OverlayShell as n } from "../primitives/OverlayShell.js";
import { SheetHeader as r } from "../primitives/SheetHeader.js";
import i from "./Drawer.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
import { useId as s } from "react";
//#region src/ui/components/Drawer.tsx
function c({ open: c, onClose: l, onOpenChange: u, title: d, width: f = 380, side: p = "right", footer: m, children: h }) {
	let g = () => {
		u?.(!1), l?.();
	}, _ = e(), v = s();
	return /* @__PURE__ */ a(n, {
		open: c,
		onClose: g,
		alignment: p === "left" ? "start" : "end",
		labelledBy: v,
		children: /* @__PURE__ */ o("div", {
			className: i.root,
			style: { width: f },
			children: [
				!d && /* @__PURE__ */ a("span", {
					"data-sr-only": "",
					id: v,
					children: _("drawer.label", "Panel lateral")
				}),
				/* @__PURE__ */ a(r, {
					id: d ? v : void 0,
					title: d,
					trailing: /* @__PURE__ */ a(t, {
						icon: "close",
						ariaLabel: _("common.close", "Cerrar"),
						onClick: g
					})
				}),
				/* @__PURE__ */ a("div", {
					className: i.body,
					children: h
				}),
				m && /* @__PURE__ */ a("div", {
					className: i.footer,
					children: m
				})
			]
		})
	});
}
//#endregion
export { c as Drawer };

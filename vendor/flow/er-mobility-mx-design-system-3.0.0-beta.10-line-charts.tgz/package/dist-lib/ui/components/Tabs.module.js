//#region src/ui/components/Tabs.module.css
var e = "HAvhUa_indicator", t = "HAvhUa_root", n = "HAvhUa_tab", r = "HAvhUa_tabCount", i = "HAvhUa_tabIcon", a = {
	indicator: e,
	root: t,
	tab: n,
	tabCount: r,
	tabIcon: i
};
//#endregion
export { a as default, e as indicator, t as root, n as tab, r as tabCount, i as tabIcon };

"use client";
import e from "./Accordion.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
import { useId as r, useState as i } from "react";
//#region src/ui/components/Accordion.tsx
function a({ items: a = [], defaultExpanded: o, defaultOpen: s, expandedKeys: c, onExpandedChange: l, multiple: u = !1 }) {
	let d = r(), [f, p] = i(() => new Set(o ?? (s ? [s] : []))), m = c ? new Set(c) : f, h = (e, t) => {
		let n;
		u ? (n = new Set(m), t ? n.delete(e) : n.add(e)) : n = t ? /* @__PURE__ */ new Set() : /* @__PURE__ */ new Set([e]), c === void 0 && p(n), l?.([...n]);
	};
	return /* @__PURE__ */ t("div", {
		className: e.root,
		children: a.map((r) => {
			let i = m.has(r.id), a = `${d}-${r.id}-h`, o = `${d}-${r.id}-p`;
			return /* @__PURE__ */ n("div", {
				className: e.item,
				children: [/* @__PURE__ */ n("button", {
					id: a,
					"data-bare": "",
					className: e.trigger,
					onClick: () => h(r.id, i),
					"aria-expanded": i,
					"aria-controls": o,
					children: [
						r.icon && /* @__PURE__ */ t("span", {
							className: `flow-symbol ${e.triggerIcon}`,
							"aria-hidden": "true",
							children: r.icon
						}),
						/* @__PURE__ */ t("span", {
							className: e.triggerTitle,
							children: r.title
						}),
						r.meta && /* @__PURE__ */ t("span", {
							className: e.triggerMeta,
							children: r.meta
						}),
						/* @__PURE__ */ t("span", {
							className: `flow-symbol ${e.chevron}`,
							"data-open": i || void 0,
							"aria-hidden": "true",
							children: "expand_more"
						})
					]
				}), i && /* @__PURE__ */ t("div", {
					id: o,
					role: "region",
					"aria-labelledby": a,
					className: e.panel,
					children: r.content
				})]
			}, r.id);
		})
	});
}
//#endregion
export { a as Accordion };

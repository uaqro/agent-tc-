//#region src/ui/components/TransactionRow.module.css
var e = "RbBQSq_amount", t = "RbBQSq_icon", n = "RbBQSq_status", r = "RbBQSq_title", i = {
	amount: e,
	icon: t,
	status: n,
	title: r
};
//#endregion
export { e as amount, i as default, t as icon, n as status, r as title };

//#region src/ui/components/ActiveFilters.module.css
var e = "L_3imG_clear", t = "L_3imG_item", n = "L_3imG_list", r = "L_3imG_root", i = {
	clear: e,
	item: t,
	list: n,
	root: r
};
//#endregion
export { e as clear, i as default, t as item, n as list, r as root };

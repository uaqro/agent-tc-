//#region src/ui/components/RoleMatrix.module.css
var e = "ri8xba_cell", t = "ri8xba_checkIcon", n = "ri8xba_groupRow", r = "ri8xba_lockIcon", i = "ri8xba_permHint", a = "ri8xba_permLabel", o = "ri8xba_permRow", s = "ri8xba_root", c = "ri8xba_table", l = "ri8xba_toggle", u = {
	cell: e,
	checkIcon: t,
	groupRow: n,
	lockIcon: r,
	permHint: i,
	permLabel: a,
	permRow: o,
	root: s,
	table: c,
	toggle: l
};
//#endregion
export { e as cell, t as checkIcon, u as default, n as groupRow, r as lockIcon, i as permHint, a as permLabel, o as permRow, s as root, c as table, l as toggle };

import { useT as e } from "../../i18n/useSafeIntl.js";
import { ChartLegend as t } from "../primitives/ChartLegend.js";
import { EmptyState as n } from "../primitives/EmptyState.js";
import { FlowChart as r } from "../primitives/FlowChart.js";
import i from "./Donut.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/ui/components/Donut.tsx
function s({ segments: s = [], size: c = 240, thickness: l, centerLabel: u, centerValue: d, formatValue: f, valueLabel: p, legend: m = !0, style: h }) {
	let g = e();
	if (!s.length) return /* @__PURE__ */ a(n, {
		icon: "donut_small",
		title: g("common.empty", "Sin datos"),
		description: g("common.emptyDescription", "No hay datos para este periodo.")
	});
	let _ = s.reduce((e, t) => e + t.value, 0) || 1, v = s.length <= 3 ? [
		"var(--viz-1)",
		"var(--viz-accent)",
		"var(--viz-neutral)"
	] : [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	].map((e) => `var(--viz-${e})`), y = s.map((e, t) => ({
		...e,
		color: e.color || v[t % v.length]
	})), b = /* @__PURE__ */ a(r, {
		type: "donut",
		height: c,
		thickness: l ?? c / 6,
		format: f,
		valueLabel: p,
		legend: !1,
		option: { aria: { decal: { show: !1 } } },
		series: [{
			label: "Donut",
			data: y
		}],
		ariaLabel: g("donut.breakdown", "Reparto: {series}", { series: y.map((e) => `${e.label}: ${Math.round(e.value / _ * 100)}%`).join(", ") })
	}), x = (d != null || u) && /* @__PURE__ */ o("div", {
		className: i.center,
		children: [d != null && /* @__PURE__ */ a("div", {
			className: i.centerValue,
			children: d
		}), u && /* @__PURE__ */ a("div", {
			className: i.centerLabel,
			children: u
		})]
	});
	return /* @__PURE__ */ o("div", {
		className: i.root,
		style: {
			"--donut-size": `${c}px`,
			...h
		},
		children: [/* @__PURE__ */ o("div", {
			className: i.ring,
			style: {
				width: c,
				height: c
			},
			children: [b, x]
		}), m && /* @__PURE__ */ a("div", {
			className: i.legend,
			children: /* @__PURE__ */ a(t, {
				direction: "vertical",
				size: "md",
				width: "fill",
				items: y.map((e) => ({
					label: e.label,
					color: e.color,
					value: Math.round(e.value / _ * 100) + "%",
					icon: e.icon,
					detail: f?.(e.value)
				}))
			})
		})]
	});
}
//#endregion
export { s as Donut };

import e from "./PeekSheet.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/components/PeekSheet.tsx
function r({ title: r, children: i, style: a }) {
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: a,
		children: [
			/* @__PURE__ */ t("span", { className: e.handle }),
			/* @__PURE__ */ t("span", {
				className: e.title,
				children: r
			}),
			/* @__PURE__ */ t("div", {
				className: e.list,
				children: i
			})
		]
	});
}
//#endregion
export { r as PeekSheet };

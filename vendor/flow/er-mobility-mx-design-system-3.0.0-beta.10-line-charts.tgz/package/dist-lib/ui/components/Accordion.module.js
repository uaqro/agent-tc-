//#region src/ui/components/Accordion.module.css
var e = "mb4lPG_chevron", t = "mb4lPG_item", n = "mb4lPG_panel", r = "mb4lPG_root", i = "mb4lPG_trigger", a = "mb4lPG_triggerIcon", o = "mb4lPG_triggerMeta", s = "mb4lPG_triggerTitle", c = {
	chevron: e,
	item: t,
	panel: n,
	root: r,
	trigger: i,
	triggerIcon: a,
	triggerMeta: o,
	triggerTitle: s
};
//#endregion
export { e as chevron, c as default, t as item, n as panel, r as root, i as trigger, a as triggerIcon, o as triggerMeta, s as triggerTitle };

//#region src/ui/components/Dialog.module.css
var e = "vKToFa_actions", t = "vKToFa_description", n = "vKToFa_root", r = "vKToFa_title", i = {
	actions: e,
	description: t,
	root: n,
	title: r
};
//#endregion
export { e as actions, i as default, t as description, n as root, r as title };

import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import n from "./BalanceDisplay.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/components/BalanceDisplay.tsx
function a({ label: a, variant: o = "surface", value: s, hidden: c, onToggleHidden: l, style: u }) {
	let d = e(), f = a ?? (o === "art" ? void 0 : d("balance.label", "Balance total"));
	return /* @__PURE__ */ i("div", {
		className: n.root,
		"data-variant": o,
		style: u,
		children: [f && /* @__PURE__ */ r("span", {
			"data-overline": "",
			children: f
		}), /* @__PURE__ */ i("div", {
			className: n.row,
			children: [/* @__PURE__ */ r("span", {
				className: n.value,
				children: c ? "••••••" : s
			}), l && /* @__PURE__ */ r(t, {
				icon: c ? "visibility" : "visibility_off",
				ariaLabel: c ? d("balance.show", "Mostrar saldo") : d("balance.hide", "Ocultar saldo"),
				variant: "ghost",
				size: "sm",
				onClick: l
			})]
		})]
	});
}
//#endregion
export { a as BalanceDisplay };

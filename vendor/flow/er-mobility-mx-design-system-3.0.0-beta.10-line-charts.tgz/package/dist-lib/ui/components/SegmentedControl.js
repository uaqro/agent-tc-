"use client";
import { useRovingTabs as e } from "../../hooks/useRovingTabs.js";
import t from "./SegmentedControl.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { useLayoutEffect as i, useRef as a, useState as o } from "react";
//#region src/ui/components/SegmentedControl.tsx
function s({ items: s, value: c, onChange: l, size: u = "md", id: d, "aria-describedby": f, "aria-invalid": p, "aria-required": m, ariaLabel: h, "aria-labelledby": g, style: _ }) {
	let v = a(null), [y, b] = o(null);
	i(() => {
		let e = C.current[c];
		if (!e) return;
		let t = () => {
			let t = e.offsetLeft, n = e.offsetWidth;
			b((e) => e && e.left === t && e.width === n ? e : {
				left: t,
				width: n
			});
		};
		if (t(), typeof ResizeObserver > "u") return;
		let n = new ResizeObserver(t);
		return n.observe(e), v.current && n.observe(v.current), () => n.disconnect();
	}, [c, s.length]);
	let { alTeclado: x, pestana: S, refs: C } = e(s.map((e) => e.value), c, l);
	return /* @__PURE__ */ r("div", {
		ref: v,
		id: d,
		role: "tablist",
		"aria-describedby": f,
		"aria-invalid": p,
		"aria-required": m,
		"aria-label": h,
		"aria-labelledby": g,
		className: t.root,
		"data-size": u === "md" ? void 0 : u,
		style: _,
		onKeyDown: x,
		children: [y && /* @__PURE__ */ n("span", {
			"aria-hidden": "true",
			className: t.indicator,
			style: {
				left: y.left,
				width: y.width
			}
		}), s.map((e) => {
			let i = e.value === c;
			return /* @__PURE__ */ r("button", {
				...S(e.value),
				role: "tab",
				type: "button",
				"aria-selected": i,
				"data-active": i || void 0,
				"data-bare": "",
				className: t.segment,
				onClick: () => l?.(e.value),
				children: [e.icon && /* @__PURE__ */ n("span", {
					className: `flow-symbol${i ? " flow-symbol--fill" : ""} ${t.segmentIcon}`,
					"aria-hidden": "true",
					children: e.icon
				}), e.label]
			}, e.value);
		})]
	});
}
//#endregion
export { s as SegmentedControl };

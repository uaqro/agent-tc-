import { useT as e } from "../../i18n/useSafeIntl.js";
import { DataGrid as t } from "./DataGrid.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/ui/components/TableTree.tsx
function r({ columns: r, rows: i, rowKey: a = "id", onRowClick: o, selectedKey: s, defaultExpanded: c, expandedKeys: l, onExpandedChange: u, style: d }) {
	let f = e();
	return /* @__PURE__ */ n(t, {
		tree: !0,
		columns: r,
		rows: i,
		rowKey: a,
		onRowClick: o,
		selectedKey: s,
		defaultExpandedKeys: c,
		expandedKeys: l,
		onExpandedChange: u ? (e) => u(e.map(String)) : void 0,
		expandLabel: f("common.expand", "Expandir"),
		collapseLabel: f("common.collapse", "Colapsar"),
		sortable: !1,
		density: "compact",
		style: d
	});
}
//#endregion
export { r as TableTree };

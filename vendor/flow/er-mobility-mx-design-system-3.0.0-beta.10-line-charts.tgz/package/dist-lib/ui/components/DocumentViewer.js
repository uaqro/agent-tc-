"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import { OverlayShell as n } from "../primitives/OverlayShell.js";
import r from "./DocumentViewer.module.js";
import { Fragment as i, jsx as a, jsxs as o } from "react/jsx-runtime";
import { useId as s, useState as c } from "react";
//#region src/ui/components/DocumentViewer.tsx
function l({ title: l, children: u, actions: d, expandable: f = !0, expanded: p, onExpandedChange: m, height: h, style: g }) {
	let _ = e(), v = s(), [y, b] = c(!1), x = p ?? y, S = (e) => {
		p === void 0 && b(e), m?.(e);
	}, C = (e) => /* @__PURE__ */ o("div", {
		className: r.header,
		children: [
			/* @__PURE__ */ a("span", {
				"data-truncate": "",
				className: r.title,
				id: e ? v : void 0,
				children: l
			}),
			d && /* @__PURE__ */ a("div", {
				className: r.actions,
				children: d
			}),
			f && /* @__PURE__ */ a(t, {
				icon: e ? "close_fullscreen" : "open_in_full",
				ariaLabel: e ? _("documentViewer.collapse", "Salir de pantalla completa") : _("documentViewer.expand", "Pantalla completa"),
				onClick: () => S(!e)
			})
		]
	});
	return /* @__PURE__ */ o(i, { children: [/* @__PURE__ */ o("div", {
		className: r.frame,
		style: {
			...h == null ? {} : { height: h },
			...g
		},
		children: [C(!1), /* @__PURE__ */ a("div", {
			className: r.body,
			children: x ? null : u
		})]
	}), /* @__PURE__ */ a(n, {
		open: x,
		onClose: () => S(!1),
		labelledBy: v,
		children: /* @__PURE__ */ o("div", {
			className: r.fullscreen,
			children: [C(!0), /* @__PURE__ */ a("div", {
				className: r.body,
				children: x ? u : null
			})]
		})
	})] });
}
//#endregion
export { l as DocumentViewer };

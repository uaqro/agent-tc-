import e from "./ListRow.module.js";
import { Fragment as t, jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/components/ListRow.tsx
function i({ leading: i, title: a, subtitle: o, trailing: s, ariaLabel: c, selected: l, onClick: u, style: d }) {
	let f = [
		a,
		o,
		s
	].filter((e) => typeof e == "string" || typeof e == "number").join(", "), p = /* @__PURE__ */ r(t, { children: [
		i,
		/* @__PURE__ */ r("span", {
			className: e.textos,
			children: [/* @__PURE__ */ n("span", {
				"data-truncate": "",
				className: e.title,
				children: a
			}), o && /* @__PURE__ */ n("span", {
				"data-truncate": "",
				className: e.subtitle,
				children: o
			})]
		}),
		s
	] });
	return u ? /* @__PURE__ */ n("button", {
		type: "button",
		"data-bare": "",
		className: e.root,
		"data-selected": l || void 0,
		"aria-label": c ?? f ?? void 0,
		onClick: u,
		style: d,
		children: p
	}) : /* @__PURE__ */ n("div", {
		className: e.root,
		"data-selected": l || void 0,
		style: d,
		children: p
	});
}
//#endregion
export { i as ListRow };

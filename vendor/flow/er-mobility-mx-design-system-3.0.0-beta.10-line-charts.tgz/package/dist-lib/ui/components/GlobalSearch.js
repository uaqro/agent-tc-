"use client";
import { Badge as e } from "../primitives/Badge.js";
import { useT as t } from "../../i18n/useSafeIntl.js";
import { Chip as n } from "../primitives/Chip.js";
import { ControlShell as r } from "../primitives/ControlShell.js";
import { EmptyState as ee } from "../primitives/EmptyState.js";
import { IconButton as te } from "../primitives/IconButton.js";
import { OverlayShell as i } from "../primitives/OverlayShell.js";
import { Spinner as a } from "../primitives/Spinner.js";
import o from "./GlobalSearch.module.js";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { useCallback as u, useEffect as d, useId as f, useMemo as p, useRef as m, useState as h } from "react";
//#region src/ui/components/GlobalSearch.tsx
var g = typeof navigator < "u" && /Mac|iPhone|iPad/.test(navigator.platform) ? "⌘K" : "Ctrl+K";
function _({ mode: _ = "palette", open: v = !1, onOpenChange: y, value: b = "", onValueChange: x, results: S = [], groupOrder: C = [], loading: w = !1, recents: T = [], suggestions: E = [], onSelect: D, onClearRecents: O, placeholder: k, emptyTitle: ne, emptyDescription: A, emptyHint: j, minChars: M = 1, shortcut: N = !0, noResultsTitle: P, style: F }) {
	let I = t(), L = f(), R = k ?? I("common.search", "Busca unidades, conductores, viajes…"), [z, B] = h(0), V = m(null), H = m(null), U = m(null), W = b.length < M && T.length > 0, G = W ? T : S, K = p(() => {
		let e = /* @__PURE__ */ new Map();
		return G.forEach((t) => {
			let n = W ? "Recientes" : t.group || "Otros";
			e.has(n) || e.set(n, []), e.get(n).push(t);
		}), Array.from(e.keys()).sort((e, t) => {
			let n = C.indexOf(e), r = C.indexOf(t);
			return n === -1 && r === -1 ? e.localeCompare(t) : n === -1 ? 1 : r === -1 ? -1 : n - r;
		}).map((t) => ({
			name: t,
			items: e.get(t)
		}));
	}, [
		G,
		C,
		W
	]), q = p(() => K.flatMap((e) => e.items), [K]);
	d(() => {
		B(0);
	}, [b, W]), d(() => {
		if (!N) return;
		let e = (e) => {
			(e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k" && (e.preventDefault(), _ === "inline" ? (V.current?.focus(), y?.(!0)) : y?.(!v));
		};
		return document.addEventListener("keydown", e), () => document.removeEventListener("keydown", e);
	}, [
		_,
		v,
		y,
		N
	]);
	let J = m(null);
	d(() => {
		_ === "palette" && (v ? (J.current = document.activeElement, V.current?.focus()) : J.current &&= (J.current.focus?.(), null));
	}, [_, v]), d(() => {
		if (_ !== "inline" || !v) return;
		let e = (e) => {
			U.current && !U.current.contains(e.target) && y?.(!1);
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, [
		_,
		v,
		y
	]);
	let Y = u((e) => {
		e && (D?.(e), y?.(!1));
	}, [D, y]), X = u((e) => {
		if (e.key === "ArrowDown" || e.key === "ArrowUp") {
			if (e.preventDefault(), !q.length) return;
			let t = e.key === "ArrowDown" ? 1 : -1, n = (z + t + q.length) % q.length;
			B(n);
			let r = H.current?.querySelector(`[data-idx="${n}"]`);
			r && r.scrollIntoView?.({ block: "nearest" });
		} else e.key === "Enter" ? (e.preventDefault(), Y(q[z])) : e.key === "Escape" && (e.preventDefault(), y?.(!1));
	}, [
		q,
		z,
		Y,
		y
	]), re = (e) => {
		if (!b || W) return e;
		let t = e.toLowerCase().indexOf(b.toLowerCase());
		return t === -1 ? e : /* @__PURE__ */ l(s, { children: [
			e.slice(0, t),
			/* @__PURE__ */ c("mark", {
				className: o.highlight,
				children: e.slice(t, t + b.length)
			}),
			e.slice(t + b.length)
		] });
	}, Z = /* @__PURE__ */ c("div", {
		className: o.searchBar,
		"data-mode": _,
		children: /* @__PURE__ */ c(r, {
			size: _ === "inline" ? "sm" : "md",
			leading: /* @__PURE__ */ c("span", {
				className: `flow-symbol ${o.searchIcon}`,
				"aria-hidden": "true",
				children: "search"
			}),
			trailing: b ? /* @__PURE__ */ c(te, {
				icon: "close",
				ariaLabel: I("search.clear", "Limpiar búsqueda"),
				size: "sm",
				onClick: () => {
					x?.(""), V.current?.focus();
				}
			}) : _ === "palette" ? /* @__PURE__ */ c(e, {
				as: "kbd",
				"aria-hidden": "true",
				children: g
			}) : void 0,
			children: /* @__PURE__ */ c("input", {
				ref: V,
				type: "text",
				role: "combobox",
				"aria-expanded": !0,
				"aria-controls": "flow-search-list",
				"aria-activedescendant": q[z] ? `flow-search-opt-${z}` : void 0,
				"aria-label": R,
				autoComplete: "off",
				placeholder: R,
				value: b,
				onChange: (e) => x?.(e.target.value),
				onKeyDown: X,
				"data-field": "",
				className: o.input,
				"data-mode": _
			})
		})
	}), ie = E.length > 0 && b.length < M ? /* @__PURE__ */ c("div", {
		className: o.suggestions,
		children: E.map((e) => /* @__PURE__ */ c(n, {
			label: e,
			size: "sm",
			mono: !0,
			onClick: () => x?.(e)
		}, e))
	}) : null, Q = w && /* @__PURE__ */ l("div", {
		className: o.loadingState,
		"aria-live": "polite",
		children: [/* @__PURE__ */ c(a, {
			size: 14,
			label: I("search.loading", "Buscando")
		}), I("search.searching", "Buscando…")]
	}), $;
	if (w && !q.length) $ = Q;
	else if (!q.length) $ = /* @__PURE__ */ c(ee, {
		icon: b.length >= M ? "search_off" : "search",
		title: b.length >= M ? P ? P(b) : `Sin resultados para "${b}"` : ne ?? "Busca en toda la plataforma",
		description: b.length >= M ? j ?? A ?? "Prueba con una placa, un nombre o un ID de viaje." : A ?? "Prueba con una placa, un nombre o un ID de viaje."
	});
	else {
		let e = -1;
		$ = /* @__PURE__ */ l("div", {
			id: "flow-search-list",
			role: "listbox",
			ref: H,
			className: o.list,
			"data-mode": _,
			children: [Q, K.map((t) => /* @__PURE__ */ l("div", {
				role: "group",
				"aria-labelledby": `flow-sg-${t.name}`,
				children: [/* @__PURE__ */ l("div", {
					id: `flow-sg-${t.name}`,
					"data-overline": "",
					className: o.groupLabel,
					children: [t.name, W && O && /* @__PURE__ */ c("button", {
						type: "button",
						"data-bare": "",
						"data-overline": "",
						className: o.clearRecentsBtn,
						onClick: O,
						children: I("common.clear", "Limpiar")
					})]
				}), t.items.map((t) => {
					e += 1;
					let n = e, r = n === z;
					return /* @__PURE__ */ l("div", {
						id: `flow-search-opt-${n}`,
						"data-idx": n,
						role: "option",
						"aria-selected": r,
						className: o.option,
						"data-active": r || void 0,
						onMouseEnter: () => B(n),
						onClick: () => Y(t),
						children: [
							t.icon && /* @__PURE__ */ c("span", {
								className: `flow-symbol ${o.optionIcon}`,
								"aria-hidden": "true",
								"data-active": r || void 0,
								children: t.icon
							}),
							/* @__PURE__ */ l("div", {
								className: o.optionBody,
								children: [/* @__PURE__ */ c("div", {
									"data-truncate": "",
									className: o.optionLabel,
									"data-mono": t.mono || void 0,
									children: re(t.label)
								}), t.meta && /* @__PURE__ */ c("div", {
									"data-truncate": "",
									className: o.optionMeta,
									children: t.meta
								})]
							}),
							t.trailing && /* @__PURE__ */ c("div", {
								className: o.optionTrailing,
								children: t.trailing
							}),
							r && /* @__PURE__ */ c("span", {
								className: `flow-symbol ${o.optionReturn}`,
								"aria-hidden": "true",
								children: "keyboard_return"
							})
						]
					}, t.id);
				})]
			}, t.name))]
		});
	}
	let ae = _ === "palette" && /* @__PURE__ */ l("div", {
		className: o.footer,
		children: [
			/* @__PURE__ */ c("span", { children: I("search.hintNavigate", "up/down navegar") }),
			/* @__PURE__ */ c("span", { children: I("search.hintOpen", "enter abrir") }),
			/* @__PURE__ */ c("span", { children: I("search.hintClose", "esc cerrar") })
		]
	});
	return _ === "inline" ? /* @__PURE__ */ l("div", {
		ref: U,
		className: o.inlineRoot,
		style: F,
		children: [/* @__PURE__ */ c("div", {
			className: o.inlineField,
			onFocus: () => y?.(!0),
			children: Z
		}), v && /* @__PURE__ */ c("div", {
			className: o.inlineDrop,
			children: $
		})]
	}) : /* @__PURE__ */ c(i, {
		open: v,
		onClose: () => y?.(!1),
		alignment: "top",
		labelledBy: L,
		children: /* @__PURE__ */ l("div", {
			className: o.paletteCard,
			style: F,
			children: [
				/* @__PURE__ */ c("span", {
					"data-sr-only": "",
					id: L,
					children: I("globalsearch.label", "Búsqueda global")
				}),
				Z,
				ie,
				$,
				ae
			]
		})
	});
}
//#endregion
export { _ as GlobalSearch };

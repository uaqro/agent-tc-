"use client";
import { Badge as e } from "../primitives/Badge.js";
import { useT as t } from "../../i18n/useSafeIntl.js";
import { IconButton as n } from "../primitives/IconButton.js";
import { OverlayShell as r } from "../primitives/OverlayShell.js";
import i from "./KanbanBoard.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
import { useCallback as s, useEffect as c, useId as l, useRef as u, useState as d } from "react";
//#region src/ui/components/KanbanBoard.tsx
var f = {
	position: "absolute",
	width: 1,
	height: 1,
	margin: -1,
	padding: 0,
	overflow: "hidden",
	clip: "rect(0 0 0 0)",
	whiteSpace: "nowrap",
	border: 0
};
function p({ columns: p, items: m, columnKey: h = "columnId", itemKey: g = "id", renderCard: _, renderActions: v, renderColumnHeader: y, columnStyle: b, onMove: x, onAdvance: S, abandonColumn: C, renderDetail: w, detailKey: T, onDetailChange: E, style: D }) {
	let O = t(), k = l(), [A, j] = d(null), [M, N] = d(null), [P, F] = d(null), [I, L] = d(""), [R, z] = d(null), [B, V] = d(null), H = u({}), U = u(null), W = C ? p.concat([{
		...C,
		abandon: !0
	}]) : p, G = (e) => String(e[g]), K = {};
	W.forEach((e) => {
		K[e.id] = [];
	}), m.forEach((e) => {
		let t = String(e[h]);
		K[t] && K[t].push(e);
	});
	let q = T !== void 0, J = q ? T : R, Y = s((e) => {
		q || z(e), E?.(e);
	}, [q, E]);
	c(() => {
		if (!P) return;
		let e = setTimeout(() => F(null), 1100);
		return () => clearTimeout(e);
	}, [P]), c(() => {
		if (!B) return;
		let e = H.current[B];
		e?.focus && e.focus(), V(null);
	}, [B]);
	function X(e, t) {
		let n = W.find((e) => e.id === t), r = m.find((t) => G(t) === String(e));
		return !n || !r || String(r[h]) === String(t) ? !1 : n.limit && K[t].length >= n.limit ? (F(t), L(`${n.label} esta en su limite de ${n.limit}. La tarjeta no se movio.`), !1) : x?.(String(e), t) === !1 ? (F(t), L(`El movimiento a ${n.label} no se acepto. La tarjeta no se movio.`), !1) : (L(`Movida a ${n.label}.`), V(String(e)), !0);
	}
	function Z(e, t) {
		let n = W[t + 1];
		if (n && !n.abandon) {
			if (S) {
				S(String(e)), L(`Avanzada a ${n.label}.`), V(String(e));
				return;
			}
			X(e, n.id);
		}
	}
	function Q(e, t) {
		for (let n = e; n >= 0 && n < W.length; n += e <= n ? 1 : -1) {
			let r = K[W[n].id];
			if (!r.length) {
				if (n === e) continue;
				break;
			}
			let i = r[Math.max(0, Math.min(t, r.length - 1))], a = H.current[G(i)];
			if (a?.focus) {
				a.focus();
				return;
			}
			break;
		}
	}
	function ee(e, t, n, r) {
		let i = e.key;
		if (i === "Enter" || i === " ") {
			if (!w) return;
			e.preventDefault(), Y(G(t));
			return;
		}
		let a = i === "ArrowRight" ? 1 : i === "ArrowLeft" ? -1 : 0, o = i === "ArrowDown" ? 1 : i === "ArrowUp" ? -1 : 0;
		if (a || o) {
			if (e.preventDefault(), a && e.shiftKey) {
				let e = W[n + a];
				e && X(G(t), e.id);
				return;
			}
			o ? Q(n, r + o) : Q(n + a, r);
		}
	}
	let $ = J == null ? null : m.find((e) => G(e) === String(J));
	return /* @__PURE__ */ o("div", {
		className: i.root,
		style: D,
		children: [
			/* @__PURE__ */ a("div", {
				role: "status",
				"aria-live": "polite",
				style: f,
				children: I
			}),
			/* @__PURE__ */ a("div", {
				ref: U,
				onDragOver: (e) => {
					let t = U.current;
					if (!t) return;
					let n = t.getBoundingClientRect();
					e.clientX > n.right - 72 ? t.scrollLeft += 20 : e.clientX < n.left + 72 && (t.scrollLeft -= 20);
				},
				className: i.pista,
				children: W.map((t, r) => {
					let s = K[t.id], c = !!t.limit && s.length >= t.limit, l = M === t.id, u = P === t.id, d = typeof b == "function" ? b(t, {
						atLimit: c,
						isOver: l,
						isReject: u
					}) : b;
					return /* @__PURE__ */ o("section", {
						role: "group",
						"aria-label": `${t.label}, ${s.length} tarjeta${s.length === 1 ? "" : "s"}${t.limit ? `, limite ${t.limit}` : ""}${t.abandon ? ", columna de salida" : ""}`,
						onDragOver: (e) => {
							e.preventDefault(), M !== t.id && N(t.id);
						},
						onDragLeave: (e) => {
							e.currentTarget === e.target && N(null);
						},
						onDrop: (e) => {
							e.preventDefault(), A && X(A, t.id), j(null), N(null);
						},
						className: i.columna,
						"data-abandon": t.abandon || void 0,
						"data-over": l || void 0,
						"data-reject": u || void 0,
						style: d,
						children: [y ? y(t, {
							count: s.length,
							atLimit: c,
							isOver: l
						}) : /* @__PURE__ */ o("header", {
							className: i.cabeceraColumna,
							children: [
								t.color && !t.abandon && /* @__PURE__ */ a("span", {
									"aria-hidden": "true",
									className: i.puntoColumna,
									style: { background: t.color }
								}),
								/* @__PURE__ */ a("span", {
									"data-overline": "",
									className: i.columnLabel,
									"data-abandon": t.abandon || void 0,
									children: t.label
								}),
								/* @__PURE__ */ a(e, {
									tone: c ? "warning" : "neutral",
									children: `${s.length}${t.limit ? `/${t.limit}` : ""}`
								})
							]
						}), /* @__PURE__ */ o("div", {
							className: i.lista,
							children: [s.map((e, c) => {
								let l = G(e), u = A === l, d = !t.abandon && !!W[r + 1] && !W[r + 1].abandon;
								return /* @__PURE__ */ o("div", {
									ref: (e) => {
										e ? H.current[l] = e : delete H.current[l];
									},
									role: "button",
									tabIndex: 0,
									"aria-roledescription": O("kanban.cardRole", "tarjeta de tablero"),
									draggable: !0,
									onDragStart: (e) => {
										j(l), e.dataTransfer.effectAllowed = "move", e.dataTransfer.setData("text/plain", l);
									},
									onDragEnd: () => {
										j(null), N(null);
									},
									onKeyDown: (t) => ee(t, e, r, c),
									onClick: w ? () => Y(l) : void 0,
									className: i.tarjeta,
									"data-abrible": w ? "" : void 0,
									"data-dragging": u || void 0,
									children: [
										_(e, { dragging: u }),
										/* @__PURE__ */ o("span", {
											style: f,
											children: [" ", O("kanban.cardPosition", "— columna {columna}, {n} de {total}", {
												columna: t.label,
												n: c + 1,
												total: s.length
											})]
										}),
										v ? /* @__PURE__ */ a("div", {
											className: i.avanzar,
											onClick: (e) => e.stopPropagation(),
											onKeyDown: (e) => e.stopPropagation(),
											children: v(e, {
												canAdvance: d,
												advance: () => Z(l, r)
											})
										}) : d && /* @__PURE__ */ a("div", {
											className: i.avanzar,
											children: /* @__PURE__ */ a(n, {
												icon: "arrow_forward",
												variant: "ghost",
												ariaLabel: O("kanban.advanceTo", "Avanzar a {columna}", { columna: W[r + 1].label }),
												onClick: (e) => {
													e.stopPropagation(), Z(l, r);
												}
											})
										})
									]
								}, l);
							}), s.length === 0 && /* @__PURE__ */ a("p", {
								className: i.emptyHint,
								children: t.abandon ? O("common.emptyColumnAbandon", "Sin salidas") : O("common.emptyColumn", "Vacía")
							})]
						})]
					}, t.id);
				})
			}),
			w && $ && /* @__PURE__ */ a(r, {
				open: !0,
				onClose: () => Y(null),
				alignment: "end",
				labelledBy: k,
				children: /* @__PURE__ */ o("aside", {
					className: i.panel,
					children: [/* @__PURE__ */ o("header", {
						className: i.cabeceraPanel,
						children: [/* @__PURE__ */ a("span", {
							"data-overline": "",
							className: i.detailLabel,
							id: k,
							children: O("kanban.detail", "Detalle")
						}), /* @__PURE__ */ a(n, {
							icon: "close",
							variant: "ghost",
							ariaLabel: O("common.close", "Cerrar"),
							onClick: () => Y(null)
						})]
					}), /* @__PURE__ */ a("div", {
						className: i.cuerpoPanel,
						children: w($)
					})]
				})
			})
		]
	});
}
//#endregion
export { p as KanbanBoard };

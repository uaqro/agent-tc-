//#region src/ui/components/KanbanBoard.module.css
var e = "Sb3L0a_avanzar", t = "Sb3L0a_cabeceraColumna", n = "Sb3L0a_cabeceraPanel", r = "Sb3L0a_columna", i = "Sb3L0a_columnLabel", a = "Sb3L0a_cuerpoPanel", o = "Sb3L0a_detailLabel", s = "Sb3L0a_emptyHint", c = "Sb3L0a_lista", l = "Sb3L0a_panel", u = "Sb3L0a_pista", d = "Sb3L0a_puntoColumna", f = "Sb3L0a_root", p = "Sb3L0a_tarjeta", m = {
	avanzar: e,
	cabeceraColumna: t,
	cabeceraPanel: n,
	columna: r,
	columnLabel: i,
	cuerpoPanel: a,
	detailLabel: o,
	emptyHint: s,
	lista: c,
	panel: l,
	pista: u,
	puntoColumna: d,
	root: f,
	tarjeta: p
};
//#endregion
export { e as avanzar, t as cabeceraColumna, n as cabeceraPanel, i as columnLabel, r as columna, a as cuerpoPanel, m as default, o as detailLabel, s as emptyHint, c as lista, l as panel, u as pista, d as puntoColumna, f as root, p as tarjeta };

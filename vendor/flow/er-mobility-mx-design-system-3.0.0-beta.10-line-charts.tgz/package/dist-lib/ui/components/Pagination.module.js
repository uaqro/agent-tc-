//#region src/ui/components/Pagination.module.css
var e = "lXdSLa_page", t = "lXdSLa_range", n = "lXdSLa_root", r = "lXdSLa_sizer", i = {
	page: e,
	range: t,
	root: n,
	sizer: r
};
//#endregion
export { i as default, e as page, t as range, n as root, r as sizer };

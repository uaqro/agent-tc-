import { useLocale as e, useT as t } from "../../i18n/useSafeIntl.js";
import { EmptyState as n } from "../primitives/EmptyState.js";
import r from "./GanttChart.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/components/GanttChart.tsx
function o(e) {
	let t = new Map(e.map((e) => [e.id, e])), n = /* @__PURE__ */ new Map(), r = [], i = (e) => {
		n.set(e, 1), r.push(e);
		for (let a of t.get(e)?.dependsOn || []) if (t.has(a)) {
			if (n.get(a) === 1) return r.slice(r.indexOf(a)).concat(a);
			if (!n.has(a)) {
				let e = i(a);
				if (e) return e;
			}
		}
		return n.set(e, 2), r.pop(), null;
	};
	for (let t of e) if (!n.has(t.id)) {
		let e = i(t.id);
		if (e) return e;
	}
	return null;
}
function s({ tasks: s, style: c }) {
	let l = t(), u = e();
	if (!s.length) return /* @__PURE__ */ i(n, {
		icon: "view_timeline",
		title: l("common.empty", "Sin datos"),
		description: l("common.emptyDescription", "No hay datos para este periodo."),
		style: c
	});
	let d = s.flatMap((e) => [new Date(e.start).getTime(), new Date(e.end).getTime()]), f = Math.min(...d), p = Math.max(...d) - f || 1, m = (e) => new Date(e).toLocaleDateString(u, {
		day: "numeric",
		month: "short"
	}), h = (e) => (new Date(e).getTime() - f) / p * 100, g = (e, t) => (new Date(t).getTime() - new Date(e).getTime()) / p * 100, _ = o(s), v = new Set(_ || []), y = new Map(s.map((e, t) => [e.id, t])), b = (e) => s[y.get(e)]?.name || e, x = [];
	for (let e of s) for (let t of e.dependsOn || []) y.has(t) && (v.has(e.id) && v.has(t) || x.push({
		key: `${t}->${e.id}`,
		x1: h(s[y.get(t)].end),
		y1: (y.get(t) + .5) / s.length * 100,
		x2: h(e.start),
		y2: (y.get(e.id) + .5) / s.length * 100
	}));
	return /* @__PURE__ */ a("div", {
		className: r.root,
		style: c,
		children: [_ && /* @__PURE__ */ i("div", {
			className: r.cycleNote,
			role: "alert",
			children: l("gantt.cycle", "Dependencia circular detectada: {ciclo}. Los conectores de ese ciclo no se dibujan.", { ciclo: _.map(b).join(" → ") })
		}), /* @__PURE__ */ a("div", {
			className: r.rows,
			children: [x.length > 0 && /* @__PURE__ */ i("svg", {
				className: r.connectors,
				viewBox: "0 0 100 100",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: x.map((e) => {
					let t = (e.x1 + e.x2) / 2;
					return /* @__PURE__ */ i("polyline", {
						points: `${e.x1},${e.y1} ${t},${e.y1} ${t},${e.y2} ${e.x2},${e.y2}`,
						fill: "none",
						stroke: "var(--viz-axis)",
						strokeWidth: "1",
						strokeDasharray: "2 2",
						vectorEffect: "non-scaling-stroke"
					}, e.key);
				})
			}), s.map((e) => {
				let t = g(e.start, e.end);
				return /* @__PURE__ */ a("div", {
					className: r.row,
					children: [/* @__PURE__ */ a("div", {
						className: r.taskName,
						"data-placeholder": !e.name || void 0,
						children: [e.name || "(sin nombre)", /* @__PURE__ */ a("span", {
							className: r.taskDates,
							children: [
								m(e.start),
								" – ",
								m(e.end)
							]
						})]
					}), /* @__PURE__ */ i("div", {
						className: r.track,
						children: t <= 0 ? /* @__PURE__ */ i("div", {
							className: r.milestone,
							"data-milestone": "",
							style: {
								left: `${h(e.start)}%`,
								background: e.color || "var(--viz-1)"
							}
						}) : /* @__PURE__ */ i("div", {
							className: r.bar,
							style: {
								left: `${h(e.start)}%`,
								width: `${t}%`,
								background: e.color || "var(--viz-1)",
								opacity: e.progress == null ? .4 : 1
							},
							children: e.progress != null && /* @__PURE__ */ i("div", {
								className: r.progress,
								style: { width: `${e.progress * 100}%` }
							})
						})
					})]
				}, e.id);
			})]
		})]
	});
}
//#endregion
export { s as GanttChart };

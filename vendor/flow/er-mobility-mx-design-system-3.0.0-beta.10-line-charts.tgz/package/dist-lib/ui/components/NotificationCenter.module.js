//#region src/ui/components/NotificationCenter.module.css
var e = "XuB-Kq_list", t = "XuB-Kq_notifBody", n = "XuB-Kq_notifDesc", r = "XuB-Kq_notifIcon", i = "XuB-Kq_notifItem", a = "XuB-Kq_notifTime", o = "XuB-Kq_notifTitle", s = "XuB-Kq_root", c = {
	list: e,
	notifBody: t,
	notifDesc: n,
	notifIcon: r,
	notifItem: i,
	notifTime: a,
	notifTitle: o,
	root: s
};
//#endregion
export { c as default, e as list, t as notifBody, n as notifDesc, r as notifIcon, i as notifItem, a as notifTime, o as notifTitle, s as root };

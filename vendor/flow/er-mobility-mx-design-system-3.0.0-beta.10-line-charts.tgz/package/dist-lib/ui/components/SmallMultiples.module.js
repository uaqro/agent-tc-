//#region src/ui/components/SmallMultiples.module.css
var e = "HPaYuG_card", t = "HPaYuG_cardLabel", n = "HPaYuG_cardValue", r = "HPaYuG_header", i = "HPaYuG_identity", a = "HPaYuG_outlierIcon", o = "HPaYuG_root", s = {
	card: e,
	cardLabel: t,
	cardValue: n,
	header: r,
	identity: i,
	outlierIcon: a,
	root: o
};
//#endregion
export { e as card, t as cardLabel, n as cardValue, s as default, r as header, i as identity, a as outlierIcon, o as root };

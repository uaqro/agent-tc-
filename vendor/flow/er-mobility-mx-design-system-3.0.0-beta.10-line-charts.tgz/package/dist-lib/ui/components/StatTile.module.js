//#region src/ui/components/StatTile.module.css
var e = "vzlona_action", t = "vzlona_body", n = "vzlona_delta", r = "vzlona_deltaIcon", i = "vzlona_description", a = "vzlona_header", o = "vzlona_root", s = "vzlona_toneIcon", c = "vzlona_value", l = {
	action: e,
	body: t,
	delta: n,
	deltaIcon: r,
	description: i,
	header: a,
	root: o,
	toneIcon: s,
	value: c
};
//#endregion
export { e as action, t as body, l as default, n as delta, r as deltaIcon, i as description, a as header, o as root, s as toneIcon, c as value };

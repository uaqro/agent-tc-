import { useT as e } from "../../i18n/useSafeIntl.js";
import { Card as t } from "../primitives/Card.js";
import { IconButton as n } from "../primitives/IconButton.js";
import r from "./RouteBanner.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/components/RouteBanner.tsx
function o({ icon: o = "navigation", title: s, subtitle: c, onClose: l, style: u }) {
	let d = e();
	return /* @__PURE__ */ i("div", {
		className: r.root,
		style: u,
		children: /* @__PURE__ */ i(t, {
			padding: 14,
			children: /* @__PURE__ */ a("div", {
				className: r.content,
				children: [
					/* @__PURE__ */ i("span", {
						className: `flow-symbol flow-symbol--fill ${r.icon}`,
						"aria-hidden": "true",
						children: o
					}),
					/* @__PURE__ */ a("div", {
						className: r.info,
						children: [/* @__PURE__ */ i("span", {
							className: r.title,
							children: s
						}), /* @__PURE__ */ i("span", {
							className: r.subtitle,
							children: c
						})]
					}),
					l && /* @__PURE__ */ i(n, {
						icon: "close",
						ariaLabel: d("common.close", "Cerrar"),
						size: "sm",
						onClick: l
					})
				]
			})
		})
	});
}
//#endregion
export { o as RouteBanner };

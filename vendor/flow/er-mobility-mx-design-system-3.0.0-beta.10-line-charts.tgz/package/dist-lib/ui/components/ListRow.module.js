//#region src/ui/components/ListRow.module.css
var e = "qCe-4a_root", t = "qCe-4a_subtitle", n = "qCe-4a_textos", r = "qCe-4a_title", i = {
	root: e,
	subtitle: t,
	textos: n,
	title: r
};
//#endregion
export { i as default, e as root, t as subtitle, n as textos, r as title };

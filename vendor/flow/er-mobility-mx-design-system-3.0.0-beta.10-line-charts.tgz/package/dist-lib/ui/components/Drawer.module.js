//#region src/ui/components/Drawer.module.css
var e = "esht2a_body", t = "esht2a_footer", n = "esht2a_root", r = {
	body: e,
	footer: t,
	root: n
};
//#endregion
export { e as body, r as default, t as footer, n as root };

//#region src/ui/components/Tooltip.module.css
var e = "UXwncq_bubble", t = "UXwncq_wrapper", n = {
	bubble: e,
	wrapper: t
};
//#endregion
export { e as bubble, n as default, t as wrapper };

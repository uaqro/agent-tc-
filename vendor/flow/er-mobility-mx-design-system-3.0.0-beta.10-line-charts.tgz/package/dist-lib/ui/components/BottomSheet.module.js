//#region src/ui/components/BottomSheet.module.css
var e = "_0l0Oua_bar", t = "_0l0Oua_body", n = "_0l0Oua_handle", r = "_0l0Oua_header", i = "_0l0Oua_headerActions", a = "_0l0Oua_headerTitle", o = "_0l0Oua_root", s = "_0l0Oua_title", c = "_0l0Oua_titleRow", l = {
	bar: e,
	body: t,
	handle: n,
	header: r,
	headerActions: i,
	headerTitle: a,
	root: o,
	title: s,
	titleRow: c
};
//#endregion
export { e as bar, t as body, l as default, n as handle, r as header, i as headerActions, a as headerTitle, o as root, s as title, c as titleRow };

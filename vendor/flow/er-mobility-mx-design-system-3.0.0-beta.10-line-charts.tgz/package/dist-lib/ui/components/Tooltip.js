"use client";
import { Popover as e } from "../primitives/Popover.js";
import t from "./Tooltip.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { cloneElement as i, isValidElement as a, useId as o, useRef as s, useState as c } from "react";
//#region src/ui/components/Tooltip.tsx
function l({ open: l, onOpenChange: u, content: d, position: f = "top", children: p, style: m }) {
	let [h, g] = c(!1), _ = l ?? h, v = (e) => {
		l === void 0 && g(e), u?.(e);
	}, y = o(), b = s(null);
	return /* @__PURE__ */ r("span", {
		ref: b,
		className: t.wrapper,
		style: m,
		onMouseEnter: () => v(!0),
		onMouseLeave: () => v(!1),
		onFocus: () => v(!0),
		onBlur: () => v(!1),
		children: [a(p) ? i(p, { "aria-describedby": _ ? y : void 0 }) : p, /* @__PURE__ */ n(e, {
			open: _,
			onOpenChange: v,
			anchorRef: b,
			placement: `${f}-center`,
			offset: 8,
			surface: "none",
			layer: "tooltip",
			interactive: !1,
			children: /* @__PURE__ */ n("span", {
				id: y,
				role: "tooltip",
				className: t.bubble,
				children: d
			})
		})]
	});
}
//#endregion
export { l as Tooltip };

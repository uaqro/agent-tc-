//#region src/ui/components/BrandHero.module.css
var e = "W89aJa_acento", t = "W89aJa_arte", n = "W89aJa_bajada", r = "W89aJa_claim", i = "W89aJa_marca", a = "W89aJa_overline", o = "W89aJa_pie", s = "W89aJa_root", c = "W89aJa_titular", l = {
	acento: e,
	arte: t,
	bajada: n,
	claim: r,
	marca: i,
	overline: a,
	pie: o,
	root: s,
	titular: c
};
//#endregion
export { e as acento, t as arte, n as bajada, r as claim, l as default, i as marca, a as overline, o as pie, s as root, c as titular };

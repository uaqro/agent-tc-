//#region src/ui/components/CardMedia.module.css
var e = "UorGSq_body", t = "UorGSq_description", n = "UorGSq_image", r = "UorGSq_media", i = "UorGSq_root", a = "UorGSq_title", o = {
	body: e,
	description: t,
	image: n,
	media: r,
	root: i,
	title: a
};
//#endregion
export { e as body, o as default, t as description, n as image, r as media, i as root, a as title };

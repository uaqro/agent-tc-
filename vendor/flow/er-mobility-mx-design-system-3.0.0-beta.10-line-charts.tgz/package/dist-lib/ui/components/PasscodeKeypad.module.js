//#region src/ui/components/PasscodeKeypad.module.css
var e = "_1YRLYG_dot", t = "_1YRLYG_dots", n = "_1YRLYG_error", r = "_1YRLYG_grid", i = "_1YRLYG_key", a = "_1YRLYG_root", o = {
	dot: e,
	dots: t,
	error: n,
	grid: r,
	key: i,
	root: a
};
//#endregion
export { o as default, e as dot, t as dots, n as error, r as grid, i as key, a as root };

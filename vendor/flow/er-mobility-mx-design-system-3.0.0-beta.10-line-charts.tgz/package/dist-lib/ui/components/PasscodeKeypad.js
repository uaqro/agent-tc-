"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./PasscodeKeypad.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { useEffect as i } from "react";
//#region src/ui/components/PasscodeKeypad.tsx
var a = [
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9"
];
function o({ length: o = 6, value: s = "", onChange: c, onComplete: l, invalid: u, errorMessage: d, biometricIcon: f, onBiometric: p, style: m }) {
	let h = e();
	i(() => {
		u && c?.("");
	}, [u]), i(() => {
		s.length === o && l?.(s);
	}, [s, o]);
	let g = (e) => {
		s.length >= o || c?.(s + e);
	}, _ = () => {
		c?.(s.slice(0, -1));
	}, v = s.length;
	return /* @__PURE__ */ r("div", {
		className: t.root,
		style: m,
		children: [
			/* @__PURE__ */ n("div", {
				className: t.dots,
				role: "status",
				"aria-label": h("passcode.progress", "{filled} de {total} dígitos ingresados", {
					filled: v,
					total: o
				}),
				"data-invalid": u || void 0,
				children: Array.from({ length: o }, (e, r) => /* @__PURE__ */ n("span", {
					className: t.dot,
					"data-filled": r < v || void 0
				}, r))
			}),
			u && /* @__PURE__ */ n("div", {
				className: t.error,
				role: "alert",
				children: d ?? h("passcode.invalid", "Código incorrecto")
			}),
			/* @__PURE__ */ r("div", {
				className: t.grid,
				children: [
					a.map((e) => /* @__PURE__ */ n("button", {
						"data-bare": "",
						className: t.key,
						type: "button",
						onClick: () => g(e),
						"aria-label": e,
						children: e
					}, e)),
					/* @__PURE__ */ n("div", {
						"data-bare": "",
						className: t.key,
						"data-empty": !p || void 0,
						children: p && /* @__PURE__ */ n("button", {
							"data-bare": "",
							className: t.key,
							type: "button",
							onClick: p,
							"aria-label": h("passcode.biometric", "Usar biométrico"),
							"data-special": !0,
							children: /* @__PURE__ */ n("span", {
								className: "flow-symbol",
								"aria-hidden": "true",
								children: f || "fingerprint"
							})
						})
					}),
					/* @__PURE__ */ n("button", {
						"data-bare": "",
						className: t.key,
						type: "button",
						onClick: () => g("0"),
						"aria-label": "0",
						children: "0"
					}),
					/* @__PURE__ */ n("button", {
						"data-bare": "",
						className: t.key,
						type: "button",
						onClick: _,
						"aria-label": h("passcode.delete", "Borrar"),
						"data-special": !0,
						children: /* @__PURE__ */ n("span", {
							className: "flow-symbol",
							"aria-hidden": "true",
							children: "backspace"
						})
					})
				]
			})
		]
	});
}
//#endregion
export { o as PasscodeKeypad };

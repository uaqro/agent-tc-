import e from "./FilterBar.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/components/FilterBar.tsx
function n({ variant: n = "inline", children: r, style: i }) {
	return /* @__PURE__ */ t("div", {
		className: e.root,
		"data-variant": n === "inline" ? void 0 : n,
		style: i,
		children: r
	});
}
//#endregion
export { n as FilterBar };

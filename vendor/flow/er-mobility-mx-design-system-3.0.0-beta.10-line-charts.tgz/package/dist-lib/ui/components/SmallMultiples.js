"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { EmptyState as t } from "../primitives/EmptyState.js";
import n from "./SmallMultiples.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useId as a, useState as o } from "react";
//#region src/ui/components/SmallMultiples.tsx
function s({ items: s, height: c = 46, color: l = "var(--viz-neutral)", layout: u = "grid", columns: d, isOutlier: f, format: p, onSelect: m, selectedId: h, style: g }) {
	let _ = e(), v = Math.max(1, Math.min(d ?? 4, s.length || 1)), y = a(), [b, x] = o(0), S = (e) => {
		let t = {
			ArrowRight: 1,
			ArrowLeft: -1,
			ArrowDown: u === "rows" ? 1 : v,
			ArrowUp: u === "rows" ? -1 : -v
		};
		e.key in t ? (e.preventDefault(), x((n) => Math.max(0, Math.min(s.length - 1, n + t[e.key])))) : e.key === "Home" ? (e.preventDefault(), x(0)) : e.key === "End" ? (e.preventDefault(), x(s.length - 1)) : (e.key === "Enter" || e.key === " ") && (e.preventDefault(), s[b] && m?.(s[b]));
	};
	if (!s.length) return /* @__PURE__ */ r(t, {
		icon: "grid_on",
		title: _("common.empty", "Sin datos"),
		description: _("common.emptyDescription", "No hay datos para este periodo."),
		style: g
	});
	let C = s.flatMap((e) => e.values), w = C.length ? Math.min(...C) : 0, T = (C.length ? Math.max(...C) : 1) - w || 1, E = (e, t) => {
		let n = (e) => c - 4 - (e - w) / T * (c - 8), i = e.length === 1 ? `3,${n(e[0])} 137,${n(e[0])}` : e.map((t, r) => `${3 + r / (e.length - 1) * 134},${n(t)}`).join(" ");
		return /* @__PURE__ */ r("svg", {
			width: "100%",
			height: c,
			viewBox: `0 0 140 ${c}`,
			preserveAspectRatio: "none",
			"aria-hidden": "true",
			style: { display: "block" },
			children: e.length > 0 && /* @__PURE__ */ r("polyline", {
				points: i,
				fill: "none",
				stroke: t,
				strokeWidth: 2,
				vectorEffect: "non-scaling-stroke",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			})
		});
	};
	return /* @__PURE__ */ r("div", {
		className: n.root,
		"data-layout": u,
		style: {
			gridTemplateColumns: `repeat(${u === "rows" ? 1 : v}, minmax(0, 1fr))`,
			...g
		},
		role: m ? "listbox" : void 0,
		tabIndex: m ? 0 : void 0,
		"aria-label": m ? _("smallMultiples.list", "Entidades comparadas") : void 0,
		"aria-activedescendant": m ? `${y}-opt-${b}` : void 0,
		onKeyDown: m ? S : void 0,
		children: s.map((e, t) => {
			let a = f ? f(e) : !1, o = e.id === h, s = e.values[e.values.length - 1];
			return /* @__PURE__ */ i("div", {
				id: m ? `${y}-opt-${t}` : void 0,
				className: n.card,
				role: m ? "option" : void 0,
				"aria-selected": m ? o : void 0,
				"data-clickable": m ? "" : void 0,
				"data-selected": o || void 0,
				"data-active": m && t === b ? "" : void 0,
				onClick: m ? () => {
					x(t), m(e);
				} : void 0,
				children: [/* @__PURE__ */ i("div", {
					className: n.identity,
					children: [/* @__PURE__ */ i("div", {
						className: n.header,
						children: [/* @__PURE__ */ r("span", {
							className: n.cardLabel,
							children: e.label
						}), a && /* @__PURE__ */ r("span", {
							className: `flow-symbol ${n.outlierIcon}`,
							"aria-hidden": "true",
							children: "priority_high"
						})]
					}), /* @__PURE__ */ r("span", {
						className: n.cardValue,
						"data-outlier": a || void 0,
						children: p ? p(s) : s
					})]
				}), E(e.values, a ? "var(--viz-negative)" : l)]
			}, e.id);
		})
	});
}
//#endregion
export { s as SmallMultiples };

//#region src/ui/components/QuickAction.module.css
var e = "J8E7Mq_circle", t = "J8E7Mq_icon", n = "J8E7Mq_label", r = "J8E7Mq_root", i = {
	circle: e,
	icon: t,
	label: n,
	root: r
};
//#endregion
export { e as circle, i as default, t as icon, n as label, r as root };

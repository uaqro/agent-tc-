//#region src/ui/components/AvatarGroup.module.css
var e = "-kWCna_item", t = "-kWCna_resto", n = "-kWCna_root", r = {
	item: e,
	resto: t,
	root: n
};
//#endregion
export { r as default, e as item, t as resto, n as root };

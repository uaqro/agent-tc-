import { Flag as e } from "./primitives/Flag.js";
import "flag-icons/css/flag-icons.min.css";
export { e as Flag };

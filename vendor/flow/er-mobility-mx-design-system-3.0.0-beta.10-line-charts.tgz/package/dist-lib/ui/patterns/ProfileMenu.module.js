//#region src/ui/patterns/ProfileMenu.module.css
var e = "roBeea_header", t = "roBeea_itemChevron", n = "roBeea_itemIcon", r = "roBeea_items", i = "roBeea_name", a = "roBeea_role", o = "roBeea_root", s = {
	header: e,
	itemChevron: t,
	itemIcon: n,
	items: r,
	name: i,
	role: a,
	root: o
};
//#endregion
export { s as default, e as header, t as itemChevron, n as itemIcon, r as items, i as name, a as role, o as root };

import { Card as e } from "../primitives/Card.js";
import { Specimen as t } from "../primitives/Specimen.js";
import n from "./StateGrid.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/patterns/StateGrid.tsx
function a({ states: a, columns: o, style: s }) {
	let c = {
		...o ? { gridTemplateColumns: `repeat(${o}, 1fr)` } : {},
		...s
	};
	return /* @__PURE__ */ r("div", {
		className: n.root,
		style: c,
		children: a.map((a, o) => /* @__PURE__ */ r(e, {
			surface: "outlined",
			padding: 0,
			children: /* @__PURE__ */ i("div", {
				className: n.cell,
				children: [/* @__PURE__ */ r(t, {
					centered: !0,
					children: a.specimen
				}), /* @__PURE__ */ r("span", {
					className: n.label,
					children: a.label
				})]
			})
		}, o))
	});
}
//#endregion
export { a as StateGrid };

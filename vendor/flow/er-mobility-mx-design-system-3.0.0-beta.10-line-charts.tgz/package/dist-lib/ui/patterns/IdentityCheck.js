"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { OTPInput as t } from "../components/OTPInput.js";
import { BiometricPrompt as n } from "../components/BiometricPrompt.js";
import { PasscodeKeypad as r } from "../components/PasscodeKeypad.js";
import i from "./IdentityCheck.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
import { useCallback as s, useEffect as c, useState as l } from "react";
//#region src/ui/patterns/IdentityCheck.tsx
var u = {
	biometric: ["identityCheck.useBiometric", "Usar biométrico"],
	passcode: ["identityCheck.usePasscode", "Usar passcode"],
	sms: ["identityCheck.useSms", "Recibir código por SMS"]
};
function d({ methods: d, greeting: f, biometricMethod: p = "face", biometricState: m = "idle", onBiometricStart: h, onSubmit: g, invalid: _ = !1, attemptsLeft: v, locked: y = !1, onVerified: b, style: x }) {
	let S = e(), [C, w] = l(d[0]), [T, E] = l("");
	c(() => {
		_ && E("");
	}, [_]), c(() => {
		m === "success" && b?.();
	}, [m, b]);
	let D = d[(d.indexOf(C) + 1) % d.length], O = s((e) => {
		w(e), E("");
	}, []), k = d.length > 1 ? /* @__PURE__ */ a("button", {
		type: "button",
		"data-bare": "",
		className: i.link,
		onClick: () => O(D),
		children: S(...u[D])
	}) : null, A = y || v === 0 ? S("identityCheck.locked", "Cuenta bloqueada temporalmente. Usa otro método.") : v == null ? S("identityCheck.wrong", "Código incorrecto.") : S("identityCheck.wrongLeft", "Código incorrecto. Te quedan {n} intento{s} antes de bloquear la cuenta.", {
		n: v,
		s: v === 1 ? "" : "s"
	}), j = (_ || y) && C !== "passcode" ? /* @__PURE__ */ a("span", {
		className: i.error,
		role: "alert",
		children: A
	}) : null;
	return /* @__PURE__ */ o("div", {
		className: i.root,
		style: x,
		children: [
			f && /* @__PURE__ */ a("span", {
				className: i.greeting,
				children: f
			}),
			C === "biometric" && /* @__PURE__ */ a(n, {
				method: p,
				state: m,
				title: p === "face" ? S("identityCheck.faceId", "Face ID") : S("identityCheck.touchId", "Touch ID"),
				description: m === "success" ? S("identityCheck.welcome", "Bienvenido.") : S("identityCheck.tapToVerify", "Toca para verificar."),
				onUse: h,
				onFallback: d.length > 1 ? () => O(D) : void 0,
				fallbackLabel: d.length > 1 ? S(...u[D]) : void 0
			}),
			C === "passcode" && /* @__PURE__ */ a(r, {
				value: T,
				invalid: _ || y,
				errorMessage: A,
				onChange: y ? void 0 : E,
				onComplete: y ? void 0 : (e) => g("passcode", e),
				biometricIcon: d.includes("biometric") ? "ar_on_you" : void 0,
				onBiometric: d.includes("biometric") ? () => O("biometric") : void 0
			}),
			C === "sms" && /* @__PURE__ */ a(t, {
				length: 6,
				value: T,
				invalid: _,
				disabled: y,
				autoFocus: !0,
				onChange: E,
				onComplete: (e) => g("sms", e)
			}),
			j,
			C !== "biometric" && (C !== "passcode" || D !== "biometric") && k
		]
	});
}
//#endregion
export { d as IdentityCheck };

import { Avatar as e } from "../primitives/Avatar.js";
import { ListRow as t } from "../components/ListRow.js";
import n from "./ProfileMenu.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/patterns/ProfileMenu.tsx
function a({ name: a, avatarName: o, role: s, badge: c, items: l, style: u }) {
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: u,
		children: [/* @__PURE__ */ i("div", {
			className: n.header,
			children: [
				/* @__PURE__ */ r(e, {
					name: o,
					size: "lg",
					status: "online"
				}),
				/* @__PURE__ */ r("span", {
					className: n.name,
					children: a
				}),
				/* @__PURE__ */ r("span", {
					className: n.role,
					children: s
				}),
				c
			]
		}), /* @__PURE__ */ r("div", {
			className: n.items,
			children: l.map((e) => /* @__PURE__ */ r(t, {
				leading: /* @__PURE__ */ r("span", {
					className: `flow-symbol ${n.itemIcon}`,
					"aria-hidden": "true",
					children: e.icon
				}),
				title: e.label,
				trailing: /* @__PURE__ */ r("span", {
					className: `flow-symbol ${n.itemChevron}`,
					"aria-hidden": "true",
					children: "chevron_right"
				}),
				onClick: e.onClick
			}, e.label))
		})]
	});
}
//#endregion
export { a as ProfileMenu };

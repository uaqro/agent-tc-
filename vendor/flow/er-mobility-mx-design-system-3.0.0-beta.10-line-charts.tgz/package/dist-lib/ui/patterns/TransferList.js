"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import { Input as n } from "../primitives/Input.js";
import r from "./TransferList.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import { useId as o, useRef as s, useState as c } from "react";
//#region src/ui/patterns/TransferList.tsx
function l({ source: l, target: u, onChange: d, titles: f, searchable: p = !0, style: m }) {
	let h = e(), g = o(), [_, v] = c({
		source: /* @__PURE__ */ new Set(),
		target: /* @__PURE__ */ new Set()
	}), [y, b] = c({
		source: 0,
		target: 0
	}), [x, S] = c({
		source: "",
		target: ""
	}), [C, w] = c(""), T = s({
		source: null,
		target: null
	}), E = f ?? [h("transferList.source", "Disponibles"), h("transferList.target", "Asignados")], D = {
		source: l,
		target: u
	}, O = (e) => {
		let t = x[e].trim().toLowerCase();
		return t ? D[e].filter((e) => e.label.toLowerCase().includes(t) || (e.meta ?? "").toLowerCase().includes(t)) : D[e];
	}, k = (e, t) => v((n) => {
		let r = new Set(n[e]);
		return r.has(t) ? r.delete(t) : r.add(t), {
			...n,
			[e]: r
		};
	});
	function A(e) {
		let t = e === "source" ? "target" : "source", n = D[e].filter((t) => _[e].has(t.id));
		if (n.length === 0) return;
		d(e === "source" ? [...u, ...n] : u.filter((e) => !_.target.has(e.id))), v({
			source: /* @__PURE__ */ new Set(),
			target: /* @__PURE__ */ new Set(),
			[t]: new Set(n.map((e) => e.id))
		}), b((e) => ({
			...e,
			[t]: 0
		}));
		let r = e === "source" ? {
			[E[0]]: l.length - n.length,
			[E[1]]: u.length + n.length
		} : {
			[E[0]]: l.length + n.length,
			[E[1]]: u.length - n.length
		};
		w(h("transferList.moved", "{n} a {destino}. {a}: {na}. {b}: {nb}.", {
			n: n.length,
			destino: E[+(t === "target")],
			a: E[0],
			na: r[E[0]],
			b: E[1],
			nb: r[E[1]]
		})), T.current[t]?.focus?.();
	}
	function j(e, t) {
		let n = O(e);
		if (n.length !== 0) {
			if (t.key === "ArrowDown" || t.key === "ArrowUp") {
				t.preventDefault();
				let r = t.key === "ArrowDown" ? 1 : -1;
				b((t) => ({
					...t,
					[e]: (t[e] + r + n.length) % n.length
				}));
			} else t.key === " " || t.key === "Enter" ? (t.preventDefault(), k(e, n[y[e]].id)) : (t.key === "Home" || t.key === "End") && (t.preventDefault(), b((r) => ({
				...r,
				[e]: t.key === "Home" ? 0 : n.length - 1
			})));
		}
	}
	let M = (e, t) => {
		let o = O(e), s = _[e].size;
		return /* @__PURE__ */ a("div", {
			className: r.panel,
			children: [
				/* @__PURE__ */ a("div", {
					className: r.cabecera,
					children: [/* @__PURE__ */ i("span", {
						className: r.titulo,
						id: `${g}-${e}`,
						children: E[t]
					}), /* @__PURE__ */ i("span", {
						className: r.cuenta,
						children: s > 0 ? h("transferList.countSelected", "{total} · {n} seleccionados", {
							total: D[e].length,
							n: s
						}) : h("transferList.count", "{total}", { total: D[e].length })
					})]
				}),
				p && /* @__PURE__ */ i(n, {
					value: x[e],
					onChange: (t) => S((n) => ({
						...n,
						[e]: t
					})),
					icon: "search",
					ariaLabel: h("transferList.search", "Buscar en {panel}", { panel: E[t] })
				}),
				/* @__PURE__ */ i("ul", {
					"data-list": "",
					className: r.lista,
					ref: (t) => {
						T.current[e] = t;
					},
					role: "listbox",
					"aria-multiselectable": "true",
					"aria-labelledby": `${g}-${e}`,
					"aria-activedescendant": o.length ? `${g}-${e}-${o[y[e]]?.id}` : void 0,
					tabIndex: 0,
					onKeyDown: (t) => j(e, t),
					children: o.map((t, n) => /* @__PURE__ */ a("li", {
						id: `${g}-${e}-${t.id}`,
						role: "option",
						"aria-selected": _[e].has(t.id),
						className: r.item,
						"data-activo": n === y[e] ? "" : void 0,
						onClick: () => {
							b((t) => ({
								...t,
								[e]: n
							})), k(e, t.id);
						},
						children: [/* @__PURE__ */ i("span", {
							className: r.etiqueta,
							children: t.label
						}), t.meta && /* @__PURE__ */ i("span", {
							className: r.meta,
							children: t.meta
						})]
					}, t.id))
				})
			]
		});
	};
	return /* @__PURE__ */ a("div", {
		className: r.root,
		style: m,
		children: [
			M("source", 0),
			/* @__PURE__ */ a("div", {
				className: r.mandos,
				children: [/* @__PURE__ */ i(t, {
					icon: "chevron_right",
					ariaLabel: h("transferList.toTarget", "Mover a {panel}", { panel: E[1] }),
					onClick: () => A("source"),
					disabled: _.source.size === 0
				}), /* @__PURE__ */ i(t, {
					icon: "chevron_left",
					ariaLabel: h("transferList.toSource", "Mover a {panel}", { panel: E[0] }),
					onClick: () => A("target"),
					disabled: _.target.size === 0
				})]
			}),
			M("target", 1),
			/* @__PURE__ */ i("span", {
				"data-sr-only": "",
				role: "status",
				children: C
			})
		]
	});
}
//#endregion
export { l as TransferList };

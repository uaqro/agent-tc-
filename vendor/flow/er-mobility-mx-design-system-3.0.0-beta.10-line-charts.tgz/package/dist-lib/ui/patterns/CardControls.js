"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { LimitBar as n } from "../primitives/LimitBar.js";
import { SectionHeader as r } from "../primitives/SectionHeader.js";
import { SheetBody as i } from "../primitives/SheetBody.js";
import { BottomSheet as a } from "../components/BottomSheet.js";
import { QuickAction as o } from "../components/QuickAction.js";
import { QuickActionBar as s } from "../components/QuickActionBar.js";
import { TransactionRow as c } from "../components/TransactionRow.js";
import { NipReveal as l } from "../components/NipReveal.js";
import u from "./CardControls.module.js";
import { jsx as d, jsxs as f } from "react/jsx-runtime";
import { useState as p } from "react";
//#region src/ui/patterns/CardControls.tsx
function m({ frozen: m = !1, onFrozenChange: h, freezeDescription: g, nip: _, nipWarning: v, limits: y, movements: b, actions: x, last4: S, onDelete: C, style: w }) {
	let T = e(), [E, D] = p(!1), [O, k] = p(!1), [A, j] = p(!1), [M, N] = p(!1);
	return /* @__PURE__ */ f("div", {
		className: u.root,
		style: w,
		children: [
			/* @__PURE__ */ f(s, { children: [
				/* @__PURE__ */ d(o, {
					icon: "ac_unit",
					label: m ? T("cardControls.unfreeze", "Descongelar") : T("cardControls.freeze", "Congelar"),
					active: m,
					onClick: () => m ? h?.(!1) : N(!0)
				}),
				_ && /* @__PURE__ */ d(o, {
					icon: "pin",
					label: T("cardControls.nip", "Ver NIP"),
					onClick: () => D(!0)
				}),
				y && y.length > 0 && /* @__PURE__ */ d(o, {
					icon: "speed",
					label: T("cardControls.limits", "Límites"),
					onClick: () => k(!0)
				}),
				x
			] }),
			b && b.length > 0 && /* @__PURE__ */ f("div", {
				className: u.movements,
				children: [/* @__PURE__ */ d(r, {
					size: "sm",
					children: T("cardControls.movements", "Movimientos de esta tarjeta")
				}), b.map((e, t) => /* @__PURE__ */ d(c, {
					category: e.category,
					title: e.title,
					subtitle: e.subtitle,
					amount: e.amount,
					status: e.pending ? "pending" : void 0
				}, t))]
			}),
			C && S && /* @__PURE__ */ d("div", {
				className: u.danger,
				children: /* @__PURE__ */ d(t, {
					variant: "danger",
					size: "lg",
					fullWidth: !0,
					onClick: () => j(!0),
					children: T("cardControls.delete", "Dar de baja esta tarjeta")
				})
			}),
			_ && /* @__PURE__ */ d(a, {
				open: E,
				onOpenChange: D,
				title: T("cardControls.nipSheet", "NIP de la tarjeta"),
				fixed: !1,
				children: /* @__PURE__ */ d(l, {
					digits: _,
					warning: v
				})
			}),
			y && y.length > 0 && /* @__PURE__ */ d(a, {
				open: O,
				onOpenChange: k,
				title: T("cardControls.limitsSheet", "Límites de gasto"),
				fixed: !1,
				children: /* @__PURE__ */ f(i, { children: [y.map((e) => /* @__PURE__ */ d(n, {
					label: e.label,
					current: e.current,
					max: e.max
				}, e.label)), /* @__PURE__ */ d("div", {
					className: u.sheetAction,
					children: /* @__PURE__ */ d(t, {
						variant: "primary",
						size: "lg",
						fullWidth: !0,
						onClick: () => k(!1),
						children: T("cardControls.close", "Cerrar")
					})
				})] })
			}),
			/* @__PURE__ */ d(a, {
				open: M,
				onOpenChange: N,
				title: T("cardControls.freezeSheet", "¿Congelar la tarjeta?"),
				fixed: !1,
				children: /* @__PURE__ */ f(i, { children: [
					g && /* @__PURE__ */ d("p", {
						className: u.freezeLead,
						children: g
					}),
					/* @__PURE__ */ d("p", {
						className: u.freezeLead,
						children: T("cardControls.freezeLead", "Puedes descongelarla cuando quieras, con un toque.")
					}),
					/* @__PURE__ */ f("div", {
						className: u.sheetAction,
						children: [/* @__PURE__ */ d(t, {
							variant: "primary",
							size: "lg",
							fullWidth: !0,
							onClick: () => {
								N(!1), h?.(!0);
							},
							children: T("cardControls.freezeConfirm", "Congelar")
						}), /* @__PURE__ */ d(t, {
							variant: "ghost",
							size: "lg",
							fullWidth: !0,
							onClick: () => N(!1),
							children: T("cardControls.freezeCancel", "Ahora no")
						})]
					})
				] })
			}),
			C && S && /* @__PURE__ */ d(a, {
				open: A,
				onOpenChange: j,
				title: T("cardControls.deleteSheet", "Dar de baja la tarjeta"),
				fixed: !1,
				children: /* @__PURE__ */ f(i, { children: [
					/* @__PURE__ */ d("p", {
						className: u.dangerLead,
						children: T("cardControls.deleteLead", "La tarjeta ·{last4} se da de baja y no se puede recuperar.", { last4: S })
					}),
					/* @__PURE__ */ d("p", {
						className: u.dangerNote,
						children: T("cardControls.deleteKeepsHistory", "Sus movimientos se quedan en tu actividad: lo que desaparece es la tarjeta.")
					}),
					/* @__PURE__ */ f("div", {
						className: u.sheetAction,
						children: [/* @__PURE__ */ d(t, {
							variant: "danger",
							size: "lg",
							fullWidth: !0,
							onClick: () => {
								j(!1), C?.();
							},
							children: T("cardControls.deleteConfirm", "Dar de baja")
						}), /* @__PURE__ */ d(t, {
							variant: "ghost",
							size: "lg",
							fullWidth: !0,
							onClick: () => j(!1),
							children: T("cardControls.deleteCancel", "Conservarla")
						})]
					})
				] })
			})
		]
	});
}
//#endregion
export { m as CardControls };

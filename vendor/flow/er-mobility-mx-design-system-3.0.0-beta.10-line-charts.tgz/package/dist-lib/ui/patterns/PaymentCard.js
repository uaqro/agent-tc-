"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { duracionDeclarada as t } from "../../hooks/useListaViva.js";
import { BalanceDisplay as n } from "../components/BalanceDisplay.js";
import r from "./PaymentCard.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import { useEffect as o, useRef as s, useState as c } from "react";
//#region src/ui/patterns/PaymentCard.tsx
function l(e) {
	return e.replace(/\S/g, "•");
}
function u({ holder: u, last4: d, variant: f = "ink", frozen: p, label: m, icon: h, expires: g, balance: _, hidden: v, onToggleHidden: y, onFreezeSettled: b, onClick: x, style: S }) {
	let C = e(), [w, T] = c(!1), E = s(p), D = s(null);
	o(() => {
		E.current && !p && T(!0), E.current = p;
	}, [p]), o(() => {
		if (!w) return;
		let e = D.current ? t(D.current) : 0, n = setTimeout(() => T(!1), e + 50);
		return () => clearTimeout(n);
	}, [w]);
	let O = s(b);
	return O.current = b, o(() => {
		if (!p) return;
		let e = D.current, t = () => O.current?.(), n = e?.getAnimations?.({ subtree: !0 });
		if (!n?.length) {
			t();
			return;
		}
		let r = !0;
		return Promise.allSettled(n.map((e) => e.finished)).then(() => {
			r && t();
		}), () => {
			r = !1;
		};
	}, [p]), /* @__PURE__ */ a(x ? "button" : "div", {
		ref: D,
		className: r.root,
		"data-variant": f,
		"data-frozen": p || void 0,
		"data-thawing": w || void 0,
		onAnimationEnd: () => T(!1),
		onClick: x,
		type: x ? "button" : void 0,
		style: S,
		"aria-label": p ? C("card.labelFrozen", "Tarjeta {holder} terminación {last4}, congelada", {
			holder: u,
			last4: d
		}) : C("card.label", "Tarjeta {holder} terminación {last4}", {
			holder: u,
			last4: d
		}),
		children: [
			/* @__PURE__ */ i("div", {
				className: r.top,
				children: _ ? /* @__PURE__ */ i(n, {
					variant: "art",
					value: _,
					hidden: v,
					onToggleHidden: y
				}) : /* @__PURE__ */ i("span", {})
			}),
			/* @__PURE__ */ a("div", {
				className: r.productRow,
				children: [/* @__PURE__ */ i("span", {
					className: r.chip,
					children: /* @__PURE__ */ i("span", {
						className: "flow-symbol flow-symbol--sm",
						"aria-hidden": "true",
						children: h ?? "sim_card"
					})
				}), m && /* @__PURE__ */ i("span", {
					"data-overline": "",
					className: r.label,
					children: m
				})]
			}),
			/* @__PURE__ */ a("div", {
				className: r.number,
				children: [
					/* @__PURE__ */ i("span", {
						className: r.dots,
						children: "••••"
					}),
					/* @__PURE__ */ i("span", {
						className: r.dots,
						children: "••••"
					}),
					/* @__PURE__ */ i("span", {
						className: r.dots,
						children: "••••"
					}),
					/* @__PURE__ */ i("span", {
						className: r.last4,
						children: v ? "••••" : d
					})
				]
			}),
			/* @__PURE__ */ a("div", {
				className: r.bottom,
				children: [/* @__PURE__ */ i("div", {
					"data-overline": "",
					className: r.holder,
					children: v ? l(u) : u
				}), g && /* @__PURE__ */ i("div", {
					className: r.expires,
					children: v ? "••/••" : g
				})]
			}),
			/* @__PURE__ */ a("div", {
				className: r.frozenOverlay,
				"aria-hidden": "true",
				children: [/* @__PURE__ */ a("svg", {
					className: r.frozenIcon,
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.6",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					children: [/* @__PURE__ */ i("path", {
						className: r.frozenShackle,
						d: "M7 11V7a5 5 0 0 1 10 0v4"
					}), /* @__PURE__ */ i("rect", {
						x: "3",
						y: "11",
						width: "18",
						height: "11",
						rx: "2"
					})]
				}), /* @__PURE__ */ i("span", {
					"data-overline": "",
					className: r.frozenLabel,
					children: C("card.frozen", "Congelada")
				})]
			})
		]
	});
}
//#endregion
export { u as PaymentCard };

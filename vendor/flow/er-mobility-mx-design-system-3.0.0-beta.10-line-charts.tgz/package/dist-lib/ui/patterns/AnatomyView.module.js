//#region src/ui/patterns/AnatomyView.module.css
var e = "TUlj8a_legend", t = "TUlj8a_number", n = "TUlj8a_part", r = "TUlj8a_partDesc", i = "TUlj8a_partLabel", a = "TUlj8a_partText", o = "TUlj8a_root", s = {
	legend: e,
	number: t,
	part: n,
	partDesc: r,
	partLabel: i,
	partText: a,
	root: o
};
//#endregion
export { s as default, e as legend, t as number, n as part, r as partDesc, i as partLabel, a as partText, o as root };

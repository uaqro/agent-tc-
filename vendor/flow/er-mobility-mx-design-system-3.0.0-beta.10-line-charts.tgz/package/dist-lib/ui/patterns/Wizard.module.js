//#region src/ui/patterns/Wizard.module.css
var e = "xx7-LG_actions", t = "xx7-LG_actionsEnd", n = "xx7-LG_body", r = "xx7-LG_root", i = "xx7-LG_summary", a = "xx7-LG_summaryLabel", o = "xx7-LG_summaryRow", s = "xx7-LG_summarySection", c = "xx7-LG_summaryTitle", l = "xx7-LG_summaryValue", u = {
	actions: e,
	actionsEnd: t,
	body: n,
	root: r,
	summary: i,
	summaryLabel: a,
	summaryRow: o,
	summarySection: s,
	summaryTitle: c,
	summaryValue: l
};
//#endregion
export { e as actions, t as actionsEnd, n as body, u as default, r as root, i as summary, a as summaryLabel, o as summaryRow, s as summarySection, c as summaryTitle, l as summaryValue };

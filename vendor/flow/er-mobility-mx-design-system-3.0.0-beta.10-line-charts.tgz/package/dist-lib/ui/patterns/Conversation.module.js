//#region src/ui/patterns/Conversation.module.css
var e = "UrsMYa_compositor", t = "UrsMYa_hilo", n = "UrsMYa_root", r = {
	compositor: e,
	hilo: t,
	root: n
};
//#endregion
export { e as compositor, r as default, t as hilo, n as root };

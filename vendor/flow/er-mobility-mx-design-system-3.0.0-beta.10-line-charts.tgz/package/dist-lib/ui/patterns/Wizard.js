import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { Stepper as n } from "../primitives/Stepper.js";
import { TextAction as r } from "../primitives/TextAction.js";
import i from "./Wizard.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/ui/patterns/Wizard.tsx
function s({ steps: r, current: s, onBack: c, onNext: l, onSubmit: u, submitting: d, nextDisabled: f, onSkip: p, skipLabel: m, nextLabel: h, submitLabel: g, children: _ }) {
	let v = e(), y = h ?? v("common.next", "Siguiente"), b = g ?? v("common.confirm", "Confirmar"), x = m ?? v("common.skip", "Saltar"), S = s >= r.length - 1;
	return /* @__PURE__ */ o("div", {
		className: i.root,
		children: [
			/* @__PURE__ */ a(n, {
				steps: r,
				current: s,
				style: {
					width: "100%",
					justifyContent: "space-between"
				}
			}),
			/* @__PURE__ */ a("div", {
				className: i.body,
				children: _
			}),
			/* @__PURE__ */ o("div", {
				className: i.actions,
				children: [s > 0 ? /* @__PURE__ */ a(t, {
					variant: "ghost",
					icon: "arrow_back",
					onClick: c,
					disabled: d,
					children: v("common.back", "Volver")
				}) : /* @__PURE__ */ a("span", {}), /* @__PURE__ */ o("div", {
					className: i.actionsEnd,
					children: [p && /* @__PURE__ */ a(t, {
						variant: "ghost",
						onClick: p,
						disabled: d,
						children: x
					}), S ? /* @__PURE__ */ a(t, {
						variant: "primary",
						onClick: u,
						loading: d,
						disabled: d,
						children: b
					}) : /* @__PURE__ */ a(t, {
						variant: "primary",
						iconTrailing: "arrow_forward",
						onClick: l,
						disabled: f,
						children: y
					})]
				})]
			})
		]
	});
}
function c({ children: e }) {
	return /* @__PURE__ */ a("div", {
		className: i.summary,
		children: e
	});
}
function l({ title: t, onEdit: n, children: s }) {
	let c = e();
	return /* @__PURE__ */ o("div", {
		className: i.summarySection,
		children: [/* @__PURE__ */ o("div", {
			className: i.summaryTitle,
			children: [t, n && /* @__PURE__ */ a(r, {
				onClick: n,
				children: c("common.edit", "Editar")
			})]
		}), s]
	});
}
function u({ label: e, value: t }) {
	return /* @__PURE__ */ o("div", {
		className: i.summaryRow,
		children: [/* @__PURE__ */ a("span", {
			className: i.summaryLabel,
			children: e
		}), /* @__PURE__ */ a("span", {
			className: i.summaryValue,
			children: t
		})]
	});
}
//#endregion
export { s as Wizard, c as WizardSummary, u as WizardSummaryRow, l as WizardSummarySection };

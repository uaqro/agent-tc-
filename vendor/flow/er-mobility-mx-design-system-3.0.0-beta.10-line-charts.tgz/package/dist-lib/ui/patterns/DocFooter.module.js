//#region src/ui/patterns/DocFooter.module.css
var e = "KVrERW_dot", t = "KVrERW_info", n = "KVrERW_item", r = "KVrERW_link", i = "KVrERW_links", a = "KVrERW_mono", o = "KVrERW_root", s = {
	dot: e,
	info: t,
	item: n,
	link: r,
	links: i,
	mono: a,
	root: o
};
//#endregion
export { s as default, e as dot, t as info, n as item, r as link, i as links, a as mono, o as root };

//#region src/ui/patterns/CardControls.module.css
var e = "_9NXYXW_danger", t = "_9NXYXW_dangerLead", n = "_9NXYXW_dangerNote", r = "_9NXYXW_freezeLead", i = "_9NXYXW_movements", a = "_9NXYXW_root", o = "_9NXYXW_sheetAction", s = {
	danger: e,
	dangerLead: t,
	dangerNote: n,
	freezeLead: r,
	movements: i,
	root: a,
	sheetAction: o
};
//#endregion
export { e as danger, t as dangerLead, n as dangerNote, s as default, r as freezeLead, i as movements, a as root, o as sheetAction };

//#region src/ui/patterns/TransactionGroup.module.css
var e = "Gz7oqq_label", t = "Gz7oqq_list", n = "Gz7oqq_root", r = {
	label: e,
	list: t,
	root: n
};
//#endregion
export { r as default, e as label, t as list, n as root };

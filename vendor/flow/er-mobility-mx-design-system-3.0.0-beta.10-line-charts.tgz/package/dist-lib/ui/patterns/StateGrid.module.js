//#region src/ui/patterns/StateGrid.module.css
var e = "vvYHXG_cell", t = "vvYHXG_label", n = "vvYHXG_root", r = {
	cell: e,
	label: t,
	root: n
};
//#endregion
export { e as cell, r as default, t as label, n as root };

import { ChatComposer as e } from "../components/ChatComposer.js";
import { ChatThread as t } from "../components/ChatThread.js";
import n from "./Conversation.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/patterns/Conversation.tsx
function a({ messages: a, value: o, onChange: s, onSend: c, busy: l = !1, suggestions: u, placeholder: d, emptyState: f, style: p }) {
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: p,
		children: [/* @__PURE__ */ r("div", {
			className: n.hilo,
			children: /* @__PURE__ */ r(t, {
				messages: a,
				emptyState: f
			})
		}), /* @__PURE__ */ r("div", {
			className: n.compositor,
			children: /* @__PURE__ */ r(e, {
				value: o,
				onChange: s,
				onSend: c,
				disabled: l,
				suggestions: u,
				placeholder: d
			})
		})]
	});
}
//#endregion
export { a as Conversation };

import { Badge as e } from "../primitives/Badge.js";
import { StatusPill as t } from "../primitives/StatusPill.js";
import n from "./DocHero.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/patterns/DocHero.tsx
var a = "­";
function o(e) {
	return e.replace(/([a-z])([A-Z])/g, `$1${a}$2`);
}
function s({ name: a, summary: s, platforms: c = [], a11yLevel: l, style: u }) {
	let d = c.length > 0 || l;
	return /* @__PURE__ */ i("section", {
		className: n.root,
		style: u,
		children: [/* @__PURE__ */ r("div", {
			className: n.main,
			children: /* @__PURE__ */ r("h1", {
				className: n.headline,
				children: o(a)
			})
		}), /* @__PURE__ */ i("div", {
			className: n.meta,
			children: [/* @__PURE__ */ r("p", {
				className: n.desc,
				children: s
			}), d && /* @__PURE__ */ i("div", {
				className: n.pills,
				children: [c.map((e) => /* @__PURE__ */ r(t, {
					label: e.label,
					tone: e.tone
				}, e.label)), l && /* @__PURE__ */ r(e, {
					tone: "info",
					children: l
				})]
			})]
		})]
	});
}
//#endregion
export { s as DocHero };

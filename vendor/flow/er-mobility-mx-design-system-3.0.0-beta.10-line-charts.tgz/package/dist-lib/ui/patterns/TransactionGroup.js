import { Card as e } from "../primitives/Card.js";
import { Divider as t } from "../primitives/Divider.js";
import n from "./TransactionGroup.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/patterns/TransactionGroup.tsx
function a({ label: a, children: o, style: s }) {
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: s,
		children: [a && /* @__PURE__ */ r("div", {
			className: n.label,
			children: /* @__PURE__ */ r(t, { label: a })
		}), /* @__PURE__ */ r(e, {
			padding: "sm",
			children: /* @__PURE__ */ r("div", {
				className: n.list,
				children: o
			})
		})]
	});
}
//#endregion
export { a as TransactionGroup };

//#region src/ui/patterns/GuidanceCard.module.css
var e = "a5K42q_body", t = "a5K42q_label", n = "a5K42q_root", r = "a5K42q_rules", i = "a5K42q_specimen", a = {
	body: e,
	label: t,
	root: n,
	rules: r,
	specimen: i
};
//#endregion
export { e as body, a as default, t as label, n as root, r as rules, i as specimen };

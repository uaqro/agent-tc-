//#region src/ui/patterns/TransferList.module.css
var e = "tn_gta_cabecera", t = "tn_gta_cuenta", n = "tn_gta_etiqueta", r = "tn_gta_item", i = "tn_gta_lista", a = "tn_gta_mandos", o = "tn_gta_meta", s = "tn_gta_panel", c = "tn_gta_root", l = "tn_gta_titulo", u = {
	cabecera: e,
	cuenta: t,
	etiqueta: n,
	item: r,
	lista: i,
	mandos: a,
	meta: o,
	panel: s,
	root: c,
	titulo: l
};
//#endregion
export { e as cabecera, t as cuenta, u as default, n as etiqueta, r as item, i as lista, a as mandos, o as meta, s as panel, c as root, l as titulo };

import { useT as e } from "../../i18n/useSafeIntl.js";
import { nombrarPorReferencia as t } from "../../hooks/useNombrePorReferencia.js";
import n from "./Settings.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useId as a } from "react";
//#region src/ui/patterns/Settings.tsx
function o({ label: e, description: o, control: s }) {
	let c = a(), l = t(s, c);
	return /* @__PURE__ */ i("div", {
		className: n.row,
		children: [/* @__PURE__ */ i("div", {
			className: n.rowText,
			children: [/* @__PURE__ */ r("div", {
				id: c,
				className: n.rowLabel,
				children: e
			}), o && /* @__PURE__ */ r("div", {
				className: n.rowDesc,
				children: o
			})]
		}), /* @__PURE__ */ r("div", {
			className: n.rowControl,
			children: l
		})]
	});
}
function s({ title: e, children: t }) {
	return /* @__PURE__ */ i("div", {
		className: n.section,
		children: [/* @__PURE__ */ r("div", {
			className: n.sectionTitle,
			children: e
		}), t]
	});
}
function c({ title: t, children: a }) {
	let o = e(), s = t ?? o("settings.dangerZone", "Zona peligrosa");
	return /* @__PURE__ */ i("div", {
		className: n.danger,
		children: [/* @__PURE__ */ r("div", {
			className: n.dangerTitle,
			children: s
		}), a]
	});
}
function l({ description: e, action: t }) {
	return /* @__PURE__ */ i("div", {
		className: n.dangerRow,
		children: [/* @__PURE__ */ r("div", {
			className: n.dangerDesc,
			children: e
		}), t]
	});
}
function u({ children: e }) {
	return /* @__PURE__ */ r("div", {
		className: n.root,
		children: e
	});
}
//#endregion
export { u as Settings, l as SettingsDangerRow, c as SettingsDangerZone, o as SettingsRow, s as SettingsSection };

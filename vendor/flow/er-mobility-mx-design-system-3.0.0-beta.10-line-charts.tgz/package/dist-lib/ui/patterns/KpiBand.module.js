//#region src/ui/patterns/KpiBand.module.css
var e = "JWe3oG_root", t = { root: e };
//#endregion
export { t as default, e as root };

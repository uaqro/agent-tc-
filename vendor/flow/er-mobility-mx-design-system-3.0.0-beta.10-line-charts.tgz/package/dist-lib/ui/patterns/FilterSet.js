"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { Chip as n } from "../primitives/Chip.js";
import { Divider as r } from "../primitives/Divider.js";
import { IconButton as i } from "../primitives/IconButton.js";
import { Input as a } from "../primitives/Input.js";
import { Select as o } from "../primitives/Select.js";
import { SheetBody as s } from "../primitives/SheetBody.js";
import { Stack as c } from "../primitives/Stack.js";
import { BottomSheet as l } from "../components/BottomSheet.js";
import { FilterBar as u } from "../components/FilterBar.js";
import { ActiveFilters as d } from "../components/ActiveFilters.js";
import { SavedViews as f } from "../components/SavedViews.js";
import p from "./FilterSet.module.js";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
import { useState as g } from "react";
//#region src/ui/patterns/FilterSet.tsx
var _ = {};
function v({ presentation: v = "inline", query: y = "", onQueryChange: b, searchLabel: x, title: S, description: C, filterLabel: w, applyLabel: T, dimensions: E, value: D, defaultValue: O, onChange: k, period: A, views: j, activeViewId: M, onViewsChange: N, onActiveViewChange: P, maxViews: F = 12, trailing: I, style: L }) {
	let R = e(), [z, B] = g(!1), [V, H] = g({}), [U, W] = g(""), [G, K] = g(null), q = D !== void 0, [J, Y] = g(O ?? _), X = q ? D : J, Z = (e, t) => {
		q || Y(e), k?.(e), t === void 0 ? M && P?.(null) : P?.(t);
	}, Q = E.flatMap((e) => (X[e.id] ?? []).map((t) => ({
		id: `${e.id}:${t}`,
		dimension: e.label,
		label: e.options.find((e) => e.value === t)?.label ?? t
	}))), $ = (e) => {
		let [t, n] = e.split(":");
		Z({
			...X,
			[t]: (X[t] ?? []).filter((e) => e !== n)
		});
	};
	if (v === "sheet") {
		let e = w ?? R("filterSet.label", "Filtros"), r = E.filter((e) => X[e.id]?.length).length, o = (e, t, n) => {
			W(""), K(null), H((r) => {
				let i = r[e] ?? [];
				return {
					...r,
					[e]: i.includes(t) ? i.filter((e) => e !== t) : n ? [...i, t] : [t]
				};
			});
		};
		return /* @__PURE__ */ h("div", {
			className: p.root,
			"data-presentation": "sheet",
			style: L,
			children: [
				/* @__PURE__ */ h("div", {
					className: p.searchRow,
					children: [b && /* @__PURE__ */ m(a, {
						icon: "search",
						type: "search",
						value: y,
						onChange: b,
						ariaLabel: x ?? R("filterSet.search", "Buscar"),
						placeholder: x ?? R("filterSet.search", "Buscar")
					}), /* @__PURE__ */ m(i, {
						icon: "tune",
						variant: "secondary",
						ariaLabel: r ? `${e}, ${r} activos` : e,
						badge: r > 0,
						"aria-haspopup": "dialog",
						"aria-expanded": z,
						onClick: () => {
							H(Object.fromEntries(Object.entries(X).map(([e, t]) => [e, [...t]]))), W(""), K(M ?? null), B(!0);
						}
					})]
				}),
				(Q.length > 0 || A) && /* @__PURE__ */ h("div", {
					className: p.chipStrip,
					"aria-label": e,
					children: [A && /* @__PURE__ */ m(n, {
						label: A,
						size: "sm"
					}), Q.map((e) => /* @__PURE__ */ m(n, {
						size: "sm",
						label: `${e.dimension}: ${e.label}`,
						onRemove: () => $(e.id)
					}, e.id))]
				}),
				/* @__PURE__ */ m(l, {
					open: z,
					onOpenChange: B,
					fullscreen: !0,
					fixed: !1,
					title: S ?? e,
					headerActions: /* @__PURE__ */ m(i, {
						icon: "close",
						ariaLabel: R("common.close", "Cerrar"),
						onClick: () => B(!1)
					}),
					children: /* @__PURE__ */ h("div", {
						className: p.sheetContent,
						children: [/* @__PURE__ */ h(s, { children: [
							C && /* @__PURE__ */ m("span", {
								className: p.hint,
								children: C
							}),
							E.map((e) => /* @__PURE__ */ h("section", {
								className: p.dimension,
								"aria-label": e.label,
								children: [/* @__PURE__ */ m("h3", {
									className: p.dimensionLabel,
									children: e.label
								}), /* @__PURE__ */ h(c, {
									wrap: !0,
									gap: "inline",
									children: [/* @__PURE__ */ m(n, {
										label: R("common.all", "Todos"),
										selected: !V[e.id]?.length,
										onClick: () => {
											W(""), K(null), H((t) => ({
												...t,
												[e.id]: []
											}));
										}
									}), e.options.map((t) => /* @__PURE__ */ m(n, {
										label: t.label,
										icon: t.icon,
										selected: V[e.id]?.includes(t.value) ?? !1,
										onClick: () => o(e.id, t.value, e.multiple)
									}, t.value))]
								})]
							}, e.id)),
							j && /* @__PURE__ */ m(f, {
								views: j.map((e) => ({
									id: e.id,
									name: e.name
								})),
								activeId: G,
								max: F,
								onApply: (e) => {
									let t = j.find((t) => t.id === e);
									t && (H(t.value), K(e));
								},
								onSave: (e) => N?.([...j, {
									id: `v${Date.now()}`,
									name: e,
									value: { ...V }
								}]),
								onDelete: (e) => N?.(j.filter((t) => t.id !== e))
							}),
							I
						] }), /* @__PURE__ */ h("div", {
							className: p.sheetActions,
							children: [
								/* @__PURE__ */ m(t, {
									onClick: () => {
										Z(V, G), B(!1);
									},
									children: T?.(V) ?? R("common.apply", "Aplicar")
								}),
								/* @__PURE__ */ m(t, {
									variant: "ghost",
									disabled: !Object.values(V).some((e) => e.length),
									onClick: () => {
										H({}), K(null), W(R("filterSet.resetDone", "Filtros restablecidos. Aplica para confirmar."));
									},
									children: R("filterSet.reset", "Restablecer")
								}),
								U && /* @__PURE__ */ m("span", {
									role: "status",
									className: p.hint,
									children: U
								})
							]
						})]
					})
				})
			]
		});
	}
	return /* @__PURE__ */ m("div", {
		className: p.root,
		style: L,
		children: /* @__PURE__ */ h(c, {
			direction: "column",
			gap: "stack",
			children: [
				/* @__PURE__ */ h("div", {
					className: p.toolbar,
					children: [/* @__PURE__ */ m(u, { children: E.map((e) => /* @__PURE__ */ m(o, {
						multiple: e.multiple,
						options: e.options,
						value: e.multiple ? X[e.id] ?? [] : X[e.id]?.[0] ?? "",
						onChange: (t) => Z({
							...X,
							[e.id]: Array.isArray(t) ? t : t ? [t] : []
						}),
						insetLabel: e.label,
						clearable: !0
					}, e.id)) }), /* @__PURE__ */ h("div", {
						className: p.actions,
						children: [I, j && /* @__PURE__ */ m(f, {
							views: j.map((e) => ({
								id: e.id,
								name: e.name
							})),
							activeId: M ?? null,
							max: F,
							onApply: (e) => {
								let t = j.find((t) => t.id === e);
								t && Z(t.value, e);
							},
							onSave: (e) => N?.([...j, {
								id: `v${Date.now()}`,
								name: e,
								value: { ...X }
							}]),
							onDelete: (e) => N?.(j.filter((t) => t.id !== e))
						})]
					})]
				}),
				Q.length > 0 && /* @__PURE__ */ m(r, { label: R("filterSet.label", "Filtros") }),
				Q.length > 0 && /* @__PURE__ */ m(c, {
					gap: "stack",
					align: "center",
					wrap: !0,
					children: /* @__PURE__ */ m(d, {
						filters: Q,
						period: A,
						onRemove: $,
						onClearAll: Q.length > 0 ? () => Z({}) : void 0
					})
				})
			]
		})
	});
}
//#endregion
export { v as FilterSet };

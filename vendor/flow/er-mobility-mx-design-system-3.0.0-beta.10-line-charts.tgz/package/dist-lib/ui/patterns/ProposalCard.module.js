//#region src/ui/patterns/ProposalCard.module.css
var e = "IIFQ_a_content", t = "IIFQ_a_footer", n = "IIFQ_a_label", r = "IIFQ_a_panel", i = "IIFQ_a_root", a = {
	content: e,
	footer: t,
	label: n,
	panel: r,
	root: i
};
//#endregion
export { e as content, a as default, t as footer, n as label, r as panel, i as root };

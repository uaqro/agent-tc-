//#region src/ui/patterns/WidgetLibrary.module.css
var e = "_4j58jG_list", t = "_4j58jG_name", n = "_4j58jG_row", r = {
	list: e,
	name: t,
	row: n
};
//#endregion
export { r as default, e as list, t as name, n as row };

"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { EmptyState as n } from "../primitives/EmptyState.js";
import { Input as r } from "../primitives/Input.js";
import { StatusView as i } from "../primitives/StatusView.js";
import { Table as a } from "../components/Table.js";
import { BulkBar as o } from "../components/BulkBar.js";
import { Pagination as ee } from "../components/Pagination.js";
import s from "./DataTable.module.js";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
import { useEffect as te, useLayoutEffect as ne, useMemo as u, useRef as d, useState as f } from "react";
//#region src/ui/patterns/DataTable.tsx
var p = (e) => e.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(), m = (e, t) => e[t];
function h({ columns: h, onCellEdit: g, rows: _, rowKey: v, caption: y, title: b, titleAs: re = "h2", description: x, searchKeys: S, searchPlaceholder: ie, searchable: C = !0, sortable: ae = !0, paginated: oe = !0, query: se, onQueryChange: ce, manual: w = !1, page: le, onPageChange: ue, total: de, sort: T, onSortChange: fe, pageSize: pe = 10, pageSizeOptions: me, onRowClick: he, selectedKey: ge, density: _e, emptyLabel: E, filters: ve, selectable: ye, selectedKeys: be, defaultSelectedKeys: xe, onSelectionChange: Se, bulkActions: Ce, onBulkAction: we, loading: Te, error: D, onRetry: O, style: Ee }) {
	let k = e(), A = d(null), [j, De] = f(), [Oe, ke] = f(""), M = se ?? Oe, [Ae, je] = f(1), Me = le ?? Ae, [N, Ne] = f(pe), [Pe, Fe] = f(null), P = T === void 0 ? Pe : T, F = (e) => {
		le === void 0 && je(e), ue?.(e);
	}, Ie = (e) => {
		T === void 0 && Fe(e), fe?.(e);
	}, Le = be !== void 0, [Re, ze] = f(xe ?? []), Be = Le ? be : Re, I = u(() => {
		let e = p(M.trim());
		if (w || !e) return _;
		let t = S ?? null;
		return _.filter((n) => (t ?? Object.keys(n).filter((e) => typeof m(n, e) == "string")).some((t) => {
			let r = m(n, t);
			return (typeof r == "string" || typeof r == "number") && p(String(r)).includes(e);
		}));
	}, [
		_,
		M,
		S,
		w
	]), L = u(() => {
		if (w || !P) return I;
		let { key: e, dir: t } = P;
		return [...I].sort((n, r) => {
			let i = m(n, e), a = m(r, e), o = typeof i == "number" && typeof a == "number" ? i - a : String(i).localeCompare(String(a));
			return t === "asc" ? o : -o;
		});
	}, [
		I,
		P,
		w
	]), Ve = u(() => new Set(_.map((e) => m(e, v))), [_, v]), R = u(() => Be.filter((e) => Ve.has(e)), [Be, Ve]), z = (e) => {
		Le || ze(e), Se?.(e);
	}, B = u(() => L.map((e) => m(e, v)), [L, v]), V = de ?? L.length, He = de ?? _.length, H = Math.max(1, Math.ceil(V / N)), U = Math.min(Me, H), W = w || !oe ? L : L.slice((U - 1) * N, U * N), G = R.length, [K, q] = f(null), [J, Ue] = f(""), We = d(null), Y = d(null), X = d(null);
	te(() => {
		if (K || !Y.current) return;
		let { row: e, col: t } = Y.current;
		Y.current = null, We.current?.querySelector(`[data-cell="${e}|${t}"]`)?.focus?.();
	}, [K]);
	let Ge = (e, t, n) => {
		Y.current = {
			row: e,
			col: t
		}, X.current = {
			row: e,
			col: t,
			valor: String(n ?? "")
		}, Ue(String(n ?? "")), q({
			row: e,
			col: t
		});
	}, Ke = (e) => {
		X.current && (X.current.valor = e), Ue(e);
	}, qe = () => {
		X.current = null, q(null);
	}, Je = () => {
		let e = X.current;
		e && (X.current = null, g?.(e.row, e.col, e.valor), q(null));
	}, Ye = u(() => h.map((e) => !e.editable || !g ? e : {
		...e,
		render: (t) => {
			let n = String(t[v]);
			return K?.row === n && K?.col === e.key ? /* @__PURE__ */ c(r, {
				size: "sm",
				autoFocus: !0,
				value: J,
				onChange: Ke,
				onBlur: Je,
				ariaLabel: k("flow.dataTable.editCell", "Editar {col}", { col: e.label ?? e.key }),
				onKeyDown: (e) => {
					e.key === "Enter" && Je(), e.key === "Escape" && qe();
				}
			}) : /* @__PURE__ */ l("button", {
				type: "button",
				"data-cell": `${n}|${e.key}`,
				"data-bare": "",
				className: s.celdaEditable,
				onClick: () => Ge(n, e.key, t[e.key]),
				children: [e.render ? e.render(t) : String(t[e.key] ?? ""), /* @__PURE__ */ c("span", {
					className: `flow-symbol ${s.iconoEditar}`,
					"aria-hidden": "true",
					children: "edit"
				})]
			});
		}
	}), [
		h,
		K,
		J,
		g,
		v
	]), Xe = (e) => {
		se === void 0 && ke(e), ce?.(e), F(1);
	}, Z = M.trim(), Q = w ? _.length === 0 && !!M.trim() : _.length > 0 && L.length === 0, Ze = Q ? E ? E.replace("{q}", Z) : k("flow.dataTable.empty", "Sin resultados para «{q}»", { q: Z }) : E ? E.replace("{q}", "") : k("flow.dataTable.noData", "Sin datos");
	ne(() => {
		A.current && W.length === N && De(A.current.offsetHeight);
	}, [
		W.length,
		N,
		_e
	]);
	let $ = ye || C || !!b || !!x;
	return /* @__PURE__ */ l("div", {
		ref: We,
		className: s.root,
		style: Ee,
		children: [
			ve,
			/* @__PURE__ */ l("div", {
				className: s.bloque,
				children: [$ && /* @__PURE__ */ c(o, {
					rest: b || x || C ? /* @__PURE__ */ l("div", {
						className: s.toolbar,
						children: [
							(b || x) && /* @__PURE__ */ l("div", {
								className: s.nombre,
								children: [b && /* @__PURE__ */ c(re, {
									className: s.titulo,
									children: b
								}), x && /* @__PURE__ */ c("span", {
									className: s.descripcion,
									children: x
								})]
							}),
							C && /* @__PURE__ */ c("div", {
								className: s.busqueda,
								children: /* @__PURE__ */ c(r, {
									type: "search",
									icon: "search",
									value: M,
									onChange: Xe,
									placeholder: ie ?? k("flow.dataTable.search", "Buscar…"),
									ariaLabel: k("flow.dataTable.searchIn", "Buscar en {caption}", { caption: y })
								})
							}),
							/* @__PURE__ */ c("p", {
								className: s.count,
								"aria-live": "polite",
								children: M ? k("flow.dataTable.count", "{n} de {total}", {
									n: V,
									total: He
								}) : k("flow.dataTable.total", "{n} filas", { n: V })
							})
						]
					}) : null,
					count: G,
					actions: Ce,
					onAction: (e) => we?.(e, [...R]),
					onClear: G > 0 ? () => z([]) : void 0,
					extendLabel: G > 0 && G < B.length ? k("flow.dataTable.selectAllFiltered", "Seleccionar los {total}", { total: B.length }) : void 0,
					onExtend: () => z([...B])
				}), /* @__PURE__ */ c("div", {
					ref: A,
					style: j ? { minHeight: j } : void 0,
					children: D ? /* @__PURE__ */ c(i, {
						status: "error",
						title: k("flow.dataTable.errorTitle", "No se pudieron cargar los datos"),
						description: D,
						primaryAction: O ? /* @__PURE__ */ c(t, {
							variant: "secondary",
							icon: "refresh",
							onClick: O,
							children: k("flow.dataTable.retry", "Reintentar")
						}) : void 0
					}) : Te ? /* @__PURE__ */ c(i, {
						status: "loading",
						title: k("flow.dataTable.loading", "Cargando…")
					}) : L.length === 0 ? /* @__PURE__ */ c(n, {
						icon: Q ? "search_off" : "inbox",
						title: Ze,
						action: Q && C && Z ? /* @__PURE__ */ c(t, {
							variant: "secondary",
							onClick: () => Xe(""),
							children: k("flow.dataTable.clear", "Limpiar búsqueda")
						}) : void 0
					}) : /* @__PURE__ */ c(a, {
						columns: Ye,
						rows: W,
						rowKey: v,
						caption: y,
						sortable: ae,
						sort: P,
						onSortChange: Ie,
						onRowClick: he,
						selectedKey: ge,
						selectable: ye,
						selectedKeys: R,
						onSelectionChange: z,
						selectAllLabel: k("flow.dataTable.selectAll", "Seleccionar todo en {caption}", { caption: y }),
						attachedTop: $,
						density: _e
					})
				})]
			}),
			oe && H > 1 && /* @__PURE__ */ c(ee, {
				page: U,
				pages: H,
				onChange: F,
				total: V,
				pageSize: N,
				pageSizeOptions: me,
				onPageSizeChange: (e) => {
					Ne(e), F(1);
				},
				style: { width: "100%" }
			})
		]
	});
}
//#endregion
export { h as DataTable };

//#region src/ui/patterns/AuthForm.module.css
var e = "_R1N5q_accion", t = "_R1N5q_error", n = "_R1N5q_root", r = "_R1N5q_subtitle", i = "_R1N5q_title", a = {
	accion: e,
	error: t,
	root: n,
	subtitle: r,
	title: i
};
//#endregion
export { e as accion, a as default, t as error, n as root, r as subtitle, i as title };

import { useT as e } from "../../i18n/useSafeIntl.js";
import { IconButton as t } from "../primitives/IconButton.js";
import { BottomSheet as n } from "../components/BottomSheet.js";
import r from "./WidgetLibrary.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/patterns/WidgetLibrary.tsx
function o({ open: o, onClose: s, widgets: c, onToggle: l, onMove: u, title: d }) {
	let f = e();
	return /* @__PURE__ */ i(n, {
		open: o,
		onOpenChange: (e) => {
			e || s();
		},
		title: d ?? f("dashboard.customize", "Personalizar dashboard"),
		children: /* @__PURE__ */ i("ul", {
			"data-list": "",
			className: r.list,
			children: c.map((e, n) => /* @__PURE__ */ a("li", {
				className: r.row,
				"data-hidden": !e.visible || void 0,
				children: [
					/* @__PURE__ */ i("span", {
						"data-truncate": "",
						className: r.name,
						children: e.title
					}),
					/* @__PURE__ */ i(t, {
						icon: "arrow_upward",
						ariaLabel: `${f("common.moveUp", "Subir")}: ${e.title}`,
						disabled: n === 0,
						onClick: () => u(e.id, -1)
					}),
					/* @__PURE__ */ i(t, {
						icon: "arrow_downward",
						ariaLabel: `${f("common.moveDown", "Bajar")}: ${e.title}`,
						disabled: n === c.length - 1,
						onClick: () => u(e.id, 1)
					}),
					/* @__PURE__ */ i(t, {
						icon: e.visible ? "visibility_off" : "visibility",
						ariaLabel: `${e.visible ? f("common.hide", "Ocultar") : f("common.show", "Mostrar")}: ${e.title}`,
						onClick: () => l(e.id)
					})
				]
			}, e.id))
		})
	});
}
//#endregion
export { o as WidgetLibrary };

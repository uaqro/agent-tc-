//#region src/ui/patterns/OnboardingCarousel.module.css
var e = "qPreYq_bottom", t = "qPreYq_continueBtn", n = "qPreYq_dot", r = "qPreYq_dots", i = "qPreYq_heroIcon", a = "qPreYq_illustration", o = "qPreYq_illustrationInner", s = "qPreYq_root", c = "qPreYq_slideArea", l = "qPreYq_slideDesc", u = "qPreYq_slideText", d = "qPreYq_slideTitle", f = {
	bottom: e,
	continueBtn: t,
	dot: n,
	dots: r,
	heroIcon: i,
	illustration: a,
	illustrationInner: o,
	root: s,
	slideArea: c,
	slideDesc: l,
	slideText: u,
	slideTitle: d
};
//#endregion
export { e as bottom, t as continueBtn, f as default, n as dot, r as dots, i as heroIcon, a as illustration, o as illustrationInner, s as root, c as slideArea, l as slideDesc, u as slideText, d as slideTitle };

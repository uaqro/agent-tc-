"use client";
import { createContext as e, useContext as t } from "react";
//#region src/ui/patterns/chrome-context.ts
var n = e(null), r = n.Provider;
function i() {
	return t(n) ?? {};
}
//#endregion
export { r as PageChromeProvider, i as usePageChrome };

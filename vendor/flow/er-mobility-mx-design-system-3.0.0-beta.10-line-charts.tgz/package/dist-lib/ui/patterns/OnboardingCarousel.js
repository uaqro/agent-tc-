"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { useRovingTabs as t } from "../../hooks/useRovingTabs.js";
import { TextAction as n } from "../primitives/TextAction.js";
import r from "./OnboardingCarousel.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import { useRef as o } from "react";
//#region src/ui/patterns/OnboardingCarousel.tsx
var s = [
	1,
	2,
	3,
	4,
	5,
	6
].map((e) => `var(--illustration-${e})`);
function c({ icon: e, index: t }) {
	let n = s[t % s.length];
	return /* @__PURE__ */ i("div", {
		className: r.illustration,
		"aria-hidden": "true",
		style: { background: `color-mix(in srgb, ${n} 10%, transparent)` },
		children: /* @__PURE__ */ i("div", {
			className: r.illustrationInner,
			style: {
				background: n,
				boxShadow: `0 12px 28px color-mix(in srgb, ${n} 25%, transparent)`
			},
			children: /* @__PURE__ */ i("span", {
				className: `flow-symbol flow-symbol--fill ${r.heroIcon}`,
				"aria-hidden": "true",
				children: e || "auto_awesome"
			})
		})
	});
}
function l({ slides: s = [], index: l = 0, onIndexChange: u, onSkip: d, onDone: f, skipLabel: p, doneLabel: m, style: h }) {
	let g = e(), _ = p ?? g("onboarding.skip", "Omitir"), v = m ?? g("onboarding.done", "Empezar"), y = g("common.continue", "Continuar"), b = o(null), x = (e) => u?.(Math.max(0, Math.min(s.length - 1, e))), { alTeclado: S, pestana: C } = t(s.map((e, t) => String(t)), String(l), (e) => x(Number(e))), w = l === s.length - 1, T = s[l] || {};
	return /* @__PURE__ */ a("div", {
		className: r.root,
		style: h,
		onTouchStart: (e) => {
			b.current = e.touches[0].clientX;
		},
		onTouchEnd: (e) => {
			if (b.current == null) return;
			let t = e.changedTouches[0].clientX - b.current;
			Math.abs(t) > 50 && x(l + (t < 0 ? 1 : -1)), b.current = null;
		},
		children: [/* @__PURE__ */ a("div", {
			className: r.slideArea,
			children: [T.illustration || /* @__PURE__ */ i(c, {
				icon: T.icon,
				index: l
			}), /* @__PURE__ */ a("div", {
				className: r.slideText,
				children: [/* @__PURE__ */ i("div", {
					className: r.slideTitle,
					children: T.title
				}), T.description && /* @__PURE__ */ i("div", {
					className: r.slideDesc,
					children: T.description
				})]
			})]
		}), /* @__PURE__ */ a("div", {
			className: r.bottom,
			children: [
				/* @__PURE__ */ a("div", {
					className: r.dots,
					role: "tablist",
					onKeyDown: S,
					children: [/* @__PURE__ */ i("span", {
						"data-sr-only": "",
						children: g("carousel.step", "Paso {n} de {total}", {
							n: l + 1,
							total: s.length
						})
					}), s.map((e, t) => /* @__PURE__ */ i("button", {
						...C(String(t)),
						type: "button",
						role: "tab",
						"aria-selected": t === l,
						"data-bare": "",
						className: r.dot,
						"data-active": t === l || void 0,
						"aria-label": g("carousel.goTo", "Ir a diapositiva {n}", { n: t + 1 }),
						onClick: () => x(t)
					}, t))]
				}),
				/* @__PURE__ */ i("button", {
					type: "button",
					"data-bare": "",
					className: r.continueBtn,
					onClick: () => w ? f?.() : x(l + 1),
					children: w ? v : y
				}),
				d && /* @__PURE__ */ i(n, {
					onClick: d,
					children: _
				})
			]
		})]
	});
}
//#endregion
export { l as OnboardingCarousel };

"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Chip as t } from "../primitives/Chip.js";
import { ChipGroup as n } from "../primitives/ChipGroup.js";
import { Specimen as r } from "../primitives/Specimen.js";
import { CodeBlock as i } from "../components/CodeBlock.js";
import { SegmentedControl as a } from "../components/SegmentedControl.js";
import o from "./PlaygroundCanvas.module.js";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { useState as u } from "react";
//#region src/ui/patterns/PlaygroundCanvas.tsx
function d({ variants: d = [], sizes: f = [], densities: p = [], snippet: m, specLabels: h, children: g, style: _ }) {
	let v = e(), [y, b] = u(d[0]?.value ?? ""), [x, S] = u(f.includes("md") ? "md" : f[0] ?? "md"), [C, w] = u(p.includes("default") ? "default" : p[0] ?? "default"), [T, E] = u(!1), [D, O] = u(!1), k = typeof m == "function" ? m({
		variant: y,
		size: x
	}) : m, A = T && h ? h({
		variant: y,
		size: x,
		density: C
	}) : null;
	return /* @__PURE__ */ c("div", {
		className: o.root,
		style: _,
		children: /* @__PURE__ */ l("div", {
			className: o.surface,
			children: [
				(d.length > 0 || f.length > 0) && /* @__PURE__ */ l("div", {
					className: o.controls,
					children: [
						d.length > 0 && /* @__PURE__ */ c(n, { children: d.map((e) => /* @__PURE__ */ c(t, {
							label: e.label,
							variant: "ghost",
							size: "sm",
							mono: !0,
							selected: e.value === y,
							onClick: () => b(e.value)
						}, e.value)) }),
						f.length > 0 && /* @__PURE__ */ c(n, { children: f.map((e) => /* @__PURE__ */ c(t, {
							label: e,
							variant: "ghost",
							size: "sm",
							mono: !0,
							selected: e === x,
							onClick: () => S(e)
						}, e)) }),
						p.length > 0 && /* @__PURE__ */ c(a, {
							size: "sm",
							items: p.map((e) => ({
								value: e,
								label: e
							})),
							value: C,
							onChange: w
						}),
						/* @__PURE__ */ l("div", {
							className: o.toggles,
							children: [/* @__PURE__ */ c(t, {
								label: v("playground.spec", "Especificación"),
								size: "sm",
								selected: T,
								onClick: () => E((e) => !e)
							}), /* @__PURE__ */ c(t, {
								label: v("playground.dark", "Oscuro"),
								size: "sm",
								selected: D,
								onClick: () => O((e) => !e)
							})]
						})
					]
				}),
				/* @__PURE__ */ c("div", {
					className: o.stage,
					"data-mode": D ? "dark" : void 0,
					children: /* @__PURE__ */ c(r, {
						grid: !0,
						centered: !0,
						children: /* @__PURE__ */ l("div", {
							className: o.specimen,
							"data-density": C === "default" ? void 0 : C,
							children: [g({
								variant: y,
								size: x,
								density: C
							}), T && /* @__PURE__ */ l(s, { children: [
								/* @__PURE__ */ c("div", { className: o.specDash }),
								A?.top && /* @__PURE__ */ c("span", {
									className: `${o.specLabel} ${o.specTop}`,
									children: A.top
								}),
								A?.right && /* @__PURE__ */ c("span", {
									className: `${o.specLabel} ${o.specRight}`,
									children: A.right
								}),
								A?.bottom && /* @__PURE__ */ c("span", {
									className: `${o.specLabel} ${o.specBottom}`,
									children: A.bottom
								})
							] })]
						})
					})
				}),
				k && /* @__PURE__ */ c("div", {
					className: o.snippetBar,
					children: /* @__PURE__ */ c(i, {
						code: k,
						variant: "inline"
					})
				})
			]
		})
	});
}
//#endregion
export { d as PlaygroundCanvas };

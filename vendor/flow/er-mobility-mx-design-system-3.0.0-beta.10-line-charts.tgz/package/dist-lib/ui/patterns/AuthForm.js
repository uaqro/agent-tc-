"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { Field as n } from "../primitives/Field.js";
import { Input as r } from "../primitives/Input.js";
import i from "./AuthForm.module.js";
import { Fragment as a, jsx as o, jsxs as s } from "react/jsx-runtime";
import { useEffect as c, useId as l, useRef as u, useState as d } from "react";
//#region src/ui/patterns/AuthForm.tsx
function f({ mode: f, loading: p, error: m, notice: h, noticeHref: g, onSubmit: _, title: v, subtitle: y, children: b, footer: x, submitLabel: S, submitIcon: C }) {
	let w = e(), T = l(), E = `${T}-name`, D = `${T}-email`, O = `${T}-pass`, [k, A] = d(""), [j, M] = d(""), [N, P] = d(""), [F, I] = d(null), [L, R] = d(null), [z, B] = d(null), V = u(null);
	c(() => {
		I(null), R(null), B(null);
	}, [f]);
	let H = (e) => {
		(V.current?.querySelectorAll("input"))?.[e]?.focus();
	}, U = +(f === "signup"), W = f === "signup" ? 2 : 1, G = (e) => {
		if (e.preventDefault(), I(null), R(null), B(null), f === "sso") {
			_({
				email: "",
				password: "",
				name: "",
				mode: f
			});
			return;
		}
		if (!k.includes("@")) {
			I(w("auth.emailError", "Ingresa un correo válido.")), H(U);
			return;
		}
		if (f !== "recover" && (!j || j.length < 8)) {
			f === "signup" ? (R(w("auth.passwordError", "La contraseña debe tener al menos 8 caracteres.")), H(W)) : (B(w("auth.credentialsError", "Correo o contraseña incorrectos.")), H(U));
			return;
		}
		_({
			email: k,
			password: j,
			name: N,
			mode: f
		});
	}, K = {
		"recover-sent": w("auth.recoverSent", "Si esa dirección de correo está en nuestra base, te enviaremos un correo para restablecer tu contraseña."),
		"signup-sent": w("auth.signupSent", "Enviamos un enlace de activación al correo que indicaste."),
		"otp-expired": w("auth.otpExpired", "El código que ingresaste expiró. Solicita uno nuevo."),
		"account-locked": w("auth.accountLocked", "Tu cuenta está bloqueada."),
		"account-inactive": w("auth.accountInactive", "Tu cuenta está inactiva."),
		"password-expired": w("auth.passwordExpired", "Tu contraseña expiró. Restablécela con la opción de recuperar contraseña.")
	}, q = {
		"account-locked": w("auth.accountLockedAction", "Sigue este enlace para continuar con el proceso de desbloqueo."),
		"account-inactive": w("auth.accountInactiveAction", "Sigue este enlace para continuar con el proceso de reactivación.")
	}, J = h != null && h !== "recover-sent" && h !== "signup-sent", Y = h && g ? q[h] : void 0, X = f === "login" ? w("auth.login", "Entrar") : f === "signup" ? w("auth.signup", "Crear cuenta") : f === "sso" ? w("auth.sso", "Entrar") : w("auth.recover", "Recuperar contraseña"), Z = f === "login" ? w("auth.submitLogin", "Entrar") : f === "signup" ? w("auth.submitSignup", "Crear cuenta") : f === "sso" ? w("auth.submitSso", "Continuar con tu proveedor") : w("auth.submitRecover", "Enviar instrucciones"), Q = f !== "sso";
	return /* @__PURE__ */ s("form", {
		ref: V,
		onSubmit: G,
		className: i.root,
		children: [
			/* @__PURE__ */ s("div", { children: [/* @__PURE__ */ o("h1", {
				className: i.title,
				children: v ?? X
			}), y && /* @__PURE__ */ o("p", {
				className: i.subtitle,
				children: y
			})] }),
			Q && f === "signup" && /* @__PURE__ */ o(n, {
				label: w("auth.name", "Nombre"),
				htmlFor: E,
				required: !0,
				children: /* @__PURE__ */ o(r, {
					id: E,
					value: N,
					onChange: P,
					icon: "person",
					autoComplete: "name",
					placeholder: w("auth.namePlaceholder", "Ana Sosa")
				})
			}),
			Q && /* @__PURE__ */ o(n, {
				label: w("auth.email", "Correo"),
				htmlFor: D,
				required: !0,
				error: F ?? void 0,
				children: /* @__PURE__ */ o(r, {
					id: D,
					value: k,
					onChange: (e) => {
						A(e), F && I(null);
					},
					icon: "mail",
					placeholder: w("auth.emailPlaceholder", "ana@flota.mx"),
					type: "email",
					autoComplete: "email",
					invalid: !!F
				})
			}),
			Q && f !== "recover" && /* @__PURE__ */ o(n, {
				label: w("auth.password", "Contraseña"),
				htmlFor: O,
				required: !0,
				help: f === "signup" ? w("auth.passwordHint", "Mínimo 8 caracteres.") : void 0,
				error: L ?? void 0,
				children: /* @__PURE__ */ o(r, {
					id: O,
					value: j,
					onChange: (e) => {
						M(e), L && R(null), z && B(null);
					},
					icon: "lock",
					placeholder: "••••••••",
					autoComplete: f === "signup" ? "new-password" : "current-password",
					revealable: !0
				})
			}),
			(h ?? m ?? z) && /* @__PURE__ */ s("p", {
				className: i.error,
				"data-tono": h && !J ? "info" : void 0,
				role: "alert",
				children: [h ? K[h] : m ?? z, Y && /* @__PURE__ */ s(a, { children: [" ", /* @__PURE__ */ o("a", {
					"data-link": !0,
					href: g,
					className: i.accion,
					children: Y
				})] })]
			}),
			b,
			/* @__PURE__ */ o(t, {
				type: "submit",
				variant: "primary",
				size: "lg",
				fullWidth: !0,
				loading: p,
				icon: C,
				children: S ?? Z
			}),
			x
		]
	});
}
//#endregion
export { f as AuthForm };

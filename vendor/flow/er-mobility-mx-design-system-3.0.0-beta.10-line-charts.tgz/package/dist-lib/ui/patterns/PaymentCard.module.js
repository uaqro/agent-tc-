//#region src/ui/patterns/PaymentCard.module.css
var e = "I4rO2a_bottom", t = "I4rO2a_chip", n = "I4rO2a_dots", r = "I4rO2a_expires", i = "I4rO2a_frozenIcon", a = "I4rO2a_frozenLabel", o = "I4rO2a_frozenOverlay", s = "I4rO2a_frozenShackle", c = "I4rO2a_holder", l = "I4rO2a_label", u = "I4rO2a_last4", d = "I4rO2a_number", f = "I4rO2a_productRow", p = "I4rO2a_root", m = "I4rO2a_top", h = {
	bottom: e,
	chip: t,
	dots: n,
	expires: r,
	frozenIcon: i,
	frozenLabel: a,
	frozenOverlay: o,
	frozenShackle: s,
	holder: c,
	label: l,
	last4: u,
	number: d,
	productRow: f,
	root: p,
	top: m
};
//#endregion
export { e as bottom, t as chip, h as default, n as dots, r as expires, i as frozenIcon, a as frozenLabel, o as frozenOverlay, s as frozenShackle, c as holder, l as label, u as last4, d as number, f as productRow, p as root, m as top };

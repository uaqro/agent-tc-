//#region src/ui/patterns/RideOffer.module.css
var e = "vNbJQG_cabecera", t = "vNbJQG_cuenta", n = "vNbJQG_cuentaNum", r = "vNbJQG_importe", i = "vNbJQG_marca", a = "vNbJQG_meta", o = "vNbJQG_parada", s = "vNbJQG_paradas", c = "vNbJQG_root", l = "vNbJQG_salidas", u = "vNbJQG_tag", d = {
	cabecera: e,
	cuenta: t,
	cuentaNum: n,
	importe: r,
	marca: i,
	meta: a,
	parada: o,
	paradas: s,
	root: c,
	salidas: l,
	tag: u
};
//#endregion
export { e as cabecera, t as cuenta, n as cuentaNum, d as default, r as importe, i as marca, a as meta, o as parada, s as paradas, c as root, l as salidas, u as tag };

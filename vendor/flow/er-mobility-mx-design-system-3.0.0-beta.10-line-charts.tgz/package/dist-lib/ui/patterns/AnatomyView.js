import { Specimen as e } from "../primitives/Specimen.js";
import t from "./AnatomyView.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/patterns/AnatomyView.tsx
function i({ parts: i, children: a, style: o }) {
	return /* @__PURE__ */ r("div", {
		className: t.root,
		style: o,
		children: [a && /* @__PURE__ */ n(e, {
			centered: !0,
			grid: !0,
			children: a
		}), /* @__PURE__ */ n("ol", {
			"data-list": "",
			className: t.legend,
			children: i.map((e, i) => /* @__PURE__ */ r("li", {
				className: t.part,
				children: [/* @__PURE__ */ n("span", {
					"data-count": "",
					className: t.number,
					children: i + 1
				}), /* @__PURE__ */ r("div", {
					className: t.partText,
					children: [/* @__PURE__ */ n("span", {
						className: t.partLabel,
						children: e.label
					}), e.description && /* @__PURE__ */ n("span", {
						className: t.partDesc,
						children: e.description
					})]
				})]
			}, i))
		})]
	});
}
//#endregion
export { i as AnatomyView };

//#region src/ui/patterns/PullToRefresh.module.css
var e = "_8BTMbW_contenido", t = "_8BTMbW_pista", n = "_8BTMbW_root", r = "_8BTMbW_zona", i = {
	contenido: e,
	pista: t,
	root: n,
	zona: r
};
//#endregion
export { e as contenido, i as default, t as pista, n as root, r as zona };

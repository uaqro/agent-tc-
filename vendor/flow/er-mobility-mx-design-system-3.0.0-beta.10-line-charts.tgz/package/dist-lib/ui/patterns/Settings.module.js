//#region src/ui/patterns/Settings.module.css
var e = "_26c8la_danger", t = "_26c8la_dangerDesc", n = "_26c8la_dangerRow", r = "_26c8la_dangerTitle", i = "_26c8la_root", a = "_26c8la_row", o = "_26c8la_rowControl", s = "_26c8la_rowDesc", c = "_26c8la_rowLabel", l = "_26c8la_rowText", u = "_26c8la_section", d = "_26c8la_sectionTitle", f = {
	danger: e,
	dangerDesc: t,
	dangerRow: n,
	dangerTitle: r,
	root: i,
	row: a,
	rowControl: o,
	rowDesc: s,
	rowLabel: c,
	rowText: l,
	section: u,
	sectionTitle: d
};
//#endregion
export { e as danger, t as dangerDesc, n as dangerRow, r as dangerTitle, f as default, i as root, a as row, o as rowControl, s as rowDesc, c as rowLabel, l as rowText, u as section, d as sectionTitle };

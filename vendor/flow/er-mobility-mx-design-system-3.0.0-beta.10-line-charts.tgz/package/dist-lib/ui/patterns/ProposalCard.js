import { Card as e } from "../primitives/Card.js";
import t from "./ProposalCard.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/patterns/ProposalCard.tsx
function i({ before: i, after: a, beforeLabel: o = "Before", afterLabel: s = "After", footer: c, style: l }) {
	return /* @__PURE__ */ r(e, {
		surface: "outlined",
		style: l,
		padding: 0,
		children: [/* @__PURE__ */ r("div", {
			className: t.root,
			children: [/* @__PURE__ */ r("div", {
				className: t.panel,
				"data-tone": "danger",
				children: [/* @__PURE__ */ n("span", {
					"data-overline": "",
					className: t.label,
					children: o
				}), /* @__PURE__ */ n("div", {
					className: t.content,
					children: i
				})]
			}), /* @__PURE__ */ r("div", {
				className: t.panel,
				"data-tone": "success",
				children: [/* @__PURE__ */ n("span", {
					"data-overline": "",
					className: t.label,
					children: s
				}), /* @__PURE__ */ n("div", {
					className: t.content,
					children: a
				})]
			})]
		}), c && /* @__PURE__ */ n("div", {
			className: t.footer,
			children: c
		})]
	});
}
//#endregion
export { i as ProposalCard };

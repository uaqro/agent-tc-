"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { CircularProgress as n } from "../primitives/CircularProgress.js";
import r from "./RideOffer.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
import { useEffect as o, useRef as s, useState as c } from "react";
//#region src/ui/patterns/RideOffer.tsx
function l({ stops: l, tag: u, meta: d = [], amount: f, seconds: p, onExpire: m, onAccept: h, onPass: g, acceptLabel: _, passLabel: v, style: y }) {
	let b = e(), [x, S] = c(p ?? 0), C = s(!1);
	return o(() => {
		S(p ?? 0), C.current = !1;
	}, [p]), o(() => {
		if (p == null) return;
		if (x <= 0) {
			C.current || (C.current = !0, m?.());
			return;
		}
		let e = setTimeout(() => S((e) => e - 1), 1e3);
		return () => clearTimeout(e);
	}, [
		x,
		p,
		m
	]), /* @__PURE__ */ a("div", {
		className: r.root,
		style: y,
		children: [
			/* @__PURE__ */ a("div", {
				className: r.cabecera,
				children: [u && /* @__PURE__ */ i("span", {
					"data-overline": "",
					className: r.tag,
					children: u
				}), p != null && /* @__PURE__ */ i("span", {
					className: r.cuenta,
					children: /* @__PURE__ */ i(n, {
						value: x,
						max: p,
						size: 40,
						strokeWidth: 3,
						tone: "inherit",
						ariaLabel: b("rideOffer.countdown", "Quedan {n} segundos para decidir", { n: x }),
						children: /* @__PURE__ */ i("span", {
							className: r.cuentaNum,
							children: x
						})
					})
				})]
			}),
			/* @__PURE__ */ i("ol", {
				"data-list": "",
				className: r.paradas,
				children: l.map((e, t) => /* @__PURE__ */ a("li", {
					className: r.parada,
					children: [/* @__PURE__ */ i("span", {
						className: r.marca,
						"data-fin": t === l.length - 1 && l.length > 1 ? "" : void 0
					}), /* @__PURE__ */ i("span", { children: e })]
				}, t))
			}),
			(d.length > 0 || f) && /* @__PURE__ */ a("p", {
				className: r.meta,
				children: [d.map((e, t) => /* @__PURE__ */ a("span", { children: [t > 0 && /* @__PURE__ */ i("span", {
					"aria-hidden": "true",
					children: " · "
				}), e] }, t)), f && /* @__PURE__ */ i("span", {
					className: r.importe,
					children: f
				})]
			}),
			/* @__PURE__ */ a("div", {
				className: r.salidas,
				children: [/* @__PURE__ */ i(t, {
					variant: "ghost",
					size: "lg",
					onClick: g,
					children: v ?? b("rideOffer.pass", "Pasar")
				}), /* @__PURE__ */ i(t, {
					variant: "primary",
					size: "lg",
					onClick: h,
					children: _ ?? b("rideOffer.accept", "Aceptar")
				})]
			})
		]
	});
}
//#endregion
export { l as RideOffer };

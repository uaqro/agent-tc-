//#region src/ui/patterns/DataTable.module.css
var e = "RP85TG_bloque", t = "RP85TG_busqueda", n = "RP85TG_celdaEditable", r = "RP85TG_count", i = "RP85TG_descripcion", a = "RP85TG_iconoEditar", o = "RP85TG_nombre", s = "RP85TG_root", c = "RP85TG_titulo", l = "RP85TG_toolbar", u = {
	bloque: e,
	busqueda: t,
	celdaEditable: n,
	count: r,
	descripcion: i,
	iconoEditar: a,
	nombre: o,
	root: s,
	titulo: c,
	toolbar: l
};
//#endregion
export { e as bloque, t as busqueda, n as celdaEditable, r as count, u as default, i as descripcion, a as iconoEditar, o as nombre, s as root, c as titulo, l as toolbar };

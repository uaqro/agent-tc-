"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { DataGrid as t } from "../components/DataGrid.js";
import { BulkBar as n } from "../components/BulkBar.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useState as a } from "react";
//#region src/ui/patterns/BulkActionsTable.tsx
function o({ columns: o, rows: s, rowKey: c, caption: l, actions: u = [], onActionClick: d, style: f }) {
	let p = e(), [m, h] = a([]), g = m.length;
	return /* @__PURE__ */ i("div", {
		style: f,
		children: [/* @__PURE__ */ r(n, {
			rest: /* @__PURE__ */ r("span", { children: p("bulk.records", "{total} registros", { total: s.length }) }),
			count: g,
			actions: u,
			onAction: (e) => d?.(e, m.map(String)),
			onClear: () => h([])
		}), /* @__PURE__ */ r(t, {
			columns: o,
			rows: s,
			rowKey: c,
			caption: l,
			attachedTop: !0,
			selectable: !0,
			selectedKeys: m,
			onSelectionChange: h,
			selectAllLabel: p("bulk.selectAll", "Seleccionar todo"),
			density: "compact",
			zebraToken: "var(--surface-sunken)"
		})]
	});
}
//#endregion
export { o as BulkActionsTable };

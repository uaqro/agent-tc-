//#region src/ui/patterns/DocHero.module.css
var e = "nmVZdG_desc", t = "nmVZdG_headline", n = "nmVZdG_main", r = "nmVZdG_meta", i = "nmVZdG_pills", a = "nmVZdG_root", o = {
	desc: e,
	headline: t,
	main: n,
	meta: r,
	pills: i,
	root: a
};
//#endregion
export { o as default, e as desc, t as headline, n as main, r as meta, i as pills, a as root };

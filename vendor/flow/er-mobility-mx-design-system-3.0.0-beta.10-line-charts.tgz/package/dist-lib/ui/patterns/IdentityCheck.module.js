//#region src/ui/patterns/IdentityCheck.module.css
var e = "f8U_xW_error", t = "f8U_xW_greeting", n = "f8U_xW_link", r = "f8U_xW_root", i = {
	error: e,
	greeting: t,
	link: n,
	root: r
};
//#endregion
export { i as default, e as error, t as greeting, n as link, r as root };

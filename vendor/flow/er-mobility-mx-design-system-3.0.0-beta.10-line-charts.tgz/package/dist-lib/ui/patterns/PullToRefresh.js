"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Spinner as t } from "../primitives/Spinner.js";
import n from "./PullToRefresh.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useRef as a, useState as o } from "react";
//#region src/ui/patterns/PullToRefresh.tsx
var s = 64, c = .5, l = 96;
function u({ onRefresh: u, refreshing: d = !1, children: f }) {
	let p = e(), [m, h] = o(0), g = a(null), _ = a(null), v = m >= s, y = d ? s : m;
	function b(e) {
		e.pointerType === "mouse" || d || (_.current?.scrollTop ?? 0) > 0 || (g.current = e.clientY);
	}
	function x(e) {
		if (g.current === null) return;
		let t = e.clientY - g.current;
		if (t <= 0) {
			h(0);
			return;
		}
		e.currentTarget.setPointerCapture?.(e.pointerId), h(Math.min(t * c, l));
	}
	async function S() {
		if (g.current === null) return;
		let e = m >= s;
		g.current = null, h(0), e && await u();
	}
	return /* @__PURE__ */ i("div", {
		className: n.root,
		"aria-busy": d || void 0,
		children: [/* @__PURE__ */ r("div", {
			className: n.zona,
			style: { height: y },
			"data-armado": v ? "" : void 0,
			children: d ? /* @__PURE__ */ r(t, { label: p("pullToRefresh.refreshing", "Actualizando") }) : /* @__PURE__ */ r("span", {
				className: n.pista,
				style: { opacity: Math.min(m / s, 1) },
				children: v ? p("pullToRefresh.release", "Suelta para actualizar") : p("pullToRefresh.pull", "Tira para actualizar")
			})
		}), /* @__PURE__ */ r("div", {
			className: n.contenido,
			ref: _,
			onPointerDown: b,
			onPointerMove: x,
			onPointerUp: S,
			onPointerCancel: S,
			children: f
		})]
	});
}
//#endregion
export { u as PullToRefresh };

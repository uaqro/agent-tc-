import { StatTile as e } from "../components/StatTile.js";
import t from "./KpiBand.module.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/ui/patterns/KpiBand.tsx
function r({ items: r, min: i = 200, style: a }) {
	return r.length ? /* @__PURE__ */ n("div", {
		className: t.root,
		style: {
			...a,
			"--kpi-min": `${i}px`
		},
		"data-kpi-band": "",
		children: r.map((t) => /* @__PURE__ */ n(e, { ...t }, t.label))
	}) : null;
}
//#endregion
export { r as KpiBand };

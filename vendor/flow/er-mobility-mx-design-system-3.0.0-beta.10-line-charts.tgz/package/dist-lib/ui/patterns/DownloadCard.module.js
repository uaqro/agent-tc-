//#region src/ui/patterns/DownloadCard.module.css
var e = "Zj4elW_action", t = "Zj4elW_desc", n = "Zj4elW_filename", r = "Zj4elW_icon", i = "Zj4elW_info", a = "Zj4elW_root", o = {
	action: e,
	desc: t,
	filename: n,
	icon: r,
	info: i,
	root: a
};
//#endregion
export { e as action, o as default, t as desc, n as filename, r as icon, i as info, a as root };

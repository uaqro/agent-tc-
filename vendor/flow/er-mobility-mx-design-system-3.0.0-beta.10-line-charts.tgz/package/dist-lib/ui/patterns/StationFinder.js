"use client";
import { Badge as e } from "../primitives/Badge.js";
import { useT as t } from "../../i18n/useSafeIntl.js";
import { Button as n } from "../primitives/Button.js";
import { Chip as r } from "../primitives/Chip.js";
import { DetailRow as i } from "../primitives/DetailRow.js";
import { Divider as a } from "../primitives/Divider.js";
import { IconButton as o } from "../primitives/IconButton.js";
import { SheetBody as s } from "../primitives/SheetBody.js";
import { BottomSheet as c } from "../components/BottomSheet.js";
import { FilterBar as l } from "../components/FilterBar.js";
import { MapCanvas as u } from "../components/MapCanvas.js";
import { RouteBanner as d } from "../components/RouteBanner.js";
import f from "./StationFinder.module.js";
import { jsx as p, jsxs as m } from "react/jsx-runtime";
import { useCallback as h, useMemo as g, useState as _ } from "react";
//#region src/ui/patterns/StationFinder.tsx
var v = "todas";
function y(e) {
	return /conector|ccs/i.test(e) ? "ev_station" : {
		Tienda: "storefront",
		"Aire y agua": "water_drop",
		Baños: "wc",
		Café: "local_cafe"
	}[e] ?? "info";
}
function b({ stations: b, filters: x, me: S, routes: C, zoom: w = 14, onStationSelect: T, style: E }) {
	let D = t(), [O, k] = _(v), A = () => [S[0], S[1]], [j, M] = _(A), [N, P] = _(null), [F, I] = _(!1), L = g(() => b.filter((e) => O === v || e.kind === O), [b, O]), R = b.find((e) => e.id === N), z = g(() => L.map((e) => ({
		id: e.id,
		lat: e.lat,
		lon: e.lon,
		label: e.label ?? e.name,
		subtitle: e.label ? e.name : void 0,
		icon: e.icon ?? (e.kind === "ev" ? "bolt" : "local_gas_station"),
		color: e.kind === "ev" ? "var(--viz-electro)" : "var(--viz-combustible)"
	})), [L]), B = h((e) => {
		P(e), I(!1), T?.(e);
	}, [T]), V = h((e) => {
		k(e), e === v || R && R.kind === e || B(null);
	}, [R, B]), H = F && N ? C?.[N] : void 0;
	return /* @__PURE__ */ m("div", {
		className: f.root,
		style: E,
		children: [
			/* @__PURE__ */ p(u, {
				center: j,
				zoom: w,
				pins: z,
				onPinClick: B,
				route: H,
				surface: "none",
				style: { flex: 1 }
			}),
			x && x.length > 0 && /* @__PURE__ */ m(l, {
				variant: "floating",
				children: [x.map(({ value: e, label: t, icon: n }) => /* @__PURE__ */ p(r, {
					label: t,
					icon: n,
					selected: O === e,
					onClick: () => V(e),
					style: { boxShadow: "var(--shadow-raised)" }
				}, e)), /* @__PURE__ */ p(o, {
					icon: "my_location",
					ariaLabel: D("stationFinder.myLocation", "Mi ubicación"),
					onClick: () => M(A()),
					variant: "tonal",
					size: "sm",
					style: {
						marginLeft: "auto",
						boxShadow: "var(--shadow-raised)"
					}
				})]
			}),
			F && R && /* @__PURE__ */ p(d, {
				title: D("stationFinder.towards", "Hacia {name}", { name: R.name }),
				subtitle: [R.dist, R.eta && D("stationFinder.eta", "llegas en {eta}", { eta: R.eta })].filter(Boolean).join(" · "),
				onClose: () => I(!1)
			}),
			/* @__PURE__ */ p(c, {
				open: !!R && !F,
				onOpenChange: (e) => !e && B(null),
				title: R?.name,
				fixed: !1,
				children: R && /* @__PURE__ */ p(s, { children: /* @__PURE__ */ m("div", {
					className: f.stationDetail,
					children: [
						/* @__PURE__ */ m("div", {
							className: f.badgeRow,
							children: [
								R.kindLabel && /* @__PURE__ */ p(e, {
									tone: R.tone ?? "neutral",
									icon: R.icon ?? (R.kind === "ev" ? "bolt" : "local_gas_station"),
									children: R.kindLabel
								}),
								R.open && /* @__PURE__ */ p(e, {
									icon: "schedule",
									children: R.open
								}),
								R.dist && /* @__PURE__ */ p(e, {
									icon: "near_me",
									children: R.dist
								}),
								R.services?.map((t) => /* @__PURE__ */ p(e, {
									tone: "neutral",
									icon: y(t),
									children: t
								}, t))
							]
						}),
						R.prices && R.prices.length > 0 && /* @__PURE__ */ p("div", {
							className: f.priceList,
							children: R.prices.map(([e, t], n) => /* @__PURE__ */ m("div", { children: [n > 0 && /* @__PURE__ */ p(a, {}), /* @__PURE__ */ p("div", {
								className: f.priceRow,
								children: /* @__PURE__ */ p(i, {
									label: e,
									value: t,
									mono: !0
								})
							})] }, e))
						}),
						C?.[R.id] && /* @__PURE__ */ p(n, {
							variant: "primary",
							size: "lg",
							icon: "navigation",
							fullWidth: !0,
							onClick: () => I(!0),
							children: R.eta ? D("stationFinder.goEta", "Cómo llegar · {eta}", { eta: R.eta }) : D("stationFinder.go", "Cómo llegar")
						})
					]
				}) })
			})
		]
	});
}
//#endregion
export { b as StationFinder };

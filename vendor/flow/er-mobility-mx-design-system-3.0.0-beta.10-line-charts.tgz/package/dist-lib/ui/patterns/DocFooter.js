import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./DocFooter.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/patterns/DocFooter.tsx
function i({ lastUpdated: i, version: a, links: o, children: s, style: c }) {
	let l = e();
	return /* @__PURE__ */ r("footer", {
		className: t.root,
		style: c,
		children: [/* @__PURE__ */ r("div", {
			className: t.info,
			children: [
				i && /* @__PURE__ */ n("span", {
					className: t.item,
					children: l("docfooter.lastUpdated", "Última actualización: {fecha}", { fecha: i })
				}),
				a && /* @__PURE__ */ n("span", {
					className: t.item,
					children: /* @__PURE__ */ n("span", {
						className: t.mono,
						children: a
					})
				}),
				s
			]
		}), o && o.length > 0 && /* @__PURE__ */ n("nav", {
			className: t.links,
			children: o.map((e, i) => /* @__PURE__ */ r("span", { children: [i > 0 && /* @__PURE__ */ n("span", {
				className: t.dot,
				children: "·"
			}), /* @__PURE__ */ n("a", {
				"data-link": "",
				href: e.href,
				className: t.link,
				children: e.label
			})] }, e.label))
		})]
	});
}
//#endregion
export { i as DocFooter };

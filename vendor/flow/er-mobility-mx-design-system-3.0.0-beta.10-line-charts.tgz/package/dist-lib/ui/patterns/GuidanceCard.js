import { Card as e } from "../primitives/Card.js";
import { Specimen as t } from "../primitives/Specimen.js";
import n from "./GuidanceCard.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/patterns/GuidanceCard.tsx
function a({ tone: a, rules: o, specimen: s, style: c }) {
	return /* @__PURE__ */ r(e, {
		style: c,
		padding: 0,
		children: /* @__PURE__ */ i("div", {
			className: n.root,
			"data-tone": a,
			children: [s && /* @__PURE__ */ r("div", {
				className: n.specimen,
				children: /* @__PURE__ */ r(t, {
					centered: !0,
					children: s
				})
			}), /* @__PURE__ */ i("div", {
				className: n.body,
				children: [/* @__PURE__ */ r("span", {
					"data-overline": "",
					className: n.label,
					children: a === "success" ? "Do" : "Don't"
				}), /* @__PURE__ */ r("ul", {
					className: n.rules,
					children: o.map((e, t) => /* @__PURE__ */ r("li", { children: e }, t))
				})]
			})]
		})
	});
}
//#endregion
export { a as GuidanceCard };

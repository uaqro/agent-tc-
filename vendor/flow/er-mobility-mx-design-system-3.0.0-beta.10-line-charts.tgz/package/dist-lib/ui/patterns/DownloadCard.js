import { Card as e } from "../primitives/Card.js";
import t from "./DownloadCard.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/patterns/DownloadCard.tsx
function i({ filename: i, description: a, icon: o = "description", href: s, style: c }) {
	return /* @__PURE__ */ n(e, {
		surface: "outlined",
		style: c,
		children: /* @__PURE__ */ r("div", {
			className: t.root,
			children: [
				/* @__PURE__ */ n("span", {
					className: `flow-symbol ${t.icon}`,
					"aria-hidden": "true",
					children: o
				}),
				/* @__PURE__ */ r("div", {
					className: t.info,
					children: [/* @__PURE__ */ n("span", {
						className: t.filename,
						children: i
					}), a && /* @__PURE__ */ n("span", {
						className: t.desc,
						children: a
					})]
				}),
				s && /* @__PURE__ */ n("a", {
					"data-link": "",
					href: s,
					className: t.action,
					children: /* @__PURE__ */ n("span", {
						className: "flow-symbol",
						"aria-hidden": "true",
						children: "download"
					})
				})
			]
		})
	});
}
//#endregion
export { i as DownloadCard };

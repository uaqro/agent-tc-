//#region src/ui/patterns/WidgetGrid.module.css
var e = "PNMgbq_celda", t = "PNMgbq_root", n = {
	celda: e,
	root: t
};
//#endregion
export { e as celda, n as default, t as root };

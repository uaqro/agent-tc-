"use client";
import { createContext as e, useContext as t } from "react";
//#region src/ui/patterns/sidebar-context.ts
var n = e(null), r = n.Provider;
function i() {
	return t(n);
}
//#endregion
export { r as SidebarProvider, i as useSidebarToggle };

//#region src/ui/patterns/PlaygroundCanvas.module.css
var e = "qLI3rW_controls", t = "qLI3rW_root", n = "qLI3rW_snippetBar", r = "qLI3rW_specBottom", i = "qLI3rW_specDash", a = "qLI3rW_specimen", o = "qLI3rW_specLabel", s = "qLI3rW_specRight", c = "qLI3rW_specTop", l = "qLI3rW_stage", u = "qLI3rW_surface", d = "qLI3rW_toggles", f = {
	controls: e,
	root: t,
	snippetBar: n,
	specBottom: r,
	specDash: i,
	specimen: a,
	specLabel: o,
	specRight: s,
	specTop: c,
	stage: l,
	surface: u,
	toggles: d
};
//#endregion
export { e as controls, f as default, t as root, n as snippetBar, r as specBottom, i as specDash, o as specLabel, s as specRight, c as specTop, a as specimen, l as stage, u as surface, d as toggles };

//#region src/ui/patterns/InstallCard.module.css
var e = "CzIRNq_header", t = "CzIRNq_platform", n = "CzIRNq_root", r = {
	header: e,
	platform: t,
	root: n
};
//#endregion
export { r as default, e as header, t as platform, n as root };

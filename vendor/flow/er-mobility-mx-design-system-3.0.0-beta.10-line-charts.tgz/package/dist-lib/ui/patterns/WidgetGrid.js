import { WidgetFrame as e } from "../components/WidgetFrame.js";
import t from "./WidgetGrid.module.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/ui/patterns/WidgetGrid.tsx
function r({ widgets: r, variant: i = "chrome", customizing: a, style: o }) {
	if (!r.length) return null;
	let s = r.findIndex((e) => e.span === "wide");
	return /* @__PURE__ */ n("div", {
		className: t.root,
		"data-variant": i,
		style: o,
		"data-widget-grid": "",
		"data-ancho": s > 0 ? "segundo" : "primero",
		children: r.map((r) => /* @__PURE__ */ n("div", {
			className: t.celda,
			"data-span": r.span ?? "normal",
			children: /* @__PURE__ */ n(e, {
				title: r.title,
				description: r.description,
				actions: r.actions,
				loading: r.loading,
				hidden: r.hidden,
				customizing: a,
				onToggle: r.onToggle,
				children: r.children
			})
		}, r.id ?? r.title))
	});
}
//#endregion
export { r as WidgetGrid };

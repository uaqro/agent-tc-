import { Badge as e } from "../primitives/Badge.js";
import { Card as t } from "../primitives/Card.js";
import { CodeBlock as n } from "../components/CodeBlock.js";
import r from "./InstallCard.module.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/ui/patterns/InstallCard.tsx
function o({ platform: o, command: s, status: c, statusTone: l = "success", style: u }) {
	return /* @__PURE__ */ i(t, {
		surface: "inverse",
		style: u,
		padding: 0,
		children: /* @__PURE__ */ a("div", {
			className: r.root,
			children: [/* @__PURE__ */ a("div", {
				className: r.header,
				children: [/* @__PURE__ */ i("span", {
					className: r.platform,
					children: o
				}), c && /* @__PURE__ */ i(e, {
					tone: l,
					children: c
				})]
			}), /* @__PURE__ */ i(n, {
				code: s,
				copyable: !0
			})]
		})
	});
}
//#endregion
export { o as InstallCard };

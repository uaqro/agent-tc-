import { useT as e } from "../../i18n/useSafeIntl.js";
import { Breadcrumb as t } from "../primitives/Breadcrumb.js";
import { IconButton as n } from "../primitives/IconButton.js";
import { NotificationCenter as r } from "../components/NotificationCenter.js";
import { useSidebarToggle as i } from "./sidebar-context.js";
import { usePageChrome as a } from "./chrome-context.js";
import o from "./PageHeader.module.js";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/ui/patterns/PageHeader.tsx
function l({ title: l, overline: u, description: d, breadcrumb: f = [], filters: p, actions: m, meta: h, utilities: g = !0, onSearch: _, searchLabel: v, notifications: y, onNotificationClick: b, onMarkAllRead: x, trailing: S, style: C }) {
	let w = e(), T = a(), E = g ? {
		onSearch: _ ?? T.onSearch,
		searchLabel: v ?? T.searchLabel,
		notifications: y ?? T.notifications,
		onNotificationClick: b ?? T.onNotificationClick,
		onMarkAllRead: x ?? T.onMarkAllRead,
		trailing: S ?? T.trailing
	} : {}, D = !!(p || m), O = i();
	return /* @__PURE__ */ c("div", {
		className: o.root,
		style: C,
		children: [/* @__PURE__ */ c("div", {
			className: o.row,
			children: [
				O && /* @__PURE__ */ s("span", {
					className: o.menuSlot,
					children: /* @__PURE__ */ s(n, {
						icon: "menu",
						variant: "ghost",
						ariaLabel: w("nav.open", "Abrir navegación"),
						onClick: O
					})
				}),
				/* @__PURE__ */ c("div", {
					className: o.identity,
					children: [
						f.length > 0 && /* @__PURE__ */ s(t, { items: f.map((e) => ({ label: e })) }),
						u && /* @__PURE__ */ s("div", {
							"data-overline": "",
							children: u
						}),
						l && /* @__PURE__ */ s("h1", {
							className: o.title,
							children: l
						}),
						d && /* @__PURE__ */ s("p", {
							className: o.description,
							children: d
						})
					]
				}),
				/* @__PURE__ */ s("div", { className: o.spacer }),
				h && /* @__PURE__ */ s("p", {
					className: o.meta,
					children: h
				}),
				!D && m && /* @__PURE__ */ s("div", {
					className: o.actions,
					children: m
				}),
				(E.onSearch || E.notifications || E.trailing) && /* @__PURE__ */ c("div", {
					className: o.utilities,
					children: [
						E.onSearch && /* @__PURE__ */ s(n, {
							icon: "search",
							ariaLabel: E.searchLabel ?? w("nav.search", "Buscar"),
							onClick: E.onSearch
						}),
						E.notifications && /* @__PURE__ */ s(r, {
							items: E.notifications,
							onItemClick: E.onNotificationClick,
							onMarkAllRead: E.onMarkAllRead
						}),
						E.trailing
					]
				})
			]
		}), D && /* @__PURE__ */ c("div", {
			className: o.row,
			children: [
				p && /* @__PURE__ */ s("div", {
					className: o.filters,
					children: p
				}),
				/* @__PURE__ */ s("div", { className: o.spacer }),
				m && /* @__PURE__ */ s("div", {
					className: o.actions,
					children: m
				})
			]
		})]
	});
}
//#endregion
export { l as PageHeader };

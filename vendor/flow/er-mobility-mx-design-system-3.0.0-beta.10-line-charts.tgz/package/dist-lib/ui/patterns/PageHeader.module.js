//#region src/ui/patterns/PageHeader.module.css
var e = "vWqtWa_actions", t = "vWqtWa_description", n = "vWqtWa_filters", r = "vWqtWa_identity", i = "vWqtWa_menuSlot", a = "vWqtWa_meta", o = "vWqtWa_root", s = "vWqtWa_row", c = "vWqtWa_spacer", l = "vWqtWa_title", u = "vWqtWa_utilities", d = {
	actions: e,
	description: t,
	filters: n,
	identity: r,
	menuSlot: i,
	meta: a,
	root: o,
	row: s,
	spacer: c,
	title: l,
	utilities: u
};
//#endregion
export { e as actions, d as default, t as description, n as filters, r as identity, i as menuSlot, a as meta, o as root, s as row, c as spacer, l as title, u as utilities };

//#region src/ui/primitives/Flag.module.css
var e = "HTjI8q_root", t = { root: e };
//#endregion
export { t as default, e as root };

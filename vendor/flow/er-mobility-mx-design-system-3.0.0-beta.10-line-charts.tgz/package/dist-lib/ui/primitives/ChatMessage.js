import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./ChatMessage.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/primitives/ChatMessage.tsx
function i({ role: i = "agent", text: a, tool: o, streaming: s = !1, children: c, timestamp: l, style: u }) {
	let d = e(), f = i === "user" ? d("chat.userMessage", "Tu mensaje") : d("chat.agentMessage", "Respuesta del asistente");
	return /* @__PURE__ */ r("div", {
		className: t.root,
		"data-role": i,
		style: u,
		"aria-label": f,
		children: [
			o && /* @__PURE__ */ r("div", {
				className: t.toolChip,
				children: [
					o.status === "running" ? /* @__PURE__ */ n("span", {
						className: t.toolSpinner,
						"aria-hidden": "true"
					}) : /* @__PURE__ */ n("span", {
						className: `flow-symbol ${t.toolDone}`,
						"aria-hidden": "true",
						children: "check_circle"
					}),
					/* @__PURE__ */ n("span", {
						className: `flow-symbol ${t.toolIcon}`,
						"aria-hidden": "true",
						children: o.icon || "bolt"
					}),
					o.label
				]
			}),
			/* @__PURE__ */ r("div", {
				className: t.bubble,
				"data-rich": c ? "" : void 0,
				children: [
					a && /* @__PURE__ */ n("span", { children: a }),
					s && /* @__PURE__ */ r("span", {
						className: t.streamingDots,
						"data-no-text": a ? void 0 : "",
						role: "status",
						"aria-live": "polite",
						"aria-label": d("chat.typing", "Escribiendo"),
						children: [
							/* @__PURE__ */ n("span", {
								className: t.dot,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ n("span", {
								className: t.dot,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ n("span", {
								className: t.dot,
								"aria-hidden": "true"
							})
						]
					}),
					c && /* @__PURE__ */ n("div", {
						className: t.richContent,
						children: c
					})
				]
			}),
			l && /* @__PURE__ */ n("span", {
				className: t.timestamp,
				children: l
			})
		]
	});
}
//#endregion
export { i as ChatMessage };

import e from "./SectionHeader.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/SectionHeader.tsx
function r({ children: r, trailing: i, size: a = "md", level: o = 2, description: s, style: c }) {
	let l = `h${o}`;
	return /* @__PURE__ */ t("div", {
		className: e.root,
		"data-size": a,
		style: c,
		children: /* @__PURE__ */ n("div", {
			className: e.row,
			children: [/* @__PURE__ */ n("div", {
				className: e.copy,
				children: [/* @__PURE__ */ t(l, {
					className: e.title,
					children: r
				}), s && /* @__PURE__ */ t("p", {
					className: e.description,
					children: s
				})]
			}), i && /* @__PURE__ */ t("span", {
				className: e.trailing,
				children: i
			})]
		})
	});
}
//#endregion
export { r as SectionHeader };

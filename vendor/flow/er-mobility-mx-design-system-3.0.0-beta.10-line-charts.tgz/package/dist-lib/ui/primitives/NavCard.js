import e from "./NavCard.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/NavCard.tsx
function r({ label: r, name: i, href: a, direction: o = "next", style: s }) {
	return /* @__PURE__ */ t("a", {
		"data-link": "",
		href: a,
		className: e.link,
		style: s,
		children: /* @__PURE__ */ t("div", {
			className: e.card,
			children: /* @__PURE__ */ n("div", {
				className: e.inner,
				"data-direction": o,
				children: [/* @__PURE__ */ t("span", {
					"data-overline": "",
					children: r
				}), /* @__PURE__ */ n("span", {
					className: e.name,
					children: [
						o === "prev" && /* @__PURE__ */ t("span", {
							className: "flow-symbol",
							"aria-hidden": "true",
							children: "arrow_back"
						}),
						i,
						o === "next" && /* @__PURE__ */ t("span", {
							className: "flow-symbol",
							"aria-hidden": "true",
							children: "arrow_forward"
						})
					]
				})]
			})
		})
	});
}
//#endregion
export { r as NavCard };

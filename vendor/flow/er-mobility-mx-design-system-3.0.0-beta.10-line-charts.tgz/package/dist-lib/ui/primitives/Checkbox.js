import { ToggleControl as e } from "./ToggleControl.js";
import t from "./Checkbox.module.js";
import { jsx as n } from "react/jsx-runtime";
import { forwardRef as r } from "react";
//#region src/ui/primitives/Checkbox.tsx
var i = r(function({ name: r, required: i, onBlur: a, "aria-labelledby": o, ariaLabel: s, id: c, "aria-describedby": l, "aria-invalid": u, "aria-required": d, checked: f, indeterminate: p, onChange: m, label: h, description: g, disabled: _, style: v }, y) {
	return /* @__PURE__ */ n(e, {
		ref: y,
		name: r,
		required: i,
		onBlur: a,
		"aria-labelledby": o,
		ariaLabel: s,
		id: c,
		"aria-describedby": l,
		"aria-invalid": u,
		"aria-required": d,
		checked: f,
		indeterminate: p,
		onChange: m,
		label: h,
		description: g,
		disabled: _,
		style: v,
		children: /* @__PURE__ */ n("span", {
			className: t.visual,
			"data-checked": f || p || void 0,
			"aria-hidden": "true",
			children: (f || p) && /* @__PURE__ */ n("span", {
				className: `flow-symbol ${t.icon}`,
				children: p ? "remove" : "check"
			})
		})
	});
});
//#endregion
export { i as Checkbox };

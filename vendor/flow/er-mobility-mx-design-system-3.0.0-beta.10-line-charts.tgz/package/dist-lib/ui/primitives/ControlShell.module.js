//#region src/ui/primitives/ControlShell.module.css
var e = "pfHiSa_content", t = "pfHiSa_footer", n = "pfHiSa_root", r = "pfHiSa_slot", i = {
	content: e,
	footer: t,
	root: n,
	slot: r
};
//#endregion
export { e as content, i as default, t as footer, n as root, r as slot };

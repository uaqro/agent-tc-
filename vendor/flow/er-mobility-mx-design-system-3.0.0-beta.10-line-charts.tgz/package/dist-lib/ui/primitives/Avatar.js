"use client";
import e from "./Avatar.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
import { useState as r } from "react";
//#region src/ui/primitives/Avatar.tsx
var i = [
	"var(--identity-1)",
	"var(--identity-2)",
	"var(--identity-3)",
	"var(--identity-4)",
	"var(--identity-5)",
	"var(--identity-6)"
], a = {
	sm: 28,
	md: 36,
	lg: 44,
	xl: 56
}, o = {
	online: "var(--status-success)",
	busy: "var(--status-danger)",
	offline: "var(--avatar-offline)"
};
function s(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) t = (t << 5) - t + e.charCodeAt(n) | 0;
	return Math.abs(t);
}
function c(e) {
	let t = e.trim().split(/\s+/);
	return t.length === 1 ? t[0][0].toUpperCase() : (t[0][0] + t[t.length - 1][0]).toUpperCase();
}
var l = {
	online: "en línea",
	busy: "ocupado",
	offline: "desconectado"
};
function u({ name: u = "", size: d = "md", status: f, src: p, style: m }) {
	let [h, g] = r(!1), _ = a[d], v = i[s(u) % i.length], y = _ < 32 ? 11 : _ < 48 ? 13 : 18, b = _ < 32 ? 8 : 10, x = _ < 32 ? -1 : 0;
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: {
			"--_size": `${_}px`,
			...m
		},
		children: [
			p && !h ? /* @__PURE__ */ t("img", {
				src: p,
				alt: u,
				className: e.img,
				onError: () => g(!0)
			}) : /* @__PURE__ */ t("div", {
				className: e.initials,
				"aria-label": u,
				style: {
					"--_bg": v,
					"--_fs": `${y}px`
				},
				children: c(u)
			}),
			f && /* @__PURE__ */ t("span", {
				"data-sr-only": "",
				children: l[f] ?? f
			}),
			f && /* @__PURE__ */ t("span", {
				"aria-hidden": "true",
				className: e.status,
				style: {
					"--_status-color": o[f],
					bottom: x,
					right: x,
					width: b,
					height: b
				}
			})
		]
	});
}
//#endregion
export { u as Avatar };

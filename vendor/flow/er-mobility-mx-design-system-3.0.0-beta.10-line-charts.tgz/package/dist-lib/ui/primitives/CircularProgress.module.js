//#region src/ui/primitives/CircularProgress.module.css
var e = "UXo7Mq_arc", t = "UXo7Mq_label", n = "UXo7Mq_ring", r = "UXo7Mq_root", i = "UXo7Mq_svg", a = "UXo7Mq_track", o = "UXo7Mq_value", s = {
	arc: e,
	label: t,
	ring: n,
	root: r,
	svg: i,
	track: a,
	value: o
};
//#endregion
export { e as arc, s as default, t as label, n as ring, r as root, i as svg, a as track, o as value };

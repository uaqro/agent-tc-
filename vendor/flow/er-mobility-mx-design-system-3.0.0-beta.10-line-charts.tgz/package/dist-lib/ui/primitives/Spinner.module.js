//#region src/ui/primitives/Spinner.module.css
var e = "dho_Gq_root", t = { root: e };
//#endregion
export { t as default, e as root };

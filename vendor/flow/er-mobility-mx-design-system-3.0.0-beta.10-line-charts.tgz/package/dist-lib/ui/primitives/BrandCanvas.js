"use client";
import { suave as e } from "../../motion/tiempo.js";
import { useEscena as t } from "../../motion/useEscena.js";
import n from "./BrandCanvas.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useCallback as a, useRef as o } from "react";
//#region src/ui/primitives/BrandCanvas.tsx
var s = 170, c = 7, l = 4, u = .32, d = 1.4, f = 2.51, p = .22, m = .5, h = .095, g = .235, _ = 286, v = 18, y = 12, b = 40, x = .34, S = 6.2, C = [
	"combustible",
	"peaje",
	"mantenimiento",
	"electro"
], w = [
	"local_gas_station",
	"toll",
	"build",
	"bolt"
], T = Array.from({ length: c }, (e, t) => Array.from({ length: s }, (e, n) => {
	let r = n / 169;
	return [
		-690 + 1380 * r,
		(t - 3) * 45 + 58 * Math.sin(r * 2 * Math.PI + t * .64) + 22 * Math.sin(r * 4 * Math.PI + t),
		40 * Math.sin(r * 2 * Math.PI + t * .6) + (t - 3) * 7
	];
})), E = 79, D = 1e3, O = 330, k = 640 - D / 2, A = 360 - O / 2, j = (e, t, n) => Math.max(t, Math.min(n, e));
function M([e, t, n], r, i) {
	let a = e * Math.cos(r) + n * Math.sin(r), o = -e * Math.sin(r) + n * Math.cos(r), s = t * Math.cos(i) - o * Math.sin(i), c = 1350 / (1350 + (t * Math.sin(i) + o * Math.cos(i)));
	return [640 + a * c * .91 - k, 360 + s * c * .91 - A];
}
function N({ signals: s, paused: c = !1, style: k }) {
	let A = o(null), N = o([]), P = o([]), F = o([]), I = a((t) => {
		let n = A.current;
		if (!n) return;
		let r = n.clientWidth, i = n.clientHeight, a = .045 * Math.sin(t * .16), o = .34 + .025 * Math.sin(t * .13);
		T.forEach((n, s) => {
			let c = N.current[s];
			if (!c) return;
			let S = s < l ? E : 0, C = n.map((e) => {
				let [t, n] = M(e, a, o);
				return [t, n + S];
			}), w = e((t - s * u) / d), T = Math.round(w * 169);
			if (T < 1) {
				c.setAttribute("d", ""), P.current[s]?.style.setProperty("--llegada", "0"), F.current[s]?.style.setProperty("--llegada", "0");
				return;
			}
			if (c.setAttribute("d", `M${C.slice(0, T + 1).map(([e, t]) => `${e.toFixed(1)} ${t.toFixed(1)}`).join("L")}`), s >= l) return;
			let k = (t * h + s * g) % 1, A = k * T, I = Math.floor(A), L = A - I, [R, z] = C[I], [B, V] = C[Math.min(I + 1, T)], H = R + (B - R) * L, U = z + (V - z) * L, W = H / D * r, G = U / O * i, K = 1 - k * 4 % 1, q = P.current[s];
			q && (q.style.setProperty("--llegada", "1"), q.style.setProperty("--x", `${W}px`), q.style.setProperty("--y", `${G}px`), q.style.setProperty("--latido", String(K)));
			let J = F.current[s];
			if (!J) return;
			let Y = Math.min(_, r - 24), X = J.offsetHeight, Z = j(W - Y / 2, y, r - Y - y), Q = i * x, $ = j(G + X + v <= i - y ? G + v : G - X - v, Q, i - X - y);
			J.style.setProperty("--izquierda", `${Z}px`), J.style.setProperty("--arriba", `${$}px`), J.style.setProperty("--cola", `${j(W - Z, y, Y - y)}px`), J.dataset.debajo = $ > G ? "true" : "";
			let ee = Math.abs(W - (Z + Y / 2)), te = 1 - e(ee / b);
			J.style.setProperty("--llegada", String(te * e((t - f - s * p) / m)));
		});
	}, []);
	return t(A, {
		pinta: I,
		tFinal: S,
		pausada: c
	}), /* @__PURE__ */ i("div", {
		ref: A,
		className: n.root,
		"aria-hidden": "true",
		style: k,
		children: [
			/* @__PURE__ */ r("svg", {
				className: n.lienzo,
				viewBox: `0 0 ${D} ${O}`,
				preserveAspectRatio: "none",
				children: T.map((e, t) => /* @__PURE__ */ r("path", {
					ref: (e) => {
						N.current[t] = e;
					},
					className: `${n.ruta} ${t < l ? n[C[t]] : n.contexto}`,
					d: ""
				}, t))
			}),
			C.map((e, t) => /* @__PURE__ */ i("div", {
				ref: (e) => {
					P.current[t] = e;
				},
				className: `${n.señal} ${n[e]}`,
				children: [/* @__PURE__ */ r("span", { className: n.halo }), /* @__PURE__ */ r("span", { className: n.punto })]
			}, e)),
			C.map((e, t) => {
				let a = s?.[t];
				return a ? /* @__PURE__ */ i("div", {
					ref: (e) => {
						F.current[t] = e;
					},
					className: `${n.tarjeta} ${n[e]}`,
					"data-orden": t,
					children: [
						/* @__PURE__ */ i("p", {
							className: n.vertical,
							"data-overline": !0,
							children: [/* @__PURE__ */ r("span", {
								className: `flow-symbol flow-symbol--sm ${n.icono}`,
								"aria-hidden": "true",
								children: w[t]
							}), a.name]
						}),
						a.detail && /* @__PURE__ */ r("p", {
							className: n.detalle,
							children: a.detail
						}),
						a.unit && /* @__PURE__ */ r("p", {
							className: n.fuente,
							children: a.unit
						})
					]
				}, e) : null;
			})
		]
	});
}
//#endregion
export { N as BrandCanvas };

"use client";
import { OverlayTarget as e } from "../../overlay/ambito.js";
import "./avisoControlado.js";
import t from "./Popover.module.js";
import { Fragment as n, jsx as r, jsxs as i } from "react/jsx-runtime";
import { useCallback as a, useContext as o, useEffect as s, useLayoutEffect as c, useRef as l, useState as u } from "react";
import { createPortal as d } from "react-dom";
//#region src/ui/primitives/Popover.tsx
function f(e) {
	let [t, n] = e.split("-");
	return [t, n ?? (t === "top" || t === "bottom" ? "start" : "center")];
}
var p = 8, m = {
	top: "bottom",
	bottom: "top",
	left: "right",
	right: "left"
};
function h({ trigger: h, fillTrigger: g, selfAlign: _, align: v, placement: y, offset: b = 6, anchorRef: x, matchAnchorWidth: S = !1, minWidth: C, surface: w = "card", layer: T = "popover", interactive: E = !0, returnFocusRef: D, children: O, open: k, onOpenChange: A }) {
	let j = o(e), [M, N] = u(!1), P = k === void 0 ? M : k, F = k === void 0 ? N : A, I = l(null), L = l(null), [R, z] = u(null), [B, V] = u(null), [H, U] = u(null), [W, G] = f(y ?? (v === "right" ? "bottom-end" : "bottom-start")), K = a(() => {
		F?.(!1), E && (D?.current ?? I.current?.querySelector("button, [tabindex], input, a"))?.focus();
	}, [
		F,
		D,
		E
	]);
	s(() => {
		if (!P) return;
		let e = () => {
			let e = x?.current ?? I.current;
			e && z(e.getBoundingClientRect());
		};
		return e(), window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0), z(null), V(null), U(null);
		};
	}, [P, x]), s(() => {
		if (!P || !E) return;
		let e = (e) => {
			I.current?.contains(e.target) || L.current?.contains(e.target) || x?.current?.contains(e.target) || K();
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, [
		P,
		K,
		x,
		E
	]), s(() => {
		if (!P) return;
		let e = (e) => {
			e.key === "Escape" && !e.defaultPrevented && (e.preventDefault(), K());
		};
		return document.addEventListener("keydown", e, !0), () => document.removeEventListener("keydown", e, !0);
	}, [P, K]), c(() => {
		if (!P || !R || !L.current) return;
		let e = j?.getBoundingClientRect(), t = e ? {
			top: R.top - e.top,
			bottom: R.bottom - e.top,
			left: R.left - e.left,
			right: R.right - e.left,
			width: R.width,
			height: R.height
		} : R, n = L.current.offsetWidth, r = L.current.offsetHeight, i = e?.width ?? window.innerWidth, a = e?.height ?? window.innerHeight, o = {
			top: t.top - b,
			bottom: a - t.bottom - b,
			left: t.left - b,
			right: i - t.right - b
		}, s = (e) => (e === "top" || e === "bottom" ? r : n) <= o[e], c = W;
		!s(c) && o[m[c]] > o[c] && (c = m[c]);
		let l = {
			position: e ? "absolute" : "fixed",
			maxWidth: Math.max(0, i - 16)
		};
		if (c === "bottom" && (l.top = t.bottom + b), c === "top" && (l.bottom = a - t.top + b), c === "left" && (l.right = i - t.left + b), c === "right" && (l.left = t.right + b), s(c) || (c === "top" || c === "bottom" ? (l.maxHeight = Math.max(0, o[c]), l.overflowY = "auto") : (l.maxWidth = Math.max(0, o[c]), l.overflowX = "auto")), c === "top" || c === "bottom") {
			let e = G === "start" ? t.left : G === "end" ? t.right - n : t.left + t.width / 2 - n / 2;
			l.left = Math.min(Math.max(e, p), Math.max(p, i - n - p));
		} else {
			let e = G === "start" ? t.top : G === "end" ? t.bottom - r : t.top + t.height / 2 - r / 2;
			l.top = Math.min(Math.max(e, p), Math.max(p, a - r - p));
		}
		S && (l.width = t.width), C !== void 0 && (l.minWidth = C), V(l), U(c);
	}, [
		P,
		R,
		W,
		G,
		b,
		S,
		C,
		j
	]);
	let q = B ?? {
		position: "fixed",
		top: 0,
		left: 0,
		visibility: "hidden",
		...C === void 0 ? {} : { minWidth: C },
		...S && R ? { width: R.width } : {}
	}, J = P && typeof document < "u" ? d(/* @__PURE__ */ r("div", {
		ref: L,
		className: t.drop,
		"data-side": H ?? W,
		"data-cross": G,
		"data-surface": w,
		"data-layer": T,
		"data-interactive": E || void 0,
		style: q,
		children: typeof O == "function" ? O({ close: K }) : O
	}), j ?? document.body) : null;
	return h ? /* @__PURE__ */ i("div", {
		className: t.root,
		"data-fill": g || void 0,
		style: _ ? { alignSelf: _ } : void 0,
		children: [/* @__PURE__ */ r("span", {
			ref: I,
			className: t.trigger,
			"data-fill": g || void 0,
			onClick: () => F?.(!P),
			children: h
		}), J]
	}) : /* @__PURE__ */ r(n, { children: J });
}
//#endregion
export { h as Popover };

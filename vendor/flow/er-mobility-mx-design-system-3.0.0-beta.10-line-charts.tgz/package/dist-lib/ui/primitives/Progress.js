import e from "./Progress.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/Progress.tsx
function r({ value: r = 0, max: i = 100, label: a, showValue: o, tone: s = "accent", style: c }) {
	let l = Math.min(Math.max(r ?? 0, 0), i), u = Math.min(100, Math.max(0, l / i * 100));
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: c,
		children: [(a || o) && /* @__PURE__ */ n("div", {
			className: e.header,
			children: [a && /* @__PURE__ */ t("span", {
				className: e.label,
				children: a
			}), o && /* @__PURE__ */ n("span", {
				className: e.value,
				children: [
					r,
					"/",
					i
				]
			})]
		}), /* @__PURE__ */ t("div", {
			className: e.track,
			role: "progressbar",
			"aria-valuenow": l,
			"aria-valuemin": 0,
			"aria-valuemax": i,
			"aria-label": a,
			children: /* @__PURE__ */ t("div", {
				className: e.bar,
				"data-tone": s,
				style: { width: `${u}%` }
			})
		})]
	});
}
//#endregion
export { r as Progress };

//#region src/ui/primitives/Progress.module.css
var e = "bqDXia_bar", t = "bqDXia_header", n = "bqDXia_label", r = "bqDXia_root", i = "bqDXia_track", a = "bqDXia_value", o = {
	bar: e,
	header: t,
	label: n,
	root: r,
	track: i,
	value: a
};
//#endregion
export { e as bar, o as default, t as header, n as label, r as root, i as track, a as value };

//#region src/ui/primitives/Button.module.css
var e = "_9mYZ7q_icon", t = "_9mYZ7q_root", n = "_9mYZ7q_spinner", r = {
	icon: e,
	root: t,
	spinner: n
};
//#endregion
export { r as default, e as icon, t as root, n as spinner };

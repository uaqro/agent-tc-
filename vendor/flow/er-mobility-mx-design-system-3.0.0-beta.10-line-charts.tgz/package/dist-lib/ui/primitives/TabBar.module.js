//#region src/ui/primitives/TabBar.module.css
var e = "Ao219q_badge", t = "Ao219q_iconWrap", n = "Ao219q_item", r = "Ao219q_label", i = "Ao219q_root", a = {
	badge: e,
	iconWrap: t,
	item: n,
	label: r,
	root: i
};
//#endregion
export { e as badge, a as default, t as iconWrap, n as item, r as label, i as root };

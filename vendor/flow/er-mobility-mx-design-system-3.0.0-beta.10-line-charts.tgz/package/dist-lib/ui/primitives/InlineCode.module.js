//#region src/ui/primitives/InlineCode.module.css
var e = "_4PErpW_root", t = { root: e };
//#endregion
export { t as default, e as root };

import e from "./IconButton.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/IconButton.tsx
function r({ "aria-haspopup": r, "aria-expanded": i, "aria-describedby": a, icon: o, ariaLabel: s, variant: c = "ghost", size: l = "md", selected: u, badge: d, type: f = "button", disabled: p, onClick: m, style: h }) {
	return /* @__PURE__ */ n("button", {
		"aria-haspopup": r,
		"aria-expanded": i,
		"aria-describedby": a,
		type: f,
		className: e.root,
		"data-variant": c,
		"data-size": l,
		"data-selected": u || void 0,
		"aria-pressed": u,
		"aria-label": s,
		onClick: m,
		disabled: p,
		style: h,
		children: [/* @__PURE__ */ t("span", {
			className: `flow-symbol${u ? " flow-symbol--fill" : ""} ${e.icon}`,
			"aria-hidden": "true",
			children: o
		}), d && /* @__PURE__ */ t("span", { className: e.badge })]
	});
}
//#endregion
export { r as IconButton };

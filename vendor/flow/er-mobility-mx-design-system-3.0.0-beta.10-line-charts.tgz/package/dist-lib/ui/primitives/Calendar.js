"use client";
import { useLocale as e, useT as t } from "../../i18n/useSafeIntl.js";
import n from "./Calendar.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { useCallback as a, useEffect as o, useRef as s, useState as c } from "react";
//#region src/ui/primitives/Calendar.tsx
var l = [
	"l",
	"m",
	"m",
	"j",
	"v",
	"s",
	"d"
];
function u(e, t) {
	return new Date(e, t + 1, 0).getDate();
}
function d(e, t) {
	let n = new Date(e, t, 1).getDay();
	return n === 0 ? 6 : n - 1;
}
function f(e, t, n) {
	return `${e}-${String(t + 1).padStart(2, "0")}-${String(n).padStart(2, "0")}`;
}
function p({ selected: p = [], rangeStart: m, rangeEnd: h, min: g, max: _, month: v, onMonthChange: y, onSelect: b, onClear: x, onToday: S, hint: C, style: w }) {
	let T = t(), E = e(), D = /* @__PURE__ */ new Date(), O = f(D.getFullYear(), D.getMonth(), D.getDate()), k = p[0] ? /* @__PURE__ */ new Date(p[0] + "T00:00:00") : D, [A, j] = c({
		y: k.getFullYear(),
		m: k.getMonth()
	}), M = (v ? ((e) => {
		let [t, n] = e.split("-").map(Number);
		return Number.isFinite(t) && n >= 1 && n <= 12 ? {
			y: t,
			m: n - 1
		} : null;
	})(v) : null) ?? A, N = M.y, P = M.m, F = a((e, t) => {
		v === void 0 && j({
			y: e,
			m: t
		}), y?.(`${e}-${String(t + 1).padStart(2, "0")}`);
	}, [v, y]), I = new Date(N, P).toLocaleDateString(E, {
		month: "long",
		year: "numeric"
	}), L = a(() => P === 0 ? F(N - 1, 11) : F(N, P - 1), [
		N,
		P,
		F
	]), R = a(() => P === 11 ? F(N + 1, 0) : F(N, P + 1), [
		N,
		P,
		F
	]), z = u(N, P), B = d(N, P), V = Array(B).fill(null);
	for (let e = 1; e <= z; e++) V.push(e);
	for (; V.length % 7 != 0;) V.push(null);
	let H = new Set(p), U = s(null), [W, G] = c(null), K = (e) => e.startsWith(`${N}-${String(P + 1).padStart(2, "0")}-`), q = W && K(W) && W || p.find(K) || K(O) && O || f(N, P, 1);
	o(() => {
		W && U.current?.querySelector(`[data-date="${W}"]`)?.focus();
	}, [
		W,
		N,
		P
	]);
	let J = (e) => {
		let t = e.getFullYear(), n = e.getMonth();
		(t !== N || n !== P) && F(t, n), G(f(t, n, e.getDate()));
	};
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: w,
		children: [
			/* @__PURE__ */ i("div", {
				className: n.header,
				children: [/* @__PURE__ */ r("button", {
					type: "button",
					className: n.monthLabel,
					children: I
				}), /* @__PURE__ */ i("div", {
					className: n.nav,
					children: [/* @__PURE__ */ r("button", {
						type: "button",
						"data-bare": "",
						className: n.navBtn,
						onClick: L,
						"aria-label": T("flow.calendar.prevMonth", "Mes anterior"),
						children: /* @__PURE__ */ r("span", {
							className: "flow-symbol",
							"aria-hidden": "true",
							children: "keyboard_arrow_up"
						})
					}), /* @__PURE__ */ r("button", {
						type: "button",
						"data-bare": "",
						className: n.navBtn,
						onClick: R,
						"aria-label": T("flow.calendar.nextMonth", "Mes siguiente"),
						children: /* @__PURE__ */ r("span", {
							className: "flow-symbol",
							"aria-hidden": "true",
							children: "keyboard_arrow_down"
						})
					})]
				})]
			}),
			C && /* @__PURE__ */ r("div", {
				className: n.hint,
				children: C
			}),
			/* @__PURE__ */ i("div", {
				className: n.grid,
				ref: U,
				onKeyDown: (e) => {
					let t = e.target.getAttribute?.("data-date");
					if (!t) return;
					let n = /* @__PURE__ */ new Date(t + "T00:00:00"), r = null;
					if (e.key === "ArrowLeft") r = new Date(n.getFullYear(), n.getMonth(), n.getDate() - 1);
					else if (e.key === "ArrowRight") r = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1);
					else if (e.key === "ArrowUp") r = new Date(n.getFullYear(), n.getMonth(), n.getDate() - 7);
					else if (e.key === "ArrowDown") r = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 7);
					else if (e.key === "Home") r = new Date(N, P, 1);
					else if (e.key === "End") r = new Date(N, P, z);
					else if (e.key === "PageUp" || e.key === "PageDown") {
						let t = e.key === "PageUp" ? -1 : 1, i = new Date(n.getFullYear(), n.getMonth() + t, 1), a = u(i.getFullYear(), i.getMonth());
						r = new Date(i.getFullYear(), i.getMonth(), Math.min(n.getDate(), a));
					} else return;
					e.preventDefault(), J(r);
				},
				children: [l.map((e, t) => /* @__PURE__ */ r("span", {
					className: n.dayHeader,
					children: e
				}, `h-${t}`)), V.map((e, t) => {
					if (e === null) return /* @__PURE__ */ r("span", {}, `e-${t}`);
					let i = f(N, P, e), a = i === O, o = H.has(i), s = m && h && i > m && i < h, c = !!(g && i < g || _ && i > _);
					return /* @__PURE__ */ r("button", {
						type: "button",
						"data-bare": "",
						className: n.day,
						"data-date": i,
						"data-selected": o || void 0,
						"data-in-range": s || void 0,
						"data-range-start": m && i === m && h || void 0,
						"data-range-end": h && i === h && m || void 0,
						"data-today": a || void 0,
						disabled: c,
						tabIndex: i === q ? 0 : -1,
						onClick: () => b?.(i),
						children: e
					}, `d-${t}`);
				})]
			}),
			(x || S) && /* @__PURE__ */ i("div", {
				className: n.footer,
				children: [x && /* @__PURE__ */ r("button", {
					type: "button",
					"data-bare": "",
					className: n.footerBtn,
					onClick: x,
					children: T("calendar.clear", "Borrar")
				}), S && /* @__PURE__ */ r("button", {
					type: "button",
					"data-bare": "",
					className: n.footerBtn,
					"data-accent": "",
					onClick: S,
					children: T("calendar.today", "Hoy")
				})]
			})
		]
	});
}
//#endregion
export { p as Calendar };

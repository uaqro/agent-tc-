import e from "./TextAction.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/TextAction.tsx
function n({ children: n, onClick: r, disabled: i, type: a = "button", style: o }) {
	return /* @__PURE__ */ t("button", {
		"data-bare": "",
		type: a,
		className: e.root,
		disabled: i,
		onClick: r,
		style: o,
		children: n
	});
}
//#endregion
export { n as TextAction };

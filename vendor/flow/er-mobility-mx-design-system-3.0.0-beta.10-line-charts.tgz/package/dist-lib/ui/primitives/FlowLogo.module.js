//#region src/ui/primitives/FlowLogo.module.css
var e = "zgyd7q_root", t = { root: e };
//#endregion
export { t as default, e as root };

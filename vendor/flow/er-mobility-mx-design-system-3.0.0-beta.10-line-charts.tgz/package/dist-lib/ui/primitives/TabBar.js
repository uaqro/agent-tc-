import { useRovingTabs as e } from "../../hooks/useRovingTabs.js";
import t from "./TabBar.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/primitives/TabBar.tsx
function i({ items: i, activeId: a, onChange: o, style: s }) {
	let { alTeclado: c, pestana: l } = e(i.map((e) => e.id), a, o);
	return /* @__PURE__ */ n("nav", {
		className: t.root,
		style: s,
		role: "tablist",
		onKeyDown: c,
		children: i.map((e) => {
			let i = e.id === a, s = e.badge === !0 ? "" : e.badge && e.badge > 9 ? "9+" : String(e.badge ?? "");
			return /* @__PURE__ */ r("button", {
				...l(e.id),
				"data-bare": "",
				className: t.item,
				"data-active": i || void 0,
				role: "tab",
				"aria-selected": i,
				"aria-current": i ? "page" : void 0,
				"aria-label": e.badge ? `${e.label}, ${s || "notificación"}` : e.label,
				onClick: () => o?.(e.id),
				type: "button",
				children: [/* @__PURE__ */ r("span", {
					className: t.iconWrap,
					children: [/* @__PURE__ */ n("span", {
						className: `flow-symbol${i ? " flow-symbol--fill" : ""}`,
						"aria-hidden": "true",
						"data-active": i || void 0,
						children: e.icon
					}), e.badge !== void 0 && /* @__PURE__ */ n("span", {
						"data-count": "",
						className: t.badge,
						"aria-hidden": "true",
						children: s
					})]
				}), /* @__PURE__ */ n("span", {
					className: t.label,
					children: e.label
				})]
			}, e.id);
		})
	});
}
//#endregion
export { i as TabBar };

import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./Chip.module.js";
import { Fragment as n, jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/primitives/Chip.tsx
function a({ label: a, size: o = "md", variant: s = "default", mono: c = !1, selected: l = !1, onClick: u, onRemove: d, icon: f, disabled: p = !1, style: m }) {
	let h = e(), g = !!u, _ = f && /* @__PURE__ */ r("span", {
		className: `flow-symbol${l ? " flow-symbol--fill" : ""} ${t.icon}`,
		"aria-hidden": "true",
		children: f
	}), v = d && /* @__PURE__ */ r("button", {
		type: "button",
		"aria-label": h("chip.remove", "Quitar {etiqueta}", { etiqueta: a }),
		disabled: p,
		onClick: (e) => {
			e.stopPropagation(), d();
		},
		"data-bare": "",
		className: t.remove,
		children: /* @__PURE__ */ r("span", {
			className: "flow-symbol flow-symbol--sm",
			"aria-hidden": "true",
			children: "close"
		})
	});
	return d ? /* @__PURE__ */ i("span", {
		className: `${t.root} ${t.compound}`,
		"data-size": o,
		"data-variant": s === "default" ? void 0 : s,
		"data-mono": c || void 0,
		"data-selected": l || void 0,
		"data-disabled": p || void 0,
		style: m,
		children: [g ? /* @__PURE__ */ i("button", {
			type: "button",
			disabled: p,
			"aria-pressed": l,
			onClick: p ? void 0 : u,
			"data-bare": "",
			className: t.action,
			children: [_, a]
		}) : /* @__PURE__ */ i(n, { children: [_, a] }), v]
	}) : /* @__PURE__ */ i(g ? "button" : "span", {
		type: g ? "button" : void 0,
		className: t.root,
		"data-size": o,
		"data-variant": s === "default" ? void 0 : s,
		"data-mono": c || void 0,
		"data-selected": l || void 0,
		"data-disabled": p || void 0,
		onClick: p ? void 0 : u,
		"aria-pressed": g ? l : void 0,
		disabled: g ? p : void 0,
		style: m,
		children: [_, a]
	});
}
//#endregion
export { a as Chip };

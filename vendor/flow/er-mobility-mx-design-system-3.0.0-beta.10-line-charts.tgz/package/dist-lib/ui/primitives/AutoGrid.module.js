//#region src/ui/primitives/AutoGrid.module.css
var e = "iMBxwG_root", t = { root: e };
//#endregion
export { t as default, e as root };

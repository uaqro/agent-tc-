import e from "./StatusPill.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/StatusPill.tsx
function r({ label: r, tone: i = "success", style: a }) {
	return /* @__PURE__ */ n("span", {
		className: e.root,
		"data-tone": i,
		style: a,
		children: [/* @__PURE__ */ t("span", { className: e.dot }), r]
	});
}
//#endregion
export { r as StatusPill };

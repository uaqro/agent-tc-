import { ToggleControl as e } from "./ToggleControl.js";
import t from "./Radio.module.js";
import { jsx as n } from "react/jsx-runtime";
import { forwardRef as r } from "react";
//#region src/ui/primitives/Radio.tsx
var i = r(function({ required: r, onBlur: i, id: a, name: o, value: s, checked: c = !1, onChange: l, label: u, description: d, disabled: f, style: p, "aria-labelledby": m, ariaLabel: h, "aria-describedby": g, "aria-invalid": _, "aria-required": v }, y) {
	return /* @__PURE__ */ n(e, {
		ref: y,
		type: "radio",
		name: o,
		value: s,
		checked: c,
		onChange: (e) => e && l?.(s ?? ""),
		label: u,
		description: d,
		disabled: f,
		required: r,
		onBlur: i,
		id: a,
		style: p,
		"aria-labelledby": m,
		ariaLabel: h,
		"aria-describedby": g,
		"aria-invalid": _,
		"aria-required": v,
		children: /* @__PURE__ */ n("span", {
			className: t.indicator,
			"data-checked": c || void 0,
			"aria-hidden": "true",
			children: /* @__PURE__ */ n("span", { className: t.dot })
		})
	});
});
//#endregion
export { i as Radio };

"use client";
import { OverlayTarget as e } from "../../overlay/ambito.js";
import t from "./OverlayShell.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { useCallback as i, useContext as a, useEffect as o, useRef as s } from "react";
import { createPortal as c } from "react-dom";
//#region src/ui/primitives/OverlayShell.tsx
function l({ open: l, onClose: u, alignment: d = "center", dismissOnBackdrop: f = !0, labelledBy: p, children: m }) {
	let h = a(e), g = s(null), _ = i((e) => {
		if (e.key === "Escape" && !e.defaultPrevented && !e.nativeEvent.defaultPrevented) {
			e.preventDefault(), e.stopPropagation(), u?.();
			return;
		}
		if (e.key === "Tab" && g.current) {
			let t = Array.from(g.current.querySelectorAll("button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex=\"-1\"])"));
			if (!t.length) {
				e.preventDefault();
				return;
			}
			let n = t[0], r = t[t.length - 1];
			e.shiftKey && document.activeElement === n ? (e.preventDefault(), r.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
		}
	}, [u]);
	return o(() => {
		if (!l) return;
		let e = document.activeElement, t = h ?? document.body, n = t.style.overflow;
		t.style.overflow = "hidden";
		let r = g.current;
		if (r) {
			let e = r.querySelector("button, [href], input, select, textarea, [tabindex]:not([tabindex=\"-1\"])");
			e ? e.focus() : r.focus();
		}
		return () => {
			t.style.overflow = n, e instanceof HTMLElement && e.focus();
		};
	}, [l, h]), !l || typeof document > "u" ? null : c(/* @__PURE__ */ r("div", {
		className: t.root,
		"data-contained": !!h || void 0,
		"data-alignment": d,
		onKeyDown: _,
		children: [/* @__PURE__ */ n("div", {
			className: t.backdrop,
			onClick: f ? u : void 0
		}), /* @__PURE__ */ n("div", {
			ref: g,
			className: t.panel,
			role: "dialog",
			"aria-labelledby": p,
			"aria-modal": "true",
			tabIndex: -1,
			children: m
		})]
	}), h ?? document.body);
}
//#endregion
export { l as OverlayShell };

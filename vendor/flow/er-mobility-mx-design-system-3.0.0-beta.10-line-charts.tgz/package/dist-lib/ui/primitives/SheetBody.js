import e from "./SheetBody.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/SheetBody.tsx
function n({ children: n, center: r, style: i }) {
	return /* @__PURE__ */ t("div", {
		className: e.root,
		"data-center": r || void 0,
		style: i,
		children: n
	});
}
//#endregion
export { n as SheetBody };

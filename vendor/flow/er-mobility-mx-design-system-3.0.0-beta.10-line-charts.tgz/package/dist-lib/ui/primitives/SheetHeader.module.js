//#region src/ui/primitives/SheetHeader.module.css
var e = "_cOz2W_root", t = "_cOz2W_title", n = {
	root: e,
	title: t
};
//#endregion
export { n as default, e as root, t as title };

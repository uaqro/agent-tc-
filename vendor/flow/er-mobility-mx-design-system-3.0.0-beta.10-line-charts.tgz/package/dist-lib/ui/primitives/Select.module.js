//#region src/ui/primitives/Select.module.css
var e = "R-HTPG_chevron", t = "R-HTPG_empty", n = "R-HTPG_insetLabel", r = "R-HTPG_search", i = "R-HTPG_searchInput", a = "R-HTPG_trigger", o = "R-HTPG_triggerText", s = {
	chevron: e,
	empty: t,
	insetLabel: n,
	search: r,
	searchInput: i,
	trigger: a,
	triggerText: o
};
//#endregion
export { e as chevron, s as default, t as empty, n as insetLabel, r as search, i as searchInput, a as trigger, o as triggerText };

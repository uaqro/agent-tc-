//#region src/ui/primitives/ScaleLegend.module.css
var e = "_1t-eSq_empty", t = "_1t-eSq_emptySwatch", n = "_1t-eSq_iconMax", r = "_1t-eSq_iconMin", i = "_1t-eSq_label", a = "_1t-eSq_root", o = "_1t-eSq_step", s = "_1t-eSq_steps", c = {
	empty: e,
	emptySwatch: t,
	iconMax: n,
	iconMin: r,
	label: i,
	root: a,
	step: o,
	steps: s
};
//#endregion
export { c as default, e as empty, t as emptySwatch, n as iconMax, r as iconMin, i as label, a as root, o as step, s as steps };

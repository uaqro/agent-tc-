//#region src/ui/primitives/avisoControlado.ts
function e(e, t, n, r, i) {}
//#endregion
export { e as avisaControladaSinCallback };

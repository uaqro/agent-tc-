//#region src/ui/primitives/Radio.module.css
var e = "rE3Zcq_dot", t = "rE3Zcq_indicator", n = {
	dot: e,
	indicator: t
};
//#endregion
export { n as default, e as dot, t as indicator };

import e from "./Stack.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/Stack.tsx
function n({ direction: n = "row", gap: r, align: i, justify: a, wrap: o, as: s = "div", children: c, style: l }) {
	let u = r === void 0 ? l : {
		"--stack-gap": typeof r == "number" ? `var(--space-${r})` : `var(--gap-${r})`,
		...l
	};
	return /* @__PURE__ */ t(s, {
		className: e.root,
		"data-direction": n,
		"data-align": i,
		"data-justify": a,
		"data-wrap": o || void 0,
		style: u,
		children: c
	});
}
//#endregion
export { n as Stack };

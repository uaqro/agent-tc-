"use client";
import e from "./Listbox.module.js";
import { jsx as t } from "react/jsx-runtime";
import { useCallback as n, useEffect as r, useRef as i, useState as a } from "react";
//#region src/ui/primitives/Listbox.tsx
function o({ items: o = [], value: s, onChange: c, renderItem: l, id: u, active: d, onActiveChange: f }) {
	let [p, m] = a(-1), h = d ?? p, g = (e) => {
		let t = typeof e == "function" ? e(h) : e;
		d === void 0 && m(t), f?.(t);
	}, _ = i(null), v = i({
		q: "",
		t: 0
	}), y = n((e) => {
		let t = o.length;
		if (t) {
			if (e.key === "ArrowDown") e.preventDefault(), g((e) => (e + 1) % t);
			else if (e.key === "ArrowUp") e.preventDefault(), g((e) => e <= 0 ? t - 1 : e - 1);
			else if (e.key === "Home") e.preventDefault(), g(0);
			else if (e.key === "End") e.preventDefault(), g(t - 1);
			else if (e.key === "Enter" && h >= 0) e.preventDefault(), c?.(o[h]);
			else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
				let t = e.timeStamp, n = v.current;
				n.q = t - n.t > 700 ? e.key : n.q + e.key, n.t = t;
				let r = n.q.toLowerCase(), i = o.findIndex((e) => String(e.label).toLowerCase().startsWith(r));
				i >= 0 && g(i);
			}
		}
	}, [
		o,
		h,
		c
	]);
	return r(() => {
		h >= 0 && _.current && _.current.children[h]?.scrollIntoView?.({ block: "nearest" });
	}, [h]), /* @__PURE__ */ t("ul", {
		"data-list": "",
		ref: _,
		role: "listbox",
		id: u,
		tabIndex: -1,
		onKeyDown: y,
		"aria-activedescendant": u && h >= 0 ? `${u}-opt-${h}` : void 0,
		className: e.root,
		children: o.map((n, r) => {
			let i = s != null && n.value === s;
			return /* @__PURE__ */ t("li", {
				role: "option",
				"aria-selected": i,
				className: e.option,
				id: u ? `${u}-opt-${r}` : void 0,
				"data-active": r === h || void 0,
				"data-selected": i || void 0,
				onClick: () => c?.(n),
				onMouseEnter: () => g(r),
				children: l ? l(n, {
					selected: i,
					active: r === h
				}) : n.label
			}, n.value ?? r);
		})
	});
}
//#endregion
export { o as Listbox };

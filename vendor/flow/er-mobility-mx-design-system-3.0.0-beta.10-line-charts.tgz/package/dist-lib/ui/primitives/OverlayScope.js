"use client";
import { OverlayTarget as e } from "../../overlay/ambito.js";
import t from "./OverlayScope.module.js";
import { jsx as n } from "react/jsx-runtime";
import { useState as r } from "react";
//#region src/ui/primitives/OverlayScope.tsx
function i({ children: i }) {
	let [a, o] = r(null);
	return /* @__PURE__ */ n("div", {
		className: t.root,
		ref: o,
		children: /* @__PURE__ */ n(e.Provider, {
			value: a,
			children: i
		})
	});
}
//#endregion
export { i as OverlayScope };

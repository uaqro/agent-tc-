//#region src/ui/primitives/Textarea.module.css
var e = "_1-SFkW_counter", t = "_1-SFkW_textarea", n = {
	counter: e,
	textarea: t
};
//#endregion
export { e as counter, n as default, t as textarea };

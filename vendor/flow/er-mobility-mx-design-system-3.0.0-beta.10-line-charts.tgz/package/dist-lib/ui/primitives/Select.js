"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { ControlShell as t } from "./ControlShell.js";
import { Listbox as n } from "./Listbox.js";
import { Popover as ee } from "./Popover.js";
import r from "./Select.module.js";
import { Fragment as te, jsx as i, jsxs as a } from "react/jsx-runtime";
import { forwardRef as o, useCallback as s, useId as c, useRef as l, useState as u } from "react";
//#region src/ui/primitives/Select.tsx
function d(e) {
	return typeof e == "string" ? {
		value: e,
		label: e
	} : e;
}
var f = o(function({ "aria-describedby": o, "aria-invalid": f, "aria-required": p, open: m, onOpenChange: ne, options: re, value: h, onChange: g, multiple: _, searchable: v, onSearch: y, loading: b, creatable: x, clearable: S, renderOption: C, size: ie = "md", placeholder: w, insetLabel: T, icon: E, disabled: D, invalid: O, id: k, "aria-labelledby": A, style: ae }, oe) {
	let j = g, M = h, N = e(), P = w ?? N("common.select", "Seleccionar…"), [F, I] = u(!1), L = m ?? F, R = (e) => {
		m === void 0 && I(e), ne?.(e);
	}, [z, B] = u(""), [V, H] = u(-1), U = l(null), W = c(), G = re.map(d), K = y || !z ? G : G.filter((e) => e.label.toLowerCase().includes(z.toLowerCase())), q = z.trim(), se = !!(x && q && !G.some((e) => e.value === q || e.label.toLowerCase() === q.toLowerCase())), J = !!(v || x || y), Y = Array.isArray(h) ? h : h != null && (h !== "" || G.some((e) => e.value === "")) ? [h] : [], X = _ && Y.length > 1 ? N("select.selectedCount", "{count} seleccionados", { count: Y.length }) : Y.map((e) => G.find((t) => t.value === e)?.label ?? e).join(", "), ce = !_ && C && Y.length === 1 ? (() => {
		let e = G.find((e) => e.value === Y[0]);
		return e ? C(e) : null;
	})() : null, Z = s((e) => {
		if (_) {
			let t = Array.isArray(M) ? M : [], n = t.includes(String(e.value)) ? t.filter((t) => t !== String(e.value)) : [...t, String(e.value)];
			j?.(n);
		} else j?.(String(e.value)), R(!1);
		B("");
	}, [
		h,
		_,
		g
	]), le = s((e) => {
		e.stopPropagation(), j?.(_ ? [] : "");
	}, [_, g]), Q = s((e) => {
		H(-1), !D && (R(e), e && J && setTimeout(() => U.current?.focus(), 0), e || B(""));
	}, [D, J]), $ = [...K.map((e) => ({
		value: e.value,
		label: e.label
	})), ...se ? [{
		value: q,
		label: N("select.create", "Crear «{texto}»", { texto: q })
	}] : []], ue = /* @__PURE__ */ i(t, {
		size: ie,
		disabled: D,
		invalid: O,
		leading: E && /* @__PURE__ */ i("span", {
			className: "flow-symbol flow-symbol--md",
			"aria-hidden": "true",
			children: E
		}),
		trailing: /* @__PURE__ */ a(te, { children: [S && Y.length > 0 && !L && /* @__PURE__ */ i("button", {
			"data-accessory": "",
			onClick: le,
			"aria-label": N("common.clear", "Limpiar"),
			type: "button",
			children: /* @__PURE__ */ i("span", {
				className: "flow-symbol flow-symbol--sm",
				"aria-hidden": "true",
				children: "close"
			})
		}), /* @__PURE__ */ i("span", {
			className: `flow-symbol ${r.chevron}`,
			"data-open": L || void 0,
			"aria-hidden": "true",
			children: "expand_more"
		})] }),
		style: ae,
		children: /* @__PURE__ */ a("span", {
			id: k,
			className: r.trigger,
			ref: oe,
			role: "combobox",
			"aria-describedby": o,
			"aria-invalid": f,
			"aria-required": p,
			"aria-label": T,
			"aria-labelledby": A,
			"aria-expanded": L,
			"aria-haspopup": "listbox",
			"aria-controls": L ? W : void 0,
			tabIndex: D ? -1 : 0,
			"aria-activedescendant": L && V >= 0 ? `${W}-opt-${V}` : void 0,
			onKeyDown: (e) => {
				if (!L) {
					(e.key === "Enter" || e.key === " " || e.key === "ArrowDown") && (e.preventDefault(), Q(!0));
					return;
				}
				e.key === "ArrowDown" ? (e.preventDefault(), H((e) => (e + 1) % $.length)) : e.key === "ArrowUp" ? (e.preventDefault(), H((e) => e <= 0 ? $.length - 1 : e - 1)) : e.key === "Enter" && V >= 0 && (e.preventDefault(), Z($[V]));
			},
			children: [T && /* @__PURE__ */ a("span", {
				className: r.insetLabel,
				children: [T, ":"]
			}), /* @__PURE__ */ i("span", {
				"data-truncate": "",
				className: r.triggerText,
				"data-empty": !X || void 0,
				children: ce ?? (X || P)
			})]
		})
	});
	return /* @__PURE__ */ a(ee, {
		trigger: ue,
		fillTrigger: !0,
		open: L,
		onOpenChange: Q,
		children: [
			J && /* @__PURE__ */ i("div", {
				className: r.search,
				children: /* @__PURE__ */ i("input", {
					ref: U,
					"data-field": "",
					className: r.searchInput,
					value: z,
					onChange: (e) => {
						B(e.target.value), y?.(e.target.value);
					},
					placeholder: N("select.search", "Buscar…"),
					autoComplete: "off"
				})
			}),
			$.length > 0 && /* @__PURE__ */ i(n, {
				id: W,
				active: V,
				onActiveChange: H,
				items: $,
				value: _ ? void 0 : h,
				onChange: Z,
				renderItem: C ? (e, t) => C(G.find((t) => t.value === e.value) ?? {
					value: String(e.value),
					label: e.label
				}) : void 0
			}),
			b ? /* @__PURE__ */ i("div", {
				className: r.empty,
				role: "status",
				children: N("select.loading", "Buscando…")
			}) : $.length === 0 && /* @__PURE__ */ i("div", {
				className: r.empty,
				children: N("select.noResults", "Sin resultados")
			})
		]
	});
});
//#endregion
export { f as Select };

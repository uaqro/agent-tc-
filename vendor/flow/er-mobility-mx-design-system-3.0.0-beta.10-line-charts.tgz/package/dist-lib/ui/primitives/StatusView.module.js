//#region src/ui/primitives/StatusView.module.css
var e = "RkE8rW_actions", t = "RkE8rW_description", n = "RkE8rW_iconWrap", r = "RkE8rW_root", i = "RkE8rW_spinner", a = "RkE8rW_statusIcon", o = "RkE8rW_title", s = {
	actions: e,
	description: t,
	iconWrap: n,
	root: r,
	spinner: i,
	statusIcon: a,
	title: o
};
//#endregion
export { e as actions, s as default, t as description, n as iconWrap, r as root, i as spinner, a as statusIcon, o as title };

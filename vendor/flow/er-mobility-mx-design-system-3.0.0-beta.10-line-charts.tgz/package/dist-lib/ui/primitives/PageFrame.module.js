//#region src/ui/primitives/PageFrame.module.css
var e = "wBT26a_root", t = { root: e };
//#endregion
export { t as default, e as root };

//#region src/ui/primitives/BrandCanvas.module.css
var e = "LItAWW_combustible", t = "LItAWW_contexto", n = "LItAWW_detalle", r = "LItAWW_electro", i = "LItAWW_fuente", a = "LItAWW_halo", o = "LItAWW_icono", s = "LItAWW_lienzo", c = "LItAWW_mantenimiento", l = "LItAWW_peaje", u = "LItAWW_punto", d = "LItAWW_root", f = "LItAWW_ruta", p = "LItAWW_tarjeta", m = "LItAWW_vertical", h = {
	combustible: e,
	contexto: t,
	detalle: n,
	electro: r,
	fuente: i,
	halo: a,
	icono: o,
	lienzo: s,
	mantenimiento: c,
	peaje: l,
	punto: u,
	root: d,
	ruta: f,
	señal: "LItAWW_señal",
	tarjeta: p,
	vertical: m
};
//#endregion
export { e as combustible, t as contexto, h as default, n as detalle, r as electro, i as fuente, a as halo, o as icono, s as lienzo, c as mantenimiento, l as peaje, u as punto, d as root, f as ruta, p as tarjeta, m as vertical };

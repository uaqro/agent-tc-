//#region src/ui/primitives/Listbox.module.css
var e = "XkTkbq_option", t = "XkTkbq_root", n = {
	option: e,
	root: t
};
//#endregion
export { n as default, e as option, t as root };

//#region src/ui/primitives/Slider.module.css
var e = "fOBKTW_fill", t = "fOBKTW_header", n = "fOBKTW_input", r = "fOBKTW_label", i = "fOBKTW_rail", a = "fOBKTW_root", o = "fOBKTW_thumb", s = "fOBKTW_track", c = "fOBKTW_value", l = {
	fill: e,
	header: t,
	input: n,
	label: r,
	rail: i,
	root: a,
	thumb: o,
	track: s,
	value: c
};
//#endregion
export { l as default, e as fill, t as header, n as input, r as label, i as rail, a as root, o as thumb, s as track, c as value };

//#region src/ui/primitives/StatusPill.module.css
var e = "_86A8pa_dot", t = "_86A8pa_root", n = {
	dot: e,
	root: t
};
//#endregion
export { n as default, e as dot, t as root };

//#region src/ui/primitives/EmptyState.module.css
var e = "rDJ8dq_action", t = "rDJ8dq_description", n = "rDJ8dq_icon", r = "rDJ8dq_root", i = "rDJ8dq_title", a = {
	action: e,
	description: t,
	icon: n,
	root: r,
	title: i
};
//#endregion
export { e as action, a as default, t as description, n as icon, r as root, i as title };

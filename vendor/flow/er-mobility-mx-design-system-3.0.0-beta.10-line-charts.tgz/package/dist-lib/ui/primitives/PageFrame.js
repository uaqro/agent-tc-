import e from "./PageFrame.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/PageFrame.tsx
function n({ maxWidth: n, children: r, as: i = "div", style: a }) {
	let o = {
		...n == null ? {} : { maxWidth: n },
		...a
	};
	return /* @__PURE__ */ t(i, {
		className: e.root,
		style: o,
		children: r
	});
}
//#endregion
export { n as PageFrame };

//#region src/ui/primitives/Badge.module.css
var e = "MPApuG_dot", t = "MPApuG_icon", n = "MPApuG_root", r = {
	dot: e,
	icon: t,
	root: n
};
//#endregion
export { r as default, e as dot, t as icon, n as root };

import e from "./Divider.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/Divider.tsx
function r({ orientation: r = "horizontal", label: i, style: a }) {
	return r === "vertical" ? /* @__PURE__ */ t("span", {
		role: i ? "separator" : void 0,
		"aria-orientation": i ? "vertical" : void 0,
		"aria-label": i || void 0,
		"aria-hidden": !i || void 0,
		className: e.vertical,
		style: a
	}) : i ? /* @__PURE__ */ n("div", {
		role: "separator",
		"aria-label": i,
		"data-overline": "",
		className: e.labeled,
		style: a,
		children: [
			/* @__PURE__ */ t("span", { className: e.line }),
			/* @__PURE__ */ t("span", {
				className: e.text,
				children: i
			}),
			/* @__PURE__ */ t("span", { className: e.line })
		]
	}) : /* @__PURE__ */ t("hr", {
		"aria-hidden": "true",
		className: e.horizontal,
		style: a
	});
}
//#endregion
export { r as Divider };

import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./ScaleLegend.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/primitives/ScaleLegend.tsx
var i = [
	"var(--viz-scale-1)",
	"var(--viz-scale-2)",
	"var(--viz-scale-3)",
	"var(--viz-scale-4)",
	"var(--viz-scale-5)"
], a = 8;
function o({ minLabel: o, maxLabel: s, icon: c, colors: l = i, emptyLabel: u, emptyColor: d = "var(--viz-neutral)", style: f }) {
	let p = e(), m = Math.max(l.length, 2);
	return /* @__PURE__ */ r("div", {
		className: t.root,
		style: f,
		children: [
			c && /* @__PURE__ */ n("span", {
				className: `flow-symbol ${t.iconMin}`,
				"aria-hidden": "true",
				children: c
			}),
			/* @__PURE__ */ n("span", {
				className: t.label,
				children: o
			}),
			/* @__PURE__ */ n("span", {
				className: t.steps,
				role: "img",
				"aria-label": p("scale.summary", "Escala de {n} tramos, de {min} a {max}", {
					n: l.length,
					min: o.toLowerCase(),
					max: s.toLowerCase()
				}),
				children: l.map((e, r) => /* @__PURE__ */ n("span", {
					className: t.step,
					style: {
						background: e,
						height: Math.round(a + r * 12 / (m - 1))
					}
				}, r))
			}),
			c && /* @__PURE__ */ n("span", {
				className: `flow-symbol ${t.iconMax}`,
				"aria-hidden": "true",
				children: c
			}),
			/* @__PURE__ */ n("span", {
				className: t.label,
				children: s
			}),
			u && /* @__PURE__ */ r("span", {
				className: t.empty,
				children: [/* @__PURE__ */ n("span", {
					className: t.emptySwatch,
					style: { background: d },
					"aria-hidden": "true"
				}), /* @__PURE__ */ n("span", {
					className: t.label,
					children: u
				})]
			})
		]
	});
}
//#endregion
export { o as ScaleLegend };

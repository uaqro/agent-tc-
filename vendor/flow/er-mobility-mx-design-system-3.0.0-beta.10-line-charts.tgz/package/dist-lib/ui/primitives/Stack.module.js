//#region src/ui/primitives/Stack.module.css
var e = "NRO_MW_root", t = { root: e };
//#endregion
export { t as default, e as root };

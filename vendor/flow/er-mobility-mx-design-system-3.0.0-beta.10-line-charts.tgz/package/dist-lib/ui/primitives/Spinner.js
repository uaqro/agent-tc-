import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./Spinner.module.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/ui/primitives/Spinner.tsx
function r({ size: r = 20, color: i, label: a, style: o }) {
	let s = e(), c = a ?? s("common.loading", "Cargando"), l = Math.max(2, r / 9);
	return /* @__PURE__ */ n("span", {
		role: "status",
		"aria-label": c,
		className: t.root,
		style: {
			width: r,
			height: r,
			borderWidth: l,
			borderTopColor: i || "var(--action-accent)",
			...o
		}
	});
}
//#endregion
export { r as Spinner };

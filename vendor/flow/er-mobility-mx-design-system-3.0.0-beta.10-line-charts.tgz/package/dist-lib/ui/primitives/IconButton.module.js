//#region src/ui/primitives/IconButton.module.css
var e = "ZPYGIq_badge", t = "ZPYGIq_icon", n = "ZPYGIq_root", r = {
	badge: e,
	icon: t,
	root: n
};
//#endregion
export { e as badge, r as default, t as icon, n as root };

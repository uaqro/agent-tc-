//#region src/ui/primitives/SheetBody.module.css
var e = "OOQoaq_root", t = { root: e };
//#endregion
export { t as default, e as root };

import e from "./Card.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/Card.tsx
var n = /* @__PURE__ */ new Set([
	"none",
	"sm",
	"md",
	"lg"
]);
function r({ padding: r, surface: i = "elevated", hover: a, interactive: o, status: s, selected: c, children: l, onClick: u, style: d }) {
	let f = a ?? (o ? "lift" : "none"), p = typeof r == "string" && n.has(r), m = o || !!u;
	return /* @__PURE__ */ t("div", {
		className: e.root,
		"data-surface": i,
		"data-hover": f === "none" ? void 0 : f,
		"data-interactive": o || void 0,
		"data-padding": p ? r : void 0,
		"data-status": s,
		"data-selected": c || void 0,
		"aria-pressed": m && c !== void 0 ? c : void 0,
		role: m ? "button" : void 0,
		tabIndex: m ? 0 : void 0,
		onKeyDown: m ? (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), u?.(e));
		} : void 0,
		onClick: u,
		style: {
			...r != null && !p ? { padding: r } : {},
			...d
		},
		children: l
	});
}
//#endregion
export { r as Card };

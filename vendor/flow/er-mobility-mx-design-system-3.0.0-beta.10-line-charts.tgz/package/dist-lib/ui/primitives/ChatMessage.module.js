//#region src/ui/primitives/ChatMessage.module.css
var e = "AKa2TG_bubble", t = "AKa2TG_dot", n = "AKa2TG_richContent", r = "AKa2TG_root", i = "AKa2TG_streamingDots", a = "AKa2TG_timestamp", o = "AKa2TG_toolChip", s = "AKa2TG_toolDone", c = "AKa2TG_toolIcon", l = "AKa2TG_toolSpinner", u = {
	bubble: e,
	dot: t,
	richContent: n,
	root: r,
	streamingDots: i,
	timestamp: a,
	toolChip: o,
	toolDone: s,
	toolIcon: c,
	toolSpinner: l
};
//#endregion
export { e as bubble, u as default, t as dot, n as richContent, r as root, i as streamingDots, a as timestamp, o as toolChip, s as toolDone, c as toolIcon, l as toolSpinner };

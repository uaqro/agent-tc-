import e from "./CircularProgress.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/CircularProgress.tsx
var r = {
	accent: "var(--action-accent)",
	success: "var(--status-success)",
	warning: "var(--status-warning)",
	danger: "var(--status-danger)"
};
function i({ value: i = 0, max: a = 100, size: o = 56, strokeWidth: s = 5, label: c, ariaLabel: l, showValue: u = !1, children: d, tone: f = "accent", style: p }) {
	let m = Math.max(0, Math.min(a, i)), h = Math.max(0, Math.min(1, a > 0 ? m / a : 0)), g = (o - s) / 2, _ = 2 * Math.PI * g, v = f === "inherit", y = v ? void 0 : r[f] || r.accent;
	return /* @__PURE__ */ n("div", {
		className: e.root,
		"data-tone": v ? "inherit" : void 0,
		role: "progressbar",
		"aria-valuenow": m,
		"aria-valuemin": 0,
		"aria-valuemax": a,
		"aria-label": l ?? c,
		style: p,
		children: [/* @__PURE__ */ n("span", {
			className: e.ring,
			style: {
				width: o,
				height: o
			},
			children: [/* @__PURE__ */ n("svg", {
				className: e.svg,
				width: o,
				height: o,
				children: [/* @__PURE__ */ t("circle", {
					className: e.track,
					cx: o / 2,
					cy: o / 2,
					r: g,
					strokeWidth: s
				}), /* @__PURE__ */ t("circle", {
					className: e.arc,
					cx: o / 2,
					cy: o / 2,
					r: g,
					stroke: y,
					strokeWidth: s,
					strokeDasharray: _,
					strokeDashoffset: _ * (1 - h)
				})]
			}), d == null ? u && /* @__PURE__ */ n("span", {
				className: e.value,
				style: { fontSize: o * .24 },
				children: [Math.round(h * 100), "%"]
			}) : /* @__PURE__ */ t("span", {
				className: e.value,
				children: d
			})]
		}), c && /* @__PURE__ */ t("span", {
			className: e.label,
			children: c
		})]
	});
}
//#endregion
export { i as CircularProgress };

//#region src/ui/primitives/DetailRow.module.css
var e = "AoT3ua_label", t = "AoT3ua_root", n = "AoT3ua_value", r = {
	label: e,
	root: t,
	value: n
};
//#endregion
export { r as default, e as label, t as root, n as value };

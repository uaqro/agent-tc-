import e from "./EmptyState.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/EmptyState.tsx
function r({ icon: r, title: i, description: a, action: o, style: s }) {
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: s,
		children: [
			r && /* @__PURE__ */ t("span", {
				className: `flow-symbol ${e.icon}`,
				"aria-hidden": "true",
				children: r
			}),
			i && /* @__PURE__ */ t("div", {
				className: e.title,
				children: i
			}),
			a && /* @__PURE__ */ t("div", {
				className: e.description,
				children: a
			}),
			o && /* @__PURE__ */ t("div", {
				className: e.action,
				children: o
			})
		]
	});
}
//#endregion
export { r as EmptyState };

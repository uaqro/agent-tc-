//#region src/ui/primitives/LimitBar.module.css
var e = "pBrVhW_fill", t = "pBrVhW_header", n = "pBrVhW_label", r = "pBrVhW_root", i = "pBrVhW_track", a = "pBrVhW_values", o = {
	fill: e,
	header: t,
	label: n,
	root: r,
	track: i,
	values: a
};
//#endregion
export { o as default, e as fill, t as header, n as label, r as root, i as track, a as values };

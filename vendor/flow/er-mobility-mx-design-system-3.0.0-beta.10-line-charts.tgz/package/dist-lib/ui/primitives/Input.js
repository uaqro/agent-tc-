"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { ControlShell as t } from "./ControlShell.js";
import n from "./Input.module.js";
import { jsx as r } from "react/jsx-runtime";
import { forwardRef as i, useState as a } from "react";
//#region src/ui/primitives/Input.tsx
var o = i(function({ name: i, required: o, onBlur: s, onKeyDown: c, autoFocus: l, value: u, onChange: d, placeholder: f, icon: p, size: m = "md", filled: h, disabled: g, invalid: _, error: v, type: y = "text", revealable: b, trailing: x, mono: S, ariaLabel: C, style: w, ...T }, E) {
	let D = e(), [O, k] = a(!1), A = b ? /* @__PURE__ */ r("button", {
		type: "button",
		tabIndex: 0,
		"aria-label": O ? D("common.hide", "Ocultar") : D("common.show", "Mostrar"),
		"aria-pressed": O,
		onClick: () => k((e) => !e),
		"data-accessory": "",
		children: /* @__PURE__ */ r("span", {
			className: "flow-symbol flow-symbol--default",
			"aria-hidden": "true",
			children: O ? "visibility_off" : "visibility"
		})
	}) : void 0;
	return /* @__PURE__ */ r(t, {
		size: m,
		filled: h,
		disabled: g,
		invalid: _ ?? v,
		leading: p && /* @__PURE__ */ r("span", {
			className: "flow-symbol flow-symbol--md",
			"aria-hidden": "true",
			children: p
		}),
		trailing: A ?? x,
		style: w,
		children: /* @__PURE__ */ r("input", {
			ref: E,
			name: i,
			required: o,
			onBlur: s,
			onKeyDown: c,
			autoFocus: l,
			type: b ? O ? "text" : "password" : y,
			"data-field": "",
			className: n.input,
			"data-mono": S || void 0,
			value: u,
			"aria-label": C,
			"aria-invalid": (_ ?? v) || void 0,
			onChange: (e) => d?.(e.target.value),
			placeholder: f,
			disabled: g,
			...T
		})
	});
});
//#endregion
export { o as Input };

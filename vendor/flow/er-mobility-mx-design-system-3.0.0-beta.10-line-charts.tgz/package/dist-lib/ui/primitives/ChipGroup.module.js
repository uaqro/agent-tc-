//#region src/ui/primitives/ChipGroup.module.css
var e = "HTJTlG_root", t = { root: e };
//#endregion
export { t as default, e as root };

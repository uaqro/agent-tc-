import e from "./AutoGrid.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/AutoGrid.tsx
function n({ minWidth: n = "320px", gap: r, children: i, style: a }) {
	let o = {
		"--ag-min": n,
		...r ? { "--ag-gap": r } : {},
		...a
	};
	return /* @__PURE__ */ t("div", {
		className: e.root,
		style: o,
		children: i
	});
}
//#endregion
export { n as AutoGrid };

import e from "./StatusView.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/StatusView.tsx
var r = {
	success: "check_circle",
	error: "error",
	pending: "schedule",
	loading: "sync",
	offline: "cloud_off"
}, i = /* @__PURE__ */ new Set(["success", "error"]);
function a({ status: a = "loading", title: o, description: s, primaryAction: c, secondaryAction: l, fullScreen: u = !1, style: d }) {
	let f = a === "error" || a === "offline";
	return /* @__PURE__ */ n("div", {
		className: e.root,
		"data-full-screen": u || void 0,
		"aria-busy": a === "loading" || void 0,
		style: d,
		children: [
			/* @__PURE__ */ n("span", {
				className: e.iconWrap,
				"data-status": a,
				children: [a === "loading" && /* @__PURE__ */ t("span", {
					className: e.spinner,
					"aria-hidden": "true"
				}), /* @__PURE__ */ t("span", {
					className: `flow-symbol${i.has(a) ? " flow-symbol--fill" : ""} ${e.statusIcon}`,
					"aria-hidden": "true",
					"data-status": a,
					children: r[a]
				})]
			}),
			o && /* @__PURE__ */ t("div", {
				role: s ? void 0 : f ? "alert" : "status",
				className: e.title,
				children: o
			}),
			s && /* @__PURE__ */ t("div", {
				role: f ? "alert" : "status",
				className: e.description,
				children: s
			}),
			(c || l) && /* @__PURE__ */ n("div", {
				className: e.actions,
				children: [c, l]
			})
		]
	});
}
//#endregion
export { a as StatusView };

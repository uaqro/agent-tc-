import e from "./SectionBar.module.js";
import { Fragment as t, jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/primitives/SectionBar.tsx
function i({ children: i, trailing: a, sticky: o = !0, contained: s = !1, style: c }) {
	let l = /* @__PURE__ */ r(t, { children: [
		i,
		/* @__PURE__ */ n("span", { className: e.spacer }),
		a && /* @__PURE__ */ n("div", {
			className: e.trailing,
			children: a
		})
	] });
	return /* @__PURE__ */ n("div", {
		className: e.root,
		"data-sticky": o || void 0,
		"data-contained": s || void 0,
		style: c,
		children: s ? /* @__PURE__ */ n("div", {
			className: e.inner,
			children: l
		}) : l
	});
}
//#endregion
export { i as SectionBar };

"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { TRAMAS as t, decalDeTrama as n, simboloDeSerie as r, trazoDeSerie as i } from "../../dataviz/marcas.js";
import { fallbackDe as a, leerFuenteSimbolos as o, leerToken as s } from "../../tokens/leerToken.js";
import c from "./FlowChart.module.js";
import { roundedPlot as l } from "../../dataviz/roundedPlot.js";
import { jsx as u, jsxs as d } from "react/jsx-runtime";
import { useEffect as f, useMemo as p, useRef as m, useState as h } from "react";
//#region src/ui/primitives/FlowChart.tsx
var g = null, _ = null;
function v() {
	return _ ??= Promise.all([
		import("echarts/core"),
		import("echarts/charts"),
		import("echarts/components"),
		import("echarts/renderers")
	]).then(([e, t, n, r]) => (e.use([
		t.BarChart,
		t.LineChart,
		t.PieChart,
		t.ScatterChart,
		t.RadarChart,
		t.GaugeChart,
		t.FunnelChart,
		t.TreemapChart,
		t.HeatmapChart,
		t.BoxplotChart,
		n.GridComponent,
		n.TooltipComponent,
		n.LegendComponent,
		n.VisualMapComponent,
		n.MarkLineComponent,
		n.AriaComponent,
		r.CanvasRenderer
	]), g = e, e)), _.catch(() => {
		_ = null;
	}), _;
}
function y(e) {
	return e.split(",").map((e) => e.trim().replace(/^["']|["']$/g, "")).filter(Boolean).join(", ");
}
function b(e) {
	let t = getComputedStyle(e), n = (e) => s(e, t), r = (e) => {
		let n = String(e || "");
		for (let e = 0; e < 4 && /^var\(/.test(n); e++) {
			let e = n.slice(4, -1).split(",")[0].trim();
			n = (t.getPropertyValue(e) || "").trim() || n.slice(4, -1).split(",").slice(1).join(",").trim();
		}
		return n || e;
	}, i = /(\d{3})\s+(\d+(?:\.\d+)?)px/, c = i.exec(n("--type-data-lg")) ?? i.exec(a("--type-data-lg")), l = i.exec(n("--type-body-sm")), u = i.exec(n("--type-viz-category")), d = i.exec(n("--type-viz-value")), f = i.exec(n("--type-viz-value"));
	return {
		labelPadding: [parseFloat(n("--space-hairline")), parseFloat(n("--space-1"))],
		labelRadius: parseFloat(n("--radius-sm")),
		cellGap: parseFloat(n("--space-1")),
		cellRadius: parseFloat(n("--radius-viz-mark")),
		stackGap: parseFloat(n("--gap-stack")),
		inlineGap: parseFloat(n("--gap-inline")),
		captionSize: l ? Number(l[2]) : void 0,
		iconSize: parseFloat(n("--icon-md")),
		fontSymbol: o(e),
		categoryColor: n("--viz-category-label"),
		categorySize: u ? Number(u[2]) : void 0,
		categoryWeight: u ? Number(u[1]) : void 0,
		axisNumberSize: f ? Number(f[2]) : void 0,
		axisNumberWeight: f ? Number(f[1]) : void 0,
		numeralSize: d ? Number(d[2]) : void 0,
		numeralWeight: d ? Number(d[1]) : void 0,
		resolve: r,
		palette: [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		].map((e) => n("--viz-" + e)),
		ramp: [
			1,
			2,
			3,
			4,
			5,
			6
		].map((e) => n("--viz-ramp-" + e)),
		scale: [
			1,
			2,
			3,
			4,
			5
		].map((e) => n("--viz-scale-" + e)),
		accent: n("--viz-accent"),
		positive: n("--viz-positive"),
		negative: n("--viz-negative"),
		neutral: n("--viz-neutral"),
		grid: n("--viz-grid"),
		axis: n("--viz-axis"),
		label: n("--viz-label"),
		tipBg: n("--viz-tooltip-bg"),
		tipText: n("--viz-tooltip-text"),
		card: n("--surface-card"),
		plotBg: n("--surface-canvas"),
		sombraRealce: n("--ref-alpha-black-12"),
		tinta: n("--ref-alpha-black-20"),
		text: n("--text-primary"),
		muted: n("--text-muted"),
		fontBody: y(n("--font-body")),
		fontMono: y(n("--font-mono")),
		kpiWeight: c ? Number(c[1]) : void 0,
		kpiSize: c ? parseFloat(c[2]) : void 0
	};
}
function x() {
	return typeof window < "u" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
}
function S(e, t) {
	if (!t) return e;
	let n = Array.isArray(e) ? e.slice() : { ...e };
	for (let e of Object.keys(t)) {
		let r = n[e], i = t[e];
		n[e] = i && typeof i == "object" && !Array.isArray(i) && r && typeof r == "object" && !Array.isArray(r) ? S(r, i) : i;
	}
	return n;
}
var C = (e, r) => e > 1 ? {
	enabled: !0,
	label: { enabled: !1 },
	decal: {
		show: !0,
		decals: t.map((e) => n(e, r))
	}
} : { enabled: !1 };
function w(e, t, n) {
	let r = [
		n.palette[0],
		n.accent,
		n.neutral
	];
	return t === "categorical" ? n.palette : t === "duo" || e <= 3 ? r : n.palette;
}
function T(e, t) {
	let n = e.startsWith("#") ? e : a("--viz-1"), r = parseInt(n.slice(1, 3), 16), i = parseInt(n.slice(3, 5), 16), o = parseInt(n.slice(5, 7), 16);
	return Array.from({ length: t }, (e, n) => {
		let a = .08 + n / (t - 1) * .92;
		return `rgba(${r},${i},${o},${a.toFixed(2)})`;
	});
}
function E(e, t) {
	if (typeof e == "string") return /var\(--/.test(e) ? t(e) : e;
	if (typeof e == "function" || e == null) return e;
	if (Array.isArray(e)) return e.map((e) => E(e, t));
	if (typeof e == "object") {
		if (e instanceof Date) return e;
		let n = {};
		for (let r of Object.keys(e)) n[r] = E(e[r], t);
		return n;
	}
	return e;
}
function D(e, t, n) {
	let { series: a = [], labels: o = [], format: s, legend: l = !1, stack: u = !1, smooth: d = !0, highlight: f, horizontal: p = !1, matrix: m, indicators: h, target: g, max: _, min: v, showValues: y = !1, area: b, palette: E = "auto", animate: D = !0, itemColors: O, color: k, thresholds: A, threshold: j, thickness: M, height: N } = t, P = D && !x(), F = typeof s == "function" ? s : (e) => String(e), ee = (e) => typeof e == "number" ? (t.axisFormat ?? F)(e) : e, I = n.resolve, L = /* @__PURE__ */ new Set([
		"label",
		"values",
		"data",
		"color",
		"icon",
		"symbolSize",
		"gapLabel"
	]), R = (e) => {
		let t = {};
		for (let n of Object.keys(e)) L.has(n) || (t[n] = e[n]);
		return t;
	}, z = w(a.length, E, n), B = f ? z.filter((e) => e !== n.accent) : z, V = [], te = 0;
	for (let e of a) V.push(f && e.label === f ? n.accent : e.color ? I(e.color) : B[te++ % B.length]);
	let H = (e, t) => f && t === f ? n.accent : V[e] || B[e % B.length] || n.text, U = {
		fontFamily: n.fontBody,
		fontSize: n.categorySize,
		fontWeight: n.categoryWeight,
		color: n.categoryColor
	}, ne = {
		fontFamily: n.fontMono,
		fontSize: n.axisNumberSize,
		fontWeight: n.axisNumberWeight,
		color: n.categoryColor
	}, W = (e) => String(e).replace(/[&<>"']/g, (e) => ({
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;",
		"'": "&#39;"
	})[e]), G = (e) => `<span class="${c.tipNumber}">${W(e)}</span>`, K = (e) => `<div class="${c.tipHeading}">${W(e)}</div>`, q = (e, t, n, r = !1) => `<div class="${c.tipRow}${r ? ` ${c.tipMissingRow}` : ""}">${e || ""}<span class="${c.tipLabel}">${W(t || "")}</span>${r ? `<span class="${c.tipMissing}">${W(n)}</span>` : G(n)}</div>`, J = (e) => P ? {
		animation: !0,
		animationDuration: 620,
		animationEasing: "cubicOut",
		animationDelay: e ? (e) => e * 36 : 0
	} : { animation: !1 }, Y = n.cellRadius, X = (e) => e ? 0 : p ? [
		0,
		Y,
		Y,
		0
	] : [
		Y,
		Y,
		0,
		0
	], re = (e, t, r) => {
		let i = a.map((e, n) => {
			let i = (e.values || [])[t] || 0;
			return e.type !== "line" && i !== 0 && Math.sign(i) === Math.sign(r) ? n : -1;
		}).filter((e) => e >= 0), o = e === i[0], s = e === i[i.length - 1], c = n.cellRadius, l = r < 0 ? s : o, u = r < 0 ? o : s;
		return p ? [
			l ? c : 0,
			u ? c : 0,
			u ? c : 0,
			l ? c : 0
		] : [
			u ? c : 0,
			u ? c : 0,
			l ? c : 0,
			l ? c : 0
		];
	}, ie = y ? {
		show: !0,
		position: p ? "right" : "top",
		fontFamily: n.fontMono,
		fontSize: n.numeralSize,
		fontWeight: n.numeralWeight,
		color: n.categoryColor,
		formatter: (e) => F(e.value)
	} : { show: !1 }, ae = /* @__PURE__ */ new Set([
		"pie",
		"donut",
		"funnel",
		"treemap"
	]), oe = a[0] && (a[0].data || a[0].values) || [], Z = {
		color: z,
		aria: C(a.length > 1 ? a.length : ae.has(e) || O && O.length > 1 ? Math.max(oe.length, O ? O.length : 0) : 1, n.tinta),
		backgroundColor: "transparent",
		textStyle: {
			fontFamily: n.fontBody,
			color: n.text
		},
		animation: P,
		animationDuration: 620,
		animationEasing: "cubicOut",
		grid: {
			left: n.inlineGap,
			right: n.inlineGap,
			top: l ? n.categorySize + n.stackGap : y ? n.numeralSize + n.inlineGap : 0,
			bottom: n.inlineGap,
			containLabel: !0
		},
		legend: l ? {
			show: !0,
			top: 0,
			left: 0,
			itemGap: n.stackGap,
			icon: "roundRect",
			itemWidth: 10,
			itemHeight: 10,
			textStyle: U
		} : { show: !1 },
		tooltip: {
			confine: !0,
			backgroundColor: n.tipBg,
			borderWidth: 0,
			padding: 0,
			extraCssText: "border-radius:var(--radius-sm);box-shadow:var(--shadow-float);padding:var(--space-3) var(--space-4);font:var(--type-body-sm);max-width:100%;box-sizing:border-box;white-space:normal",
			textStyle: { color: n.tipText },
			axisPointer: {
				type: "line",
				lineStyle: {
					color: n.axis,
					width: 1
				}
			}
		}
	}, Q = {
		type: "category",
		data: o,
		boundaryGap: e === "bar" || e === "stackedBar" || e === "stacked100" || e === "waterfall" || e === "pareto",
		axisLine: { show: !1 },
		axisTick: { show: !1 },
		axisLabel: {
			color: n.categoryColor,
			fontFamily: n.fontBody,
			fontSize: n.categorySize,
			fontWeight: n.categoryWeight,
			hideOverlap: !0,
			margin: n.stackGap
		}
	}, $ = {
		type: "value",
		splitLine: { lineStyle: {
			color: n.grid,
			type: "dashed"
		} },
		axisLine: { show: !1 },
		axisTick: { show: !1 },
		axisLabel: {
			...ne,
			formatter: ee,
			margin: n.stackGap
		},
		min: v,
		max: _
	};
	switch (e) {
		case "line":
		case "area": {
			let n = e === "area" || b;
			return S(Z, {
				tooltip: {
					trigger: "axis",
					formatter: (e) => {
						if (!e.length) return "";
						let n = e[0].dataIndex;
						return K(e[0].axisValueLabel) + a.map((r, i) => {
							let a = r.values?.[n], o = e.find((e) => e.seriesIndex === i)?.marker ?? "";
							return q(o, r.label, a == null ? r.gapLabel ?? t.gapLabel ?? "Sin datos" : F(a), a == null);
						}).join("");
					}
				},
				xAxis: Q,
				yAxis: $,
				series: a.map((e, t) => {
					let o = e.color || H(t, e.label);
					return S({
						name: e.label,
						type: "line",
						data: e.values,
						connectNulls: !1,
						smooth: d ? .35 : !1,
						showSymbol: (e.values ?? []).some((e, t, n) => e != null && n[t - 1] == null && n[t + 1] == null),
						symbolSize: 7,
						symbol: r(t, a.length),
						lineStyle: {
							width: 2.25,
							color: o,
							cap: "round",
							join: "round",
							type: i(t, a.length)
						},
						itemStyle: { color: o },
						stack: u ? "total" : void 0,
						emphasis: {
							focus: "series",
							scale: 1.4
						},
						areaStyle: n ? {
							opacity: .14,
							color: o
						} : void 0
					}, P ? {
						animationDuration: 900,
						animationDelay: t * 160,
						animationEasing: "cubicOut"
					} : { animation: !1 });
				})
			});
		}
		case "bar":
		case "stackedBar": {
			let t = e === "stackedBar" || u, n = p ? [
				Y,
				0,
				0,
				Y
			] : [
				0,
				0,
				Y,
				Y
			];
			return S(Z, {
				tooltip: {
					trigger: "axis",
					axisPointer: { type: "shadow" },
					formatter: (e) => K(e[0].axisValueLabel) + e.map((e) => q(e.marker, e.seriesName, F(e.value))).join("")
				},
				xAxis: p ? $ : Q,
				yAxis: p ? S(Q, {
					boundaryGap: !0,
					inverse: !0
				}) : $,
				series: a.map((e, o) => {
					if (e.type === "line") {
						let t = I(e.color || H(o, e.label));
						return S(S({
							name: e.label,
							type: "line",
							data: e.values,
							smooth: d ? .35 : !1,
							showSymbol: !1,
							symbolSize: 7,
							symbol: r(o, a.length),
							lineStyle: {
								width: 2.25,
								color: t,
								cap: "round",
								join: "round",
								type: i(o, a.length)
							},
							itemStyle: { color: t },
							emphasis: {
								focus: "series",
								scale: 1.4
							},
							z: 3
						}, R(e)), P ? {
							animationDuration: 900,
							animationDelay: 260,
							animationEasing: "cubicOut"
						} : { animation: !1 });
					}
					let s = (e.values || []).some((e) => e != null && e < 0);
					return S(S({
						name: e.label,
						type: "bar",
						data: O || s || t ? (e.values || []).map((r, i) => ({
							value: r,
							itemStyle: {
								color: I(O && O[i] || e.color || H(o, e.label)),
								...t ? { borderRadius: r == null ? 0 : re(o, i, r) } : r != null && r < 0 ? { borderRadius: n } : {}
							}
						})) : e.values,
						stack: t ? "total" : void 0,
						barMaxWidth: 34,
						itemStyle: {
							color: I(e.color || H(o, e.label)),
							borderRadius: X(!!t)
						},
						emphasis: { focus: "series" },
						label: ie
					}, R(e)), J(!0));
				})
			});
		}
		case "stacked100": {
			let e = a[0]?.values?.length || 0, t = Array.from({ length: e }, (e, t) => a.reduce((e, n) => e + ((n.values || [])[t] || 0), 0) || 1), r = {
				position: "inside",
				color: n.tipText,
				backgroundColor: n.tipBg,
				padding: n.labelPadding,
				borderRadius: n.labelRadius,
				fontFamily: n.fontMono,
				fontSize: n.numeralSize,
				fontWeight: n.numeralWeight,
				formatter: (e) => `${Math.round(e.value)}%`
			};
			return S(Z, {
				aria: a.every((e) => e.icon) ? {
					enabled: !0,
					decal: { show: !1 }
				} : Z.aria,
				tooltip: {
					trigger: "axis",
					axisPointer: { type: "shadow" },
					formatter: (e) => K(e[0].axisValueLabel) + a.map((n, r) => {
						let i = n.icon, a = i ? `<span class="flow-symbol ${c.tipIcon}" aria-hidden="true" style="color:${W(H(r, n.label))}">${W(i)}</span>` : "", o = e[0].dataIndex;
						return q(a, n.label, `${Math.round(((n.values || [])[o] || 0) / t[o] * 100)}%`);
					}).join("")
				},
				xAxis: p ? S($, {
					max: "dataMax",
					axisLabel: { show: !1 }
				}) : Q,
				yAxis: p ? S(Q, {
					boundaryGap: !0,
					inverse: !0
				}) : S($, {
					max: "dataMax",
					axisLabel: { show: !1 }
				}),
				series: [...a.map((e, n) => S({
					name: e.label,
					type: "bar",
					stack: "total",
					tooltip: {
						trigger: "item",
						formatter: (t) => {
							let r = e.icon ? `<span class="flow-symbol ${c.tipIcon}" aria-hidden="true" style="color:${W(H(n, e.label))}">${W(e.icon)}</span>` : "";
							return K(t.name) + q(r, e.label, `${Math.round(t.value)}%`);
						}
					},
					data: (e.values || []).map((e, r) => ({
						value: e == null ? null : e / t[r] * 100,
						itemStyle: { borderRadius: e == null ? 0 : re(n, r, e) }
					})),
					label: {
						...r,
						show: y
					},
					labelLayout: { hideOverlap: !0 },
					itemStyle: { color: I(e.color || H(n, e.label)) },
					emphasis: {
						focus: "series",
						label: {
							...r,
							show: !0
						}
					}
				}, J(!0))), {
					name: "",
					type: "bar",
					stack: "total",
					silent: !0,
					data: Array.from({ length: e }, () => 0),
					tooltip: { trigger: "axis" },
					itemStyle: { opacity: 0 },
					emphasis: { disabled: !0 }
				}]
			});
		}
		case "donut":
		case "pie": {
			let r = (a[0] && (a[0].data || a[0].values) || []).map((e, t) => typeof e == "number" ? {
				name: o[t] || String(t),
				value: e
			} : {
				name: e.label || e.name || "",
				value: e.value,
				itemStyle: e.color ? { color: I(e.color) } : void 0
			}), i = w(r.length, E, n);
			return S(Z, {
				color: i,
				tooltip: {
					trigger: "item",
					formatter: (e) => {
						let n = a[0]?.data?.[e.dataIndex], r = n?.icon ? `<span class="flow-symbol ${c.tipIcon}" aria-hidden="true"${n.color ? ` style="color:${W(I(n.color))}"` : ""}>${W(n.icon)}</span>` : "";
						return `<div class="${c.tipHeading}">${r}<span>${W(e.name)}</span></div>` + q("", t.valueLabel || "Valor", F(e.value)) + q("", t.percentLabel || "Del total", `${e.percent}%`);
					}
				},
				legend: l ? {
					show: !0,
					orient: "vertical",
					right: 0,
					top: "middle",
					itemGap: 12,
					icon: "circle",
					itemWidth: 9,
					itemHeight: 9,
					textStyle: U
				} : { show: !1 },
				series: [S({
					type: "pie",
					radius: e === "donut" ? [M != null && N ? `${Math.max(0, 82 - M / (N / 2) * 100)}%` : "58%", "82%"] : ["0%", "80%"],
					center: l ? ["36%", "52%"] : ["50%", e === "donut" ? "50%" : "52%"],
					data: r.map((e, t) => S({ itemStyle: { color: i[t % i.length] } }, e)),
					itemStyle: {
						borderColor: n.card,
						borderWidth: 2,
						borderRadius: e === "donut" ? M == null ? "100%" : M / 2 : n.cellRadius
					},
					label: { show: !1 },
					emphasis: {
						scale: !0,
						scaleSize: 5,
						itemStyle: {
							shadowBlur: 14,
							shadowColor: n.sombraRealce
						}
					}
				}, P ? {
					animationType: "expansion",
					animationDuration: 760,
					animationEasing: "cubicOut"
				} : { animation: !1 })]
			});
		}
		case "scatter": {
			let e = (e) => e ? {
				name: e,
				nameLocation: "middle",
				nameGap: n.axisNumberSize + n.stackGap + n.captionSize + n.inlineGap,
				nameTextStyle: {
					fontFamily: n.fontBody,
					fontSize: n.captionSize,
					color: n.label
				}
			} : {};
			return S(Z, {
				grid: {
					right: n.axisNumberSize + n.stackGap,
					bottom: t.axisLabels?.x ? n.captionSize + n.stackGap : n.inlineGap,
					left: t.axisLabels?.y ? n.axisNumberSize + n.stackGap + n.captionSize + n.inlineGap : n.inlineGap
				},
				tooltip: {
					trigger: "item",
					formatter: (e) => K(e.seriesName) + q("", F(e.value[0]), F(e.value[1]))
				},
				xAxis: S(S($, e(t.axisLabels?.x)), {
					axisLabel: {
						alignMinLabel: "left",
						alignMaxLabel: "right"
					},
					splitLine: {
						show: !0,
						showMinLine: t.plotSurface !== "canvas",
						showMaxLine: t.plotSurface !== "canvas",
						lineStyle: {
							color: n.grid,
							type: "dashed"
						}
					}
				}),
				yAxis: S(S($, e(t.axisLabels?.y)), { splitLine: {
					showMinLine: t.plotSurface !== "canvas",
					showMaxLine: t.plotSurface !== "canvas"
				} }),
				series: a.map((e, t) => S({
					name: e.label,
					type: "scatter",
					data: e.values,
					symbolSize: e.symbolSize || 10,
					symbol: r(t, a.length),
					itemStyle: {
						color: I(e.color || H(t, e.label)),
						opacity: .78
					},
					emphasis: {
						focus: "series",
						itemStyle: { opacity: 1 }
					}
				}, S(R(e), P ? {
					animationDuration: 700,
					animationDelay: (e) => e * 22 + t * 90,
					animationEasing: "cubicOut"
				} : { animation: !1 })))
			});
		}
		case "heatmap": {
			let e = t.legend !== !1, r = m || {
				rows: [],
				cols: [],
				values: []
			}, i = r.values.map((e) => e[2]);
			return S(Z, {
				tooltip: {
					position: "top",
					formatter: (e) => K(r.rows[e.value[1]] + " · " + r.cols[e.value[0]]) + q(t.valueIcon ? `<span class="flow-symbol ${c.tipIcon}" aria-hidden="true">${W(t.valueIcon)}</span>` : "", t.valueLabel || "Valor", F(e.value[2]))
				},
				grid: {
					left: n.inlineGap,
					right: n.inlineGap,
					top: 0,
					bottom: e ? n.axisNumberSize + n.stackGap : n.inlineGap,
					containLabel: !0
				},
				xAxis: S(Q, {
					data: r.cols,
					axisLabel: r.columnRole === "number" || r.columnRole === "time" ? {
						...Q.axisLabel,
						fontFamily: n.fontMono,
						fontSize: n.axisNumberSize,
						fontWeight: n.axisNumberWeight
					} : Q.axisLabel,
					boundaryGap: !0,
					splitArea: { show: !1 },
					axisLine: { show: !1 }
				}),
				yAxis: S(Q, {
					data: r.rows,
					axisLabel: {
						...Q.axisLabel,
						interval: 0
					},
					boundaryGap: !0,
					splitArea: { show: !1 },
					axisLine: { show: !1 },
					inverse: !0
				}),
				visualMap: {
					show: e,
					min: Math.min(...i, 0),
					max: Math.max(...i, 1),
					orient: "horizontal",
					left: "center",
					bottom: 0,
					itemWidth: 11,
					itemHeight: 90,
					inRange: { color: k ? T(I(k), 6) : n.scale },
					textStyle: ne,
					formatter: (e) => String(F(Math.round(e)))
				},
				series: [S({
					type: "heatmap",
					data: r.values,
					itemStyle: {
						borderColor: n.card,
						borderWidth: n.cellGap,
						borderRadius: n.cellRadius + n.cellGap / 2
					},
					emphasis: { itemStyle: {
						borderColor: n.text,
						borderWidth: n.cellGap
					} }
				}, J(!0))]
			});
		}
		case "radar": {
			let e = (h || o).map((e) => typeof e == "string" ? {
				name: e,
				max: _ || 100
			} : e), t = O && O.length === e.length ? O.map((e) => I(e)) : null, r = e.some((e) => e.icon), i = {}, s;
			(r || t) && (e.forEach((e, r) => {
				let a = t ? t[r] : n.label;
				e.icon ? (i[`i${r}`] = {
					fontFamily: n.fontSymbol,
					fontSize: n.iconSize,
					color: a,
					verticalAlign: "middle"
				}, i[`t${r}`] = {
					fontFamily: n.fontBody,
					fontSize: n.categorySize,
					fontWeight: n.categoryWeight,
					color: n.categoryColor,
					verticalAlign: "middle",
					padding: [
						0,
						0,
						0,
						n.inlineGap
					]
				}) : i[`t${r}`] = {
					fontFamily: n.fontBody,
					fontSize: n.categorySize,
					fontWeight: n.categoryWeight,
					color: t ? a : n.label
				};
			}), s = (t) => {
				let n = e.findIndex((e) => e.name === t);
				if (n < 0) return t;
				let r = e[n];
				return r.icon ? `{i${n}|${r.icon}}{t${n}| ${t}}` : `{t${n}|${t}}`;
			});
			let c = s ? {
				formatter: s,
				rich: i
			} : U;
			return S(Z, {
				tooltip: { show: !1 },
				radar: {
					indicator: e.map((e) => ({
						name: e.name,
						max: e.max
					})),
					radius: "66%",
					splitNumber: 4,
					axisName: c,
					splitLine: { lineStyle: {
						color: n.grid,
						type: "dashed"
					} },
					splitArea: { show: !1 },
					axisLine: { lineStyle: { color: n.grid } }
				},
				series: [S({
					type: "radar",
					data: a.map((e, t) => {
						let n = e.color || H(t, e.label);
						return {
							name: e.label,
							value: e.values,
							lineStyle: {
								color: n,
								width: 2.25,
								join: "round"
							},
							itemStyle: { color: n },
							areaStyle: {
								color: n,
								opacity: .16
							}
						};
					})
				}, J(!1))]
			});
		}
		case "waterfall": {
			let e = a[0]?.values || [], r = [], i = [], o = 0;
			return e.forEach((e, n) => {
				if (e == null) {
					r.push(null), i.push(null);
					return;
				}
				if (t.totals?.includes(n)) {
					let t = e === 0 ? o : e;
					r.push(0), i.push(t), o = t;
					return;
				}
				r.push(e >= 0 ? o : o + e), i.push(Math.abs(e)), o += e;
			}), S(Z, {
				tooltip: {
					trigger: "axis",
					axisPointer: { type: "shadow" },
					formatter: (n) => {
						let r = n.filter((e) => e.seriesName !== "__helper")[0];
						if (!r) return "";
						let a = e[r.dataIndex];
						if (a == null) return K(r.name) + G(t.gapLabel ?? "Sin datos");
						let o = t.totals?.includes(r.dataIndex);
						return K(r.name) + G(o ? F(i[r.dataIndex]) : (a >= 0 ? "+" : "−") + F(Math.abs(a)));
					}
				},
				xAxis: Q,
				yAxis: $,
				series: [{
					name: "__helper",
					type: "bar",
					stack: "wf",
					silent: !0,
					itemStyle: { color: "transparent" },
					emphasis: { itemStyle: { color: "transparent" } },
					data: r,
					animation: !1
				}, S({
					name: a[0]?.label || "Cambio",
					type: "bar",
					stack: "wf",
					barMaxWidth: 38,
					data: i.map((r, i) => ({
						value: r,
						itemStyle: {
							color: t.totals?.includes(i) ? n.neutral : (e[i] ?? 0) >= 0 ? n.positive : n.negative,
							borderRadius: n.cellRadius
						}
					})),
					label: ie
				}, J(!0))]
			});
		}
		case "pareto": {
			let e = a[0]?.values || [], t = e.reduce((e, t) => e + (t ?? 0), 0) || 1, r = 0, i = e.map((e) => e == null ? null : (r += e, +(r / t * 100).toFixed(1)));
			return S(Z, {
				tooltip: {
					trigger: "axis",
					axisPointer: { type: "shadow" },
					formatter: (e) => K(e[0].name) + e.map((e) => q(e.marker, e.seriesName, e.seriesIndex === 1 ? e.value + "%" : F(e.value))).join("")
				},
				legend: l ? {
					show: !0,
					top: 0,
					left: 0,
					textStyle: U
				} : { show: !1 },
				xAxis: Q,
				yAxis: [$, S($, {
					max: 100,
					axisLabel: { formatter: (e) => e + "%" },
					splitLine: { show: !1 }
				})],
				series: [S({
					name: a[0]?.label || "Frecuencia",
					type: "bar",
					barMaxWidth: 34,
					data: O ? e.map((e, t) => ({
						value: e,
						itemStyle: { color: I(O[t] || n.text) }
					})) : e,
					itemStyle: {
						color: n.text,
						borderRadius: X(!1)
					}
				}, J(!0)), S({
					name: "Acumulado",
					type: "line",
					yAxisIndex: 1,
					data: i,
					smooth: !1,
					lineStyle: {
						color: n.accent,
						width: 2.25,
						cap: "round",
						join: "round"
					},
					itemStyle: { color: n.accent },
					symbolSize: 6,
					...j == null ? {} : { markLine: {
						silent: !0,
						symbol: "none",
						animation: !1,
						lineStyle: {
							color: n.muted,
							type: "dashed",
							width: 1
						},
						label: {
							show: !0,
							position: "insideEndTop",
							formatter: Math.round(j * 100) + "%",
							color: n.muted,
							fontFamily: n.fontMono,
							fontSize: n.captionSize
						},
						data: [{ yAxis: Math.round(j * 100) }]
					} }
				}, P ? {
					animationDuration: 900,
					animationDelay: 260
				} : { animation: !1 })]
			});
		}
		case "gauge": {
			let e = a[0]?.values?.[0] || 0, t = _ ?? 100, r = (() => {
				if (A?.length) {
					for (let [t, n] of A) if (e < t) return I(n);
					return I(A[A.length - 1][1]);
				}
				return e / t >= .85 ? n.negative : I(a[0]?.color || k || n.palette[0]);
			})(), i = [{
				type: "gauge",
				startAngle: 200,
				endAngle: -20,
				min: v || 0,
				max: t,
				radius: "96%",
				center: ["50%", "62%"],
				progress: {
					show: !0,
					width: 14,
					roundCap: !0,
					itemStyle: { color: r }
				},
				axisLine: {
					lineStyle: {
						width: 14,
						color: [[1, n.grid]]
					},
					roundCap: !0
				},
				axisTick: { show: !1 },
				splitLine: { show: !1 },
				axisLabel: { show: !1 },
				pointer: { show: !1 },
				anchor: { show: !1 },
				title: { show: !1 },
				detail: {
					valueAnimation: P,
					offsetCenter: [0, "-6%"],
					fontFamily: n.fontMono,
					fontSize: n.kpiSize,
					fontWeight: n.kpiWeight,
					color: n.text,
					formatter: (e) => String(F(e))
				},
				data: [{ value: e }],
				animation: P,
				animationDuration: 900,
				animationEasing: "cubicOut"
			}];
			return g != null && i.push({
				type: "gauge",
				startAngle: 200,
				endAngle: -20,
				min: v || 0,
				max: t,
				radius: "96%",
				center: ["50%", "62%"],
				axisLine: { show: !1 },
				axisTick: { show: !1 },
				splitLine: { show: !1 },
				axisLabel: { show: !1 },
				progress: { show: !1 },
				detail: { show: !1 },
				pointer: {
					show: !0,
					length: "12%",
					width: 3,
					offsetCenter: [0, "-38%"],
					icon: "triangle",
					itemStyle: { color: n.text }
				},
				anchor: { show: !1 },
				title: { show: !1 },
				data: [{ value: g }],
				animation: !1
			}), S(Z, {
				tooltip: { show: !1 },
				series: i
			});
		}
		case "funnel": {
			let e = (a[0] && (a[0].data || a[0].values) || []).map((e, t) => typeof e == "number" ? {
				name: o[t] || String(t),
				value: e
			} : {
				name: e.label || e.name || "",
				value: e.value
			});
			return S(Z, {
				tooltip: {
					trigger: "item",
					formatter: (e) => q(e.marker, e.name, F(e.value))
				},
				series: [S({
					type: "funnel",
					left: "4%",
					right: "4%",
					top: l ? 34 : 10,
					bottom: 6,
					minSize: "24%",
					gap: n.inlineGap,
					sort: "descending",
					data: e.map((t, r) => {
						let i = k || a[0]?.color ? T(I(k || a[0]?.color), e.length) : n.ramp, o = i[Math.max(0, i.length - 1 - r)];
						return {
							...t,
							itemStyle: {
								color: o,
								borderWidth: 0,
								borderRadius: n.cellRadius
							}
						};
					}),
					label: {
						show: !0,
						position: "inside",
						fontFamily: n.fontBody,
						fontSize: n.categorySize,
						fontWeight: n.categoryWeight,
						formatter: (e) => e.name
					},
					emphasis: { label: { fontSize: n.categorySize } }
				}, J(!0))]
			});
		}
		case "treemap": {
			let e = a[0] && a[0].data || [];
			return S(Z, {
				tooltip: { formatter: (e) => q("", e.name, F(e.value)) },
				series: [S({
					type: "treemap",
					roam: !1,
					nodeClick: !1,
					breadcrumb: { show: !1 },
					left: 0,
					right: 0,
					top: l ? n.categorySize + n.stackGap : 0,
					bottom: 0,
					itemStyle: {
						borderColor: n.card,
						borderWidth: 2,
						gapWidth: n.inlineGap,
						borderRadius: n.cellRadius
					},
					label: U,
					data: (() => {
						let t = e.reduce((e, t) => e + t.value, 0) || 1;
						return e.map((e, n) => {
							let r = I(e.color || H(n, e.label || e.name || "")), i = e.value / t, a = String(e.label || e.name || ""), o = i >= .06 && (i >= .14 || a.length <= 9);
							return {
								name: e.label || e.name,
								value: e.value,
								itemStyle: { color: r },
								label: { show: o }
							};
						});
					})()
				}, J(!1))]
			});
		}
		case "boxplot": return S(Z, {
			tooltip: { trigger: "item" },
			xAxis: S(Q, { boundaryGap: !0 }),
			yAxis: $,
			series: [S({
				type: "boxplot",
				data: a[0]?.values || [],
				itemStyle: {
					color: n.card,
					borderColor: n.text,
					borderWidth: 1.5
				},
				emphasis: { itemStyle: {
					borderColor: n.accent,
					borderWidth: 2
				} }
			}, J(!0))]
		});
		default: return Z;
	}
}
function O({ type: t = "line", height: n = 280, loading: r = !1, emptyLabel: i, option: o, onSelect: s, ariaLabel: _, style: y, ...x }) {
	let C = e(), w = i ?? C("common.noData", "Sin datos para este periodo"), T = m(null), O = m(null), k = m(0), A = m({
		w: 0,
		h: 0
	}), j = m(null), [M, N] = h(0), [P, F] = h(0), [ee, I] = h(!1), L = {
		...x,
		valueLabel: x.valueLabel ?? C("chart.value", "Valor"),
		percentLabel: x.percentLabel ?? C("chart.percentOfTotal", "Del total"),
		gapLabel: x.gapLabel ?? C("common.noData", "Sin datos para este periodo")
	}, R = p(() => L.target == null ? L.matrix ? (L.matrix.values || []).length > 0 : (L.series || []).some((e) => (e.data?.length ?? 0) > 0 || e.values?.some((e) => e != null)) : !0, [
		L.series,
		L.matrix,
		L.target
	]);
	if (f(() => {
		if (typeof MutationObserver > "u") return;
		let e = new MutationObserver(() => N((e) => e + 1));
		for (let t = T.current; t; t = t.parentElement) e.observe(t, {
			attributes: !0,
			attributeFilter: ["data-mode", "data-density"]
		});
		return () => e.disconnect();
	}, [R]), f(() => {
		if (!R) {
			O.current?.dispose(), O.current = null;
			return;
		}
		if (!T.current) return;
		let e = g;
		if (!e) {
			let e = !0;
			return v().then(() => {
				e && F((e) => e + 1);
			}).catch(() => {
				e && I(!0);
			}), () => {
				e = !1;
			};
		}
		(!O.current || O.current.isDisposed()) && (O.current = e.init(T.current, void 0, { renderer: "canvas" }), s && O.current.on("click", (e) => s(e)));
		let r = b(T.current), i = E(S(D(t, {
			...L,
			type: t,
			height: n
		}, r), o), r.resolve);
		O.current.setOption(i, !0);
		let a = t === "scatter" && L.plotSurface === "canvas" ? l(O.current, e.graphic.Rect, r.plotBg, r.cellRadius, r.grid) : () => {};
		if (t === "radar") {
			j.current && O.current.getZr().off("mousemove", j.current);
			let e = T.current, t = (L.indicators || L.labels || []).map((e) => typeof e == "string" ? {
				name: e,
				max: L.max || 100
			} : e), n = t.length, i = O.current, a = (L.series || []).length > 1 ? (L.series || [])[1] : null, o = e.querySelector(".flow-radar-tip");
			o || (o = document.createElement("div"), o.className = "flow-radar-tip", o.style.cssText = `position:absolute;pointer-events:none;z-index:var(--z-tooltip);display:none;background:${r.card};border:var(--border-width) solid ${r.grid};border-radius:var(--radius-sm);padding:var(--space-2) var(--space-3);box-shadow:var(--shadow-float);transition:opacity var(--dur-fast) var(--ease-out)`, e.style.position = "relative", e.appendChild(o)), o.style.background = r.card, o.style.borderColor = r.grid;
			let s = (e, t, n) => {
				let r = document.createElement(e);
				return t && (r.style.cssText = t), n != null && (r.textContent = n), r;
			}, c = -1, l = !1;
			i.on("mouseover", (e) => {
				e.componentType === "series" && e.seriesType === "radar" && (l = !0, o && (o.style.display = ""));
			}), i.on("mouseout", (e) => {
				e.componentType === "series" && e.seriesType === "radar" && (l = !1, c = -1, o && (o.style.display = "none"));
			});
			let u = (i) => {
				if (!e || !l || n === 0 || !o) return;
				let u = e.clientWidth / 2, d = e.clientHeight / 2, f = i.offsetX - u, p = -(i.offsetY - d), m = Math.atan2(p, f);
				m < 0 && (m += 2 * Math.PI);
				let h = 0, g = Infinity;
				for (let e = 0; e < n; e++) {
					let t = (Math.PI / 2 + 2 * Math.PI * e / n) % (2 * Math.PI), r = Math.abs(m - t);
					r > Math.PI && (r = 2 * Math.PI - r), r < g && (g = r, h = e);
				}
				if (h !== c) {
					c = h;
					let e = t[h];
					if (!e) return;
					let n = L.series?.[0]?.values?.[h] ?? 0;
					if (a) {
						let t = a.values?.[h] ?? 0, i = n - t, c = i >= 0 ? r.positive : i > -10 ? r.resolve("var(--status-warning)") : r.negative, l = s("div", `font-family:${r.fontBody};font-size:12px;color:${r.text};min-width:120px`), u = s("div", `border-left:3px solid ${c};padding-left:8px`);
						u.appendChild(s("div", "font-weight:700;margin-bottom:4px", e.name));
						let d = s("div", "");
						d.appendChild(s("span", "font:var(--type-viz-value)", String(n))), d.appendChild(document.createTextNode(" ")), d.appendChild(s("span", `color:${r.label}`, `/ ${t}`)), u.appendChild(d), l.appendChild(u), o.textContent = "", o.appendChild(l);
					} else {
						let t = s("div", `font-family:${r.fontBody};font-size:12px;color:${r.text}`);
						t.appendChild(s("div", "font-weight:700;margin-bottom:4px", e.name)), t.appendChild(s("div", "font:var(--type-viz-value)", String(n))), o.textContent = "", o.appendChild(t);
					}
				}
				let _ = o.offsetWidth, v = o.offsetHeight, y = e.clientWidth;
				e.clientHeight;
				let b = i.offsetX + 14, x = i.offsetY - v - 10;
				b + _ > y && (b = i.offsetX - _ - 14), x < 0 && (x = i.offsetY + 14), o.style.left = b + "px", o.style.top = x + "px";
			};
			j.current = u, i.getZr().on("mousemove", u);
		} else j.current &&= (O.current.getZr().off("mousemove", j.current), null);
		let c = !1, u = requestAnimationFrame(() => {
			c = !0;
		}), d = setTimeout(() => {
			if (c) return;
			let e = O.current;
			if (!e || e.isDisposed()) return;
			let i = E(S(D(t, {
				...L,
				type: t,
				height: n,
				animate: !1
			}, r), o), r.resolve);
			i.animation = !1, Array.isArray(i.series) && (i.series = i.series.map((e) => ({
				...e,
				animation: !1,
				animationDuration: 0,
				animationDelay: 0,
				animationDurationUpdate: 0
			}))), e.clear(), e.setOption(i, !0);
		}, 320);
		return () => {
			a(), cancelAnimationFrame(u), clearTimeout(d), t === "radar" && O.current && !O.current.isDisposed() && (O.current.off("mouseover"), O.current.off("mouseout"));
			let e = T.current?.querySelector(".flow-radar-tip");
			e && e.remove();
		};
	}, [
		R,
		t,
		M,
		P,
		o,
		JSON.stringify(L.series || null),
		JSON.stringify(L.labels || null),
		JSON.stringify(L.matrix || null),
		L.highlight,
		L.stack,
		L.legend,
		L.horizontal,
		L.showValues,
		L.palette,
		L.animate,
		L.format,
		L.axisFormat,
		L.gapLabel,
		L.min,
		L.max,
		L.smooth,
		L.area,
		L.color,
		L.target,
		L.thickness,
		L.valueLabel,
		L.percentLabel,
		n,
		JSON.stringify(L.itemColors || null),
		JSON.stringify(L.totals || null),
		JSON.stringify(L.indicators || null),
		JSON.stringify(L.thresholds || null),
		L.threshold,
		L.plotSurface,
		JSON.stringify(L.axisLabels || null)
	]), f(() => {
		if (O.current) {
			if (r) {
				let e = T.current ? b(T.current) : { accent: a("--viz-accent") };
				O.current.showLoading("default", {
					text: "",
					maskColor: "transparent",
					color: e.accent,
					spinnerRadius: 9,
					lineWidth: 2
				});
			} else O.current.hideLoading();
		}
	}, [r, R]), f(() => {
		if (!T.current || typeof ResizeObserver > "u") return;
		let e = new ResizeObserver(() => {
			cancelAnimationFrame(k.current), k.current = requestAnimationFrame(() => {
				let e = T.current;
				if (!e || !O.current || O.current.isDisposed()) return;
				let t = e.clientWidth, n = e.clientHeight;
				(t !== A.current.w || n !== A.current.h) && (A.current = {
					w: t,
					h: n
				}, O.current.resize());
			});
		});
		return e.observe(T.current), () => {
			e.disconnect(), cancelAnimationFrame(k.current);
		};
	}, [R]), f(() => () => {
		cancelAnimationFrame(k.current), O.current && !O.current.isDisposed() && O.current.dispose(), O.current = null;
	}, []), !R) return /* @__PURE__ */ u("div", {
		className: c.empty,
		style: {
			height: n,
			...y
		},
		role: "img",
		"aria-label": w,
		children: /* @__PURE__ */ d("div", {
			className: c.emptyInner,
			children: [/* @__PURE__ */ u("span", {
				className: `flow-symbol ${c.emptyIcon}`,
				"aria-hidden": "true",
				children: "bar_chart"
			}), w]
		})
	});
	if (ee) {
		let e = C("chart.loadError", "La gráfica no pudo cargarse. Recarga la página para intentarlo de nuevo.");
		return /* @__PURE__ */ u("div", {
			className: c.empty,
			style: {
				height: n,
				...y
			},
			role: "img",
			"aria-label": e,
			children: /* @__PURE__ */ d("div", {
				className: c.emptyInner,
				children: [/* @__PURE__ */ u("span", {
					className: `flow-symbol ${c.emptyIcon}`,
					"aria-hidden": "true",
					children: "error"
				}), e]
			})
		});
	}
	return /* @__PURE__ */ u("div", {
		ref: T,
		role: "img",
		"aria-label": _,
		style: {
			width: "100%",
			height: n,
			...y
		}
	});
}
//#endregion
export { O as FlowChart, D as buildOption, b as readTokens };

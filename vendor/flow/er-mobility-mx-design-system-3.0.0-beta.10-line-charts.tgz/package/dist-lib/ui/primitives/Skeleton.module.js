//#region src/ui/primitives/Skeleton.module.css
var e = "-5UNlG_root", t = { root: e };
//#endregion
export { t as default, e as root };

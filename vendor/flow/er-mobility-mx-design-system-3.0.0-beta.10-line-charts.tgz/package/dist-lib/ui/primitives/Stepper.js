import e from "./Stepper.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
import { Fragment as r } from "react";
//#region src/ui/primitives/Stepper.tsx
function i({ steps: i, current: a = 0, orientation: o = "horizontal", style: s }) {
	return /* @__PURE__ */ n("ol", {
		"data-list": "",
		className: e.root,
		"data-orientation": o,
		style: s,
		children: [/* @__PURE__ */ n("span", {
			"data-sr-only": "",
			children: [
				"Paso ",
				a + 1,
				" de ",
				i.length,
				i[a] ? `: ${i[a].label}` : ""
			]
		}), i.map((o, s) => {
			let c = s < a ? "done" : s === a ? "active" : "pending";
			return /* @__PURE__ */ n(r, { children: [/* @__PURE__ */ n("li", {
				className: e.step,
				"data-status": c,
				"aria-current": c === "active" ? "step" : void 0,
				children: [/* @__PURE__ */ t("span", {
					className: e.indicator,
					"data-status": c,
					"aria-hidden": "true",
					children: c === "done" ? /* @__PURE__ */ t("span", {
						className: `flow-symbol ${e.check}`,
						children: "check"
					}) : s + 1
				}), /* @__PURE__ */ n("span", {
					className: e.text,
					children: [/* @__PURE__ */ t("span", {
						className: e.label,
						children: o.label
					}), o.description && /* @__PURE__ */ t("span", {
						className: e.description,
						children: o.description
					})]
				})]
			}), s < i.length - 1 && /* @__PURE__ */ t("span", {
				className: e.connector,
				"data-done": s < a || void 0,
				"aria-hidden": "true"
			})] }, s);
		})]
	});
}
//#endregion
export { i as Stepper };

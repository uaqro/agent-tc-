import e from "./Badge.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/Badge.tsx
function r({ tone: r = "neutral", icon: i, live: a, as: o = "span", children: s, style: c }) {
	return /* @__PURE__ */ n(o, {
		className: e.root,
		"data-tone": r,
		style: c,
		children: [
			a && /* @__PURE__ */ t("span", { className: e.dot }),
			i && /* @__PURE__ */ t("span", {
				className: `flow-symbol ${e.icon}`,
				"aria-hidden": "true",
				children: i
			}),
			s
		]
	});
}
//#endregion
export { r as Badge };

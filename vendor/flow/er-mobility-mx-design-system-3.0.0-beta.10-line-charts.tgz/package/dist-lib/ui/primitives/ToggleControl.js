import e from "./ToggleControl.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
import { forwardRef as r, useId as i } from "react";
//#region src/ui/primitives/ToggleControl.tsx
var a = r(function({ type: r = "checkbox", role: a, value: o, description: s, name: c, required: l, onBlur: u, id: d, checked: f, indeterminate: p, onChange: m, disabled: h, label: g, "aria-labelledby": _, ariaLabel: v, children: y, style: b, "aria-describedby": x, "aria-invalid": S, "aria-required": C }, w) {
	let T = i();
	return /* @__PURE__ */ n("label", {
		className: e.root,
		"data-disabled": h || void 0,
		style: b,
		children: [/* @__PURE__ */ n("span", {
			className: e.visual,
			children: [/* @__PURE__ */ t("input", {
				name: c,
				required: l,
				onBlur: u,
				id: d,
				"aria-describedby": [s ? T : null, x].filter(Boolean).join(" ") || void 0,
				"aria-invalid": S,
				"aria-required": C,
				type: r,
				role: a,
				value: o,
				className: e.input,
				checked: f,
				"aria-labelledby": _,
				"aria-label": v,
				ref: (e) => {
					e && (e.indeterminate = !!p), typeof w == "function" ? w(e) : w && (w.current = e);
				},
				onChange: (e) => m?.(e.target.checked),
				disabled: h
			}), y]
		}), (g || s) && /* @__PURE__ */ n("span", {
			className: e.contenido,
			children: [g && /* @__PURE__ */ t("span", {
				className: e.label,
				children: g
			}), s && /* @__PURE__ */ t("span", {
				className: e.description,
				id: T,
				children: s
			})]
		})]
	});
});
//#endregion
export { a as ToggleControl };

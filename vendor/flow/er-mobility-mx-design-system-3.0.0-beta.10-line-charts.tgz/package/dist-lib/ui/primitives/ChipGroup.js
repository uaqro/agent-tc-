import e from "./ChipGroup.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/ChipGroup.tsx
function n({ children: n, style: r }) {
	return /* @__PURE__ */ t("div", {
		className: e.root,
		style: r,
		children: n
	});
}
//#endregion
export { n as ChipGroup };

import e from "./Button.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/Button.tsx
function r({ variant: r = "primary", size: i = "md", icon: a, iconTrailing: o, loading: s, disabled: c, fullWidth: l, onClick: u, ariaLabel: d, children: f, style: p, type: m = "button", ...h }) {
	return /* @__PURE__ */ n("button", {
		type: m,
		className: e.root,
		"data-variant": r,
		"data-size": i,
		"data-full-width": l || void 0,
		"aria-label": d,
		"aria-busy": s || void 0,
		onClick: u,
		disabled: c || s,
		style: p,
		...h,
		children: [
			s && /* @__PURE__ */ t("span", {
				className: `flow-symbol ${e.spinner}`,
				"aria-hidden": "true",
				children: "progress_activity"
			}),
			!s && a && /* @__PURE__ */ t("span", {
				className: `flow-symbol ${e.icon}`,
				"aria-hidden": "true",
				children: a
			}),
			f,
			o && /* @__PURE__ */ t("span", {
				className: `flow-symbol ${e.icon}`,
				"aria-hidden": "true",
				children: o
			})
		]
	});
}
//#endregion
export { r as Button };

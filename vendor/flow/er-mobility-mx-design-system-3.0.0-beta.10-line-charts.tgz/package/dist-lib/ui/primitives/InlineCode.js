import e from "./InlineCode.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/InlineCode.tsx
function n({ children: n, style: r }) {
	return /* @__PURE__ */ t("code", {
		className: e.root,
		style: r,
		children: n
	});
}
//#endregion
export { n as InlineCode };

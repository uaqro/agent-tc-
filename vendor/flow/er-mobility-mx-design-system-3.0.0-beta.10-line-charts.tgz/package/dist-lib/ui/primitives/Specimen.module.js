//#region src/ui/primitives/Specimen.module.css
var e = "_9uFVJq_root", t = { root: e };
//#endregion
export { t as default, e as root };

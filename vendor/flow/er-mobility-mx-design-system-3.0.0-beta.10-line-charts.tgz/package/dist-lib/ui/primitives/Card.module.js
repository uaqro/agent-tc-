//#region src/ui/primitives/Card.module.css
var e = "UnN0ra_root", t = { root: e };
//#endregion
export { t as default, e as root };

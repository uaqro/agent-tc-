import e from "./Skeleton.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/Skeleton.tsx
function n({ variant: n = "text", width: r, height: i, style: a }) {
	return /* @__PURE__ */ t("div", {
		className: e.root,
		"data-variant": n,
		"aria-hidden": "true",
		style: {
			...r == null ? {} : { width: r },
			...i == null ? {} : { height: i },
			...a
		}
	});
}
//#endregion
export { n as Skeleton };

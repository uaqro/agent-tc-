import e from "./ControlShell.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
import { forwardRef as r } from "react";
//#region src/ui/primitives/ControlShell.tsx
var i = r(function({ size: r = "md", filled: i, disabled: a, invalid: o, error: s, leading: c, trailing: l, footer: u, children: d, style: f, onClick: p, ...m }, h) {
	return /* @__PURE__ */ n("div", {
		ref: h,
		className: e.root,
		"data-control-shell": "",
		"data-footer": u ? "" : void 0,
		"data-size": r,
		"data-filled": i || void 0,
		"data-invalid": (o ?? s) || void 0,
		"data-disabled": a || void 0,
		onClick: p,
		style: f,
		...m,
		children: [
			c && /* @__PURE__ */ t("span", {
				className: e.slot,
				"data-side": "leading",
				children: c
			}),
			/* @__PURE__ */ t("div", {
				className: e.content,
				children: d
			}),
			l && /* @__PURE__ */ t("span", {
				className: e.slot,
				"data-side": "trailing",
				children: l
			}),
			u && /* @__PURE__ */ t("div", {
				className: e.footer,
				children: u
			})
		]
	});
});
//#endregion
export { i as ControlShell };

import { jsx as e, jsxs as t } from "react/jsx-runtime";
//#region src/ui/primitives/Sparkline.tsx
function n({ values: n = [], width: r = 120, height: i = 40, color: a, showDot: o = !0, style: s }) {
	if (!n.length) return null;
	let c = Math.min(...n), l = Math.max(...n), u = l === c, d = (e) => u ? i / 2 : i - (e - c) / (l - c) * (i - 4) - 2, f = n.length === 1 ? [`0,${i / 2}`, `${r},${i / 2}`] : n.map((e, t) => `${t / (n.length - 1) * r},${d(e)}`), p = n[n.length - 1], m = r, h = d(p), g = a || "var(--viz-1)";
	return /* @__PURE__ */ t("svg", {
		width: r,
		height: i,
		viewBox: `0 0 ${r} ${i}`,
		style: {
			display: "block",
			...s
		},
		"aria-hidden": "true",
		children: [/* @__PURE__ */ e("polyline", {
			points: f.join(" "),
			fill: "none",
			stroke: g,
			strokeWidth: 2,
			strokeLinecap: "round",
			strokeLinejoin: "round"
		}), o && /* @__PURE__ */ e("circle", {
			cx: m,
			cy: h,
			r: 3,
			fill: g
		})]
	});
}
//#endregion
export { n as Sparkline };

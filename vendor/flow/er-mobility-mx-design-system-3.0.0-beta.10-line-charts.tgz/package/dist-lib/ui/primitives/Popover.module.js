//#region src/ui/primitives/Popover.module.css
var e = "P4DALG_drop", t = "P4DALG_root", n = "P4DALG_trigger", r = {
	drop: e,
	root: t,
	trigger: n
};
//#endregion
export { r as default, e as drop, t as root, n as trigger };

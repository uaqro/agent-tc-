//#region src/ui/primitives/Switch.module.css
var e = "_1dIdra_thumb", t = "_1dIdra_track", n = {
	thumb: e,
	track: t
};
//#endregion
export { n as default, e as thumb, t as track };

//#region src/ui/primitives/Stepper.module.css
var e = "yEk8tq_check", t = "yEk8tq_connector", n = "yEk8tq_description", r = "yEk8tq_indicator", i = "yEk8tq_label", a = "yEk8tq_root", o = "yEk8tq_step", s = "yEk8tq_text", c = {
	check: e,
	connector: t,
	description: n,
	indicator: r,
	label: i,
	root: a,
	step: o,
	text: s
};
//#endregion
export { e as check, t as connector, c as default, n as description, r as indicator, i as label, a as root, o as step, s as text };

//#region src/ui/primitives/SectionBar.module.css
var e = "c-eA6q_inner", t = "c-eA6q_root", n = "c-eA6q_spacer", r = "c-eA6q_trailing", i = {
	inner: e,
	root: t,
	spacer: n,
	trailing: r
};
//#endregion
export { i as default, e as inner, t as root, n as spacer, r as trailing };

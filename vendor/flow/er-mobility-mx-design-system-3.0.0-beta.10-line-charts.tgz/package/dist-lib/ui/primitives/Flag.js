import { avisaDelCaminoViejo as e, urlDeBandera as t, useFlagsBase as n } from "../../flags/contexto.js";
import r from "./Flag.module.js";
import { jsx as i } from "react/jsx-runtime";
//#region src/ui/primitives/Flag.tsx
var a = {
	circle: "50%",
	rounded: "var(--radius-xs)",
	square: "0"
}, o = "[Flow] Flag sin FlowFlagsProvider: sigue el camino 1.x (la hoja global de flag-icons, que empaqueta 271 banderas para pintar las que uses). Declara <FlowFlagsProvider baseUrl=\"/flags\"> y sirve los códigos de tu producto — `npx flow-banderas --codigos mx,us --destino public/flags`. El entry ./flag y este camino se retiran en 4.0 (RFC 0012).";
function s({ country: s, size: c = 20, shape: l = "circle", label: u, ring: d = !0, style: f }) {
	let p = n(), m = String(s || "").toLowerCase(), h = {
		width: c,
		height: c,
		borderRadius: a[l] || a.circle,
		boxShadow: d ? "inset 0 0 0 1px var(--alpha-black-12)" : "none",
		...f
	};
	return p ? /* @__PURE__ */ i("img", {
		className: r.root,
		src: t(p, m),
		alt: u || "",
		width: c,
		height: c,
		fetchPriority: "high",
		decoding: "sync",
		onError: () => {
			process.env.NODE_ENV !== "production" && console.error(`[Flow] Flag: no se pudo cargar ${t(p, m)} — ¿está servido ese código?`);
		},
		style: h
	}) : (e(o), /* @__PURE__ */ i("span", {
		className: `fi fi-${m} fis ${r.root}`,
		role: u ? "img" : void 0,
		"aria-label": u || void 0,
		"aria-hidden": !u || void 0,
		style: h
	}));
}
//#endregion
export { s as Flag };

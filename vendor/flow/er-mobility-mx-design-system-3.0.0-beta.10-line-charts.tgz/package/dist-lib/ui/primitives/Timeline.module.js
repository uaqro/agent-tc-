//#region src/ui/primitives/Timeline.module.css
var e = "LiCJja_eventBody", t = "LiCJja_eventDescription", n = "LiCJja_eventDot", r = "LiCJja_eventHeader", i = "LiCJja_eventItem", a = "LiCJja_eventStatus", o = "LiCJja_eventTimestamp", s = "LiCJja_eventTitle", c = "LiCJja_root", l = "LiCJja_stepBody", u = "LiCJja_stepConnector", d = "LiCJja_stepDescription", f = "LiCJja_stepDot", p = "LiCJja_stepDotIcon", m = "LiCJja_stepHeader", h = "LiCJja_stepItem", g = "LiCJja_stepRail", _ = "LiCJja_stepTimestamp", v = "LiCJja_stepTitle", y = {
	eventBody: e,
	eventDescription: t,
	eventDot: n,
	eventHeader: r,
	eventItem: i,
	eventStatus: a,
	eventTimestamp: o,
	eventTitle: s,
	root: c,
	stepBody: l,
	stepConnector: u,
	stepDescription: d,
	stepDot: f,
	stepDotIcon: p,
	stepHeader: m,
	stepItem: h,
	stepRail: g,
	stepTimestamp: _,
	stepTitle: v
};
//#endregion
export { y as default, e as eventBody, t as eventDescription, n as eventDot, r as eventHeader, i as eventItem, a as eventStatus, o as eventTimestamp, s as eventTitle, c as root, l as stepBody, u as stepConnector, d as stepDescription, f as stepDot, p as stepDotIcon, m as stepHeader, h as stepItem, g as stepRail, _ as stepTimestamp, v as stepTitle };

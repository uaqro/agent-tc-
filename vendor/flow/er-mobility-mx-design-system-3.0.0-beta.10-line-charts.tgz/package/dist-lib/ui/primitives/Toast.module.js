//#region src/ui/primitives/Toast.module.css
var e = "r4LP2q_action", t = "r4LP2q_dismiss", n = "r4LP2q_icon", r = "r4LP2q_message", i = "r4LP2q_root", a = "r4LP2q_stack", o = {
	action: e,
	dismiss: t,
	icon: n,
	message: r,
	root: i,
	stack: a
};
//#endregion
export { e as action, o as default, t as dismiss, n as icon, r as message, i as root, a as stack };

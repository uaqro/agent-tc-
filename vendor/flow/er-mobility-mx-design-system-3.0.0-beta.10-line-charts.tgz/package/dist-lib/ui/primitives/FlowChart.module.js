//#region src/ui/primitives/FlowChart.module.css
var e = "SxBAxq_empty", t = "SxBAxq_emptyIcon", n = "SxBAxq_emptyInner", r = "SxBAxq_tipHeading", i = "SxBAxq_tipIcon", a = "SxBAxq_tipLabel", o = "SxBAxq_tipMissing", s = "SxBAxq_tipMissingRow", c = "SxBAxq_tipNumber", l = "SxBAxq_tipRow", u = {
	empty: e,
	emptyIcon: t,
	emptyInner: n,
	tipHeading: r,
	tipIcon: i,
	tipLabel: a,
	tipMissing: o,
	tipMissingRow: s,
	tipNumber: c,
	tipRow: l
};
//#endregion
export { u as default, e as empty, t as emptyIcon, n as emptyInner, r as tipHeading, i as tipIcon, a as tipLabel, o as tipMissing, s as tipMissingRow, c as tipNumber, l as tipRow };

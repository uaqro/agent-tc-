//#region src/ui/primitives/Breadcrumb.module.css
var e = "wKyvuq_gap", t = "wKyvuq_homeIcon", n = "wKyvuq_item", r = "wKyvuq_link", i = "wKyvuq_list", a = "wKyvuq_separator", o = "wKyvuq_text", s = {
	gap: e,
	homeIcon: t,
	item: n,
	link: r,
	list: i,
	separator: a,
	text: o
};
//#endregion
export { s as default, e as gap, t as homeIcon, n as item, r as link, i as list, a as separator, o as text };

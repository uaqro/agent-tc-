//#region src/ui/primitives/SectionHeader.module.css
var e = "ux6o8G_copy", t = "ux6o8G_description", n = "ux6o8G_root", r = "ux6o8G_row", i = "ux6o8G_title", a = "ux6o8G_trailing", o = {
	copy: e,
	description: t,
	root: n,
	row: r,
	title: i,
	trailing: a
};
//#endregion
export { e as copy, o as default, t as description, n as root, r as row, i as title, a as trailing };

//#region src/ui/primitives/Input.module.css
var e = "e4pDPW_input", t = { input: e };
//#endregion
export { t as default, e as input };

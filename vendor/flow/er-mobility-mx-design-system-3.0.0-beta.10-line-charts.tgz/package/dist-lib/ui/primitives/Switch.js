import { ToggleControl as e } from "./ToggleControl.js";
import t from "./Switch.module.js";
import { jsx as n } from "react/jsx-runtime";
import { forwardRef as r } from "react";
//#region src/ui/primitives/Switch.tsx
var i = r(function({ name: r, required: i, onBlur: a, id: o, "aria-describedby": s, "aria-invalid": c, "aria-required": l, checked: u, onChange: d, label: f, disabled: p, "aria-labelledby": m, ariaLabel: h, style: g }, _) {
	return /* @__PURE__ */ n(e, {
		ref: _,
		role: "switch",
		name: r,
		required: i,
		onBlur: a,
		id: o,
		"aria-describedby": s,
		"aria-invalid": c,
		"aria-required": l,
		checked: u,
		onChange: d,
		label: f,
		disabled: p,
		"aria-labelledby": m,
		ariaLabel: h,
		style: g,
		children: /* @__PURE__ */ n("span", {
			className: t.track,
			"data-checked": u || void 0,
			"aria-hidden": "true",
			children: /* @__PURE__ */ n("span", { className: t.thumb })
		})
	});
});
//#endregion
export { i as Switch };

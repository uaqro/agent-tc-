"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./Toast.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { createContext as i, useCallback as a, useContext as o, useEffect as s, useMemo as c, useRef as l, useState as u } from "react";
import { createPortal as d } from "react-dom";
//#region src/ui/primitives/Toast.tsx
var f = {
	neutral: {
		icon: "notifications",
		color: "var(--text-secondary)"
	},
	success: {
		icon: "check_circle",
		color: "var(--status-success-text)"
	},
	warning: {
		icon: "warning",
		color: "var(--status-warning-text)"
	},
	danger: {
		icon: "error",
		color: "var(--status-danger-text)"
	},
	info: {
		icon: "info",
		color: "var(--status-info-text)"
	}
};
function p({ message: i, tone: a = "neutral", actionLabel: o, onAction: c, duration: l, onDismiss: d }) {
	let p = e(), m = f[a], [h, g] = u(!1);
	return s(() => {
		if (l == null || !d || h) return;
		let e = setTimeout(d, l);
		return () => clearTimeout(e);
	}, [
		l,
		d,
		h
	]), /* @__PURE__ */ r("div", {
		role: "status",
		className: t.root,
		onMouseEnter: () => g(!0),
		onMouseLeave: () => g(!1),
		onFocus: () => g(!0),
		onBlur: (e) => {
			e.currentTarget.contains(e.relatedTarget) || g(!1);
		},
		children: [
			/* @__PURE__ */ n("span", {
				className: `flow-symbol flow-symbol--fill ${t.icon}`,
				style: { color: m.color },
				"aria-hidden": "true",
				children: m.icon
			}),
			/* @__PURE__ */ n("span", {
				className: t.message,
				children: i
			}),
			o && c && /* @__PURE__ */ n("button", {
				onClick: c,
				"data-bare": "",
				className: t.action,
				children: o
			}),
			d && /* @__PURE__ */ n("button", {
				onClick: d,
				"aria-label": p("common.close", "Cerrar"),
				"data-bare": "",
				className: t.dismiss,
				children: /* @__PURE__ */ n("span", {
					className: "flow-symbol flow-symbol--md",
					"aria-hidden": "true",
					children: "close"
				})
			})
		]
	});
}
function m({ children: e }) {
	return /* @__PURE__ */ n("div", {
		"aria-live": "polite",
		className: t.stack,
		children: e
	});
}
var h = i(null);
function g({ max: e = 3, children: t }) {
	let [i, o] = u([]), s = l(0), f = a((e) => {
		o((t) => t.filter((t) => t.id !== e));
	}, []), g = a((t) => {
		let n = "flow-toast-" + ++s.current;
		return o((r) => [...r, {
			...t,
			id: n
		}].slice(-e)), n;
	}, [e]), _ = c(() => ({
		show: g,
		dismiss: f
	}), [g, f]);
	return /* @__PURE__ */ r(h.Provider, {
		value: _,
		children: [t, typeof document < "u" && d(/* @__PURE__ */ n(m, { children: i.map((e) => /* @__PURE__ */ n(p, {
			message: e.message,
			tone: e.tone,
			actionLabel: e.actionLabel,
			onAction: e.onAction ? () => {
				e.onAction(), f(e.id);
			} : void 0,
			duration: e.duration === null ? void 0 : e.duration ?? 5e3,
			onDismiss: () => f(e.id)
		}, e.id)) }), document.body)]
	});
}
function _() {
	let e = o(h);
	if (!e) throw Error("useToast requiere un <ToastHost> arriba en el árbol.");
	return e;
}
//#endregion
export { p as Toast, g as ToastHost, m as ToastStack, _ as useToast };

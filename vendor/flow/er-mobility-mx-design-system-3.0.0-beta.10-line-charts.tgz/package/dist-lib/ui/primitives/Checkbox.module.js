//#region src/ui/primitives/Checkbox.module.css
var e = "exZqAq_icon", t = "exZqAq_visual", n = {
	icon: e,
	visual: t
};
//#endregion
export { n as default, e as icon, t as visual };

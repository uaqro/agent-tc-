import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./Timeline.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/primitives/Timeline.tsx
var i = {
	done: "check",
	active: "radio_button_checked",
	pending: "radio_button_unchecked",
	error: "close"
}, a = {
	done: "var(--status-success)",
	active: "var(--action-accent)",
	pending: "var(--text-disabled)",
	error: "var(--status-danger)"
};
function o({ items: o, mode: s = "steps", style: c }) {
	let l = e(), u = {
		done: l("timeline.done", "Completado"),
		active: l("timeline.active", "En curso"),
		pending: l("timeline.pending", "Pendiente"),
		error: l("timeline.error", "Error")
	}, d = s === "events";
	return /* @__PURE__ */ n("ol", {
		"data-list": "",
		className: t.root,
		"data-mode": s,
		style: c,
		children: o.map((e, s) => {
			let c = e.status || "pending", l = s === o.length - 1;
			return d ? /* @__PURE__ */ r("li", {
				className: t.eventItem,
				children: [/* @__PURE__ */ n("span", {
					"aria-hidden": "true",
					className: t.eventDot,
					"data-status": c
				}), /* @__PURE__ */ r("div", {
					className: t.eventBody,
					children: [/* @__PURE__ */ r("div", {
						className: t.eventHeader,
						children: [
							/* @__PURE__ */ n("span", {
								className: t.eventTitle,
								children: e.title
							}),
							/* @__PURE__ */ n("span", {
								"data-overline": "",
								className: t.eventStatus,
								style: { color: a[c] },
								children: u[c]
							}),
							e.timestamp && /* @__PURE__ */ n("span", {
								className: t.eventTimestamp,
								children: e.timestamp
							})
						]
					}), e.description && /* @__PURE__ */ n("span", {
						className: t.eventDescription,
						children: e.description
					})]
				})]
			}, s) : /* @__PURE__ */ r("li", {
				className: t.stepItem,
				children: [/* @__PURE__ */ r("div", {
					className: t.stepRail,
					children: [/* @__PURE__ */ n("span", {
						"aria-hidden": "true",
						className: t.stepDot,
						"data-status": c,
						children: /* @__PURE__ */ n("span", {
							className: `flow-symbol ${t.stepDotIcon}`,
							"aria-hidden": "true",
							children: e.icon || i[c]
						})
					}), !l && /* @__PURE__ */ n("span", { className: t.stepConnector })]
				}), /* @__PURE__ */ r("div", {
					className: t.stepBody,
					style: { paddingBottom: l ? 0 : 22 },
					children: [/* @__PURE__ */ r("div", {
						className: t.stepHeader,
						children: [/* @__PURE__ */ n("span", {
							className: t.stepTitle,
							children: e.title
						}), e.timestamp && /* @__PURE__ */ n("span", {
							className: t.stepTimestamp,
							children: e.timestamp
						})]
					}), e.description && /* @__PURE__ */ n("div", {
						className: t.stepDescription,
						children: e.description
					})]
				})]
			}, s);
		})
	});
}
//#endregion
export { o as Timeline };

"use client";
import e from "./Slider.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
import { forwardRef as r, useState as i } from "react";
//#region src/ui/primitives/Slider.tsx
var a = r(function({ name: r, required: a, onBlur: o, id: s, value: c = 0, onChange: l, min: u = 0, max: d = 100, step: f = 1, label: p, format: m, disabled: h, style: g, "aria-labelledby": _, "aria-describedby": v, "aria-invalid": y, "aria-required": b }, x) {
	let [S, C] = i(!1), [w, T] = i(!1), E = Math.min(d, Math.max(u, c)), D = (E - u) / (d - u) * 100, O = m ? m(E) : String(E);
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: g,
		children: [p != null && /* @__PURE__ */ n("div", {
			className: e.header,
			children: [/* @__PURE__ */ t("span", {
				className: e.label,
				children: p
			}), /* @__PURE__ */ t("span", {
				className: e.value,
				"data-drag": S || void 0,
				children: O
			})]
		}), /* @__PURE__ */ n("div", {
			className: e.track,
			"data-disabled": h || void 0,
			children: [
				/* @__PURE__ */ t("div", { className: e.rail }),
				/* @__PURE__ */ t("div", {
					className: e.fill,
					style: { width: `${D}%` }
				}),
				/* @__PURE__ */ t("div", {
					className: e.thumb,
					"data-drag": S || void 0,
					"data-focus": w || void 0,
					"aria-hidden": "true",
					style: { left: `calc(${D}% - 11px)` }
				}),
				/* @__PURE__ */ t("input", {
					ref: x,
					name: r,
					required: a,
					id: s,
					"aria-labelledby": _,
					"aria-describedby": v,
					"aria-invalid": y,
					"aria-required": b,
					type: "range",
					className: e.input,
					min: u,
					max: d,
					step: f,
					value: E,
					disabled: h,
					"aria-label": typeof p == "string" ? p : void 0,
					"aria-valuetext": m ? O : void 0,
					onChange: (e) => l?.(Number(e.target.value)),
					onMouseDown: () => C(!0),
					onMouseUp: () => C(!1),
					onTouchStart: () => C(!0),
					onTouchEnd: () => C(!1),
					onFocus: () => T(!0),
					onBlur: (e) => {
						T(!1), C(!1), o?.(e);
					}
				})
			]
		})]
	});
});
//#endregion
export { a as Slider };

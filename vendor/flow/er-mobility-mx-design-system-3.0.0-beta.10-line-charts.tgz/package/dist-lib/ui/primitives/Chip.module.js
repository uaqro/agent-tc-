//#region src/ui/primitives/Chip.module.css
var e = "_72nsNa_action", t = "_72nsNa_compound", n = "_72nsNa_icon", r = "_72nsNa_remove", i = "_72nsNa_root", a = {
	action: e,
	compound: t,
	icon: n,
	remove: r,
	root: i
};
//#endregion
export { e as action, t as compound, a as default, n as icon, r as remove, i as root };

import e from "./SheetHeader.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/SheetHeader.tsx
function r({ title: r, trailing: i, id: a, size: o = "md", style: s }) {
	return /* @__PURE__ */ n("div", {
		className: e.root,
		"data-size": o,
		style: s,
		children: [/* @__PURE__ */ t("div", {
			id: a,
			className: e.title,
			children: r
		}), i]
	});
}
//#endregion
export { r as SheetHeader };

//#region src/ui/primitives/TextAction.module.css
var e = "_469NXG_root", t = { root: e };
//#endregion
export { t as default, e as root };

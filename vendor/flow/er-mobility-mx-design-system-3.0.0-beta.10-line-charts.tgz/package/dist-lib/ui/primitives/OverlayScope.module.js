//#region src/ui/primitives/OverlayScope.module.css
var e = "gVKWXa_root", t = { root: e };
//#endregion
export { t as default, e as root };

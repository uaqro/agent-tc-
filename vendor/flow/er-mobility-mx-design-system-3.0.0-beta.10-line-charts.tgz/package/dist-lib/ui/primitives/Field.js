import { tieneNombrePropio as e } from "../../hooks/useNombrePorReferencia.js";
import t from "./Field.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { Children as i, cloneElement as a, isValidElement as o, useId as s } from "react";
//#region src/ui/primitives/Field.tsx
function c({ label: c, htmlFor: l, required: u, help: d, error: f, valid: p, validMessage: m, children: h, style: g }) {
	let _ = s(), v = `${l ?? _}-msg`, y = `${l ?? _}-label`, b = f ?? (p && m ? m : d), x = f ? "error" : p ? "valid" : void 0, S = b ? v : void 0, C = i.map(h, (t) => {
		if (!o(t)) return t;
		let n = t.props, r = n["aria-describedby"];
		return a(t, {
			"aria-describedby": [r, S].filter(Boolean).join(" ") || void 0,
			"aria-invalid": f ? !0 : void 0,
			"aria-required": u ? !0 : void 0,
			...e(n) ? {} : { "aria-labelledby": y }
		});
	});
	return /* @__PURE__ */ r("div", {
		className: t.root,
		"data-error": f ? "" : void 0,
		"data-valid": p || void 0,
		style: g,
		children: [
			/* @__PURE__ */ r("label", {
				id: y,
				className: t.label,
				htmlFor: l,
				children: [c, u && /* @__PURE__ */ r("span", {
					className: t.required,
					"aria-hidden": "true",
					children: [" ", "*"]
				})]
			}),
			/* @__PURE__ */ n("div", {
				className: t.control,
				children: C
			}),
			/* @__PURE__ */ r("div", {
				className: t.message,
				id: v,
				role: f ? "alert" : void 0,
				"data-state": x,
				children: [
					x === "valid" && /* @__PURE__ */ n("span", {
						className: `flow-symbol ${t.validIcon}`,
						"aria-hidden": "true",
						children: "check_circle"
					}),
					x === "error" && /* @__PURE__ */ n("span", {
						className: `flow-symbol ${t.errorIcon}`,
						"aria-hidden": "true",
						children: "error"
					}),
					b
				]
			})
		]
	});
}
//#endregion
export { c as Field };

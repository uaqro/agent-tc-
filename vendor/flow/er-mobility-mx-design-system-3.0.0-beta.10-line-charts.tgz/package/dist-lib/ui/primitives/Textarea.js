"use client";
import { ControlShell as e } from "./ControlShell.js";
import t from "./Textarea.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { forwardRef as i, useState as a } from "react";
//#region src/ui/primitives/Textarea.tsx
var o = i(function({ name: i, required: o, onBlur: s, id: c, value: l, onChange: u, placeholder: d, rows: f = 3, maxLength: p, disabled: m, invalid: h, style: g, "aria-labelledby": _, "aria-describedby": v, "aria-invalid": y, "aria-required": b }, x) {
	let [S, C] = a(l?.length ?? 0), w = l == null ? S : l.length, T = p == null ? w : Math.min(w, p), E = (e) => {
		let t = p == null ? e : e.slice(0, p);
		C(t.length), u?.(t);
	};
	return /* @__PURE__ */ n(e, {
		disabled: m,
		invalid: h,
		style: g,
		footer: p == null ? void 0 : /* @__PURE__ */ r("span", {
			className: t.counter,
			children: [
				T,
				"/",
				p
			]
		}),
		children: /* @__PURE__ */ n("textarea", {
			ref: x,
			name: i,
			required: o,
			onBlur: s,
			"aria-labelledby": _,
			"aria-describedby": v,
			"aria-required": b,
			id: c,
			"data-field": "",
			className: t.textarea,
			value: l,
			onChange: (e) => E(e.target.value),
			placeholder: d,
			rows: f,
			maxLength: p,
			disabled: m,
			"aria-invalid": h || y || void 0
		})
	});
});
//#endregion
export { o as Textarea };

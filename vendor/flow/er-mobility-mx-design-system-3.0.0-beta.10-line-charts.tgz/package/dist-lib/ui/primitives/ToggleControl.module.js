//#region src/ui/primitives/ToggleControl.module.css
var e = "AxPcdq_contenido", t = "AxPcdq_description", n = "AxPcdq_input", r = "AxPcdq_label", i = "AxPcdq_root", a = "AxPcdq_visual", o = {
	contenido: e,
	description: t,
	input: n,
	label: r,
	root: i,
	visual: a
};
//#endregion
export { e as contenido, o as default, t as description, n as input, r as label, i as root, a as visual };

//#region src/ui/primitives/OverlayShell.module.css
var e = "_5a8vVG_backdrop", t = "_5a8vVG_panel", n = "_5a8vVG_root", r = {
	backdrop: e,
	panel: t,
	root: n
};
//#endregion
export { e as backdrop, r as default, t as panel, n as root };

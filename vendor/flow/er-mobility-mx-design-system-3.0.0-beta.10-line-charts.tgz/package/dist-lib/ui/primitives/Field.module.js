//#region src/ui/primitives/Field.module.css
var e = "mQuarq_control", t = "mQuarq_errorIcon", n = "mQuarq_label", r = "mQuarq_message", i = "mQuarq_required", a = "mQuarq_root", o = "mQuarq_validIcon", s = {
	control: e,
	errorIcon: t,
	label: n,
	message: r,
	required: i,
	root: a,
	validIcon: o
};
//#endregion
export { e as control, s as default, t as errorIcon, n as label, r as message, i as required, a as root, o as validIcon };

//#region src/ui/primitives/Avatar.module.css
var e = "_2kWZ9a_img", t = "_2kWZ9a_initials", n = "_2kWZ9a_root", r = "_2kWZ9a_status", i = {
	img: e,
	initials: t,
	root: n,
	status: r
};
//#endregion
export { i as default, e as img, t as initials, n as root, r as status };

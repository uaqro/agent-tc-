//#region src/ui/primitives/Divider.module.css
var e = "Dnw6uW_horizontal", t = "Dnw6uW_labeled", n = "Dnw6uW_line", r = "Dnw6uW_text", i = "Dnw6uW_vertical", a = {
	horizontal: e,
	labeled: t,
	line: n,
	text: r,
	vertical: i
};
//#endregion
export { a as default, e as horizontal, t as labeled, n as line, r as text, i as vertical };

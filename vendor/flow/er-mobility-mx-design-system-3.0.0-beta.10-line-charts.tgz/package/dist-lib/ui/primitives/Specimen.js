import e from "./Specimen.module.js";
import { jsx as t } from "react/jsx-runtime";
//#region src/ui/primitives/Specimen.tsx
function n({ grid: n, centered: r = !0, children: i, style: a }) {
	return /* @__PURE__ */ t("div", {
		className: e.root,
		"data-grid": n || void 0,
		"data-centered": r || void 0,
		style: a,
		children: i
	});
}
//#endregion
export { n as Specimen };

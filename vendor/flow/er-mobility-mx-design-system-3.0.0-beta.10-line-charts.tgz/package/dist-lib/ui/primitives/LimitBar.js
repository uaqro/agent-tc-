import { useLocale as e } from "../../i18n/useSafeIntl.js";
import t from "./LimitBar.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/primitives/LimitBar.tsx
function i({ label: i, current: a, max: o, kind: s = "cap", stacked: c, bare: l, format: u, style: d }) {
	let f = e(), p = o > 0 ? a / o * 100 : 0, m = u ?? ((e) => `$${e.toLocaleString(f)}`), h = p >= 100 ? s === "goal" ? "met" : "over" : void 0;
	return /* @__PURE__ */ r("div", {
		className: t.root,
		"data-stacked": c || void 0,
		style: d,
		children: [!l && /* @__PURE__ */ r("div", {
			className: t.header,
			children: [/* @__PURE__ */ n("span", {
				className: t.label,
				children: i
			}), /* @__PURE__ */ r("span", {
				className: t.values,
				"data-state": h,
				children: [
					m(a),
					" / ",
					m(o)
				]
			})]
		}), /* @__PURE__ */ n("div", {
			className: t.track,
			children: /* @__PURE__ */ n("div", {
				className: t.fill,
				"data-state": h,
				style: { width: `${Math.min(100, p)}%` }
			})
		})]
	});
}
//#endregion
export { i as LimitBar };

//#region src/ui/primitives/NavCard.module.css
var e = "npyeRa_card", t = "npyeRa_inner", n = "npyeRa_link", r = "npyeRa_name", i = {
	card: e,
	inner: t,
	link: n,
	name: r
};
//#endregion
export { e as card, i as default, t as inner, n as link, r as name };

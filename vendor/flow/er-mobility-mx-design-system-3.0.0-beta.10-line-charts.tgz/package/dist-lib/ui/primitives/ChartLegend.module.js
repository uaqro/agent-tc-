//#region src/ui/primitives/ChartLegend.module.css
var e = "dmyGla_detail", t = "dmyGla_icon", n = "dmyGla_item", r = "dmyGla_label", i = "dmyGla_labelGroup", a = "dmyGla_root", o = "dmyGla_swatch", s = "dmyGla_value", c = {
	detail: e,
	icon: t,
	item: n,
	label: r,
	labelGroup: i,
	root: a,
	swatch: o,
	value: s
};
//#endregion
export { c as default, e as detail, t as icon, n as item, r as label, i as labelGroup, a as root, o as swatch, s as value };

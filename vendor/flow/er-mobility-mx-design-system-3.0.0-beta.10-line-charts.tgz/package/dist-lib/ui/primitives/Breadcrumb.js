import { useT as e } from "../../i18n/useSafeIntl.js";
import t from "./Breadcrumb.module.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/ui/primitives/Breadcrumb.tsx
var i = 4;
function a({ items: a = [], variant: o = "default", homeIcon: s = "home" }) {
	let c = e(), l = o === "subtle", u = a.length > i ? [
		a[0],
		"…",
		...a.slice(a.length - 2)
	] : a;
	return /* @__PURE__ */ n("nav", {
		"aria-label": c("nav.breadcrumb", "Breadcrumb"),
		"data-variant": o,
		children: /* @__PURE__ */ n("ol", {
			"data-list": "",
			className: t.list,
			"data-variant": o,
			children: u.map((e, i) => {
				if (e === "…") return /* @__PURE__ */ r("li", {
					className: t.item,
					children: [l ? /* @__PURE__ */ n("span", {
						className: t.separator,
						"aria-hidden": "true",
						children: "/"
					}) : /* @__PURE__ */ n("span", {
						className: `flow-symbol ${t.separator}`,
						"aria-hidden": "true",
						children: "chevron_right"
					}), /* @__PURE__ */ n("span", {
						className: t.gap,
						"aria-hidden": "true",
						children: "…"
					})]
				}, "gap");
				let a = i === 0, o = i === u.length - 1, c = e.icon || l && a, d = c ? /* @__PURE__ */ n("span", {
					className: `flow-symbol ${t.homeIcon}`,
					"aria-hidden": "true",
					children: e.icon || s
				}) : e.label;
				return /* @__PURE__ */ r("li", {
					className: t.item,
					children: [i > 0 && (l ? /* @__PURE__ */ n("span", {
						className: t.separator,
						"aria-hidden": "true",
						children: "/"
					}) : /* @__PURE__ */ n("span", {
						className: `flow-symbol ${t.separator}`,
						"aria-hidden": "true",
						children: "chevron_right"
					})), e.href && !o ? /* @__PURE__ */ n("a", {
						"data-link": "",
						href: e.href,
						className: t.link,
						"aria-label": c ? e.label : void 0,
						children: d
					}) : /* @__PURE__ */ n("span", {
						className: t.text,
						"data-current": o || void 0,
						"aria-current": o ? "page" : void 0,
						"aria-label": c ? e.label : void 0,
						children: d
					})]
				}, i);
			})
		})
	});
}
//#endregion
export { a as Breadcrumb };

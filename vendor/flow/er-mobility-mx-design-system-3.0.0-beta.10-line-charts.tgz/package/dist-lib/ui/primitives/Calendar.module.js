//#region src/ui/primitives/Calendar.module.css
var e = "xTmQ-W_day", t = "xTmQ-W_dayHeader", n = "xTmQ-W_footer", r = "xTmQ-W_footerBtn", i = "xTmQ-W_grid", a = "xTmQ-W_header", o = "xTmQ-W_hint", s = "xTmQ-W_monthLabel", c = "xTmQ-W_nav", l = "xTmQ-W_navBtn", u = "xTmQ-W_root", d = {
	day: e,
	dayHeader: t,
	footer: n,
	footerBtn: r,
	grid: i,
	header: a,
	hint: o,
	monthLabel: s,
	nav: c,
	navBtn: l,
	root: u
};
//#endregion
export { e as day, t as dayHeader, d as default, n as footer, r as footerBtn, i as grid, a as header, o as hint, s as monthLabel, c as nav, l as navBtn, u as root };

import e from "./DetailRow.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/DetailRow.tsx
function r({ label: r, value: i, mono: a, as: o = "div", style: s }) {
	let c = o === "definition", l = c ? "dt" : "span", u = c ? "dd" : "span";
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: s,
		children: [/* @__PURE__ */ t(l, {
			className: e.label,
			children: r
		}), /* @__PURE__ */ t(u, {
			className: e.value,
			"data-mono": a || void 0,
			children: i
		})]
	});
}
//#endregion
export { r as DetailRow };

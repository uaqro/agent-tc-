"use client";
import { createContext as e } from "react";
//#region src/overlay/ambito.ts
var t = e(null);
//#endregion
export { t as OverlayTarget };

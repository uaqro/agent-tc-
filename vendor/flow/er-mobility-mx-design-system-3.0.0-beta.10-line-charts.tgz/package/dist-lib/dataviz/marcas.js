//#region src/dataviz/marcas.ts
var e = [
	{ tipo: "liso" },
	{
		tipo: "lineas",
		angulo: 45,
		paso: 6,
		grosor: 2
	},
	{
		tipo: "puntos",
		paso: 6,
		radio: 1.6
	},
	{
		tipo: "lineas",
		angulo: 135,
		paso: 6,
		grosor: 2
	},
	{
		tipo: "lineas",
		angulo: 0,
		paso: 5,
		grosor: 2
	},
	{
		tipo: "rejilla",
		paso: 7,
		grosor: 1.5
	},
	{
		tipo: "lineas",
		angulo: 90,
		paso: 5,
		grosor: 2
	},
	{
		tipo: "puntos",
		paso: 4,
		radio: 1
	}
], t = [
	"solid",
	[9, 5],
	[2, 4],
	[
		14,
		5,
		2,
		5
	],
	[
		6,
		3,
		1,
		3
	],
	[1, 5],
	[18, 6],
	[
		4,
		3,
		10,
		3
	]
], n = [
	"circle",
	"rect",
	"triangle",
	"diamond",
	"roundRect",
	"pin",
	"arrow",
	"emptyCircle"
], r = (e, n) => n > 1 ? t[e % t.length] : "solid", i = (e, t) => t > 1 ? n[e % n.length] : "circle", a = (t, n) => n > 1 ? e[t % e.length] : { tipo: "liso" };
function o(e, t) {
	switch (e.tipo) {
		case "liso": return { color: "transparent" };
		case "lineas": return {
			color: t,
			dashArrayX: [1, 0],
			dashArrayY: [e.grosor, e.paso - e.grosor],
			rotation: e.angulo * Math.PI / 180
		};
		case "puntos": return {
			color: t,
			symbol: "circle",
			symbolSize: e.radio * 2 / e.paso,
			dashArrayX: [[e.paso, e.paso], [
				0,
				e.paso,
				e.paso,
				0
			]],
			dashArrayY: [e.paso, 0]
		};
		case "rejilla": return {
			color: t,
			dashArrayX: [[e.paso - e.grosor, e.grosor], [0, e.paso]],
			dashArrayY: [e.grosor, e.paso - e.grosor]
		};
	}
}
function s(e, t) {
	switch (e.tipo) {
		case "liso": return {};
		case "lineas": return { backgroundImage: `repeating-linear-gradient(${e.angulo}deg, ${t} 0 ${e.grosor}px, transparent ${e.grosor}px ${e.paso}px)` };
		case "puntos": return {
			backgroundImage: `radial-gradient(circle at 50% 50%, ${t} 0 ${e.radio}px, transparent ${e.radio}px)`,
			backgroundSize: `${e.paso}px ${e.paso}px`
		};
		case "rejilla": return { backgroundImage: `repeating-linear-gradient(0deg, ${t} 0 ${e.grosor}px, transparent ${e.grosor}px ${e.paso}px), repeating-linear-gradient(90deg, ${t} 0 ${e.grosor}px, transparent ${e.grosor}px ${e.paso}px)` };
	}
}
function c(e, t) {
	if (e === "solid") return {};
	let [n, r] = [e[0], e[1]], i = .55, a = +(n * i).toFixed(1);
	return { backgroundImage: `repeating-linear-gradient(90deg, ${t} 0 ${a}px, transparent ${a}px ${+((n + r) * i).toFixed(1)}px)` };
}
//#endregion
export { n as SIMBOLOS, e as TRAMAS, t as TRAZOS, s as capasDeTrama, c as capasDeTrazo, o as decalDeTrama, i as simboloDeSerie, a as tramaDeSerie, r as trazoDeSerie };

//#region src/dataviz/roundedPlot.ts
function e(e, t, n, r, i) {
	let a = e.getZr?.();
	if (!e.getModel || !a?.storage) return () => {};
	let o, s = "", c = /* @__PURE__ */ new WeakSet(), l = () => {
		let l = e.getModel().getComponent("grid")?.coordinateSystem?.getRect();
		if (!l) return;
		let u = {
			x: l.x,
			y: l.y,
			width: l.width,
			height: l.height,
			r: Math.min(r, l.width / 2, l.height / 2)
		}, d = JSON.stringify(u);
		d !== s && (s = d, c = /* @__PURE__ */ new WeakSet(), o ? o.attr({
			shape: u,
			style: {
				fill: n,
				stroke: i,
				lineWidth: 1,
				lineDash: "dashed"
			}
		}) : (o = new t({
			shape: u,
			style: {
				fill: n,
				stroke: i,
				lineWidth: 1,
				lineDash: "dashed"
			},
			silent: !0,
			z: -1
		}), a.add(o)));
		for (let e of a.storage.getDisplayList()) {
			if (e === o || c.has(e) || !e.setClipPath || ![
				"line",
				"polyline",
				"compound"
			].includes(e.type)) continue;
			let n = e.getBoundingRect().clone();
			e.transform && n.applyTransform(e.transform);
			let r = Number(e.style?.lineWidth || 0);
			if (n.x < l.x - r || n.y < l.y - r || n.x + n.width > l.x + l.width + r || n.y + n.height > l.y + l.height + r) continue;
			c.add(e);
			let i = new t({ shape: u });
			e.invTransform && i.setLocalTransform(e.invTransform), e.setClipPath(i);
		}
	};
	return e.on("finished", l), l(), () => {
		e.off("finished", l), o && a.remove(o);
	};
}
//#endregion
export { e as roundedPlot };

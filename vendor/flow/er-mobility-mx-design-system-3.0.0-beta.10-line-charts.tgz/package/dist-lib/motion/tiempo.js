//#region src/motion/tiempo.ts
var e = (e) => Math.min(1, Math.max(0, e)), t = (t) => {
	let n = e(t);
	return n * n * (3 - 2 * n);
};
//#endregion
export { e as recorte, t as suave };

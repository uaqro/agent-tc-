"use client";
import { useEffect as e } from "react";
//#region src/motion/useEscena.ts
function t(t, { pinta: n, tFinal: r, pausada: i = !1 }) {
	e(() => {
		let e = t.current;
		if (!e) return;
		let a = typeof window < "u" ? window.matchMedia?.("(prefers-reduced-motion: reduce)") : null, o = i || !!a?.matches, s = 0, c = 0, l = 0, u = !0, d = (e) => {
			if (s = 0, document.hidden || !u || o) {
				n(r);
				return;
			}
			c && (l += Math.min((e - c) / 1e3, .05)), c = e, n(l), s = requestAnimationFrame(d);
		}, f = () => {
			if (c = 0, o || document.hidden || !u) {
				n(r);
				return;
			}
			s ||= requestAnimationFrame(d);
		}, p = () => {
			cancelAnimationFrame(s), s = 0, c = 0, n(r);
		}, m = typeof IntersectionObserver > "u" ? null : new IntersectionObserver((e) => {
			u = e.some((e) => e.isIntersecting), p(), f();
		});
		m?.observe(e);
		let h = () => {
			p(), f();
		};
		document.addEventListener("visibilitychange", h);
		let g = () => {
			o = i || !!a?.matches, p(), o || (l = 0, f());
		};
		return a?.addEventListener?.("change", g), f(), () => {
			cancelAnimationFrame(s), s = 0, m?.disconnect(), document.removeEventListener("visibilitychange", h), a?.removeEventListener?.("change", g);
		};
	}, [
		t,
		n,
		r,
		i
	]);
}
//#endregion
export { t as useEscena };

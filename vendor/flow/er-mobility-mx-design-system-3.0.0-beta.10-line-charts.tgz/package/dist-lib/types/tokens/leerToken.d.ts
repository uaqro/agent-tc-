/** El modo es un atributo, no una hoja: se sabe aunque el CSS no haya cargado. */
export declare function modoOscuro(): boolean;
/** El valor del diccionario para este token en el modo vigente. */
export declare function fallbackDe(nombre: string): string;
/**
 * Lee un token del DOM. `cs` es un `getComputedStyle` ya tomado —leerlo por
 * elemento es lo que permite que una pieza dentro de un subárbol con su propio
 * modo o densidad lea SU valor y no el de la raíz.
 */
export declare function leerToken(nombre: string, cs?: CSSStyleDeclaration): string;
/** El canvas lee la misma clase de iconografía que usan los primitives DOM. */
export declare function leerFuenteSimbolos(el: HTMLElement): string;

export declare const FALLBACKS: Record<string, readonly [claro: string, oscuro: string]>;

/** El patrón de relleno, en el único vocabulario que entienden los dos lados. */
export type Trama = {
    tipo: 'liso';
} | {
    tipo: 'lineas';
    angulo: 0 | 45 | 90 | 135;
    paso: number;
    grosor: number;
} | {
    tipo: 'puntos';
    paso: number;
    radio: number;
} | {
    tipo: 'rejilla';
    paso: number;
    grosor: number;
};
export declare const TRAMAS: Trama[];
/** El trazo de una línea: sólido primero, y siete patrones de guion que no se repiten. */
export declare const TRAZOS: Array<'solid' | number[]>;
/** Las formas de un punto en una dispersión. */
export declare const SIMBOLOS: string[];
export declare const trazoDeSerie: (i: number, total: number) => "solid" | number[];
export declare const simboloDeSerie: (i: number, total: number) => string;
export declare const tramaDeSerie: (i: number, total: number) => Trama;
/**
 * La trama como `decal` de ECharts.
 *
 * `liso` devuelve un decal con la tinta TRANSPARENTE y no la cadena `'none'`:
 * `'none'` vale como `itemStyle.decal` de una serie, pero dentro de
 * `aria.decal.decals[]` ECharts le escribe encima una propiedad interna y
 * revienta —«Cannot create property 'dirty' on string 'none'»—, lo que tira el
 * gráfico entero al límite de error. Y no lo vio ningún test: la suite dobla
 * ECharts, así que la opción era «correcta» y la librería la rechazaba. Lo vio
 * el navegador. Dentro de `decals[]` todo tiene que ser un objeto.
 */
export declare function decalDeTrama(t: Trama, color: string): unknown;
/**
 * La misma trama, como CAPAS CSS: la imagen del patrón y su tamaño. El color de
 * la serie lo pone quien la pinta, en `backgroundColor`.
 *
 * Se devuelve por partes y no como un `background` de una línea porque el
 * atajo mezcla imagen, posición, tamaño y color en una sola cadena, y entonces
 * el navegador —y jsdom— reinterpretan lo que escribiste: medido, el color de
 * la última capa volvía como `transparent`. Una pieza no puede verificar lo que
 * el atajo decide reescribir.
 */
export declare function capasDeTrama(t: Trama, tinta: string): {
    backgroundImage?: string;
    backgroundSize?: string;
};
/**
 * El trazo, como capa CSS de un swatch con forma de línea: el guion se dibuja
 * con el color de la serie sobre nada, así que aquí el color sí entra —es la
 * tinta del trazo, no una capa de fondo—.
 */
export declare function capasDeTrazo(trazo: 'solid' | number[], color: string): {
    backgroundImage?: string;
};

/** Adapta la superficie del plot al rectángulo resuelto por ECharts.
 * Los textos de los ejes quedan fuera del recorte; las líneas de rejilla se recortan. */
export declare function roundedPlot(chart: any, Rect: any, color: string, radius: number, borderColor?: string): () => void;

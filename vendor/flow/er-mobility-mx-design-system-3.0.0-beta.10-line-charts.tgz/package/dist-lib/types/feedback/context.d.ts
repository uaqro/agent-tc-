import { type ReactNode } from 'react';
import type { FeedbackAdapter, Momento } from './types';
export interface FlowFeedbackProviderProps {
    /** Sin adapter no pasa nada, y eso es el estado por defecto: un sistema de
        diseño no decide que el teléfono de alguien vibre.
        Un producto con los dos canales pasa UN objeto con los dos métodos; los
        dos adapters del paquete cubren un canal cada uno, así que
        `{ ...vibracionAdapter(), ...sonidoAdapter() }` es la composición entera.
        No hay combinador y es a propósito: sería API para un problema que nadie
        tiene todavía. */
    adapter?: FeedbackAdapter;
    children: ReactNode;
}
export declare function FlowFeedbackProvider({ adapter, children }: FlowFeedbackProviderProps): import("react").JSX.Element;
/**
 * Nombra lo que acaba de pasar. Lo que se sienta o se oiga lo decide el
 * producto por su adapter; sin adapter, `feedback()` no hace nada.
 *
 * Avisa en consola si el momento no está en el diccionario o no está aprobado,
 * igual que `useTrack` — un vocabulario que nadie comprueba se llena de
 * sinónimos.
 */
export declare function useFeedback(): (momento: Momento, donde?: Element | null) => void;
/** El vocabulario, para quien escriba un adapter y quiera saber qué puede llegar. */
export declare function useMomentos(): Record<string, import("./types").MomentoDefinition>;

import type { FeedbackAdapter } from './types';
/**
 * Qué dibuja un momento. El MOTOR es del sistema —de dónde sale, hacia dónde
 * va, con qué gravedad, cuánto vive— y el ARTE es del producto (fbk-13): el
 * hielo de una tarjeta congelada y el confeti de una alta son decisiones de ese
 * producto, no del sistema de diseño.
 */
export interface Emision {
    /** De dónde salen y cómo se mueven. Cuatro, porque son cuatro gestos
        distintos y no una escala: `estalla` desde un punto, `llueve` cayendo del
        borde de abajo, `fluye` de un sitio HACIA otro, y `chispea` repartido por
        toda el área. */
    patron: 'estalla' | 'llueve' | 'fluye' | 'chispea';
    /** Nombres de token, no valores: `var()` no llega a un lienzo, así que el
        adapter los LEE del DOM (fbk-12). Se reparten entre las partículas. */
    tokens: string[];
    forma?: 'punto' | 'diamante' | 'barra' | 'gota';
    /** Cuántas. El motor la acota: una emisión no puede hundir un teléfono. */
    cantidad?: number;
    /** Solo para `fluye`: hacia qué elemento van. Sin él, `fluye` es `estalla`. */
    hacia?: Element | null;
}
/** Solo para los testigos: sin esto, un doble nuevo hereda el lienzo del anterior. */
export declare function olvidaElLienzo(): void;
/**
 * Adapter de efectos sobre un lienzo 2D. El tercer canal del vocabulario
 * (fbk-11): los mismos momentos, otra forma de acompañar.
 *
 *  · **Calla con `prefers-reduced-motion`**, al revés que el sonido y por el
 *    mismo criterio: una partícula ES movimiento, así que ahí la consulta de
 *    medios dice exactamente lo que hay que saber.
 *  · **Un lienzo y un bucle por documento**, y el bucle para solo cuando no
 *    queda ninguna partícula (fbk-12).
 *  · **El arte lo pone quien lo llama** (fbk-13): `efectos` mapea momento a
 *    emisión, y los colores van por NOMBRE DE TOKEN porque `var()` no llega a
 *    un lienzo.
 *
 * Sin `donde` no dibuja nada, y eso no es un fallo: una partícula sin sitio no
 * tiene dónde salir. El sitio lo pasa quien nombra el momento.
 */
export declare function fxAdapter(opciones: {
    efectos: Record<string, Emision>;
    apagado?: () => boolean;
}): FeedbackAdapter;

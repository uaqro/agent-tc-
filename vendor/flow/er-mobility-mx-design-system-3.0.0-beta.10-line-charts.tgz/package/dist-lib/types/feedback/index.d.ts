export { FlowFeedbackProvider, useFeedback, useMomentos, type FlowFeedbackProviderProps } from './context';
export { vibracionAdapter } from './vibracion-adapter';
export { sonidoAdapter } from './sonido-adapter';
export { fxAdapter, type Emision } from './fx-adapter';
export type { FeedbackAdapter, Momento, MomentoDictionary, MomentoDefinition, MomentoStatus } from './types';

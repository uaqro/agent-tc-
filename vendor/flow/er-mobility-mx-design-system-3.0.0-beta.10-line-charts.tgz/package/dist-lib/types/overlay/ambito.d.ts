/**
 * El destino de las capas de una superficie embebida.
 *
 * Vive FUERA de `ui/` por el mismo motivo que `tokens/leerToken.ts` y que
 * `dataviz/marcas.ts`: lo comparten dos piezas de la MISMA capa —`OverlayScope`
 * lo provee y `OverlayShell` lo consume— y un primitive no importa de su propia
 * capa. La primera versión lo declaraba dentro de `OverlayScope.tsx`, así que
 * `OverlayShell` tenía que importar de un vecino y `cmp-7` lo acusó: R1 solo va
 * hacia abajo, y la excepción de hospedar por hueco (imp-4) no aplica a un
 * import de verdad.
 *
 * `null` es el estado normal y no un hueco: sin ámbito, OverlayShell portaliza
 * a `document.body` y bloquea la página, que es lo correcto cuando la capa es
 * de la pantalla (ovs-3).
 */
export declare const OverlayTarget: import("react").Context<HTMLElement | null>;

import type { ReactNode } from 'react';
/** Los tres idiomas en los que existe el diccionario. */
export type FlowIdioma = 'es' | 'en' | 'pt';
export type FlowLocale = FlowIdioma | `${FlowIdioma}-${string}`;
export interface FlowIntlProviderProps {
    locale?: FlowLocale;
    children: ReactNode;
}
export declare function FlowIntlProvider({ locale, children }: FlowIntlProviderProps): import("react").JSX.Element;
export declare function useFlowIntl(): import("react-intl").IntlShape;

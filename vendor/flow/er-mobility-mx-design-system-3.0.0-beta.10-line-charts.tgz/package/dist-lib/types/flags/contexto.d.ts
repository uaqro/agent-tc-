import { type ReactNode } from 'react';
export interface FlowFlagsProviderProps {
    /** Dónde sirve el producto sus banderas: `/flags`, `https://cdn…/flags`.
        Sin barra final — la pieza la pone. */
    baseUrl: string;
    children: ReactNode;
}
export declare function FlowFlagsProvider({ baseUrl, children }: FlowFlagsProviderProps): import("react").JSX.Element;
/** La base declarada, o `null` si el producto no declaró ninguna. */
export declare function useFlagsBase(): string | null;
/** La URL de una bandera. Es una cadena armada en ejecución: ningún
    empaquetador la ve, así que no se emite nada. */
export declare function urlDeBandera(base: string, country: string): string;
export declare function avisaDelCaminoViejo(mensaje: string): void;
export declare function reiniciaAvisoDeBanderas(): void;

import { type CSSProperties } from 'react';
export interface UploadedFile {
    name: string;
    size: number;
    file?: File;
}
/** upl-7: por qué no entró. Es un CÓDIGO y no una frase: la frase depende del
    producto y del idioma, y la pieza no sabe ninguno de los dos. */
export type RejectReason = 'accept' | 'maxSize' | 'maxFiles';
export interface RejectedFile {
    file: File;
    reason: RejectReason;
}
export interface FileUploadProps {
    files?: UploadedFile[];
    onChange?: (files: UploadedFile[]) => void;
    accept?: string;
    label?: string;
    hint?: string;
    /** upl-7: tamaño máximo por archivo, en bytes. */
    maxSize?: number;
    /** upl-7: cuántos archivos como mucho, contando los que ya hay. */
    maxFiles?: number;
    /** upl-7: lo que NO entra se dice, con el archivo y el motivo. Una sola
        llamada por intento —soltar cinco puede rechazar tres—. Sin esta prop un
        archivo rechazado desaparecía sin dejar rastro, que es lo que obligaba a
        cada producto a envolver la pieza para poder avisar. */
    onReject?: (rejected: RejectedFile[]) => void;
    /** Varios archivos (default). Con false, uno nuevo reemplaza al anterior. */
    multiple?: boolean;
    disabled?: boolean;
    style?: CSSProperties;
}
export declare function FileUpload({ files, onChange, accept, label, hint, maxSize, maxFiles, onReject, multiple, disabled, style, }: FileUploadProps): import("react").JSX.Element;

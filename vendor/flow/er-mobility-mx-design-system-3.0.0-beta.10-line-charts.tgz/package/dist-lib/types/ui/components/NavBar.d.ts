import type { CSSProperties, ReactNode } from 'react';
export interface NavBarProps {
    title: string;
    onBack?: () => void;
    trailing?: ReactNode;
    style?: CSSProperties;
}
export declare function NavBar({ title, onBack, trailing, style }: NavBarProps): import("react").JSX.Element;

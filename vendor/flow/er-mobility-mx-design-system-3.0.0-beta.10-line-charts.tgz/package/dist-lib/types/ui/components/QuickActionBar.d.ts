import type { CSSProperties, ReactNode } from 'react';
export interface QuickActionBarProps {
    children: ReactNode;
    style?: CSSProperties;
}
export declare function QuickActionBar({ children, style }: QuickActionBarProps): import("react").JSX.Element;

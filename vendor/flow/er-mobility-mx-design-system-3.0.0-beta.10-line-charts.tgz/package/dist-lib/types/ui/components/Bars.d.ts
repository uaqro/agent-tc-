import { type CSSProperties } from 'react';
export interface BarsDataPoint {
    label: string;
    value: number;
    color?: string;
}
export interface BarsProps {
    data?: BarsDataPoint[];
    /** Alto en px, o `'fill'` para tomar el de su zona del layout. Un número
        fijo dentro de una tarjeta que crece deja hueco debajo; `'fill'` evita
        que el consumidor tenga que pisar la altura con un `style`. */
    height?: number | 'fill';
    color?: string;
    /** Exactamente la barra maxima va en acento; con empate, ninguna. */
    highlightMax?: boolean;
    format?: (value: number) => string | number;
    style?: CSSProperties;
}
export declare function Bars({ data, height, color, highlightMax, format, style }: BarsProps): import("react").JSX.Element;

import { type CSSProperties } from 'react';
interface Role {
    id: string;
    label: string;
    locked?: boolean;
}
interface Permission {
    id: string;
    label: string;
    group?: string;
    /** Matiz bajo el nombre del permiso («módulo pendiente de construcción»). */
    hint?: string;
}
type Values = Record<string, Record<string, boolean>>;
export interface RoleMatrixProps {
    roles: Role[];
    permissions: Permission[];
    values: Values;
    onChange?: (next: Values, permId: string, roleId: string) => void;
    style?: CSSProperties;
}
export declare function RoleMatrix({ roles, permissions, values, onChange, style }: RoleMatrixProps): import("react").JSX.Element;
export {};

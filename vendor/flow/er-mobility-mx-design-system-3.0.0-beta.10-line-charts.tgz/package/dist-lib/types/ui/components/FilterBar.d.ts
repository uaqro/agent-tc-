import type { CSSProperties, ReactNode } from 'react';
export interface FilterBarProps {
    /** `inline` en el flujo de la página (default); `floating` encima de un
        lienzo, como un mapa. */
    variant?: 'inline' | 'floating';
    children: ReactNode;
    style?: CSSProperties;
}
export declare function FilterBar({ variant, children, style }: FilterBarProps): import("react").JSX.Element;

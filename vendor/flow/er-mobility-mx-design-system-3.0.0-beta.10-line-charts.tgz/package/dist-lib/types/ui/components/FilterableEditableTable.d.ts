import { type CSSProperties } from 'react';
import { type GridColumn } from './DataGrid';
export interface FilterableColumn extends GridColumn {
    filterable?: boolean;
    editable?: boolean;
}
export interface FilterableEditableTableProps {
    columns: FilterableColumn[];
    rows: Record<string, unknown>[];
    rowKey: string;
    onUpdate?: (rowKey: string, columnKey: string, value: string) => void;
    onFilter?: (filters: Record<string, string>) => void;
    style?: CSSProperties;
}
/** @deprecated En retiro (RFC 0004): usa `DataTable` con columnas `editable`
    y `onCellEdit`, y `searchKeys` o el slot `filters` para filtrar. Esta pieza
    obligaba a elegir entre filtrar o editar, y traía su propia carcasa en
    estilos inline, su propio <input> crudo y su propio estado vacío.
    Se retira en 4.0. */
export declare function FilterableEditableTable({ columns, rows, rowKey, onUpdate, onFilter, style, }: FilterableEditableTableProps): import("react").JSX.Element;

import type { ReactNode } from 'react';
export interface DialogProps {
    open: boolean;
    /** @deprecated Alias de `onOpenChange(false)`. Se retira en 4.0 (RFC 0002). */
    onClose?: () => void;
    /** La apertura se reporta al dueño. Convención única del sistema (cst-6). */
    onOpenChange?: (open: boolean) => void;
    title: string;
    description?: string;
    actions?: ReactNode;
    tone?: 'danger' | 'success';
    /** Ancho del modal en px. Default el max-width del shell. El código aceptaba
        además un string CSS que el contrato no promete y nadie pasaba. */
    width?: number;
    children?: ReactNode;
}
export declare function Dialog({ open, onClose, onOpenChange, title, description, actions, tone, width, children, }: DialogProps): import("react").JSX.Element;

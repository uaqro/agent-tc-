import { type ReactNode, type CSSProperties } from 'react';
export interface DocumentViewerProps {
    title: string;
    /** El documento lo pinta el producto (iframe, imagen, render de PDF). */
    children: ReactNode;
    /** Descargar, compartir… viven en la cabecera del marco. */
    actions?: ReactNode;
    expandable?: boolean;
    /** Expansión a pantalla completa, controlada por el dueño (cst-7). */
    expanded?: boolean;
    /** La expansión se reporta al dueño (cst-7, forma booleana). */
    onExpandedChange?: (expanded: boolean) => void;
    /** Alto del marco en línea; el expandido ocupa la pantalla. */
    height?: number | string;
    style?: CSSProperties;
}
export declare function DocumentViewer({ title, children, actions, expandable, expanded: expandedProp, onExpandedChange, height, style, }: DocumentViewerProps): import("react").JSX.Element;

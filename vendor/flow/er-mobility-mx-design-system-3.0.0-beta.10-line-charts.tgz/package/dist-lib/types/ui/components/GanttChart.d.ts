import type { CSSProperties } from 'react';
export interface GanttTask {
    id: string;
    name: string;
    start: string;
    end: string;
    progress?: number;
    color?: string;
    /** Ids de tareas previas. Los conectores se dibujan; un ciclo se detecta
        y se declara en pantalla sin colgar el render (gnt-2). */
    dependsOn?: string[];
}
export interface GanttChartProps {
    tasks: GanttTask[];
    style?: CSSProperties;
}
export declare function GanttChart({ tasks, style }: GanttChartProps): import("react").JSX.Element;

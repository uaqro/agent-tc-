import type { CSSProperties, ReactNode } from 'react';
export interface SectionRuleProps {
    label: string;
    meta?: ReactNode;
    style?: CSSProperties;
}
export declare function SectionRule({ label, meta, style }: SectionRuleProps): import("react").JSX.Element;

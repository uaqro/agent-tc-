import { type ReactNode, type CSSProperties } from 'react';
interface ToolChip {
    label: string;
    icon?: string;
    status?: 'running' | 'done';
}
export interface ChatMsg {
    id: string;
    role: 'user' | 'agent';
    text?: string;
    tool?: ToolChip;
    streaming?: boolean;
    content?: ReactNode;
    timestamp?: string;
}
export interface ChatThreadProps {
    messages: ChatMsg[];
    emptyState?: ReactNode;
    style?: CSSProperties;
}
export declare function ChatThread({ messages, emptyState, style }: ChatThreadProps): import("react").JSX.Element;
export {};

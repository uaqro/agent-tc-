import { type CSSProperties } from 'react';
export interface PasscodeKeypadProps {
    length?: number;
    value?: string;
    onChange?: (value: string) => void;
    onComplete?: (value: string) => void;
    invalid?: boolean;
    /** Sustituye el «Código incorrecto» propio cuando el dueño sabe más —cuántos
        intentos quedan—. Sin esto, quien quiera decir más añade un SEGUNDO
        role=alert y el lector lee el error dos veces. */
    errorMessage?: string;
    biometricIcon?: string;
    onBiometric?: () => void;
    style?: CSSProperties;
}
export declare function PasscodeKeypad({ length, value, onChange, onComplete, invalid, errorMessage, biometricIcon, onBiometric, style, }: PasscodeKeypadProps): import("react").JSX.Element;

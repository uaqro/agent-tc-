import { type ReactNode } from 'react';
export interface DrawerProps {
    open: boolean;
    /** @deprecated Alias de `onOpenChange(false)`. Se retira en 4.0 (RFC 0002). */
    onClose?: () => void;
    /** La apertura se reporta al dueño. Convención única del sistema (cst-6). */
    onOpenChange?: (open: boolean) => void;
    title?: string;
    width?: number;
    /** Lado desde el que entra. Default 'right'. */
    side?: 'right' | 'left';
    footer?: ReactNode;
    children?: ReactNode;
}
export declare function Drawer({ open, onClose, onOpenChange, title, width, side, footer, children, }: DrawerProps): import("react").JSX.Element;

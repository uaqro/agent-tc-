import { type CSSProperties } from 'react';
export interface ChatComposerProps {
    value?: string;
    onChange?: (value: string) => void;
    onSend?: (value: string) => void;
    placeholder?: string;
    suggestions?: string[];
    disabled?: boolean;
    style?: CSSProperties;
}
export declare function ChatComposer({ value, onChange, onSend, placeholder, suggestions, disabled, style, }: ChatComposerProps): import("react").JSX.Element;

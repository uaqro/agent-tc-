import { type CSSProperties } from 'react';
export interface MapPin {
    id: string;
    lat: number;
    lon: number;
    label?: string;
    subtitle?: string;
    /** mc-13: atributos del tooltip como LISTA — una fila por dato, en vez de
        una sola línea con separadores. Si existe, manda sobre `subtitle`. */
    details?: string[];
    color?: string;
    icon?: string;
    /** mc-9: radio en px para el modo de RED DENSA. Un pin con `size` se pinta
        como PUNTO —relleno + aro fino, sin sombra ni halo ni botón DOM propio—:
        miles de estaciones son marcas de dato, como las barras de una gráfica,
        y su superficie accesible es el directorio que las lista (cazado en
        eOne: 6 977 estaciones ahogaban el chip de 24px y sus 6 977 botones). */
    size?: number;
}
/** mc-10: una ruta real llega a menudo en TRAMOS que no se tocan (el INEGI
    devuelve MultiLineString); unirlos trazaría rectas que cruzan un golfo. */
export type MapRoute = [number, number][] | [number, number][][];
export interface MapCanvasProps {
    /** mc-16: quién dibuja la tarjeta. Por defecto el lienzo; `'none'` cuando ya
        vive dentro de una carcasa ajena. Mismo trato que `surface` en Table
        (tb-10): quien lo mete en otra superficie no se la apaga por fuera con un
        estilo inline, porque la carcasa tiene dueño (R3). */
    surface?: 'card' | 'none';
    center: [number, number];
    zoom?: number;
    pins?: MapPin[];
    cluster?: boolean;
    selectedPin?: string | null;
    onPinClick?: (id: string) => void;
    route?: MapRoute;
    routeColor?: string;
    /** mc-11: puntos a ENCUADRAR. Cuando el conjunto cambia, el mapa se centra
        y elige el zoom que los contiene con margen — el gesto de «enséñame lo
        filtrado» (cazado en eOne: al filtrar por estado, el mapa viaja a ese
        estado; al soltar el filtro, vuelve al país). El pan del usuario se
        respeta hasta el siguiente cambio del conjunto. */
    fitBounds?: [number, number][];
    /** El fondo es lienzo: en mono (default) los tiles van en escala de grises y
        el color queda reservado a pins y ruta — el matiz es del dato, no del mapa. */
    tone?: 'mono' | 'color';
    /** mc-6: plantilla de tiles. La clave del proveedor viaja dentro de la URL,
        que es donde la ponen todos. Default: OSM estándar. Por ejemplo
        `https://tiles.tuempresa.mx/{z}/{x}/{y}.png?key=abc`. */
    tileUrl?: string;
    /** Quién firma los tiles. Cambiar de proveedor sin cambiar esto deja el
        crédito de OSM sobre el mapa de otro — por eso van en la misma pieza. */
    attribution?: string;
    /** mc-7: el dueño se entera de dónde está mirando el usuario, para pedir al
        servidor solo lo que cabe en pantalla. Sin esto hay que cargarlo todo o
        no cargar nada. Se emite al soltar el paneo o al cambiar el zoom, no en
        cada píxel del arrastre. */
    onViewportChange?: (viewport: {
        center: [number, number];
        zoom: number;
    }) => void;
    /** mc-8: techo de tiles en memoria. La caché expulsa el menos usado
        (LRU) al pasarse; sin cota, una sesión larga de paneo retiene toda
        imagen que haya visto. */
    tileCacheMax?: number;
    style?: CSSProperties;
}
export declare function podarCache<T>(cache: Map<string, T>, max: number): Map<string, T>;
/** mc-8: leer un tile lo reinserta al final — así el primero del Map es
    siempre el menos usado recientemente. */
export declare function tocarCache<T>(cache: Map<string, T>, key: string): T | undefined;
/** Agrupa cabezas que se solapan en pantalla; el zoom las separa. */
export declare function agruparPins(pins: MapPin[], zoom: number): MapPin[][];
export declare function MapCanvas({ surface, center, zoom: zoomProp, pins, cluster, selectedPin, onPinClick, route, routeColor, fitBounds, style, tone, tileUrl, attribution, onViewportChange, tileCacheMax, }: MapCanvasProps): import("react").JSX.Element;

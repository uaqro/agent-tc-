import { type CSSProperties, type FocusEvent } from 'react';
export interface OTPInputProps {
    name?: string;
    required?: boolean;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    /** Para que Field htmlFor alcance al input real (fld-1). */
    id?: string;
    length?: number;
    value?: string;
    onChange?: (value: string) => void;
    onComplete?: (value: string) => void;
    invalid?: boolean;
    disabled?: boolean;
    autoFocus?: boolean;
    style?: CSSProperties;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
}
export declare const OTPInput: import("react").ForwardRefExoticComponent<OTPInputProps & import("react").RefAttributes<HTMLInputElement>>;

import { type CSSProperties, type FocusEvent } from 'react';
export interface InputAmountProps {
    name?: string;
    required?: boolean;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    id?: string;
    value?: string;
    onChange?: (value: string) => void;
    placeholder?: string;
    currency?: string;
    /** Locale de formato. Por defecto el del IntlProvider de tu app. */
    locale?: string;
    size?: 'sm' | 'md';
    disabled?: boolean;
    invalid?: boolean;
    style?: CSSProperties;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
}
export declare const InputAmount: import("react").ForwardRefExoticComponent<InputAmountProps & import("react").RefAttributes<HTMLInputElement>>;

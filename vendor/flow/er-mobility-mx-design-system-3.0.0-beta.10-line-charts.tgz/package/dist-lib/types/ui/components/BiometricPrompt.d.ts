import type { CSSProperties } from 'react';
export interface BiometricPromptProps {
    method?: 'face' | 'fingerprint';
    state?: 'idle' | 'scanning' | 'success' | 'error';
    title?: string;
    description?: string;
    onUse?: () => void;
    onFallback?: () => void;
    fallbackLabel?: string;
    style?: CSSProperties;
}
export declare function BiometricPrompt({ method, state, title, description, onUse, onFallback, fallbackLabel, style, }: BiometricPromptProps): import("react").JSX.Element;

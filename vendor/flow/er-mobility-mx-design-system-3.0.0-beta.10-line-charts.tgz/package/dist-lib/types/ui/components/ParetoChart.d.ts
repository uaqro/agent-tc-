import { type CSSProperties } from 'react';
export interface ParetoItem {
    label: string;
    value: number;
}
export interface ParetoChartProps {
    data?: ParetoItem[];
    height?: number;
    format?: (value: number) => string;
    threshold?: number;
    style?: CSSProperties;
}
export declare function ParetoChart({ data, height, format, threshold, style }: ParetoChartProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface ActiveFilter {
    id: string;
    dimension: string;
    label: string;
}
export interface ActiveFiltersProps {
    filters: ActiveFilter[];
    /** Periodo activo como chip fijo: informa, no se quita desde aquí. */
    period?: string;
    onRemove: (id: string) => void;
    /** Limpiar todo. Solo se ofrece con 2 o más filtros. */
    onClearAll?: () => void;
    clearLabel?: string;
    style?: CSSProperties;
}
export declare function ActiveFilters({ filters, period, onRemove, onClearAll, clearLabel, style }: ActiveFiltersProps): import("react").JSX.Element | null;

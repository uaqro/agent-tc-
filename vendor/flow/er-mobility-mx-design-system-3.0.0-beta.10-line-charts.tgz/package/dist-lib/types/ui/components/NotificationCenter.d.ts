export interface NotificationItem {
    id: string;
    tone: 'warning' | 'danger' | 'success' | 'info';
    title: string;
    desc?: string;
    time: string;
    read: boolean;
}
export interface NotificationCenterProps {
    items?: NotificationItem[];
    /** Lado del panel respecto a la campana. Default 'right'. */
    align?: 'left' | 'right';
    onItemClick?: (item: NotificationItem) => void;
    onMarkAllRead?: () => void;
    /** Apertura controlada. Sin ella el panel se abre solo (cst-3). */
    open?: boolean;
    /** La apertura se reporta al dueño. Convención única del sistema (cst-6). */
    onOpenChange?: (open: boolean) => void;
}
export declare function NotificationCenter({ items, align, onItemClick, onMarkAllRead, open, onOpenChange, }: NotificationCenterProps): import("react").JSX.Element;

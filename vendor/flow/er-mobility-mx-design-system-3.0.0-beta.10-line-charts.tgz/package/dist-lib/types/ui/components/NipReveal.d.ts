import { type CSSProperties } from 'react';
export interface NipRevealProps {
    digits: string;
    blurLast?: boolean;
    duration?: number;
    warning?: string;
    style?: CSSProperties;
}
export declare function NipReveal({ digits, blurLast, duration, warning, style }: NipRevealProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface QuickActionProps {
    icon: string;
    label: string;
    active?: boolean;
    disabled?: boolean;
    onClick?: () => void;
    style?: CSSProperties;
}
export declare function QuickAction({ icon, label, active, disabled, onClick, style }: QuickActionProps): import("react").JSX.Element;

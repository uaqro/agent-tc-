import type { CSSProperties } from 'react';
export interface BalanceDisplayProps {
    label?: string;
    /** bd-3: dónde vive. `surface` es una página; `art` es sobre la ilustración
        de una tarjeta, donde el valor es más pequeño y el ojo se apoya en un
        velo claro en vez de en el fondo. Es la misma mecánica con otra piel, así
        que es una prop y no una pieza (R2): PaymentCard la dibujaba aparte. */
    variant?: 'surface' | 'art';
    value: string;
    hidden?: boolean;
    onToggleHidden?: () => void;
    style?: CSSProperties;
}
export declare function BalanceDisplay({ label, variant, value, hidden, onToggleHidden, style, }: BalanceDisplayProps): import("react").JSX.Element;

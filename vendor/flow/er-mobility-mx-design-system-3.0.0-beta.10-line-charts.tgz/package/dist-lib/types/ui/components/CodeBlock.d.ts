import { type CSSProperties, type ReactNode } from 'react';
export interface CodeBlockProps {
    code?: string;
    filename?: string;
    heading?: ReactNode;
    trailing?: ReactNode;
    copyable?: boolean;
    variant?: 'default' | 'inline';
    children?: ReactNode;
    style?: CSSProperties;
}
export declare function CodeBlock({ code, filename, heading, trailing, copyable, variant, children, style, }: CodeBlockProps): import("react").JSX.Element;

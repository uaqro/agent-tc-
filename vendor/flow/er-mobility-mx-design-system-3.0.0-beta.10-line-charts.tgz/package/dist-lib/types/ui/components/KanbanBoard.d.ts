import { type CSSProperties, type ReactNode } from 'react';
export interface KanbanColumn {
    id: string;
    label: string;
    color?: string;
    limit?: number;
    abandon?: boolean;
}
export interface KanbanBoardProps<T extends object = Record<string, unknown>> {
    columns: KanbanColumn[];
    items: T[];
    columnKey?: string;
    itemKey?: string;
    renderCard: (item: T, state: {
        dragging: boolean;
    }) => ReactNode;
    renderColumnHeader?: (column: KanbanColumn, state: {
        count: number;
        atLimit: boolean;
        isOver: boolean;
    }) => ReactNode;
    columnStyle?: CSSProperties | ((column: KanbanColumn, state: {
        atLimit: boolean;
        isOver: boolean;
        isReject: boolean;
    }) => CSSProperties);
    onMove?: (key: string, toColumnId: string) => boolean | void;
    onAdvance?: (key: string) => void;
    abandonColumn?: KanbanColumn;
    /** Acciones propias de la tarjeta. Recibe si puede avanzar y la función que
        lo hace, así que el producto decide qué dibujar sin reimplementar la
        regla de a qué columna va. Sin esta prop se dibuja el botón de avanzar de
        siempre: la pieza no se queda sin su acción por no declararla. */
    renderActions?: (item: T, state: {
        canAdvance: boolean;
        advance: () => void;
    }) => ReactNode;
    renderDetail?: (item: T) => ReactNode;
    detailKey?: string | null;
    onDetailChange?: (key: string | null) => void;
    style?: CSSProperties;
}
export declare function KanbanBoard<T extends object>({ columns, items, columnKey, itemKey, renderCard, renderActions, renderColumnHeader, columnStyle, onMove, onAdvance, abandonColumn, renderDetail, detailKey, onDetailChange, style, }: KanbanBoardProps<T>): import("react").JSX.Element;

import { type ReactNode, type CSSProperties } from 'react';
export interface SidebarItem {
    id: string;
    label: string;
    icon?: string;
    href?: string;
    /** Contador (número, 99+ al pasar) o punto vivo (true). Colapsado, el
        contador viaja al nombre accesible y el punto se posa en el icono. */
    badge?: number | boolean;
    /** Rótulo de grupo, no destino: no es interactivo y sus hijos se listan
        siempre (sbr-6). Colapsado se reduce a separador. */
    caption?: boolean;
    children?: SidebarItem[];
}
export interface SidebarProps {
    items: SidebarItem[];
    activeId?: string;
    collapsed?: boolean;
    /** Adapta presentación a los rangos de Flow; collapsed sigue siendo manual sin responsive. */
    responsive?: boolean;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** Secciones abiertas, controladas por el dueño (cst-7). */
    expandedKeys?: string[];
    /** La expansión se reporta con el valor nuevo completo (cst-7). */
    onExpandedChange?: (keys: string[]) => void;
    /** @deprecated Alias de `expandedKeys`. Se retira en 4.0 (RFC 0002). */
    expandedSections?: Set<string>;
    onNavigate?: (id: string, href?: string) => void;
    /** @deprecated Reporta qué sección se tocó, no el valor nuevo. Alias de
        `onExpandedChange`. Se retira en 4.0 (RFC 0002). */
    onToggleSection?: (id: string) => void;
    headerContent?: ReactNode;
    footerActions?: ReactNode;
    width?: string;
    style?: CSSProperties;
}
export declare function Sidebar({ items, activeId, collapsed: manualCollapsed, responsive, open, onOpenChange, expandedKeys, onExpandedChange, expandedSections, onNavigate, onToggleSection, headerContent, footerActions, width, style, }: SidebarProps): import("react").JSX.Element;

import type { CSSProperties, ReactNode, FocusEvent } from 'react';
export interface InputPhoneProps {
    name?: string;
    required?: boolean;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    id?: string;
    value?: string;
    onChange?: (value: string) => void;
    placeholder?: string;
    /** La lada como adorno, fuera del valor y no borrable (tel-1). La bandera
        no se ensambla aquí: eso es `country` (tel-6). */
    prefix?: ReactNode | string;
    /** ISO 3166-1 alpha-2: con él, la pieza dibuja la bandera junto a la lada.
        No guarda ningún mapa país→lada — ese dato es del producto y llega por
        `prefix`, igual que la lista del selector de país (pai-p5). */
    country?: string;
    size?: 'sm' | 'md' | 'lg';
    disabled?: boolean;
    invalid?: boolean;
    style?: CSSProperties;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
}
export declare const InputPhone: import("react").ForwardRefExoticComponent<InputPhoneProps & import("react").RefAttributes<HTMLInputElement>>;

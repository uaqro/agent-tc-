import type { CSSProperties, ReactNode } from 'react';
export interface ListRowProps {
    /** Lo que va delante: Avatar, glifo, nada. Es el hueco que faltaba —las dos
        filas de dominio derivaban su icono de una prop cerrada— y por el que
        siete pantallas volvían a dibujar la fila a mano. */
    leading?: ReactNode;
    title: ReactNode;
    /** La línea de soporte, debajo del título. */
    subtitle?: ReactNode;
    /** Lo que va detrás: una cifra, un control, un chevron. */
    trailing?: ReactNode;
    /** El nombre accesible cuando la fila es un control. La fila lo arma sola
        con sus textos; si el contenido viene envuelto —el precio de StationRow
        es un `<span>` para pintarlo en familia de dato— solo quien compone
        sabe leerlo. */
    ariaLabel?: string;
    selected?: boolean;
    /** lr-2: sin `onClick` la fila no finge ser interactiva. */
    onClick?: () => void;
    style?: CSSProperties;
}
export declare function ListRow({ leading, title, subtitle, trailing, ariaLabel, selected, onClick, style }: ListRowProps): import("react").JSX.Element;

import { type ReactNode, type CSSProperties } from 'react';
export interface CardCarouselProps {
    children: ReactNode[];
    activeIndex?: number;
    onChange?: (index: number) => void;
    style?: CSSProperties;
}
export declare function CardCarousel({ children, activeIndex, onChange, style }: CardCarouselProps): import("react").JSX.Element;

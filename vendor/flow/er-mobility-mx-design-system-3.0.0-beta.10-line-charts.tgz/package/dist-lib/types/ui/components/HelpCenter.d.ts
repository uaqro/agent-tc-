import { type CSSProperties } from 'react';
export interface HelpArticle {
    id: string;
    title: string;
    category?: string;
    content?: string;
    keywords?: string[];
}
export interface HelpCenterProps {
    articles: HelpArticle[];
    style?: CSSProperties;
}
export declare function HelpCenter({ articles, style }: HelpCenterProps): import("react").JSX.Element;

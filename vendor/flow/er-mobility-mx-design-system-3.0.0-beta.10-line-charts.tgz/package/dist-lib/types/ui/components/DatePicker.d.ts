export interface DatePickerPreset {
    label: string;
    /** En mode single: 'YYYY-MM-DD'. En mode range: 'inicio|fin'. */
    value: string;
}
export interface DatePickerProps {
    /** Nombre por referencia — Field y SettingsRow lo inyectan. */
    'aria-labelledby'?: string;
    /** single: 'YYYY-MM-DD' · range: 'inicio|fin' en ISO. */
    value?: string;
    onChange?: (value: string) => void;
    /** El único calendario del sistema: una fecha o un rango. Default 'single'. */
    mode?: 'single' | 'range';
    /** Fecha mínima seleccionable (ISO). */
    min?: string;
    /** Fecha máxima seleccionable (ISO). */
    max?: string;
    /** dp-8: mes visible del calendario interior, 'YYYY-MM'. Lo que se monta en
        una pantalla es esto y no el Calendar suelto, así que sin reenviarlo el
        arreglo no llega: reabrir un filtro guardado tiene que abrir en el mes de
        su fecha, y pedir la disponibilidad del mes exige saber cuál se ve. */
    month?: string;
    /** El mes visible se reporta con el valor nuevo, 'YYYY-MM'. */
    onMonthChange?: (month: string) => void;
    /** Atajos ("Últimos 30 días") mostrados sobre el calendario. */
    presets?: DatePickerPreset[];
    disabled?: boolean;
    invalid?: boolean;
    /** Id del control focusable — permite asociar <Field htmlFor>. */
    id?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
    /** Apertura controlada. Sin ella la pieza se abre sola (cst-3). */
    open?: boolean;
    /** La apertura se reporta al dueño. Convención única del sistema (cst-6). */
    onOpenChange?: (open: boolean) => void;
    placeholder?: string;
}
export declare const DatePicker: import("react").ForwardRefExoticComponent<DatePickerProps & import("react").RefAttributes<HTMLSpanElement>>;
export interface DateRangePickerProps {
    value?: string;
    onChange?: (value: string) => void;
    placeholder?: string;
}
/** @deprecated Usa `<DatePicker mode="range">` — el único calendario del sistema. */
export declare function DateRangePicker({ value, onChange, placeholder }: DateRangePickerProps): import("react").JSX.Element;

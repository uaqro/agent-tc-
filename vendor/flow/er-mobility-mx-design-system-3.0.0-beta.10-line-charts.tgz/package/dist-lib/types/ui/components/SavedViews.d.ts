import { type CSSProperties } from 'react';
export interface SavedView {
    id: string;
    name: string;
}
export interface SavedViewsProps {
    views: SavedView[];
    /** La vista aplicada se marca con aria-current. */
    activeId?: string | null;
    onApply: (id: string) => void;
    /** Guarda la combinación actual con el nombre capturado. */
    onSave: (name: string) => void;
    onDelete: (id: string) => void;
    max?: number;
    style?: CSSProperties;
}
export declare function SavedViews({ views, activeId, onApply, onSave, onDelete, max, style }: SavedViewsProps): import("react").JSX.Element;

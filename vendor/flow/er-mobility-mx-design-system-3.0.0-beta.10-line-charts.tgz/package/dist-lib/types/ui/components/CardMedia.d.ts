import type { ReactNode, CSSProperties } from 'react';
type CardMediaComun = {
    title?: string;
    description?: string;
    interactive?: boolean;
    onClick?: () => void;
    style?: CSSProperties;
    children?: ReactNode;
};
export type CardMediaProps = CardMediaComun & ({
    image: string;
    media?: never;
} | {
    media: ReactNode;
    image?: never;
});
export declare function CardMedia({ image, media, title, description, interactive, onClick, style, children }: CardMediaProps): import("react").JSX.Element;
export {};

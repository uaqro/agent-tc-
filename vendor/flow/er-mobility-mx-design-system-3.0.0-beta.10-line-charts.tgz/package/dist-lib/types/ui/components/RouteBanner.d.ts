import type { CSSProperties } from 'react';
export interface RouteBannerProps {
    icon?: string;
    title: string;
    subtitle: string;
    onClose?: () => void;
    style?: CSSProperties;
}
export declare function RouteBanner({ icon, title, subtitle, onClose, style }: RouteBannerProps): import("react").JSX.Element;

import { type ReactNode, type CSSProperties } from 'react';
export interface GridColumn<T = Record<string, unknown>> {
    key: string;
    label: string;
    align?: 'left' | 'right' | 'center';
    mono?: boolean;
    /** Retiro responsivo: 1 (o ausente) siempre visible; 3 se retira primero,
        bajo --bp-expanded (982px); 2 después, bajo --bp-sm (576px). En la práctica:
        2 sobrevive más que 3. */
    priority?: 1 | 2 | 3;
    render?: (row: T) => ReactNode;
}
export type Density = 'default' | 'compact';
export interface GridSort {
    key: string;
    dir: 'asc' | 'desc';
}
export type GridSkin = Partial<Record<'root' | 'table' | 'th' | 'thButton' | 'row' | 'td', string>>;
export interface DataGridProps<T = Record<string, unknown>> {
    columns?: GridColumn<T>[];
    rows?: T[];
    rowKey?: string;
    /** Resalta UNA fila —la abierta en un detalle—. No es selección múltiple. */
    selectedKey?: string | number;
    /** Añade la columna de selección múltiple (dg-20). */
    selectable?: boolean;
    /** Selección controlada. Sin esta prop la rejilla lleva la suya. */
    selectedKeys?: (string | number)[];
    /** Siembra la selección cuando no está controlada (cst-3). */
    defaultSelectedKeys?: (string | number)[];
    onSelectionChange?: (keys: (string | number)[]) => void;
    /** Nombre de la casilla de cabecera cuando no hay caption que lo dé. */
    selectAllLabel?: string;
    /** Va pegada a lo que tiene encima —una BulkBar—: cuadra sus esquinas de
        arriba y cede el borde superior, para que las dos lean como un bloque. */
    attachedTop?: boolean;
    /** dg-17: quien dibuja la tarjeta. Por defecto la rejilla; `'none'` cuando
        ya vive dentro de una carcasa ajena —un Card, un WidgetFrame— y volver a
        dibujarla daria dos superficies anidadas (R3, una carcasa un dueno). */
    surface?: 'card' | 'none';
    onRowClick?: (row: T) => void;
    sortable?: boolean;
    /** Orden controlado: con `sort` el grid NO reordena filas — el dueño ordena
        (tambien en servidor) y el grid solo pinta el estado y emite el cambio.
        Es la salida de la trampa de ordenar 1 140 filas en el cliente. */
    sort?: GridSort | null;
    onSortChange?: (sort: GridSort | null) => void;
    density?: Density;
    /** Nombre de la tabla para el lector: <caption> visualmente oculto (tb-5). */
    caption?: string;
    zebraToken?: string;
    /** El gancho de las pieles (Table): reemplaza clases sin duplicar la mecanica. */
    skin?: GridSkin;
    /** dg-18: las filas anidan por `children`. La rejilla las aplana, indenta,
        pone la chevron y declara `role="treegrid"`. La jerarquia es una mecanica
        de la tabla, no una tabla distinta. */
    tree?: boolean;
    /** Ramas abiertas, controladas por el dueno. Sin ella la rejilla lleva la suya. */
    expandedKeys?: (string | number)[];
    /** Siembra las ramas abiertas cuando la expansion no esta controlada (cst-3). */
    defaultExpandedKeys?: (string | number)[];
    onExpandedChange?: (keys: (string | number)[]) => void;
    /** Nombre de la chevron segun su estado. Como `selectAllLabel`: la rejilla
        no trae `useIntl` —obligaria a un IntlProvider a todo el que la use— y
        recibe el texto de quien ya lo tiene. */
    expandLabel?: string;
    collapseLabel?: string;
    style?: CSSProperties;
}
export declare function DataGrid<T extends object = Record<string, unknown>>({ columns, rows, rowKey, selectedKey, selectable, selectedKeys, defaultSelectedKeys, onSelectionChange, selectAllLabel, attachedTop, surface, onRowClick, sortable, sort, onSortChange, density, caption, zebraToken, skin, tree, expandedKeys, defaultExpandedKeys, onExpandedChange, expandLabel, collapseLabel, style, }: DataGridProps<T>): import("react").JSX.Element;

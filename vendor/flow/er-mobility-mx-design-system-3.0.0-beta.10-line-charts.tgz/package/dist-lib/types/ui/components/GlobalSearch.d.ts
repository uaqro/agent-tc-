import { type ReactNode, type CSSProperties } from 'react';
export interface SearchResult {
    id: string;
    label: string;
    group?: string;
    hint?: string;
    icon?: string;
    meta?: string;
    mono?: boolean;
    trailing?: ReactNode;
}
export interface GlobalSearchProps {
    mode?: 'palette' | 'inline';
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    value?: string;
    onValueChange?: (value: string) => void;
    results?: SearchResult[];
    groupOrder?: string[];
    loading?: boolean;
    recents?: SearchResult[];
    suggestions?: string[];
    onSelect?: (item: SearchResult) => void;
    onClearRecents?: () => void;
    placeholder?: string;
    emptyTitle?: string;
    emptyDescription?: string;
    /** Qué escribir cuando no hay resultados (descripción del estado vacío). */
    emptyHint?: string;
    /** Caracteres mínimos antes de buscar. Default 1. */
    minChars?: number;
    /** Registra ⌘K/Ctrl+K (solo palette). Default true. */
    shortcut?: boolean;
    noResultsTitle?: (query: string) => string;
    style?: CSSProperties;
}
export declare function GlobalSearch({ mode, open, onOpenChange, value, onValueChange, results, groupOrder, loading, recents, suggestions, onSelect, onClearRecents, placeholder, emptyTitle, emptyDescription, emptyHint, minChars, shortcut, noResultsTitle, style, }: GlobalSearchProps): import("react").JSX.Element;

import type { CSSProperties, ReactNode } from 'react';
export interface PeekSheetProps {
    title: string;
    children: ReactNode;
    style?: CSSProperties;
}
/** @deprecated El flujo de estaciones abre el detalle desde los pines de StationFinder. Se conserva para compatibilidad. */
export declare function PeekSheet({ title, children, style }: PeekSheetProps): import("react").JSX.Element;

import { type CSSProperties } from 'react';
export interface ScatterPoint {
    id: string;
    x: number;
    y: number;
    label?: string;
}
export interface ScatterPlotProps {
    points?: ScatterPoint[];
    xLabel?: string;
    yLabel?: string;
    xThreshold?: number;
    yThreshold?: number;
    color?: string;
    format?: {
        x?: (v: number) => string;
        y?: (v: number) => string;
    };
    height?: number;
    selectedId?: string;
    onSelect?: (point: ScatterPoint) => void;
    style?: CSSProperties;
}
export declare function ScatterPlot({ points, xLabel, yLabel, xThreshold, yThreshold, color, format, height, selectedId, onSelect, style, }: ScatterPlotProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface PaginationProps {
    page?: number;
    pages?: number;
    onChange?: (page: number) => void;
    /** Total de filas: habilita el rótulo de rango «X–Y de Z» (pag-6). */
    total?: number;
    /** Filas por página, para calcular el rango. */
    pageSize?: number;
    /** Pasos del selector de tamaño; sin ella el selector no existe. */
    pageSizeOptions?: number[];
    /** Cambiar el tamaño también emite onChange(1): se vuelve a la primera. */
    onPageSizeChange?: (size: number) => void;
    style?: CSSProperties;
}
export declare function Pagination({ page, pages, onChange, total, pageSize, pageSizeOptions, onPageSizeChange, style, }: PaginationProps): import("react").JSX.Element;

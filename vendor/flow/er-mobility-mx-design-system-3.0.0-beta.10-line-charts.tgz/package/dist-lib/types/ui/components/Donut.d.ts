import type { CSSProperties } from 'react';
export interface DonutSegment {
    label: string;
    value: number;
    color?: string;
    icon?: string;
}
export interface DonutProps {
    segments?: DonutSegment[];
    size?: number;
    thickness?: number;
    centerLabel?: string;
    centerValue?: string | number;
    /** Unidad del producto, compartida por tooltip y leyenda. */
    valueLabel?: string;
    formatValue?: (value: number) => string;
    legend?: boolean;
    style?: CSSProperties;
}
export declare function Donut({ segments, size, thickness, centerLabel, centerValue, formatValue, valueLabel, legend, style, }: DonutProps): import("react").JSX.Element;

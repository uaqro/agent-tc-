import type { CSSProperties, ReactNode } from 'react';
export interface BulkAction {
    id: string;
    label: string;
    icon?: string;
    danger?: boolean;
}
export interface BulkBarProps {
    /** bbr-6: lo que la franja HACE cuando no hay selección — la barra de
        herramientas de la tabla: búsqueda, recuento, acciones de conjunto. Es
        obligatorio y no por capricho: la franja ocupa el sitio de la cabecera,
        así que tiene que ganárselo. Primero llevó un recuento que ya daba la
        paginación; luego un título que ya daba la pantalla. Las dos veces era
        relleno para que la tabla no saltara al marcar una casilla. */
    rest: ReactNode;
    /** Filas seleccionadas. Con 0 la franja NO desaparece: cambia de estado
        (bbr-1). Así la tabla no salta al marcar la primera casilla. */
    count: number;
    actions?: BulkAction[];
    onAction?: (actionId: string) => void;
    onClear?: () => void;
    /** Ofrecer extender a todo el resultado filtrado, diciendo cuántas son. */
    extendLabel?: string;
    onExtend?: () => void;
    style?: CSSProperties;
}
export declare function BulkBar({ rest, count, actions, onAction, onClear, extendLabel, onExtend, style }: BulkBarProps): import("react").JSX.Element;

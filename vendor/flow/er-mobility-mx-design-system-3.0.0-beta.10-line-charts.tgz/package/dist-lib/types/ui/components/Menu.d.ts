import { type ReactNode, type CSSProperties } from 'react';
export interface MenuItem {
    label: string;
    icon?: string;
    danger?: boolean;
    disabled?: boolean;
    onClick?: () => void;
}
export type MenuItemOrDivider = MenuItem | 'divider';
export interface MenuProps {
    trigger: ReactNode;
    items?: MenuItemOrDivider[];
    align?: 'left' | 'right';
    /** Apertura controlada. Sin ella la pieza se abre sola (cst-3). */
    open?: boolean;
    /** La apertura se reporta al dueño. Convención única del sistema (cst-6). */
    onOpenChange?: (open: boolean) => void;
    style?: CSSProperties;
}
export declare function Menu({ open: openProp, onOpenChange, trigger, items, align, style }: MenuProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
import { type AvatarProps } from '../primitives/Avatar';
export interface AvatarGroupProps {
    /** Las personas, en el orden que llegan: el grupo no reordena por estado. */
    people: AvatarProps[];
    /** Cuántas se ven. De la siguiente en adelante, «+N» (avg-2). */
    max?: number;
    size?: 'sm' | 'md' | 'lg';
    style?: CSSProperties;
}
/**
 * Apilado de avatares con solape y desborde «+N».
 *
 * Vive en components y no en primitives aunque su contrato lo dijera hasta el
 * 14-oct-2026: compone `Avatar`, y un primitive que importa un primitive es
 * `cmp-7` —la única excepción declarada de R1 son las carcasas, y `Avatar` no lo
 * es—; no importarlo sería redibujarlo, que es R2. Y coordina sub-conceptos, que
 * es el criterio de la capa: N avatares más el desborde, con UN nombre accesible
 * encima.
 */
export declare function AvatarGroup({ people, max, size, style }: AvatarGroupProps): import("react").JSX.Element | null;

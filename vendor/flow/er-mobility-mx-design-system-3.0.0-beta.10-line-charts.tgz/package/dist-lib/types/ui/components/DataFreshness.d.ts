import type { CSSProperties } from 'react';
export interface DataFreshnessProps {
    /** Texto ya formateado («datos al miércoles 12:40»): el formato de fechas es del producto. */
    updatedLabel: string;
    /** «ingesta a día vencido» */
    cadence?: string;
    /** «próximo refresco en 15 min» */
    nextRefresh?: string;
    /** Sin él, la barra es solo lectura: no hay botón. */
    onRefresh?: () => void;
    /** Carga en el botón y lo bloquea: sin doble disparo. */
    refreshing?: boolean;
    refreshLabel?: string;
    style?: CSSProperties;
}
export declare function DataFreshness({ updatedLabel, cadence, nextRefresh, onRefresh, refreshing, refreshLabel, style, }: DataFreshnessProps): import("react").JSX.Element;

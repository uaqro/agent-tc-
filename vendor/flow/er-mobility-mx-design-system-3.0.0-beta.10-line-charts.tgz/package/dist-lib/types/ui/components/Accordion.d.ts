import { type ReactNode } from 'react';
export interface AccordionItem {
    id: string;
    title: string;
    icon?: string;
    meta?: string;
    content: ReactNode;
}
export interface AccordionProps {
    items?: AccordionItem[];
    /** Sembrado no controlado. Con `multiple`, puede abrir varios de inicio —
        cosa que `defaultOpen` no podía. */
    defaultExpanded?: string[];
    /** @deprecated Alias de `defaultExpanded` con una sola clave. Se retira en
        4.0 (RFC 0002). */
    defaultOpen?: string;
    /** Paneles abiertos, controlados por el dueño (cst-7). */
    expandedKeys?: string[];
    /** La expansión se reporta con el valor nuevo completo (cst-7). */
    onExpandedChange?: (keys: string[]) => void;
    /** Permite varios paneles abiertos a la vez. Default false (exclusivo). */
    multiple?: boolean;
}
export declare function Accordion({ items, defaultExpanded, defaultOpen, expandedKeys, onExpandedChange, multiple, }: AccordionProps): import("react").JSX.Element;

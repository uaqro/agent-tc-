import { type CSSProperties } from 'react';
export interface SegmentedItem {
    value: string;
    label: string;
    icon?: string;
}
export interface SegmentedControlProps {
    items: SegmentedItem[];
    value: string;
    onChange?: (value: string) => void;
    size?: 'md' | 'sm';
    /** Para que Field htmlFor alcance al control (fld-1). */
    id?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
    /** Nombre accesible del tablist (sgm-6). Sin esto el lector anuncia un
        grupo de pestañas sin decir qué elige. */
    ariaLabel?: string;
    /** Nombre por referencia — SettingsRow y afines lo inyectan clonando. */
    'aria-labelledby'?: string;
    style?: CSSProperties;
}
export declare function SegmentedControl({ items, value, onChange, size, id, 'aria-describedby': ariaDescribedBy, 'aria-invalid': ariaInvalid, 'aria-required': ariaRequired, ariaLabel, 'aria-labelledby': ariaLabelledBy, style, }: SegmentedControlProps): import("react").JSX.Element;

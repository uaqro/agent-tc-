import type { CSSProperties, ReactNode } from 'react';
import { type BrandCanvasSignal } from '../primitives/BrandCanvas';
export interface BrandHeroProps {
    /** La primera línea del titular. */
    title: string;
    /** La etiqueta que rotula de qué va la pantalla, encima del titular: el
        titular afirma y la overline dice el tema. El acceso no la lleva. */
    eyebrow?: string;
    /** La segunda, en tinta secundaria. Una sola: dos acentos no jerarquizan
        nada (bh-4), y el rojo de marca se reserva para la ruta. */
    accent?: string;
    description?: string;
    /** El pie del panel: copyright, versión, lo que el producto quiera. */
    footer?: ReactNode;
    /** Lo que la escena rotula: una señal por vertical. Palabras del producto,
        no del sistema. */
    signals?: BrandCanvasSignal[];
    /** Apaga la escena y deja la tinta limpia. */
    scene?: boolean;
    paused?: boolean;
    style?: CSSProperties;
}
export declare function BrandHero({ eyebrow, title, accent, description, footer, signals, scene, paused, style, }: BrandHeroProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface BulletRow {
    label: string;
    value: number;
    target: number;
    prev?: number;
    max?: number;
    color?: string;
    icon?: string;
}
export interface BulletChartProps {
    rows: BulletRow[];
    color?: string;
    format?: (value: number) => string;
    style?: CSSProperties;
}
export declare function BulletChart(props: BulletChartProps): import("react").JSX.Element;

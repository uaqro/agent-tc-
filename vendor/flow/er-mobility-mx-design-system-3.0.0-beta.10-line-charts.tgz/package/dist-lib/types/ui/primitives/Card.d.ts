import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';
export type CardPadding = 'none' | 'sm' | 'md' | 'lg';
export interface CardProps {
    /** Escala primero ('none'/'sm'/'md'/'lg'; md = --pad-card, sensible a
        densidad). Un valor libre es puente de migración, no destino. */
    padding?: CardPadding | string | number;
    surface?: 'elevated' | 'outlined' | 'inverse';
    hover?: 'lift' | 'fill' | 'none';
    interactive?: boolean;
    /** Franja de estado en el borde de ataque (--status-*). Es refuerzo:
        el estado se dice también en el contenido (crd-6). */
    status?: 'success' | 'warning' | 'danger' | 'info';
    /** Seleccionada (tarjetas-lista): borde fuerte + superficie tenue,
        legible sin color (crd-3). */
    selected?: boolean;
    children: ReactNode;
    onClick?: MouseEventHandler<HTMLDivElement>;
    style?: CSSProperties;
}
export declare function Card({ padding, surface, hover, interactive, status, selected, children, onClick, style, }: CardProps): import("react").JSX.Element;

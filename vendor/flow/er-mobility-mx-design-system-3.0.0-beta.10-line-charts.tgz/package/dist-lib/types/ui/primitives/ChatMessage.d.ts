import type { ReactNode, CSSProperties } from 'react';
interface ToolChip {
    label: string;
    icon?: string;
    status?: 'running' | 'done';
}
export interface ChatMessageProps {
    role?: 'user' | 'agent';
    text?: string;
    tool?: ToolChip;
    streaming?: boolean;
    children?: ReactNode;
    timestamp?: string;
    style?: CSSProperties;
}
export declare function ChatMessage({ role, text, tool, streaming, children, timestamp, style, }: ChatMessageProps): import("react").JSX.Element;
export {};

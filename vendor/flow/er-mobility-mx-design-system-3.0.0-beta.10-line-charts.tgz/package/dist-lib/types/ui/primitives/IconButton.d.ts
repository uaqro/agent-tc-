import type { CSSProperties, MouseEventHandler } from 'react';
export type IconButtonVariant = 'ghost' | 'tonal' | 'primary' | 'secondary';
export type IconButtonSize = 'sm' | 'md' | 'lg';
export interface IconButtonProps {
    'aria-haspopup'?: 'menu' | 'dialog' | 'listbox' | 'true' | boolean;
    'aria-expanded'?: boolean;
    'aria-describedby'?: string;
    icon: string;
    ariaLabel: string;
    variant?: IconButtonVariant;
    size?: IconButtonSize;
    selected?: boolean;
    badge?: boolean;
    /** Default `'button'`: un icono de acción no envía formularios. Sin esto,
        un IconButton dentro de un form lo enviaba y no había forma de
        impedirlo — la prop no existía (ib-type). */
    type?: 'button' | 'submit' | 'reset';
    disabled?: boolean;
    onClick?: MouseEventHandler<HTMLButtonElement>;
    style?: CSSProperties;
}
export declare function IconButton({ 'aria-haspopup': ariaHasPopup, 'aria-expanded': ariaExpanded, 'aria-describedby': ariaDescribedBy, icon, ariaLabel, variant, size, selected, badge, type, disabled, onClick, style, }: IconButtonProps): import("react").JSX.Element;

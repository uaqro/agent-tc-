import type { CSSProperties } from 'react';
export type AvatarSize = 'sm' | 'md' | 'lg' | 'xl';
export type AvatarStatus = 'online' | 'busy' | 'offline';
export interface AvatarProps {
    name?: string;
    size?: AvatarSize;
    status?: AvatarStatus;
    src?: string;
    style?: CSSProperties;
}
export declare function Avatar({ name, size, status, src, style }: AvatarProps): import("react").JSX.Element;

export declare function avisaControladaSinCallback(pieza: string, prop: string, callback: string, controlada: boolean, tieneCallback: boolean): void;

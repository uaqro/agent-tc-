import type { CSSProperties } from 'react';
export interface NavCardProps {
    label: string;
    name: string;
    href: string;
    direction?: 'prev' | 'next';
    style?: CSSProperties;
}
export declare function NavCard({ label, name, href, direction, style }: NavCardProps): import("react").JSX.Element;

import type { CSSProperties, ReactNode } from 'react';
export interface ChipGroupProps {
    children: ReactNode;
    style?: CSSProperties;
}
export declare function ChipGroup({ children, style }: ChipGroupProps): import("react").JSX.Element;

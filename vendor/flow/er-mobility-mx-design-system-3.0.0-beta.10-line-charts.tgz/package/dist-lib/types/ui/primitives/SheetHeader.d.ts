import type { CSSProperties, ReactNode } from 'react';
export interface SheetHeaderProps {
    title: ReactNode;
    trailing?: ReactNode;
    id?: string;
    size?: 'sm' | 'md';
    style?: CSSProperties;
}
export declare function SheetHeader({ title, trailing, id, size, style }: SheetHeaderProps): import("react").JSX.Element;

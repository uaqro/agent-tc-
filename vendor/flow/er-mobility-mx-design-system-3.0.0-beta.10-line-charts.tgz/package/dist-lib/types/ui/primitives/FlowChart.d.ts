import { type CSSProperties } from 'react';
export type FlowChartType = 'line' | 'area' | 'bar' | 'stackedBar' | 'stacked100' | 'donut' | 'pie' | 'scatter' | 'heatmap' | 'radar' | 'waterfall' | 'pareto' | 'gauge' | 'funnel' | 'treemap' | 'boxplot';
export interface ChartSeries {
    label: string;
    /** null is a missing observation, never a zero or an interpolated point. */
    values?: Array<number | null>;
    gapLabel?: string;
    data?: Array<{
        label: string;
        value: number;
        color?: string;
        icon?: string;
    }>;
    color?: string;
    icon?: string;
    symbolSize?: number;
    [k: string]: unknown;
}
export interface ChartMatrix {
    rows: string[];
    cols: string[];
    columnRole?: 'category' | 'number' | 'time';
    values: [number, number, number][];
}
export interface FlowChartProps {
    /** Solo pareto: fracción (0–1) del corte acumulado — colorea las barras Y dibuja la línea de referencia (prt-3). */
    threshold?: number;
    /** Solo donut: grosor del anillo en px. El radio vivía en duro, y el escape
        de `option` no sirve para tocarlo —su merge REEMPLAZA arrays, así que
        pasar `series` borraría los datos—, así que `Donut thickness` era una prop
        declarada que nadie leía (ctl-4). */
    thickness?: number;
    type?: FlowChartType;
    series?: ChartSeries[];
    plotSurface?: 'none' | 'canvas';
    axisLabels?: {
        x?: string;
        y?: string;
    };
    labels?: string[];
    matrix?: ChartMatrix;
    indicators?: Array<string | {
        name: string;
        max: number;
        icon?: string;
    }>;
    totals?: number[];
    target?: number;
    max?: number;
    min?: number;
    valueIcon?: string;
    valueLabel?: string;
    percentLabel?: string;
    format?: (value: number) => string;
    /** Numeric axes only; defaults to format for backwards compatibility. */
    axisFormat?: (value: number) => string;
    gapLabel?: string;
    palette?: 'auto' | 'duo' | 'categorical';
    highlight?: string;
    animate?: boolean;
    loading?: boolean;
    height?: number;
    legend?: boolean;
    stack?: boolean;
    smooth?: boolean;
    horizontal?: boolean;
    showValues?: boolean;
    area?: boolean;
    itemColors?: string[];
    color?: string;
    thresholds?: [number, string][];
    option?: Record<string, unknown>;
    onSelect?: (params: unknown) => void;
    ariaLabel: string;
    emptyLabel?: string;
    style?: CSSProperties;
}
export declare function readTokens(el: HTMLElement): {
    labelPadding: number[];
    labelRadius: number;
    cellGap: number;
    cellRadius: number;
    stackGap: number;
    inlineGap: number;
    captionSize: number | undefined;
    iconSize: number;
    fontSymbol: string;
    categoryColor: string;
    categorySize: number | undefined;
    categoryWeight: number | undefined;
    axisNumberSize: number | undefined;
    axisNumberWeight: number | undefined;
    numeralSize: number | undefined;
    numeralWeight: number | undefined;
    resolve: (c: string) => string;
    palette: string[];
    ramp: string[];
    scale: string[];
    accent: string;
    positive: string;
    negative: string;
    neutral: string;
    grid: string;
    axis: string;
    label: string;
    tipBg: string;
    tipText: string;
    card: string;
    plotBg: string;
    sombraRealce: string;
    tinta: string;
    text: string;
    muted: string;
    fontBody: string;
    fontMono: string;
    kpiWeight: number | undefined;
    kpiSize: number | undefined;
};
export type Tokens = ReturnType<typeof readTokens>;
export declare function buildOption(type: FlowChartType, props: FlowChartProps, tk: Tokens): any;
export declare function FlowChart({ type, height, loading, emptyLabel, option: override, onSelect, ariaLabel, style, ...rest }: FlowChartProps): import("react").JSX.Element;

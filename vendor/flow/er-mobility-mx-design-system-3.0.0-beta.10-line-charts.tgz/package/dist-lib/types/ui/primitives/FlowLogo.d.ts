import type { CSSProperties } from 'react';
export interface FlowLogoProps {
    height?: number;
    /** navigation escala con densidad y cabe en el carril; height explícito conserva el override. */
    variant?: 'default' | 'navigation';
    /** Con `'inherit'` la marca entera sale de `currentColor` (fl-2): el rojo de
        Edenred no se lee como marca sobre una superficie oscura, y hasta ahora
        cada pantalla lo resolvía invirtiendo un <img> con un filtro. Mismo
        precedente que `CircularProgress`. */
    tone?: 'brand' | 'inherit';
    style?: CSSProperties;
}
export declare function FlowLogo({ height, variant, tone, style }: FlowLogoProps): import("react").JSX.Element;

import { type ReactNode, type CSSProperties, type FocusEvent, type KeyboardEvent } from 'react';
export interface InputProps {
    name?: string;
    required?: boolean;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    /** inp-12: teclas del campo — Enter confirma, Escape cancela. Sin esto,
        quien las necesita (una celda que se edita en línea) acaba montando un
        <input> crudo y redeclarando foco, altura y tokens (R3). */
    onKeyDown?: (e: KeyboardEvent<HTMLInputElement>) => void;
    /** Toma el foco al montar. Solo donde el campo SUSTITUYE a algo que ya lo
        tenía —una celda que pasa a edición—, nunca al abrir una pantalla. */
    autoFocus?: boolean;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
    value?: string;
    onChange?: (value: string) => void;
    placeholder?: string;
    icon?: string;
    size?: 'sm' | 'md' | 'lg';
    filled?: boolean;
    disabled?: boolean;
    /** Estado inválido — el nombre canónico, como en Textarea/InputAmount/InputPhone. */
    invalid?: boolean;
    /** @deprecated Alias de `invalid` (nombre viejo de eOne). */
    error?: boolean;
    type?: string;
    revealable?: boolean;
    /** Adorno al final del control (unidad, contador, icono). */
    trailing?: ReactNode;
    mono?: boolean;
    /** Nombre accesible cuando no hay <Field> que etiquete el control. */
    ariaLabel?: string;
    /** Autorrelleno del navegador (email, current-password, tel…): sin esto
        el gestor de contraseñas no funciona. */
    autoComplete?: string;
    style?: CSSProperties;
    id?: string;
}
export declare const Input: import("react").ForwardRefExoticComponent<InputProps & import("react").RefAttributes<HTMLInputElement>>;

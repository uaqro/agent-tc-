import { type ReactNode, type RefObject } from 'react';
export type PopoverSide = 'top' | 'bottom' | 'left' | 'right';
export type PopoverPlacement = PopoverSide | `${PopoverSide}-${'start' | 'center' | 'end'}`;
export interface PopoverProps {
    trigger?: ReactNode;
    /** @deprecated Usa placement ('left' ≙ bottom-start, 'right' ≙ bottom-end). */
    align?: 'left' | 'right';
    /** Lado y alineación en el eje cruzado. Default 'bottom-start'. */
    placement?: PopoverPlacement;
    /** Separación en px entre ancla y panel. Default 6. */
    offset?: number;
    /** Ancla externa: el panel se posiciona junto a ese elemento en vez del trigger. */
    anchorRef?: RefObject<HTMLElement | null>;
    /** El panel toma el ancho del ancla (dropdowns tipo Select). Default false. */
    matchAnchorWidth?: boolean;
    minWidth?: number;
    /** 'none' deja el panel sin piel: el consumidor la pinta. El shell sigue siendo dueño del anclaje y la colisión. */
    surface?: 'card' | 'none';
    /** pp-8: la capa de apilado del panel. El portal la vuelve decisión del shell
        —el panel sale del árbol del consumidor, así que su .module.css ya no
        puede elevarlo—. Default 'popover'. */
    layer?: 'popover' | 'tooltip';
    /** false para un panel que no se puede señalar (tooltips informativos). Default true. */
    interactive?: boolean;
    /** Al cerrar, el foco regresa a este elemento (default: el trigger). */
    returnFocusRef?: RefObject<HTMLElement | null>;
    children: ReactNode | ((helpers: {
        close: () => void;
    }) => ReactNode);
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    /** El envoltorio del trigger es inline (shrink-to-fit) para menus y botones.
        Un control de campo (Select) necesita llenar su contenedor: sin esto, el
        ancho depende del contenido y asignar/limpiar mueve el layout. */
    fillTrigger?: boolean;
    /** mnu-5: la raiz declara su alineacion propia — como hijo de un flex de
        alto fijo se estiraba y el disparador con el. La fija el dueno (Menu),
        no el shell: un control de campo en columna necesita el stretch. */
    selfAlign?: 'auto' | 'flex-start' | 'center' | 'flex-end' | 'stretch';
}
export declare function Popover({ trigger, fillTrigger, selfAlign, align, placement, offset, anchorRef, matchAnchorWidth, minWidth, surface, layer, interactive, returnFocusRef, children, open: controlledOpen, onOpenChange, }: PopoverProps): import("react").JSX.Element;

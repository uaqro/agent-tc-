import type { ReactNode, CSSProperties } from 'react';
export type BadgeTone = 'neutral' | 'success' | 'warning' | 'danger' | 'info' | 'accent';
export interface BadgeProps {
    tone?: BadgeTone;
    icon?: string;
    live?: boolean;
    as?: 'span' | 'kbd';
    children?: ReactNode;
    style?: CSSProperties;
}
export declare function Badge({ tone, icon, live, as: Tag, children, style }: BadgeProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface LimitBarProps {
    label: string;
    current: number;
    max: number;
    /** Qué significa cruzar el 100%: en un techo (`cap`, default) es un
        problema — danger; en un objetivo (`goal`) es la meta cumplida —
        success. Cazado en eOne: su objetivo de unidades (≥ 92%) pintaba
        danger justo al cumplirse. */
    kind?: 'cap' | 'goal';
    /** Etiqueta arriba y valores abajo, en dos FILAS — para tarjetas
        estrechas donde la fila única obliga a envolver ambos lados en un
        dos-columnas apretado (cazado en eOne: sus tarjetas-medidor). */
    stacked?: boolean;
    /** Solo la PISTA, sin encabezado — para composiciones que ya dicen
        etiqueta y valores en su propio lenguaje (las tarjetas-medidor de
        eOne hablan en el idioma del StatTile). Conserva kind y el estado
        over/met en el relleno. */
    bare?: boolean;
    /** Formatea los valores del encabezado. Por defecto, moneda con $ — el
        origen wallet de la pieza; un techo de litros o un objetivo en % pasan
        el suyo (cazado en eOne, 7-sep: pintaba «$70.952,8» para litros). */
    format?: (value: number) => string;
    style?: CSSProperties;
}
export declare function LimitBar({ label, current, max, kind, stacked, bare, format, style }: LimitBarProps): import("react").JSX.Element;

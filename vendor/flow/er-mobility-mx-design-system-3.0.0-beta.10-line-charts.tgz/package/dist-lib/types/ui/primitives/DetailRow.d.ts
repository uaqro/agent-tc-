import type { CSSProperties, ReactNode } from 'react';
export interface DetailRowProps {
    label: ReactNode;
    value: ReactNode;
    mono?: boolean;
    /** Qué etiquetas se emiten (dr-2). `definition` envuelve un `<dt>` y un
        `<dd>` en el mismo `<div>`, que es lo que una `<dl>` admite como hijo: la
        semántica de lista de definiciones se pierde si la fila es dos `<span>`.
        `div` sigue siendo el defecto porque la mayoría de las filas no viven
        dentro de una `<dl>` y un `<dt>` suelto no significa nada. */
    as?: 'div' | 'definition';
    style?: CSSProperties;
}
export declare function DetailRow({ label, value, mono, as, style }: DetailRowProps): import("react").JSX.Element;

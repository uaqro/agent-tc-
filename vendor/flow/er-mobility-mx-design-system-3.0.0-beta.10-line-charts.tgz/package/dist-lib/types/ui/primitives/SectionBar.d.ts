import type { CSSProperties, ReactNode } from 'react';
export interface SectionBarProps {
    children: ReactNode;
    trailing?: ReactNode;
    sticky?: boolean;
    /** Centra el contenido a --content-max (para barras full-bleed de página). */
    contained?: boolean;
    style?: CSSProperties;
}
export declare function SectionBar({ children, trailing, sticky, contained, style }: SectionBarProps): import("react").JSX.Element;

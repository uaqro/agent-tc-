import type { CSSProperties, ReactNode } from 'react';
export interface EmptyStateProps {
    icon?: string;
    title: string;
    description?: string;
    action?: ReactNode;
    style?: CSSProperties;
}
export declare function EmptyState({ icon, title, description, action, style }: EmptyStateProps): import("react").JSX.Element;

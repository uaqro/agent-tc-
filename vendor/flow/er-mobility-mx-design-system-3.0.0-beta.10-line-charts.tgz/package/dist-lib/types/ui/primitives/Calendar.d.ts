import type { CSSProperties } from 'react';
export interface CalendarProps {
    selected?: string[];
    rangeStart?: string;
    rangeEnd?: string;
    /** Fecha mínima seleccionable (ISO). */
    min?: string;
    /** Fecha máxima seleccionable (ISO). */
    max?: string;
    /** cal-3: mes visible controlado, 'YYYY-MM'. Sin él, el calendario lleva el
        suyo y lo ancla en la fecha seleccionada (cst-3). Con él, navegar no lo
        mueve: lo reporta y el dueño decide — que es lo que permite pedir la
        disponibilidad del mes antes de pintarlo. */
    month?: string;
    /** El mes visible se reporta con el valor nuevo, 'YYYY-MM' (cst-1). */
    onMonthChange?: (month: string) => void;
    onSelect?: (date: string) => void;
    onClear?: () => void;
    onToday?: () => void;
    hint?: string;
    style?: CSSProperties;
}
export declare function Calendar({ selected, rangeStart, rangeEnd, min, max, month: monthProp, onMonthChange, onSelect, onClear, onToday, hint, style, }: CalendarProps): import("react").JSX.Element;

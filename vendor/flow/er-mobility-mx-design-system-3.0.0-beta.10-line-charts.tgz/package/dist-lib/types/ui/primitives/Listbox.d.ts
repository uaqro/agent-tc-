import { type ReactNode } from 'react';
export interface ListboxItem {
    value: string | number;
    label: string;
    group?: string;
    disabled?: boolean;
    [key: string]: unknown;
}
export interface ListboxProps<T extends ListboxItem = ListboxItem> {
    /** Modo combobox: el dueño (Select) conduce el resaltado desde su trigger y
        este indice manda; el interno queda para uso directo. */
    active?: number;
    onActiveChange?: (index: number) => void;
    items?: T[];
    value?: string | number;
    onChange?: (item: T) => void;
    renderItem?: (item: T, state: {
        selected: boolean;
        active: boolean;
    }) => ReactNode;
    id?: string;
}
export declare function Listbox<T extends ListboxItem = ListboxItem>({ items, value, onChange, renderItem, id, active: controlado, onActiveChange, }: ListboxProps<T>): import("react").JSX.Element;

import { type ReactNode } from 'react';
export interface OverlayShellProps {
    open: boolean;
    onClose?: () => void;
    /** 'top' es arriba y centrada: la posición de una paleta de comandos, que
        no es ni `center` —se hunde— ni `start` —se va al borde izquierdo—. */
    alignment?: 'center' | 'top' | 'end' | 'start' | 'bottom';
    /** false para diálogos que exigen decisión: el backdrop no cierra. Default true. */
    dismissOnBackdrop?: boolean;
    /** Id del titulo que etiqueta este dialogo (aria-labelledby en la carcasa).
        OBLIGATORIO: un `role="dialog" aria-modal` sin nombre no lo anuncia ningun
        lector de pantalla, y era opcional — asi que cuatro capas del sistema
        salian sin nombre, tres de ellas con el titulo delante y sin cablear. El
        canon lo exige desde siempre. Si la capa no tiene titulo visible, se
        nombra por lo que ES con un nodo `data-sr-only`, como hacen BottomSheet
        sin titulo y la paleta de GlobalSearch. */
    labelledBy: string;
    children: ReactNode;
}
export declare function OverlayShell({ open, onClose, alignment, dismissOnBackdrop, labelledBy, children, }: OverlayShellProps): import("react").ReactPortal | null;

import type { CSSProperties, FocusEvent } from 'react';
export interface CheckboxProps {
    name?: string;
    required?: boolean;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    /** Nombre por referencia — Field y SettingsRow lo inyectan. */
    'aria-labelledby'?: string;
    /** Nombre accesible cuando no hay label visible ni Field que etiquete: una
        casilla en una columna de tabla. Antes se pasaba `aria-label` y la pieza
        lo tiraba — la casilla quedaba anónima sin que nadie avisara (cbx-5). */
    ariaLabel?: string;
    /** Para que Field htmlFor alcance al control (fld-1). */
    id?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
    checked?: boolean;
    indeterminate?: boolean;
    onChange?: (checked: boolean) => void;
    label?: string;
    description?: string;
    disabled?: boolean;
    style?: CSSProperties;
}
export declare const Checkbox: import("react").ForwardRefExoticComponent<CheckboxProps & import("react").RefAttributes<HTMLInputElement>>;

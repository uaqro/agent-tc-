import type { CSSProperties } from 'react';
export type SkeletonVariant = 'text' | 'title' | 'card' | 'circle';
export interface SkeletonProps {
    variant?: SkeletonVariant;
    width?: number | string;
    height?: number | string;
    style?: CSSProperties;
}
export declare function Skeleton({ variant, width, height, style }: SkeletonProps): import("react").JSX.Element;

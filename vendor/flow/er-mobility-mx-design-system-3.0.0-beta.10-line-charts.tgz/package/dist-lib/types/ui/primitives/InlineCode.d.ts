import type { CSSProperties, ReactNode } from 'react';
export interface InlineCodeProps {
    children: ReactNode;
    style?: CSSProperties;
}
export declare function InlineCode({ children, style }: InlineCodeProps): import("react").JSX.Element;

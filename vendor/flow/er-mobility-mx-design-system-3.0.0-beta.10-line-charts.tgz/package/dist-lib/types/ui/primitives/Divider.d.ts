import type { CSSProperties } from 'react';
export interface DividerProps {
    orientation?: 'horizontal' | 'vertical';
    label?: string;
    style?: CSSProperties;
}
export declare function Divider({ orientation, label, style }: DividerProps): import("react").JSX.Element;

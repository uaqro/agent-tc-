import { type ReactNode, type CSSProperties } from 'react';
export interface FieldProps {
    label: string;
    htmlFor?: string;
    required?: boolean;
    help?: string;
    error?: string;
    valid?: boolean;
    validMessage?: string;
    children: ReactNode;
    style?: CSSProperties;
}
export declare function Field({ label, htmlFor, required, help, error, valid, validMessage, children, style }: FieldProps): import("react").JSX.Element;

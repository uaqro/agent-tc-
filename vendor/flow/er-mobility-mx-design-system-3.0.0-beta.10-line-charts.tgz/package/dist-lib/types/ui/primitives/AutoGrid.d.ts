import type { CSSProperties, ReactNode } from 'react';
export interface AutoGridProps {
    minWidth?: string;
    gap?: string;
    children: ReactNode;
    style?: CSSProperties;
}
export declare function AutoGrid({ minWidth, gap, children, style }: AutoGridProps): import("react").JSX.Element;

import type { CSSProperties, MouseEventHandler } from 'react';
export interface ChipProps {
    label: string;
    size?: 'sm' | 'md';
    variant?: 'default' | 'ghost';
    mono?: boolean;
    selected?: boolean;
    onClick?: MouseEventHandler<HTMLButtonElement>;
    onRemove?: () => void;
    icon?: string;
    disabled?: boolean;
    style?: CSSProperties;
}
export declare function Chip({ label, size, variant, mono, selected, onClick, onRemove, icon, disabled, style, }: ChipProps): import("react").JSX.Element;

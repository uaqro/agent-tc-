import type { CSSProperties } from 'react';
export interface ProgressProps {
    value?: number;
    max?: number;
    label?: string;
    showValue?: boolean;
    tone?: 'accent' | 'success' | 'warning' | 'ink';
    style?: CSSProperties;
}
export declare function Progress({ value, max, label, showValue, tone, style }: ProgressProps): import("react").JSX.Element;

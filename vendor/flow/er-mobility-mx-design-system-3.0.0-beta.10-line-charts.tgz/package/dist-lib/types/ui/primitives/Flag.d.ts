import { type CSSProperties } from 'react';
export interface FlagProps {
    country: string;
    size?: number;
    shape?: 'circle' | 'rounded' | 'square';
    label?: string;
    ring?: boolean;
    style?: CSSProperties;
}
export declare function Flag({ country, size, shape, label, ring, style }: FlagProps): import("react").JSX.Element;

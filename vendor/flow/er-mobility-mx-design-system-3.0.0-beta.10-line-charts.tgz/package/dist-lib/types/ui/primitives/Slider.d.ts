import { type CSSProperties, type FocusEvent } from 'react';
export interface SliderProps {
    name?: string;
    required?: boolean;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    /** Para que Field htmlFor alcance al control (fld-1). */
    id?: string;
    value?: number;
    onChange?: (value: number) => void;
    min?: number;
    max?: number;
    step?: number;
    label?: string;
    format?: (value: number) => string;
    disabled?: boolean;
    style?: CSSProperties;
    'aria-labelledby'?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
}
export declare const Slider: import("react").ForwardRefExoticComponent<SliderProps & import("react").RefAttributes<HTMLInputElement>>;

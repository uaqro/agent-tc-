import type { CSSProperties, ReactNode } from 'react';
export interface CircularProgressProps {
    value?: number;
    max?: number;
    size?: number;
    strokeWidth?: number;
    /** Texto VISIBLE bajo el anillo. El nombre accesible es `ariaLabel`. */
    label?: string;
    /** cpr-6: el nombre accesible del progressbar, separado del texto visible.
        Eran una sola prop haciendo los dos trabajos. */
    ariaLabel?: string;
    showValue?: boolean;
    /** cpr-5: lo que va DENTRO del anillo —los segundos que quedan, una cifra con
        su unidad—. Sustituye al porcentaje de `showValue`. */
    children?: ReactNode;
    tone?: 'accent' | 'success' | 'warning' | 'danger' | 'inherit';
    style?: CSSProperties;
}
export declare function CircularProgress({ value, max, size, strokeWidth, label, ariaLabel, showValue, children, tone, style, }: CircularProgressProps): import("react").JSX.Element;

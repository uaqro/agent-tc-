export interface BreadcrumbItem {
    label: string;
    href?: string;
    /** Reemplaza el label visible con un icono (el label queda como aria-label). */
    icon?: string;
}
export interface BreadcrumbProps {
    items?: BreadcrumbItem[];
    variant?: 'default' | 'subtle';
    homeIcon?: string;
}
export declare function Breadcrumb({ items, variant, homeIcon }: BreadcrumbProps): import("react").JSX.Element;

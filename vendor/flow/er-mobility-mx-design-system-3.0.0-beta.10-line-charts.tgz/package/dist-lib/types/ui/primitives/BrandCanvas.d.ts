import { type CSSProperties } from 'react';
/** Una señal de la escena: lo que una vertical está diciendo ahora mismo.
    Son palabras del PRODUCTO —no las inventa el sistema (bc-5)—. */
export interface BrandCanvasSignal {
    /** El nombre de la vertical. Se rotula en versalitas, en su color. */
    name: string;
    /** Lo que acaba de pasar. Ej: «Carga registrada · 42 L». */
    detail?: string;
    /** De quién. Ej: «Unidad 0427 · Datos de demostración». */
    unit?: string;
}
export interface BrandCanvasProps {
    /** Hasta cuatro, una por vertical. Sin ellas la escena va sin tarjetas, y
        sigue siendo una escena. */
    signals?: BrandCanvasSignal[];
    /** Pausa el movimiento sin cambiar lo que se ve: la escena queda completa. */
    paused?: boolean;
    style?: CSSProperties;
}
export declare function BrandCanvas({ signals, paused, style }: BrandCanvasProps): import("react").JSX.Element;

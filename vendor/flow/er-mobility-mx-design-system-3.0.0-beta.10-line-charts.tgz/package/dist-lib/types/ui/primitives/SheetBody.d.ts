import type { CSSProperties, ReactNode } from 'react';
export interface SheetBodyProps {
    children: ReactNode;
    center?: boolean;
    style?: CSSProperties;
}
export declare function SheetBody({ children, center, style }: SheetBodyProps): import("react").JSX.Element;

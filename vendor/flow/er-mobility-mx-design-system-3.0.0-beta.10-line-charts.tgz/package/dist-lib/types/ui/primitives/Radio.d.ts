import type { CSSProperties, FocusEvent } from 'react';
export interface RadioProps {
    required?: boolean;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    /** Para que Field htmlFor alcance al control (fld-1). */
    id?: string;
    name?: string;
    value?: string;
    checked?: boolean;
    onChange?: (value: string) => void;
    label?: string;
    description?: string;
    disabled?: boolean;
    style?: CSSProperties;
    'aria-labelledby'?: string;
    /** Nombre accesible sin label visible (cbx-5). */
    ariaLabel?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
}
export declare const Radio: import("react").ForwardRefExoticComponent<RadioProps & import("react").RefAttributes<HTMLInputElement>>;

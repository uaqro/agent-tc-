import { type ReactNode, type CSSProperties, type MouseEventHandler } from 'react';
export interface ControlShellProps {
    size?: 'sm' | 'md' | 'lg';
    filled?: boolean;
    disabled?: boolean;
    /** Estado inválido — el nombre canónico, como en Input/Textarea. */
    invalid?: boolean;
    /** @deprecated Alias de `invalid` (nombre viejo). */
    error?: boolean;
    leading?: ReactNode;
    trailing?: ReactNode;
    footer?: ReactNode;
    children: ReactNode;
    style?: CSSProperties;
    onClick?: MouseEventHandler<HTMLDivElement>;
}
export declare const ControlShell: import("react").ForwardRefExoticComponent<ControlShellProps & import("react").RefAttributes<HTMLDivElement>>;

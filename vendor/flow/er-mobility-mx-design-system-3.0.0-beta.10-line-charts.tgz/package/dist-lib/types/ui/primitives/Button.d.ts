import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';
export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'link';
export type ButtonSize = 'sm' | 'md' | 'lg';
export interface ButtonProps {
    'aria-haspopup'?: 'menu' | 'dialog' | 'listbox' | 'true' | boolean;
    'aria-expanded'?: boolean;
    'aria-describedby'?: string;
    variant?: ButtonVariant;
    size?: ButtonSize;
    icon?: string;
    iconTrailing?: string;
    loading?: boolean;
    disabled?: boolean;
    fullWidth?: boolean;
    /** Default `'button'`: una pieza de acción no envía formularios. El default
        del HTML es `submit`, y eso convertía cualquier Button dentro de un form
        en un botón de envío accidental (btn-type). */
    type?: 'button' | 'submit' | 'reset';
    ariaLabel?: string;
    onClick?: MouseEventHandler<HTMLButtonElement>;
    children?: ReactNode;
    style?: CSSProperties;
}
export declare function Button({ variant, size, icon, iconTrailing, loading, disabled, fullWidth, onClick, ariaLabel, children, style, type, ...rest }: ButtonProps): import("react").JSX.Element;

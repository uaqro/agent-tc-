import { type ReactNode } from 'react';
export interface OverlayScopeProps {
    /** La superficie embebida. Las capas que se monten dentro se quedan dentro. */
    children: ReactNode;
}
/**
 * Delimita las capas de una superficie EMBEBIDA: el portal, el backdrop y el
 * bloqueo de scroll se quedan dentro.
 *
 * `OverlayShell` portaliza a `document.body` y bloquea el scroll de la página,
 * que es lo correcto cuando la capa es de la pantalla. Dentro del marco de
 * teléfono de las demos no lo era: una hoja cubría el navegador en vez de
 * cubrir el teléfono. La alternativa era que cada consumidor pisara los
 * selectores internos de OverlayShell, que es lo que R4 evita.
 *
 * Sin props más que `children` a propósito (ovs-5): un ámbito con opciones
 * deja de ser un ámbito. Lo que publica no es API, es el contexto que
 * OverlayShell consume — y sin ámbito el comportamiento es el de siempre, así
 * que ningún consumidor de hoy cambia (ovs-3).
 */
export declare function OverlayScope({ children }: OverlayScopeProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface ScaleLegendProps {
    minLabel: string;
    maxLabel: string;
    /** Refuerzo temático: chico junto al mínimo, grande junto al máximo. */
    icon?: string;
    /** Swatches de menor a mayor. Default: la escala de color del sistema. */
    colors?: string[];
    /** Casilla de ausencia de dato, separada de la escala. */
    emptyLabel?: string;
    emptyColor?: string;
    style?: CSSProperties;
}
export declare function ScaleLegend({ minLabel, maxLabel, icon, colors, emptyLabel, emptyColor, style, }: ScaleLegendProps): import("react").JSX.Element;

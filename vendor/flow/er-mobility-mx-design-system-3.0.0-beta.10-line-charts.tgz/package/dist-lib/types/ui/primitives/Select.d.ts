import { type CSSProperties, type ReactNode, type ReactElement } from 'react';
export interface SelectOption {
    value: string;
    label: string;
    icon?: string;
    group?: string;
}
export interface SelectProps<M extends boolean = false> {
    options: Array<string | SelectOption>;
    value?: M extends true ? string[] : string;
    onChange?: (value: M extends true ? string[] : string) => void;
    multiple?: M;
    searchable?: boolean;
    /** sel-11: el dueño busca. Con ella la pieza NO filtra en memoria, porque
        `options` ES la respuesta a la consulta — volver a filtrarla escondería
        lo que el dueño acaba de devolver (que es lo que le pasaba a DataTable
        con `query` controlada). Abre el campo de búsqueda sin pedir
        `searchable`: sin dónde escribir no hay nada que buscar. El debounce es
        del dueño; la pieza reporta cada tecla. */
    onSearch?: (query: string) => void;
    /** sel-12: esperando opciones. La lista lo dice en vez de decir «sin
        resultados», que mientras se busca es lo contrario de la verdad. */
    loading?: boolean;
    creatable?: boolean;
    clearable?: boolean;
    renderOption?: (o: SelectOption) => ReactNode;
    size?: 'sm' | 'md' | 'lg';
    placeholder?: string;
    /** Label integrada compacta (filtros): viaja dentro del trigger y da el
        nombre accesible al control — 9 selects de eOne la piden (§6). */
    insetLabel?: string;
    icon?: string;
    disabled?: boolean;
    invalid?: boolean;
    /** Id del control focusable — permite asociar <Field htmlFor>. */
    id?: string;
    'aria-describedby'?: string;
    'aria-invalid'?: boolean;
    'aria-required'?: boolean;
    /** Nombre accesible por referencia (SettingsRow y afines lo inyectan). */
    'aria-labelledby'?: string;
    /** Apertura controlada. Sin ella la pieza se abre sola (cst-3). */
    open?: boolean;
    /** La apertura se reporta al dueño. Convención única del sistema (cst-6). */
    onOpenChange?: (open: boolean) => void;
    style?: CSSProperties;
}
export declare const Select: <M extends boolean = false>(props: SelectProps<M> & {
    ref?: React.Ref<HTMLSpanElement>;
}) => ReactElement;

import type { CSSProperties } from 'react';
export interface ChartLegendItem {
    label: string;
    color: string;
    value?: string;
    /** Valor o contexto complementario bajo la categoría. */
    detail?: string;
    icon?: string;
    shape?: 'circle' | 'square' | 'line';
}
export interface ChartLegendProps {
    items: ChartLegendItem[];
    /** Escala tipográfica: md para la leyenda principal de un gráfico. */
    size?: 'sm' | 'md';
    width?: 'content' | 'fill';
    /**
     * cl-2: la marca no-color que el gráfico dio a cada serie — el trazo si
     * dibuja líneas, la trama si rellena. El patrón sale del ÍNDICE del item, que
     * es el de su serie, así que el consumidor no tiene que saber qué trama le
     * tocó a la serie 3. Sin la prop, el swatch es el de siempre.
     */
    marks?: 'line' | 'fill';
    direction?: 'horizontal' | 'vertical';
    style?: CSSProperties;
}
export declare function ChartLegend({ items, marks, size, width, direction, style, }: ChartLegendProps): import("react").JSX.Element;

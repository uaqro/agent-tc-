import type { CSSProperties, ReactNode } from 'react';
export interface PageFrameProps {
    maxWidth?: string | number;
    children: ReactNode;
    as?: 'div' | 'main' | 'section';
    style?: CSSProperties;
}
/**
 * @deprecated Se retira en 4.0. El ancho y el centrado del contenido los
 * decide el LAYOUT, no una pieza que cada pantalla se envuelva.
 *
 * Nació para «reemplazar el patrón repetido de max-width + margin auto» y
 * nunca la montó nadie: medido, los tres layouts del banco —shell, consola
 * interna y docs— lo resuelven con `.main > * { max-width: var(--content-max);
 * margin-inline: auto }`, que es una regla por layout en vez de un envoltorio
 * por pantalla. Y no es que no se hubieran enterado: envolver ahí SUMA el
 * padding de esta pieza al de `.main`, y rompe el `gap` con el que el área de
 * contenido separa a sus hijos (spc-5), porque pasaría a tener uno solo.
 *
 * Si tu layout no tiene esa regla, cópiala: son dos declaraciones y las lleva
 * el contenedor con scroll, que es quien sabe de márgenes.
 */
export declare function PageFrame({ maxWidth, children, as: Tag, style }: PageFrameProps): import("react").JSX.Element;

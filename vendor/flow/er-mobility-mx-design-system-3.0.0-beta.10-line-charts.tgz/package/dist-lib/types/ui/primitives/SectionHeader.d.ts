import type { CSSProperties, ReactNode } from 'react';
export interface SectionHeaderProps {
    children: ReactNode;
    trailing?: ReactNode;
    size?: 'sm' | 'md' | 'display';
    /** Nivel del heading real que emite el titulo. El viejo emitia h2; el span
        que lo sustituyo rompia el outline del documento (×86 usos en eOne). */
    level?: 2 | 3 | 4;
    /** Bajada del título en muted, fuera del heading (sh-3): el outline
        dice el título limpio. `ReactNode` y no `string` porque el contexto de
        una sección lleva a veces un enlace o una cifra envuelta, y con `string`
        el consumidor la escribía fuera de la pieza. */
    description?: ReactNode;
    style?: CSSProperties;
}
export declare function SectionHeader({ children, trailing, size, level, description, style }: SectionHeaderProps): import("react").JSX.Element;

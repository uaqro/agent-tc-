import { type CSSProperties } from 'react';
export interface RideOfferProps {
    /** Las paradas en orden de lectura: la primera es el origen y la última el destino. */
    stops: string[];
    /** La etiqueta de cabecera: «NUEVO VIAJE · +1.8×». */
    tag?: string;
    /** Los datos del viaje en una fila: distancia, duración. */
    meta?: string[];
    /** El importe, que se lee aparte del resto de la fila. */
    amount?: string;
    /** Segundos para decidir. Sin ellos la propuesta no caduca y no hay anillo (rof-4). */
    seconds?: number;
    onExpire?: () => void;
    onAccept?: () => void;
    onPass?: () => void;
    acceptLabel?: string;
    passLabel?: string;
    style?: CSSProperties;
}
/**
 * RideOffer — la propuesta de viaje que llega a quien conduce.
 *
 * Nace de una medición (Solicitud #293): la pantalla del conductor la dibujaba
 * con SIETE clases locales —la superficie de acento, su realce, la overline,
 * los dos puntos de parada, la fila de meta y la rejilla de CTAs—. Eso es el
 * banco construyendo, no componiendo.
 */
export declare function RideOffer({ stops, tag, meta, amount, seconds, onExpire, onAccept, onPass, acceptLabel, passLabel, style, }: RideOfferProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
import { type BadgeTone } from '../primitives/Badge';
export interface InstallCardProps {
    platform: string;
    command: string;
    status?: string;
    statusTone?: BadgeTone;
    style?: CSSProperties;
}
export declare function InstallCard({ platform, command, status, statusTone, style }: InstallCardProps): import("react").JSX.Element;

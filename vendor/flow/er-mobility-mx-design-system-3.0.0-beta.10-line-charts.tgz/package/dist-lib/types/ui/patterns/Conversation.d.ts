import type { CSSProperties, ReactNode } from 'react';
import { type ChatMsg } from '../components/ChatThread';
export interface ConversationProps {
    messages: ChatMsg[];
    /** El borrador. Controlado, como en ChatComposer. */
    value?: string;
    onChange?: (value: string) => void;
    onSend?: (value: string) => void;
    /** Mientras el agente responde (cnv-2). */
    busy?: boolean;
    suggestions?: string[];
    placeholder?: string;
    /** Sin él, el hilo pone el suyo. Con él, manda éste (cnv-3). */
    emptyState?: ReactNode;
    style?: CSSProperties;
}
export declare function Conversation({ messages, value, onChange, onSend, busy, suggestions, placeholder, emptyState, style, }: ConversationProps): import("react").JSX.Element;

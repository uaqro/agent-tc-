import { type CSSProperties } from 'react';
export interface PaymentCardProps {
    holder: string;
    last4: string;
    variant?: 'ink' | 'accent' | 'sand' | 'fuel' | 'ev' | 'maintenance' | 'toll';
    frozen?: boolean;
    label?: string;
    icon?: string;
    expires?: string;
    balance?: string;
    hidden?: boolean;
    onToggleHidden?: () => void;
    /** Avisa cuando el gesto de congelar YA CERRÓ (pc-8). El gesto tiene dos
        tiempos y la pieza no llama al canal de feedback —eso es del producto
        (fbk-3)—, así que dice cuándo se asentó y el producto decide qué hacer
        con ello. */
    onFreezeSettled?: () => void;
    onClick?: () => void;
    style?: CSSProperties;
}
export declare function PaymentCard({ holder, last4, variant, frozen, label, icon, expires, balance, hidden, onToggleHidden, onFreezeSettled, onClick, style, }: PaymentCardProps): import("react").JSX.Element;

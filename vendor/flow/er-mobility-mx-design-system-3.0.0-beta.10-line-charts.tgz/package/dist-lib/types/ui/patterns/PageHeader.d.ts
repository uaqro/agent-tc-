import type { ReactNode, CSSProperties } from 'react';
import { type NotificationItem } from '../components/NotificationCenter';
export interface PageHeaderProps {
    /** ph-4: opcional. Una pantalla cuyo contenido ya se nombra —una tabla con
        su propio título— no pasa ninguno, y el encabezado lo pone ese contenido.
        Hubo una versión con `titleHidden` que dejaba el h1 en el DOM midiendo
        1×1: el resultado medido fue una página con UN encabezado, invisible,
        mientras lo que se veía era un <span>. Ocultar un encabezado no es
        tenerlo. */
    title?: string;
    overline?: string;
    description?: string;
    breadcrumb?: string[];
    filters?: ReactNode;
    actions?: ReactNode;
    /** ph-6: false apaga la fila de utilidades en esta pantalla. El default es
        que vengan del shell: un shell que hay que prender pantalla por pantalla
        acaba prendido en una de trece — medido. */
    utilities?: boolean;
    /** ph-5: prende el botón de búsqueda. La parte existe cuando hay a quién
        avisar, no cuando alguien la ensambla. */
    onSearch?: () => void;
    /** Nombre accesible del botón, con su atajo si lo hay. */
    searchLabel?: string;
    /** ph-5: prende la campana con su panel. Sin lista no hay campana. */
    notifications?: NotificationItem[];
    onNotificationClick?: (item: NotificationItem) => void;
    onMarkAllRead?: () => void;
    /** Dato de utilidad junto a la identidad —«3 abiertos de 6»—, con la
        tipografía que decide el patrón. `trailing` se queda para lo que no es
        texto. */
    meta?: ReactNode;
    trailing?: ReactNode;
    style?: CSSProperties;
}
export declare function PageHeader({ title, overline, description, breadcrumb, filters, actions, meta, utilities, onSearch, searchLabel, notifications, onNotificationClick, onMarkAllRead, trailing, style, }: PageHeaderProps): import("react").JSX.Element;

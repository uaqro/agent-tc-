import type { CSSProperties, ReactNode } from 'react';
export interface ProposalCardProps {
    before: ReactNode;
    after: ReactNode;
    beforeLabel?: string;
    afterLabel?: string;
    footer?: ReactNode;
    style?: CSSProperties;
}
export declare function ProposalCard({ before, after, beforeLabel, afterLabel, footer, style, }: ProposalCardProps): import("react").JSX.Element;

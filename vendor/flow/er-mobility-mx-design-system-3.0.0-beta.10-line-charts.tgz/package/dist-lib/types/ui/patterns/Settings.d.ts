import { type ReactNode } from 'react';
export interface SettingsRowProps {
    label: string;
    description?: string;
    control: ReactNode;
}
export declare function SettingsRow({ label, description, control }: SettingsRowProps): import("react").JSX.Element;
export interface SettingsSectionProps {
    title: string;
    children: ReactNode;
}
export declare function SettingsSection({ title, children }: SettingsSectionProps): import("react").JSX.Element;
export interface SettingsDangerZoneProps {
    title?: string;
    children: ReactNode;
}
export declare function SettingsDangerZone({ title, children }: SettingsDangerZoneProps): import("react").JSX.Element;
export interface SettingsDangerRowProps {
    description: string;
    action: ReactNode;
}
export declare function SettingsDangerRow({ description, action }: SettingsDangerRowProps): import("react").JSX.Element;
export interface SettingsProps {
    children: ReactNode;
}
export declare function Settings({ children }: SettingsProps): import("react").JSX.Element;

export declare const SidebarProvider: import("react").Provider<(() => void) | null>;
export declare function useSidebarToggle(): (() => void) | null;

import { type ReactNode } from 'react';
/**
 * Las cuatro formas en que una app deja entrar.
 *
 * `sso` es el TRASPASO: la app no recoge credenciales porque no es quien
 * autentica —lo hace un proveedor de identidad— y su contrato con el usuario
 * suele ser justamente que nunca ve su contraseña. Sin este modo, una pantalla
 * de SSO no tenía forma de usar este patrón: o pintaba campos que no puede
 * tener, o se escribía a mano (cazado en eOne, cuya única pantalla de acceso
 * es un traspaso a Edenred Connect).
 *
 * El SEGUNDO FACTOR no está aquí a propósito: es `OTPInput` o
 * `BiometricPrompt`, compuestos en la misma carcasa. Lo dice el canon.
 */
export type AuthMode = 'login' | 'signup' | 'recover' | 'sso';
/**
 * Las cinco situaciones cuya redacción prescribe SEC-GUI-040 §4.1.7 — la guía
 * de diseño seguro de la organización, control *Mandatory for all
 * applications*.
 *
 * La prop toma la SITUACIÓN y el texto lo pone el sistema, en los tres
 * idiomas. Eso es el control: `error` es una cadena libre, así que las
 * palabras las escribía cada producto, y el ejemplo que el propio documento
 * marca como incorrecto —«We just sent you a password reset link»— es lo que
 * escribe cualquiera que no haya leído la guía. Un design system es el sitio
 * donde esto se arregla una vez.
 *
 * `recover-sent` y `signup-sent` responden **lo mismo exista o no la cuenta**,
 * que es lo que `aut-p5` ya exigía sin que la implementación tuviera con qué
 * decirlo.
 *
 * `account-locked`, `account-inactive` y `password-expired` solo se muestran
 * **si la contraseña proporcionada era correcta**. Con credenciales incorrectas va el mensaje
 * genérico: «tu cuenta está bloqueada» le confirma a quien prueba contraseñas
 * que esa cuenta existe, que es exactamente lo que §4.1.7 viene a impedir.
 * Esa condición no es una nota al pie, es parte del control.
 *
 * `otp-expired` es del paso de segundo factor, que se compone metiendo
 * `OTPInput` en `children`. §4.1.7 admite ese mensaje específico por
 * experiencia de uso: decir que un código caducó no revela nada de la cuenta.
 *
 * Y **la cuenta inactiva es otro caso, no otra piel**: el texto prescrito dice
 * «Your account has been locked [OR Your account is inactive] … unlocking [OR
 * reactivation] process», o sea otro estado con otro flujo. Faltaba.
 */
export type AuthNotice = 'recover-sent' | 'signup-sent' | 'otp-expired' | 'account-locked' | 'account-inactive' | 'password-expired';
export interface AuthSubmitData {
    email: string;
    password: string;
    name: string;
    mode: AuthMode;
}
export interface AuthFormProps {
    mode: AuthMode;
    loading?: boolean;
    /** El rechazo del servidor —credenciales inválidas, cuenta bloqueada— en la
        misma caja que la validación local, y no en un Toast lejos del
        formulario que lo causó (aut-p7). Es del dueño: escribir en un campo no
        lo borra, solo él lo quita. */
    error?: string;
    /** La situación que §4.1.7 regula — el texto lo pone el sistema (aut-p8).
        Gana sobre `error`, que queda para lo que la guía no regula: el servidor
        caído, el límite de intentos. La condición de uso de las dos últimas
        está en `AuthNotice`. */
    notice?: AuthNotice;
    /** El destino del proceso de desbloqueo o reactivación, que es del producto:
        el sistema no puede inventar la URL. Sin él, el aviso dice el estado y se
        calla la invitación — prometer un enlace que no está es un callejón sin
        salida (aut-p9). */
    noticeHref?: string;
    onSubmit: (data: AuthSubmitData) => void;
    title?: ReactNode;
    subtitle?: ReactNode;
    children?: ReactNode;
    footer?: ReactNode;
    submitLabel?: string;
    /** Glifo del botón de envío — el candado del traspaso, la marca del
        proveedor. */
    submitIcon?: string;
}
export declare function AuthForm({ mode, loading, error, notice, noticeHref, onSubmit, title, subtitle, children, footer, submitLabel, submitIcon, }: AuthFormProps): import("react").JSX.Element;

import { type CSSProperties, type ReactNode } from 'react';
export interface OnboardingSlide {
    title: string;
    description?: string;
    illustration?: ReactNode;
    icon?: string;
}
export interface OnboardingCarouselProps {
    slides: OnboardingSlide[];
    index?: number;
    onIndexChange?: (index: number) => void;
    onSkip?: () => void;
    onDone?: () => void;
    skipLabel?: string;
    doneLabel?: string;
    style?: CSSProperties;
}
export declare function OnboardingCarousel({ slides, index, onIndexChange, onSkip, onDone, skipLabel, doneLabel, style, }: OnboardingCarouselProps): import("react").JSX.Element;

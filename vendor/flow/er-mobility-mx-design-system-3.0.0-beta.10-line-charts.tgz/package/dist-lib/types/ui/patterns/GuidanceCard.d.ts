import type { CSSProperties, ReactNode } from 'react';
export interface GuidanceCardProps {
    tone: 'success' | 'danger';
    rules: string[];
    specimen?: ReactNode;
    style?: CSSProperties;
}
export declare function GuidanceCard({ tone, rules, specimen, style }: GuidanceCardProps): import("react").JSX.Element;

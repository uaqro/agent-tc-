import type { CSSProperties, ReactNode } from 'react';
export interface ProfileMenuItem {
    icon: string;
    label: string;
    onClick: () => void;
}
export interface ProfileMenuProps {
    name: string;
    avatarName: string;
    role: string;
    badge?: ReactNode;
    items: ProfileMenuItem[];
    style?: CSSProperties;
}
export declare function ProfileMenu({ name, avatarName, role, badge, items, style }: ProfileMenuProps): import("react").JSX.Element;

import type { CSSProperties, ReactNode } from 'react';
export interface AnatomyPart {
    label: string;
    description?: string;
}
export interface AnatomyViewProps {
    parts: AnatomyPart[];
    children?: ReactNode;
    style?: CSSProperties;
}
export declare function AnatomyView({ parts, children, style }: AnatomyViewProps): import("react").JSX.Element;

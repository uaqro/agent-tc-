import { type CSSProperties, type ReactNode } from 'react';
export type IdentityMethod = 'biometric' | 'passcode' | 'sms';
export interface IdentityCheckProps {
    /** Los métodos disponibles, y su orden ES el orden de caída: el primero se
        ofrece y cada uno propone el siguiente. Con uno solo no hay enlace de
        alternativa, porque un enlace que no lleva a ningún sitio no se dibuja. */
    methods: IdentityMethod[];
    /** Quien entra ya es conocido: el saludo es la diferencia con pedir credenciales. */
    greeting?: ReactNode;
    biometricMethod?: 'face' | 'fingerprint';
    /** Controlado: solo el producto sabe cómo va el escaneo. */
    biometricState?: 'idle' | 'scanning' | 'success' | 'error';
    onBiometricStart?: () => void;
    /** El valor completo, para que lo verifique quien puede. La receta no verifica. */
    onSubmit: (method: IdentityMethod, value: string) => void;
    /** El producto dice que el último intento falló. La receta enseña el error y
        limpia el campo: limpiarlo sola sin que nadie se lo diga sería adivinar. */
    invalid?: boolean;
    /** Cuántos quedan antes de bloquear. Se dice el número, no solo que falló. */
    attemptsLeft?: number;
    locked?: boolean;
    onVerified?: () => void;
    style?: CSSProperties;
}
export declare function IdentityCheck({ methods, greeting, biometricMethod, biometricState, onBiometricStart, onSubmit, invalid, attemptsLeft, locked, onVerified, style, }: IdentityCheckProps): import("react").JSX.Element;

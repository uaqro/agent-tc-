import type { CSSProperties, ReactNode } from 'react';
export interface DocFooterLink {
    label: string;
    href: string;
}
export interface DocFooterProps {
    lastUpdated?: string;
    version?: string;
    links?: DocFooterLink[];
    children?: ReactNode;
    style?: CSSProperties;
}
export declare function DocFooter({ lastUpdated, version, links, children, style }: DocFooterProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface DownloadCardProps {
    filename: string;
    description?: string;
    icon?: string;
    href?: string;
    style?: CSSProperties;
}
export declare function DownloadCard({ filename, description, icon, href, style }: DownloadCardProps): import("react").JSX.Element;

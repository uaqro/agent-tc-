import { type CSSProperties } from 'react';
import { type GridColumn } from '../components/DataGrid';
import { type BulkAction } from '../components/BulkBar';
export interface BulkActionsTableProps {
    columns: GridColumn[];
    rows: Record<string, unknown>[];
    rowKey: string;
    /** Nombre de la tabla para el lector: va al <caption> (blk-6). NO se pinta
        en la franja — ahí repetiría el título de la pantalla. */
    caption: string;
    actions?: BulkAction[];
    onActionClick?: (actionId: string, selectedKeys: string[]) => void;
    style?: CSSProperties;
}
/** @deprecated En retiro (RFC 0004): usa `DataTable` con `selectable` y
    `bulkActions`. Esta pieza hace un trozo del flujo que el pattern hace
    completo, y quien la usaba se quedaba sin buscar, filtrar ni paginar — en
    Back-office, un revisor con cuarenta documentos no tenía cómo buscar.
    Se retira en 4.0. */
export declare function BulkActionsTable({ columns, rows, rowKey, caption, actions, onActionClick, style, }: BulkActionsTableProps): import("react").JSX.Element;

import { type CSSProperties, type ReactNode } from 'react';
import { type GridColumn, type TableSort, type Density } from '../components/Table';
import { type BulkAction } from '../components/BulkBar';
/** dtb-16: una columna de la tabla de trabajo puede editarse en línea. El
    flag vive en la columna —como `mono` o `align`— y no en una lista aparte
    que habría que mantener en paralelo. */
export interface DataTableColumn<T = Record<string, unknown>> extends GridColumn<T> {
    editable?: boolean;
}
export interface DataTableProps<T = Record<string, unknown>> {
    columns: DataTableColumn<T>[];
    rows: T[];
    rowKey: string;
    /** Nombre de la tabla; también etiqueta la búsqueda («Buscar en {caption}»). */
    caption: string;
    /** dtb-21: el título se pinta como ENCABEZADO real. `h2` por defecto —una
        tabla dentro de una pantalla es una sección—; `h1` cuando la tabla ES la
        pantalla y nadie más la nombra. Era un <span> con pinta de título: quien
        navega por encabezados no encontraba la tabla. */
    titleAs?: 'h1' | 'h2' | 'h3';
    /** dtb-15: título VISIBLE, en la franja que corona la tabla. Opcional a
        propósito — una tabla que ya ES la pantalla se nombra con el PageHeader,
        y repetirlo aquí es el relleno que bbr-6 prohíbe. */
    title?: string;
    /** Una línea bajo el título: qué contiene la tabla o cómo leerla. Opcional
        e independiente del título — se pone lo que la tabla necesite. */
    description?: string;
    /** dtb-16: edición en línea. La columna se marca con `editable` y el cambio
        se reporta aquí. Sin esta prop las celdas editables no se abren: la tabla
        no guarda nada por su cuenta — el dueño de los datos decide. */
    onCellEdit?: (rowKey: string, columnKey: string, value: string) => void;
    /** Campos donde busca la consulta. Sin ella, todos los campos de texto de la fila. */
    searchKeys?: string[];
    searchPlaceholder?: string;
    /** dtb-6: `false` oculta el buscador — para tablas cuyo dueño ya filtra
        aguas arriba y una segunda caja confundiría sobre cuál filtra qué. */
    searchable?: boolean;
    /** dtb-19: `false` apaga el orden por cabecera. Para tablas cuyo orden ES
        información —una prioridad, un itinerario— y reordenar la destruiría. */
    sortable?: boolean;
    /** dtb-19: `false` muestra todas las filas, sin pie. Para conjuntos cortos
        y fijos, donde paginar añade un control que nunca hace falta. */
    paginated?: boolean;
    /** Consulta controlada por el dueño (cst-1). Sin ella la tabla busca sola. */
    query?: string;
    /** La consulta se reporta con el valor nuevo (cst-1). */
    onQueryChange?: (query: string) => void;
    /** Filas por página; la paginación solo aparece si hay más filas. */
    pageSize?: number;
    /** dtb-7: pasos del selector de tamaño de página. Con ella, el pie usa la
        Paginación COMPLETA del sistema: rango «X–Y de Z», páginas y selector. */
    pageSizeOptions?: number[];
    onRowClick?: (row: T) => void;
    selectedKey?: string | number;
    density?: Density;
    /** Mensaje del estado sin resultados; `{q}` se interpola con la consulta. */
    emptyLabel?: string;
    /** El cinturón de filtros, sobre la barra de búsqueda. Llega MONTADO —un
        FilterSet, normalmente— en vez de importarse: un pattern no compone otro
        pattern, y la pantalla es quien los junta (dtb-13). */
    filters?: ReactNode;
    /** Selección múltiple por fila. La mecánica la pone DataGrid (dg-20). */
    selectable?: boolean;
    selectedKeys?: (string | number)[];
    defaultSelectedKeys?: (string | number)[];
    onSelectionChange?: (keys: (string | number)[]) => void;
    /** Acciones sobre la selección. Sin selección, su barra no existe. */
    bulkActions?: BulkAction[];
    onBulkAction?: (actionId: string, keys: (string | number)[]) => void;
    /** dtb-22: el procesamiento lo hace el dueño. La tabla no busca, no ordena
        y no recorta: pinta `rows` tal cual, porque `rows` ES la página ya
        servida. Para listados que no caben en el navegador. Sin ella, todo se
        procesa en local igual que siempre.
  
        Es una sola bandera y no tres a propósito: paginar fuera y ordenar
        dentro ordena la página, no el conjunto — que es dtb-2 roto. */
    manual?: boolean;
    /** Página controlada, 1-based. Sin ella la tabla lleva la suya (cst-3). */
    page?: number;
    /** La página se reporta con el valor nuevo (cst-1). */
    onPageChange?: (page: number) => void;
    /** Filas del CONJUNTO, no del arreglo local: es lo que cuentan el recuento
        y el rango del pie cuando la página viene servida (dtb-24). */
    total?: number;
    /** Orden controlado: con él la tabla NO reordena — ordena el dueño. Misma
        semántica que `DataGrid` (cst-3). */
    sort?: TableSort | null;
    /** El orden se reporta con el valor nuevo (cst-1). */
    onSortChange?: (sort: TableSort | null) => void;
    /** Esperando datos. No es lo mismo que no tenerlos (dtb-12). */
    loading?: boolean;
    /** Falló la carga. Tampoco es un vacío. */
    error?: string;
    onRetry?: () => void;
    style?: CSSProperties;
}
export declare function DataTable<T extends object = Record<string, unknown>>({ columns, onCellEdit, rows, rowKey, caption, title, titleAs: Titulo, description, searchKeys, searchPlaceholder, searchable, sortable, paginated, query: queryProp, onQueryChange, manual, page: pageProp, onPageChange, total: totalProp, sort: sortProp, onSortChange, pageSize, pageSizeOptions, onRowClick, selectedKey, density, emptyLabel, filters, selectable, selectedKeys, defaultSelectedKeys, onSelectionChange, bulkActions, onBulkAction, loading, error, onRetry, style, }: DataTableProps<T>): import("react").JSX.Element;

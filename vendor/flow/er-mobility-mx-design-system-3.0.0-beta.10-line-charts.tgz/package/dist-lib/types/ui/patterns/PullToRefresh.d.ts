import { type ReactNode } from 'react';
export interface PullToRefreshProps {
    /** Lo que hay que refrescar. La pantalla decide cuándo terminó con `refreshing`. */
    onRefresh: () => Promise<void>;
    /** Controlado: la receta no guarda si está refrescando, lo pide y lo obedece. */
    refreshing?: boolean;
    children?: ReactNode;
}
/**
 * Tirar hacia abajo para refrescar una lista, en touch.
 *
 * Dos cosas que el contrato promete NO hacer, y que están en el código y no en
 * la disciplina de quien lo use: no engancha con ratón —«No existe en desktop:
 * con mouse el refresco es el botón»— y no pagina ni carga incrementalmente.
 *
 * Y una que es de la PANTALLA y esta pieza no puede garantizar: el gesto es un
 * atajo, nunca la única vía (ptr-1), así que quien la monta ofrece además un
 * refresco sin gesto. Por eso ese criterio es `manual` en el canon.
 */
export declare function PullToRefresh({ onRefresh, refreshing, children }: PullToRefreshProps): import("react").JSX.Element;

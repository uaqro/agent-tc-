import { type CSSProperties, type ReactNode } from 'react';
export interface PlaygroundOption {
    value: string;
    label: string;
}
export interface SpecLabels {
    top?: string;
    right?: string;
    bottom?: string;
}
export interface PlaygroundCanvasProps {
    variants?: PlaygroundOption[];
    sizes?: string[];
    densities?: string[];
    snippet?: string | ((state: {
        variant: string;
        size: string;
    }) => string);
    specLabels?: (state: {
        variant: string;
        size: string;
        density: string;
    }) => SpecLabels;
    children: (state: {
        variant: string;
        size: string;
        density: string;
    }) => ReactNode;
    style?: CSSProperties;
}
export declare function PlaygroundCanvas({ variants, sizes, densities, snippet, specLabels, children, style, }: PlaygroundCanvasProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface KpiBandItem {
    label: string;
    value: string | number;
    delta?: string;
    trend?: number[];
    icon?: string;
    tone?: 'neutral' | 'success' | 'warning' | 'danger';
    /** El JUICIO del delta — verde o rojo. Sin él se deriva del signo, que solo
        vale cuando subir es bueno. Viaja entero a StatTile (kpb-2). */
    deltaTone?: 'success' | 'danger' | 'neutral';
    deltaArrow?: boolean;
}
export interface KpiBandProps {
    /** Las cifras, en su orden de lectura. */
    items: KpiBandItem[];
    /** kpb-1: ancho mínimo de cada cifra; por debajo, la rejilla pliega una
        columna. No hay prop de «columnas» a propósito: el número de KPI cambia
        por vista, y preguntárselo al consumidor devuelve la rejilla a mano que
        esta receta viene a quitar. */
    min?: number;
    style?: CSSProperties;
}
/**
 * KpiBand — la banda de cifras que corona una vista de tablero.
 *
 * Nace de una medición, no de una idea: seis vistas del banco repetían
 * `<div className={css.kpiGrid4}>` con sus StatTile sueltos, y la clase era
 * local de cada pantalla. Una rejilla repetida no importa nada, así que no
 * aparece en ningún grafo — por eso `cmp-1` veía doce piezas directas y no
 * veía la receta que faltaba.
 */
export declare function KpiBand({ items, min, style }: KpiBandProps): import("react").JSX.Element | null;

import { type ReactNode } from 'react';
import type { NotificationItem } from '../components/NotificationCenter';
/**
 * El chrome de la página, cableado por el shell.
 *
 * Mismo wiring que `sidebar-context`, que ya vivía al lado: quien monta el
 * shell provee, y PageHeader consume. La diferencia con pasarlo por prop es
 * todo lo que importa — medido: mientras la búsqueda y los avisos fueron prop
 * por pantalla, estaban en UNA de trece, porque «se puede prender» no es «está
 * prendido» y ninguna pantalla nueva sabe que tiene que prenderlo.
 *
 * La pantalla sigue mandando: una prop propia gana sobre esto, y
 * `utilities={false}` apaga la fila donde estorbe.
 */
export interface PageChrome {
    /** Abre la búsqueda global. Sin esto no hay botón. */
    onSearch?: () => void;
    /** Nombre accesible del botón, con su atajo si lo hay. */
    searchLabel?: string;
    /** Avisos sin leer. Sin lista no hay campana. */
    notifications?: NotificationItem[];
    onNotificationClick?: (item: NotificationItem) => void;
    onMarkAllRead?: () => void;
    /** Lo que es de la app y no del sistema: el interruptor de tema, por ejemplo. */
    trailing?: ReactNode;
}
export declare const PageChromeProvider: import("react").Provider<PageChrome | null>;
export declare function usePageChrome(): PageChrome;

import type { CSSProperties } from 'react';
export interface DocHeroPlatform {
    label: string;
    tone: 'success' | 'warning' | 'danger' | 'info';
}
export interface DocHeroProps {
    name: string;
    summary: string;
    platforms?: DocHeroPlatform[];
    a11yLevel?: string;
    style?: CSSProperties;
}
export declare function DocHero({ name, summary, platforms, a11yLevel, style }: DocHeroProps): import("react").JSX.Element;

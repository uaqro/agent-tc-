/**
 * @deprecated El entry `./flag` se retira en 4.0 (RFC 0012). Importa `Flag` del
 * barril principal y declara `FlowFlagsProvider`.
 */
import 'flag-icons/css/flag-icons.min.css';
export { Flag, type FlagProps } from './primitives/Flag';

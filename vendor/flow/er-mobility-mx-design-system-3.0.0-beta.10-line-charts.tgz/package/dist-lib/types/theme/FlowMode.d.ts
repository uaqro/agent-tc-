import { type ReactNode } from 'react';
export type FlowMode = 'light' | 'dark' | 'system';
/** El DS entrega el tema con el atributo data-mode, no con un provider de
    contexto de valores (el mecanismo del canon). Este provider existe como
    puente para apps que venían de FlowThemeProvider/useFlowTheme (1.x):
    administra el atributo en <html> y expone modo y cambio. */
interface FlowModeValue {
    mode: FlowMode;
    /** El modo efectivo tras resolver 'system'. */
    resolved: 'light' | 'dark';
    setMode: (mode: FlowMode) => void;
    toggle: () => void;
}
export interface FlowModeProviderProps {
    defaultMode?: FlowMode;
    /** Dónde recuerda la elección. El mismo valor tiene que usar el script que
        pinta `data-mode` antes del primer frame, o al montar habría un salto de
        claro a oscuro. */
    storageKey?: string;
    children: ReactNode;
}
export declare function FlowModeProvider({ defaultMode, storageKey, children, }: FlowModeProviderProps): import("react").JSX.Element;
export declare function useFlowMode(): FlowModeValue;
export {};

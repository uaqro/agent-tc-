import { type ReactNode } from 'react';
export interface SpecimenState {
    variant: string;
    size: string;
    density: string;
}
export interface Specimen {
    /** Valores que el playground ofrece; vacío = la pieza no varía por ese eje. */
    variants?: string[];
    sizes?: string[];
    /** El render recibe el estado del playground — el enchufe de PlaygroundCanvas. */
    render: (state: SpecimenState) => ReactNode;
}
export declare const SPECIMENS: Record<string, Specimen>;

/** Tabla de equivalencias de iconos para la migración de eOne (Flow 1.x → 3.0).
 *
 * eOne reparte 68 nombres estilo Feather como strings por 100+ archivos
 * (§4 del inventario). El DS usa Material Symbols Rounded por ligadura
 * (snake_case). Esta tabla es el puente medido; `mapEoneIcon` cae al nombre
 * original si no hay entrada, para que un icono nuevo no pinte «Missing icon»
 * en silencio durante la migración.
 *
 * Los dos nombres inválidos del inventario también resuelven: `navigation`
 * existe en Material Symbols y `x` era `close`.
 */
export declare const EONE_ICON_MAP: Record<string, string>;
/** Resuelve un nombre de icono de eOne al glifo Material del DS. */
export declare function mapEoneIcon(name: string): string;

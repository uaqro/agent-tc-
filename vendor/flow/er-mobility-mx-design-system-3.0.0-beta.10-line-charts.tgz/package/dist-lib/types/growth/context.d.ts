import { type ReactNode } from 'react';
import type { GrowthAdapter } from './types';
export interface FlowGrowthProviderProps {
    adapter: GrowthAdapter;
    children: ReactNode;
}
export declare function FlowGrowthProvider({ adapter, children }: FlowGrowthProviderProps): import("react").JSX.Element;
/** Función de tracking governada: en dev avisa si el evento no está aprobado. */
export declare function useTrack(): (event: string, props?: Record<string, unknown>) => void;
/** Adapter completo (track / identify / variant) para casos avanzados. */
export declare function useGrowth(): GrowthAdapter;
/**
 * Variante asignada de un experimento. Reporta la exposición una sola vez
 * por render del hook (evento `experiment_exposed`). Sin adapter con
 * soporte de experimentos, devuelve `fallback` y no reporta nada.
 */
export declare function useExperiment(experiment: string, fallback: string): string;

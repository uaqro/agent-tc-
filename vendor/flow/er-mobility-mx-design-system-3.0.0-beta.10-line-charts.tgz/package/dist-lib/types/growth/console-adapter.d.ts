import type { GrowthAdapter } from './types';
export declare const consoleAdapter: GrowthAdapter;

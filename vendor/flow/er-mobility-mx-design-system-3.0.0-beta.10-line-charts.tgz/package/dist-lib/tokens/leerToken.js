import { FALLBACKS as e } from "./fallbacks.js";
//#region src/tokens/leerToken.ts
function t() {
	return typeof document < "u" && document.documentElement.dataset.mode === "dark";
}
function n(n) {
	let r = e[n];
	return r ? r[+!!t()] : "";
}
function r(e, t) {
	let r = t ?? (typeof document < "u" ? getComputedStyle(document.documentElement) : null);
	return (r ? r.getPropertyValue(e).trim() : "") || n(e);
}
function i(e) {
	let t = document.createElement("span");
	t.className = "flow-symbol", t.hidden = !0, e.appendChild(t);
	let n = getComputedStyle(t).fontFamily;
	return t.remove(), n;
}
//#endregion
export { n as fallbackDe, i as leerFuenteSimbolos, r as leerToken, t as modoOscuro };

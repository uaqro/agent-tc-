"use client";
import e from "./events.js";
import { jsx as t } from "react/jsx-runtime";
import { createContext as n, useCallback as r, useContext as i, useEffect as a, useMemo as o } from "react";
//#region src/growth/context.tsx
e.events;
var s = n({ track: () => {} });
function c(e) {
	let t = {};
	for (let [n, r] of Object.entries(e.dataset)) {
		if (n === "growthEvent" || !n.startsWith("growth")) continue;
		let e = n.slice(6).replace(/([A-Z])/g, "_$1").toLowerCase().replace(/^_/, "");
		t[e] = r;
	}
	return t;
}
function l({ adapter: e, children: n }) {
	return a(() => {
		function t(t) {
			let n = t.target?.closest("[data-growth-event]");
			if (!n) return;
			let r = n.dataset.growthEvent;
			r && e.track(r, c(n));
		}
		return document.addEventListener("click", t, !0), () => document.removeEventListener("click", t, !0);
	}, [e]), /* @__PURE__ */ t(s.Provider, {
		value: e,
		children: n
	});
}
function u() {
	let e = i(s);
	return r((t, n) => {
		e.track(t, n);
	}, [e]);
}
function d() {
	return i(s);
}
function f(e, t) {
	let n = i(s);
	return o(() => {
		let r = n.variant?.(e);
		return r === void 0 ? t : (n.track("experiment_exposed", {
			experiment: e,
			variant: r
		}), r);
	}, [
		n,
		e,
		t
	]);
}
//#endregion
export { l as FlowGrowthProvider, f as useExperiment, d as useGrowth, u as useTrack };

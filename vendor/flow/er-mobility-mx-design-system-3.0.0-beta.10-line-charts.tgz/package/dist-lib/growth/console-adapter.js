//#region src/growth/console-adapter.ts
var e = {
	track(e, t) {
		console.info(`[growth] ${e}`, t ?? {});
	},
	identify(e, t) {
		console.info(`[growth] identify ${e}`, t ?? {});
	},
	variant() {}
};
//#endregion
export { e as consoleAdapter };

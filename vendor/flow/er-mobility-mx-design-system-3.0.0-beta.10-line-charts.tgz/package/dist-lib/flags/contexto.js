"use client";
import { jsx as e } from "react/jsx-runtime";
import { createContext as t, useContext as n, useMemo as r } from "react";
//#region src/flags/contexto.tsx
var i = t(null);
function a({ baseUrl: t, children: n }) {
	let a = r(() => t.replace(/\/+$/, ""), [t]);
	return /* @__PURE__ */ e(i.Provider, {
		value: a,
		children: n
	});
}
function o() {
	return n(i);
}
function s(e, t) {
	return `${e}/${String(t || "").toLowerCase()}.svg`;
}
var c = !1;
function l(e) {
	c || process.env.NODE_ENV === "production" || (c = !0, console.warn(e));
}
//#endregion
export { a as FlowFlagsProvider, l as avisaDelCaminoViejo, s as urlDeBandera, o as useFlagsBase };

"use client";
import { jsx as e } from "react/jsx-runtime";
import { createContext as t, useCallback as n, useContext as r, useEffect as i, useMemo as a, useState as o } from "react";
//#region src/theme/FlowMode.tsx
var s = t(null), c = () => typeof window < "u" && window.matchMedia?.("(prefers-color-scheme: dark)").matches, l = (e) => {
	try {
		let t = localStorage.getItem(e);
		return t === "dark" || t === "light" || t === "system" ? t : null;
	} catch {
		return null;
	}
};
function u({ defaultMode: t = "system", storageKey: r = "flow-theme", children: u }) {
	let [d, f] = o(() => l(r) ?? t), [p, m] = o(c);
	i(() => {
		let e = window.matchMedia?.("(prefers-color-scheme: dark)");
		if (!e) return;
		let t = () => m(e.matches);
		return e.addEventListener?.("change", t), () => e.removeEventListener?.("change", t);
	}, []);
	let h = d === "system" ? p ? "dark" : "light" : d;
	i(() => {
		let e = document.documentElement;
		h === "dark" ? e.setAttribute("data-mode", "dark") : e.removeAttribute("data-mode");
	}, [h]), i(() => {
		try {
			localStorage.setItem(r, d);
		} catch {}
	}, [d, r]);
	let g = n(() => {
		f(h === "dark" ? "light" : "dark");
	}, [h]), _ = a(() => ({
		mode: d,
		resolved: h,
		setMode: f,
		toggle: g
	}), [
		d,
		h,
		g
	]);
	return /* @__PURE__ */ e(s.Provider, {
		value: _,
		children: u
	});
}
function d() {
	let e = r(s);
	if (!e) throw Error("useFlowMode necesita un FlowModeProvider en el árbol.");
	return e;
}
//#endregion
export { u as FlowModeProvider, d as useFlowMode };

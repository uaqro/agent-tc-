//#region src/hooks/useReveal.module.css
var e = "ECmdpq_hidden", t = "ECmdpq_visible", n = {
	hidden: e,
	visible: t
};
//#endregion
export { n as default, e as hidden, t as visible };

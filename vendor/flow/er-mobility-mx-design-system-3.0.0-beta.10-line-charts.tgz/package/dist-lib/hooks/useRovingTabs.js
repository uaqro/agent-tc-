"use client";
import { useCallback as e, useRef as t } from "react";
//#region src/hooks/useRovingTabs.ts
function n(n, r, i) {
	let a = t({});
	return {
		alTeclado: e((e) => {
			let t = r === void 0 ? -1 : n.indexOf(r), o = t;
			if (e.key === "ArrowRight" || e.key === "ArrowDown") o = (t + 1) % n.length;
			else if (e.key === "ArrowLeft" || e.key === "ArrowUp") o = (t - 1 + n.length) % n.length;
			else if (e.key === "Home") o = 0;
			else if (e.key === "End") o = n.length - 1;
			else return;
			e.preventDefault();
			let s = n[o];
			s !== void 0 && (i?.(s), a.current[s]?.focus());
		}, [
			n,
			r,
			i
		]),
		pestana: (e) => ({
			tabIndex: e === r ? 0 : -1,
			ref: (t) => {
				a.current[e] = t;
			}
		}),
		refs: a
	};
}
//#endregion
export { n as useRovingTabs };

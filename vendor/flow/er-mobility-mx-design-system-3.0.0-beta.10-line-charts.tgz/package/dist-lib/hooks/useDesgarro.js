import { leerToken as e } from "../tokens/leerToken.js";
//#region src/hooks/useDesgarro.ts
var t = 10, n = (t, n) => {
	let r = e(t);
	if (!r) return n;
	let i = parseFloat(r);
	return r.trim().endsWith("ms") || !r.includes("s") ? i : i * 1e3;
}, r = (e) => e.overflow !== "visible" || e.overflowX !== "visible" || e.overflowY !== "visible";
function i(e) {
	let t = e.parentElement, n = null, i = !1;
	for (; t && t !== document.body;) {
		let e = getComputedStyle(t);
		if (r(e)) i = !0;
		else if (e.position !== "static") {
			if (i) return t;
			n ??= t;
		}
		t = t.parentElement;
	}
	return n ?? document.body;
}
function a(r) {
	if (!r || typeof document > "u" || typeof r.animate != "function" || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return !1;
	let a = r.getBoundingClientRect?.();
	if (!a?.width) return !1;
	let o = i(r), s = o?.getBoundingClientRect?.();
	if (!o || !s) return !1;
	let c = n("--dur-shred", 1200), l = n("--dur-stagger", 30), u = s.height - (a.y - s.y) + a.height;
	for (let n = 0; n < t; n++) {
		let i = r.cloneNode(!0), d = n * 100 / t, f = 100 - (n + 1) * 100 / t;
		Object.assign(i.style, {
			position: "absolute",
			left: `${a.x - s.x}px`,
			top: `${a.y - s.y}px`,
			width: `${a.width}px`,
			height: `${a.height}px`,
			margin: "0",
			clipPath: `inset(0 ${f}% 0 ${d}%)`,
			pointerEvents: "none",
			zIndex: e("--z-fx") || "1400"
		}), i.setAttribute("aria-hidden", "true"), o.appendChild(i);
		let p = n - 9 / 2, m = i.animate?.([
			{
				transform: "translate(0,0) rotate(0deg)",
				opacity: 1
			},
			{
				transform: `translate(${p * 2.6}px, 6px) rotate(${p * .35}deg)`,
				opacity: 1,
				offset: .16
			},
			{
				transform: `translate(${p * 16}px, ${u}px) rotate(${p * 7}deg)`,
				opacity: 0
			}
		], {
			duration: c,
			delay: n * l,
			easing: "cubic-bezier(.45,0,.9,.4)",
			fill: "both"
		}), h = () => i.remove();
		m ? m.finished.then(h).catch(h) : h();
	}
	return !0;
}
//#endregion
export { a as desgarra };

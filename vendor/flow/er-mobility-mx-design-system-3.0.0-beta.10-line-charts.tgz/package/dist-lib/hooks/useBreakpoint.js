"use client";
import { useSyncExternalStore as e } from "react";
//#region src/hooks/useBreakpoint.ts
var t = [
	["compact", "--bp-compact"],
	["medium", "--bp-medium"],
	["expanded", "--bp-expanded"]
];
function n() {
	let e = getComputedStyle(document.documentElement), n = [];
	for (let [r, i] of t) {
		let t = parseFloat(e.getPropertyValue(i));
		Number.isFinite(t) && n.push([r, t]);
	}
	return n;
}
function r() {
	if (typeof window > "u" || typeof document > "u") return "expanded";
	let e = n();
	if (!e.length) return "expanded";
	let t = window.innerWidth;
	for (let [n, r] of e) if (t <= r) return n;
	return "expanded";
}
function i(e) {
	return typeof window > "u" ? () => {} : (window.addEventListener("resize", e), window.addEventListener("orientationchange", e), () => {
		window.removeEventListener("resize", e), window.removeEventListener("orientationchange", e);
	});
}
function a() {
	return e(i, r, () => "expanded");
}
//#endregion
export { a as useBreakpoint };

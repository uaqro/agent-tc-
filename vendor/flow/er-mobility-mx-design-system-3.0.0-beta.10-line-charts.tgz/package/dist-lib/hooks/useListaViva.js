"use client";
import { useEffect as e, useRef as t, useState as n } from "react";
//#region src/hooks/useListaViva.ts
function r(e) {
	let t = getComputedStyle(e), n = (e, t) => {
		let n = e.split(",").map((e) => parseFloat(e) || 0), r = t.split(",").map((e) => parseFloat(e) || 0);
		return n.reduce((e, t, n) => Math.max(e, t + (r[n % r.length] ?? 0)), 0);
	};
	return Math.max(n(t.transitionDuration, t.transitionDelay), n(t.animationDuration, t.animationDelay)) * 1e3;
}
function i(i, a) {
	let o = i.map(a), s = t(/* @__PURE__ */ new Map()), c = t(/* @__PURE__ */ new Map()), l = t(/* @__PURE__ */ new Map());
	i.forEach((e, t) => l.current.set(a(e), {
		item: e,
		indice: t
	}));
	let [u, d] = n(o), f = t(!0);
	e(() => {
		f.current = !1;
	}, []);
	let [p, m] = n([]), [h, g] = n([]);
	if (u.join("\0") !== o.join("\0")) {
		let e = f.current ? [] : o.filter((e) => !u.includes(e));
		e.length && g((t) => [...t, ...e]);
		let t = u.filter((e) => !o.includes(e) && !p.some((t) => t.clave === e));
		d(o), t.length && m((e) => [...e, ...t.map((e) => ({
			clave: e,
			item: l.current.get(e).item,
			indice: l.current.get(e).indice
		}))]);
	}
	let _ = t(/* @__PURE__ */ new Set());
	e(() => {
		for (let { clave: e } of p) {
			if (_.current.has(e)) continue;
			_.current.add(e);
			let t = s.current.get(e), n = () => {
				m((t) => t.filter((t) => t.clave !== e)), s.current.delete(e), l.current.delete(e), _.current.delete(e), clearTimeout(c.current.get(e)), c.current.delete(e);
			}, i = t ? r(t) : 0;
			if (!t || i === 0) {
				n();
				continue;
			}
			let a = (e) => {
				e.target === t && ((t.getAnimations?.()?.length ?? 0) > 0 || n());
			};
			t.addEventListener("transitionend", a), t.addEventListener("animationend", a), c.current.set(e, setTimeout(n, i + 50));
		}
	}, [p]), e(() => {
		let e = c.current;
		return () => {
			e.forEach(clearTimeout), e.clear();
		};
	}, []);
	let v = (e) => (t) => {
		t && s.current.set(e, t);
	};
	e(() => {
		if (!h.length) return;
		let e = Math.max(0, ...h.map((e) => s.current.get(e) ? r(s.current.get(e)) : 0)), t = setTimeout(() => g([]), e + 50);
		return () => clearTimeout(t);
	}, [h]);
	let y = i.map((e) => ({
		clave: a(e),
		item: e,
		saliendo: !1,
		entrando: h.includes(a(e)),
		ref: v(a(e))
	}));
	for (let e of [...p].sort((e, t) => t.indice - e.indice)) o.includes(e.clave) || y.splice(Math.min(e.indice, y.length), 0, {
		clave: e.clave,
		item: e.item,
		saliendo: !0,
		entrando: !1,
		ref: v(e.clave)
	});
	return y;
}
//#endregion
export { r as duracionDeclarada, i as useListaViva };

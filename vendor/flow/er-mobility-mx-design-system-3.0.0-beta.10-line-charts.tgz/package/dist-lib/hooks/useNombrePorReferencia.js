import { cloneElement as e, isValidElement as t } from "react";
//#region src/hooks/useNombrePorReferencia.ts
var n = (e) => e["aria-labelledby"] !== void 0 || e["aria-label"] !== void 0 || e.ariaLabel !== void 0;
function r(r, i) {
	if (!t(r)) return r;
	let a = r.props;
	return n(a) ? r : e(r, { "aria-labelledby": i });
}
//#endregion
export { r as nombrarPorReferencia, n as tieneNombrePropio };

"use client";
import e from "./useReveal.module.js";
import { useEffect as t, useRef as n, useState as r } from "react";
//#region src/hooks/useReveal.ts
function i() {
	let i = n(null), [a, o] = r(!1);
	return t(() => {
		let e = i.current;
		if (!e || typeof IntersectionObserver > "u") return;
		let t = new IntersectionObserver(([e]) => {
			e.isIntersecting && (o(!0), t.disconnect());
		}, { threshold: .1 });
		return t.observe(e), () => t.disconnect();
	}, []), {
		ref: i,
		className: a ? e.visible : e.hidden
	};
}
//#endregion
export { i as useReveal };

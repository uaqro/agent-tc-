"use client";
import { Avatar as e } from "../ui/primitives/Avatar.js";
import { Badge as t } from "../ui/primitives/Badge.js";
import { Breadcrumb as n } from "../ui/primitives/Breadcrumb.js";
import { BrandCanvas as r } from "../ui/primitives/BrandCanvas.js";
import { Button as i } from "../ui/primitives/Button.js";
import { Card as a } from "../ui/primitives/Card.js";
import { ChartLegend as o } from "../ui/primitives/ChartLegend.js";
import { Checkbox as s } from "../ui/primitives/Checkbox.js";
import { Chip as c } from "../ui/primitives/Chip.js";
import { ChipGroup as l } from "../ui/primitives/ChipGroup.js";
import { Divider as u } from "../ui/primitives/Divider.js";
import { Field as d } from "../ui/primitives/Field.js";
import { Flag as f } from "../ui/primitives/Flag.js";
import { FlowLogo as p } from "../ui/primitives/FlowLogo.js";
import { IconButton as m } from "../ui/primitives/IconButton.js";
import { Input as h } from "../ui/primitives/Input.js";
import { Radio as g } from "../ui/primitives/Radio.js";
import { SectionHeader as _ } from "../ui/primitives/SectionHeader.js";
import { Select as ee } from "../ui/primitives/Select.js";
import { Skeleton as v } from "../ui/primitives/Skeleton.js";
import { Slider as y } from "../ui/primitives/Slider.js";
import { Spinner as b } from "../ui/primitives/Spinner.js";
import { StatusPill as x } from "../ui/primitives/StatusPill.js";
import { Stepper as S } from "../ui/primitives/Stepper.js";
import { Switch as C } from "../ui/primitives/Switch.js";
import { Textarea as w } from "../ui/primitives/Textarea.js";
import { ToastHost as T, useToast as E } from "../ui/primitives/Toast.js";
import { BrandHero as D } from "../ui/components/BrandHero.js";
import { HelpCenter as O } from "../ui/components/HelpCenter.js";
import { Menu as k } from "../ui/components/Menu.js";
import { NotificationCenter as A } from "../ui/components/NotificationCenter.js";
import { SegmentedControl as j } from "../ui/components/SegmentedControl.js";
import { Sidebar as M } from "../ui/components/Sidebar.js";
import { StatTile as N } from "../ui/components/StatTile.js";
import { Tabs as P } from "../ui/components/Tabs.js";
import { Tooltip as F } from "../ui/components/Tooltip.js";
import { TransactionRow as I } from "../ui/components/TransactionRow.js";
import { InputPhone as L } from "../ui/components/InputPhone.js";
import { DocumentViewer as te } from "../ui/components/DocumentViewer.js";
import { Pagination as R } from "../ui/components/Pagination.js";
import { DataTable as z } from "../ui/patterns/DataTable.js";
import { TransactionGroup as B } from "../ui/patterns/TransactionGroup.js";
import { jsx as V, jsxs as H } from "react/jsx-runtime";
import { useState as U } from "react";
//#region src/specimens/index.tsx
function W() {
	let [e, t] = U(!0);
	return /* @__PURE__ */ V(C, {
		checked: e,
		onChange: t,
		label: "Alertas de mantenimiento"
	});
}
function G() {
	let [e, t] = U(!0);
	return /* @__PURE__ */ H("div", {
		style: {
			display: "flex",
			flexDirection: "column",
			gap: 8
		},
		children: [
			/* @__PURE__ */ V(s, {
				checked: e,
				onChange: t,
				label: "Ver unidades",
				description: "Acceso de solo lectura a la flota"
			}),
			/* @__PURE__ */ V(s, {
				checked: !0,
				indeterminate: !0,
				label: "Editar unidades"
			}),
			/* @__PURE__ */ V(s, {
				checked: !1,
				onChange: () => {},
				label: "Eliminar unidades",
				disabled: !0
			})
		]
	});
}
function K() {
	let [e, t] = U("a");
	return /* @__PURE__ */ H("div", {
		style: {
			display: "flex",
			flexDirection: "column",
			gap: 8
		},
		children: [
			/* @__PURE__ */ V(g, {
				name: "sp-radio",
				value: "a",
				checked: e === "a",
				onChange: t,
				label: "Diario",
				description: "Un resumen cada mañana"
			}),
			/* @__PURE__ */ V(g, {
				name: "sp-radio",
				value: "b",
				checked: e === "b",
				onChange: t,
				label: "Semanal"
			}),
			/* @__PURE__ */ V(g, {
				name: "sp-radio",
				value: "c",
				checked: e === "c",
				onChange: t,
				label: "Nunca",
				disabled: !0
			})
		]
	});
}
function q({ size: e }) {
	let [t, n] = U("ruta");
	return /* @__PURE__ */ H(l, { children: [[
		"ruta",
		"taller",
		"inactiva"
	].map((r) => /* @__PURE__ */ V(c, {
		label: "En " + r,
		size: e,
		selected: t === r,
		onClick: () => n(r)
	}, r)), /* @__PURE__ */ V(c, {
		label: "KTR-882",
		size: e,
		mono: !0,
		onRemove: () => {}
	})] });
}
function J({ variant: e }) {
	let [t, n] = U("todas");
	return /* @__PURE__ */ V(P, {
		variant: e,
		value: t,
		onChange: n,
		items: [
			{
				value: "todas",
				label: "Todas",
				count: 24
			},
			{
				value: "ruta",
				label: "En ruta",
				count: 18
			},
			{
				value: "taller",
				label: "Taller",
				count: 3
			}
		]
	});
}
function Y({ size: e }) {
	let [t, n] = U("lista");
	return /* @__PURE__ */ V(j, {
		size: e,
		value: t,
		onChange: n,
		items: [
			{
				value: "lista",
				label: "Lista",
				icon: "table_rows"
			},
			{
				value: "mapa",
				label: "Mapa",
				icon: "map"
			},
			{
				value: "stats",
				label: "Stats",
				icon: "insert_chart"
			}
		]
	});
}
function X({ size: e }) {
	let [t, n] = U("cdmx");
	return /* @__PURE__ */ V(ee, {
		size: e,
		insetLabel: "Zona",
		value: t,
		onChange: n,
		options: [
			{
				value: "cdmx",
				label: "Ciudad de México"
			},
			{
				value: "gdl",
				label: "Guadalajara"
			},
			{
				value: "mty",
				label: "Monterrey"
			}
		]
	});
}
function Z() {
	let [e, t] = U(80);
	return /* @__PURE__ */ V(y, {
		label: "Velocidad máxima",
		value: e,
		onChange: t,
		min: 0,
		max: 140,
		format: (e) => `${e} km/h`
	});
}
function Q() {
	let { show: e } = E();
	return /* @__PURE__ */ H("div", {
		style: {
			display: "flex",
			gap: 8
		},
		children: [
			/* @__PURE__ */ V(i, {
				variant: "secondary",
				onClick: () => e({
					message: "Cambios guardados",
					tone: "success"
				}),
				children: "Éxito"
			}),
			/* @__PURE__ */ V(i, {
				variant: "secondary",
				onClick: () => e({
					message: "La unidad quedó sin conductor",
					tone: "warning",
					actionLabel: "Asignar",
					onAction: () => {}
				}),
				children: "Con acción"
			}),
			/* @__PURE__ */ V(i, {
				variant: "secondary",
				onClick: () => e({
					message: "No se pudo exportar",
					tone: "danger",
					duration: null
				}),
				children: "Persistente"
			})
		]
	});
}
function ne() {
	let [e, t] = U(4);
	return /* @__PURE__ */ V(R, {
		page: e,
		pages: 9,
		onChange: t,
		total: 87,
		pageSize: 10
	});
}
var $ = [
	{
		name: "Combustible",
		detail: "Carga registrada · 42 L",
		unit: "Unidad 0427 · Datos de demostración"
	},
	{
		name: "Peaje",
		detail: "Cruce confirmado · $148",
		unit: "Unidad 0427 · Datos de demostración"
	},
	{
		name: "Mantenimiento",
		detail: "Servicio preventivo programado",
		unit: "Unidad 0427 · Datos de demostración"
	},
	{
		name: "Electromovilidad",
		detail: "Recarga en curso · Batería al 68%",
		unit: "Unidad 0182 · Datos de demostración"
	}
], re = {
	"flow-logo": {
		variants: ["default", "navigation"],
		sizes: [],
		render: ({ variant: e }) => /* @__PURE__ */ V(p, { variant: e })
	},
	"brand-hero": {
		variants: ["con escena", "sin escena"],
		render: ({ variant: e }) => /* @__PURE__ */ V(D, {
			style: {
				width: 560,
				height: 420
			},
			title: "Todo tu día,",
			accent: "en movimiento.",
			description: "Gestiona tu flota, tus conductores y tus viajes desde un solo lugar.",
			footer: "© 2026 Flow Mobility",
			scene: e !== "sin escena",
			paused: !0,
			signals: $
		})
	},
	"brand-canvas": {
		variants: ["con señales", "sin señales"],
		render: ({ variant: e }) => /* @__PURE__ */ V("div", {
			style: {
				width: 560,
				height: 420,
				background: "var(--surface-canvas)"
			},
			children: /* @__PURE__ */ V(r, {
				paused: !0,
				signals: e === "sin señales" ? void 0 : $
			})
		})
	},
	switch: { render: () => /* @__PURE__ */ V(W, {}) },
	checkbox: { render: () => /* @__PURE__ */ V(G, {}) },
	radio: { render: () => /* @__PURE__ */ V(K, {}) },
	chip: {
		sizes: ["sm", "md"],
		render: ({ size: e }) => /* @__PURE__ */ V(q, { size: e === "sm" ? "sm" : "md" })
	},
	"chip-group": { render: () => /* @__PURE__ */ V(q, { size: "md" }) },
	avatar: {
		sizes: [
			"sm",
			"md",
			"lg",
			"xl"
		],
		render: ({ size: t }) => /* @__PURE__ */ H("div", {
			style: {
				display: "flex",
				gap: 16,
				alignItems: "center"
			},
			children: [
				/* @__PURE__ */ V(e, {
					name: "Marta Vidal",
					size: t,
					status: "online"
				}),
				/* @__PURE__ */ V(e, {
					name: "Diego Herrera",
					size: t,
					status: "busy"
				}),
				/* @__PURE__ */ V(e, {
					name: "Ana",
					size: t,
					status: "offline"
				})
			]
		})
	},
	badge: {
		variants: [
			"neutral",
			"success",
			"warning",
			"danger",
			"info",
			"accent"
		],
		render: ({ variant: e }) => /* @__PURE__ */ H("div", {
			style: {
				display: "flex",
				gap: 8,
				alignItems: "center"
			},
			children: [
				/* @__PURE__ */ V(t, {
					tone: e,
					children: "Etiqueta"
				}),
				/* @__PURE__ */ V(t, {
					tone: e,
					icon: "bolt",
					children: "Con icono"
				}),
				/* @__PURE__ */ V(t, {
					tone: e,
					live: !0,
					children: "En vivo"
				})
			]
		})
	},
	"status-pill": { render: () => /* @__PURE__ */ H("div", {
		style: {
			display: "flex",
			gap: 8
		},
		children: [
			/* @__PURE__ */ V(x, {
				label: "Activa",
				tone: "success"
			}),
			/* @__PURE__ */ V(x, {
				label: "En revisión",
				tone: "warning"
			}),
			/* @__PURE__ */ V(x, {
				label: "Bloqueada",
				tone: "danger"
			}),
			/* @__PURE__ */ V(x, {
				label: "Informativa",
				tone: "info"
			})
		]
	}) },
	skeleton: { render: () => /* @__PURE__ */ H("div", {
		style: {
			display: "flex",
			flexDirection: "column",
			gap: 8,
			width: 260
		},
		children: [
			/* @__PURE__ */ V(v, {
				variant: "title",
				width: 160
			}),
			/* @__PURE__ */ V(v, { variant: "text" }),
			/* @__PURE__ */ V(v, {
				variant: "text",
				width: "80%"
			}),
			/* @__PURE__ */ V(v, {
				variant: "card",
				height: 72
			})
		]
	}) },
	spinner: { render: () => /* @__PURE__ */ V(b, {}) },
	field: {
		variants: [
			"default",
			"error",
			"valid"
		],
		render: ({ variant: e }) => /* @__PURE__ */ V(d, {
			label: "Correo de trabajo",
			htmlFor: "sp-field",
			required: !0,
			help: e === "default" ? "Se usa para las alertas de la flota." : void 0,
			error: e === "error" ? "Ese dominio no está permitido." : void 0,
			valid: e === "valid",
			validMessage: e === "valid" ? "Correo verificado." : void 0,
			children: /* @__PURE__ */ V(h, {
				id: "sp-field",
				type: "email",
				value: "marta@flota.mx",
				onChange: () => {},
				invalid: e === "error"
			})
		})
	},
	input: {
		sizes: [
			"sm",
			"md",
			"lg"
		],
		variants: [
			"default",
			"invalid",
			"mono"
		],
		render: ({ size: e, variant: t }) => /* @__PURE__ */ V(h, {
			size: e,
			value: t === "mono" ? "KTR-882-A" : "Transportes Vidal",
			onChange: () => {},
			icon: "search",
			mono: t === "mono",
			invalid: t === "invalid",
			ariaLabel: "Ejemplo",
			trailing: t === "mono" ? /* @__PURE__ */ V("span", { children: "placa" }) : void 0
		})
	},
	"input-phone": {
		sizes: [
			"sm",
			"md",
			"lg"
		],
		render: ({ size: e }) => /* @__PURE__ */ V(d, {
			label: "Teléfono móvil",
			htmlFor: "sp-tel",
			children: /* @__PURE__ */ V(L, {
				id: "sp-tel",
				size: e,
				value: "5512345678",
				onChange: () => {},
				prefix: /* @__PURE__ */ H("span", {
					style: {
						display: "inline-flex",
						alignItems: "center",
						gap: 6
					},
					children: [/* @__PURE__ */ V(f, {
						country: "mx",
						size: 16
					}), "+52"]
				})
			})
		})
	},
	textarea: { render: () => /* @__PURE__ */ V(d, {
		label: "Notas del turno",
		htmlFor: "sp-ta",
		children: /* @__PURE__ */ V(w, {
			id: "sp-ta",
			value: "Observaciones del turno…",
			onChange: () => {},
			rows: 3,
			maxLength: 200
		})
	}) },
	select: {
		sizes: [
			"sm",
			"md",
			"lg"
		],
		render: ({ size: e }) => /* @__PURE__ */ V(X, { size: e })
	},
	slider: { render: () => /* @__PURE__ */ V(Z, {}) },
	divider: { render: () => /* @__PURE__ */ H("div", {
		style: { width: 320 },
		children: [/* @__PURE__ */ V(u, {}), /* @__PURE__ */ V(u, { label: "Sección" })]
	}) },
	stepper: {
		variants: ["horizontal", "vertical"],
		render: ({ variant: e }) => /* @__PURE__ */ V(S, {
			orientation: e === "vertical" ? "vertical" : "horizontal",
			steps: [
				{ label: "Datos" },
				{ label: "Pago" },
				{ label: "Confirmar" }
			],
			current: 1
		})
	},
	breadcrumb: { render: () => /* @__PURE__ */ H("div", {
		style: {
			display: "flex",
			flexDirection: "column",
			gap: 12
		},
		children: [/* @__PURE__ */ V(n, { items: [
			{
				label: "Flota",
				href: "#"
			},
			{
				label: "Unidades",
				href: "#"
			},
			{ label: "KTR-882" }
		] }), /* @__PURE__ */ V(n, { items: [
			{
				label: "Flota",
				href: "#"
			},
			{
				label: "Regiones",
				href: "#"
			},
			{
				label: "Norte",
				href: "#"
			},
			{
				label: "Unidades",
				href: "#"
			},
			{
				label: "KTR-882",
				href: "#"
			},
			{ label: "Servicio 40k" }
		] })]
	}) },
	pagination: { render: () => /* @__PURE__ */ V(ne, {}) },
	"chart-legend": {
		variants: ["horizontal", "vertical"],
		render: ({ variant: e }) => /* @__PURE__ */ V(o, {
			direction: e === "vertical" ? "vertical" : "horizontal",
			items: [
				{
					label: "Combustible",
					color: "var(--viz-1)",
					value: "73%"
				},
				{
					label: "Peaje",
					color: "var(--viz-4)",
					value: "17%"
				},
				{
					label: "Mantenimiento",
					color: "var(--viz-5)",
					value: "10%"
				}
			]
		})
	},
	button: {
		variants: [
			"primary",
			"secondary",
			"ghost",
			"danger",
			"link"
		],
		sizes: [
			"sm",
			"md",
			"lg"
		],
		render: ({ variant: e, size: t }) => /* @__PURE__ */ V(i, {
			variant: e,
			size: t,
			icon: "add",
			children: "Agregar unidad"
		})
	},
	"icon-button": { render: () => /* @__PURE__ */ H("div", {
		style: {
			display: "flex",
			gap: 8
		},
		children: [
			/* @__PURE__ */ V(m, {
				icon: "favorite",
				ariaLabel: "Favorito"
			}),
			/* @__PURE__ */ V(m, {
				icon: "favorite",
				ariaLabel: "Favorito activo",
				selected: !0
			}),
			/* @__PURE__ */ V(m, {
				icon: "delete",
				ariaLabel: "Eliminar",
				variant: "ghost"
			})
		]
	}) },
	card: {
		variants: [
			"elevated",
			"outlined",
			"inverse",
			"selected"
		],
		render: ({ variant: e }) => /* @__PURE__ */ H(a, {
			surface: e === "selected" ? "outlined" : e,
			selected: e === "selected",
			status: e === "outlined" ? "warning" : void 0,
			style: { width: 280 },
			children: [/* @__PURE__ */ H(_, {
				size: "sm",
				level: 3,
				description: "Radio interior menor que el de la tarjeta.",
				children: ["Tarjeta ", e]
			}), /* @__PURE__ */ V(t, {
				tone: "info",
				children: "Anidado"
			})]
		})
	},
	menu: { render: () => /* @__PURE__ */ V(k, {
		trigger: /* @__PURE__ */ V(i, {
			variant: "secondary",
			icon: "more_vert",
			children: "Acciones"
		}),
		items: [
			{
				label: "Editar",
				icon: "edit"
			},
			{
				label: "Duplicar",
				icon: "content_copy"
			},
			"divider",
			{
				label: "Eliminar",
				icon: "delete",
				danger: !0
			}
		]
	}) },
	tooltip: { render: () => /* @__PURE__ */ V(F, {
		content: "Explica sin interrumpir",
		children: /* @__PURE__ */ V(i, {
			variant: "secondary",
			children: "Pasa el cursor"
		})
	}) },
	tabs: {
		variants: [
			"pill",
			"underline",
			"bar"
		],
		render: ({ variant: e }) => /* @__PURE__ */ V(J, { variant: e })
	},
	segmented: {
		sizes: ["sm", "md"],
		render: ({ size: e }) => /* @__PURE__ */ V(Y, { size: e === "sm" ? "sm" : "md" })
	},
	stattile: { render: ({ density: e }) => /* @__PURE__ */ V(N, {
		label: "Viajes hoy",
		value: 412,
		delta: "+12% vs ayer",
		trend: [
			3,
			5,
			4,
			6,
			8,
			7,
			9
		],
		description: "Completados esta semana",
		loading: e === "loading",
		style: { width: 240 }
	}) },
	"data-table": { render: () => /* @__PURE__ */ V(z, {
		caption: "Personas del equipo",
		rowKey: "n",
		pageSize: 5,
		columns: [
			{
				key: "n",
				label: "Nombre"
			},
			{
				key: "rol",
				label: "Rol"
			},
			{
				key: "viajes",
				label: "Viajes",
				align: "right",
				mono: !0
			}
		],
		rows: Array.from({ length: 13 }, (e, t) => ({
			n: [
				"Ana Sosa",
				"Luis Prieto",
				"Marta Vidal",
				"Diego Vera",
				"Rosa Duarte"
			][t % 5] + (t > 4 ? " " + t : ""),
			rol: t % 2 ? "Conductor" : "Admin",
			viajes: 40 - t * 3
		})),
		style: { width: 520 }
	}) },
	"toast-host": { render: () => /* @__PURE__ */ V(T, {
		max: 3,
		children: /* @__PURE__ */ V(Q, {})
	}) },
	sidebar: { render: () => /* @__PURE__ */ V(M, {
		style: { height: 360 },
		activeId: "unidades",
		items: [{
			id: "op",
			label: "Operación",
			caption: !0,
			children: [{
				id: "unidades",
				label: "Unidades",
				icon: "local_taxi",
				badge: 3
			}, {
				id: "conductores",
				label: "Conductores",
				icon: "group"
			}]
		}, {
			id: "adm",
			label: "Administración",
			caption: !0,
			children: [{
				id: "roles",
				label: "Roles",
				icon: "admin_panel_settings"
			}, {
				id: "ajustes",
				label: "Ajustes",
				icon: "settings"
			}]
		}]
	}) },
	"transaction-group": { render: () => /* @__PURE__ */ H("div", {
		style: { width: 340 },
		children: [/* @__PURE__ */ H(B, {
			label: "Hoy",
			children: [/* @__PURE__ */ V(I, {
				category: "fuel",
				title: "Gasolinera Pemex #412",
				subtitle: "14:23",
				amount: -850.5
			}), /* @__PURE__ */ V(I, {
				category: "toll",
				title: "Caseta Tepotzotlán",
				subtitle: "09:10",
				amount: -118
			})]
		}), /* @__PURE__ */ V(B, {
			label: "Ayer",
			children: /* @__PURE__ */ V(I, {
				category: "fuel",
				title: "G500 Roma Norte",
				subtitle: "19:44",
				amount: -620.4
			})
		})]
	}) },
	"document-viewer": { render: () => /* @__PURE__ */ V(te, {
		title: "Tarjeta de circulación.pdf",
		height: 180,
		actions: /* @__PURE__ */ V(i, {
			variant: "ghost",
			size: "sm",
			icon: "download",
			children: "Descargar"
		}),
		children: /* @__PURE__ */ V("div", {
			style: {
				display: "grid",
				placeItems: "center",
				height: "100%",
				color: "var(--text-muted)"
			},
			children: "(el documento lo pinta el producto)"
		})
	}) },
	"help-center": { render: () => /* @__PURE__ */ V(O, {
		style: {
			width: 560,
			height: 300
		},
		articles: [
			{
				id: "a",
				title: "Cómo agregar una unidad",
				category: "Flota",
				content: "Ve a Unidades y pulsa Agregar."
			},
			{
				id: "b",
				title: "Congelar una tarjeta",
				category: "Tarjetas",
				content: "Desde el detalle de la tarjeta."
			},
			{
				id: "c",
				title: "Exportar reportes",
				category: "Reportes",
				content: "Cada dashboard exporta a CSV."
			}
		]
	}) },
	"notification-center": {
		variants: ["con-avisos", "vacio"],
		render: ({ variant: e }) => /* @__PURE__ */ V(A, { items: e === "vacio" ? [] : [{
			id: "1",
			tone: "warning",
			title: "Consumo 38% sobre promedio",
			desc: "KTR-882-A",
			time: "hace 2 h",
			read: !1
		}, {
			id: "2",
			tone: "success",
			title: "Servicio completado",
			desc: "MVD-101-C",
			time: "ayer",
			read: !0
		}] })
	},
	"section-header": {
		variants: [
			"sm",
			"md",
			"display"
		],
		render: ({ variant: e }) => /* @__PURE__ */ V(_, {
			size: e,
			description: "La bajada vive fuera del heading.",
			trailing: /* @__PURE__ */ V(t, { children: "3" }),
			children: "Actividad de la flota"
		})
	}
};
//#endregion
export { re as SPECIMENS };

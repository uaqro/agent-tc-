import e from "./es.js";
import t from "./en.js";
import n from "./pt.js";
import { jsx as r } from "react/jsx-runtime";
import { IntlProvider as i, useIntl as a } from "react-intl";
//#region src/i18n/FlowIntlProvider.tsx
var o = {
	es: e,
	en: t,
	pt: n
}, s = (e) => e.split("-")[0];
function c({ locale: e = "es", children: t }) {
	return /* @__PURE__ */ r(i, {
		locale: e,
		messages: o[s(e)],
		defaultLocale: "es",
		children: t
	});
}
function l() {
	return a();
}
//#endregion
export { c as FlowIntlProvider, l as useFlowIntl };

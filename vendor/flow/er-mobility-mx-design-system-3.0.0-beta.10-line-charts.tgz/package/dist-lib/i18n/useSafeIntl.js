import { useIntl as e } from "react-intl";
//#region src/i18n/useSafeIntl.ts
function t() {
	try {
		return e();
	} catch {
		return null;
	}
}
function n() {
	let e = t();
	return (t, n, r) => e ? e.formatMessage({
		id: t,
		defaultMessage: n
	}, r) : r ? Object.entries(r).reduce((e, [t, n]) => e.replaceAll(`{${t}}`, String(n)), n) : n;
}
function r() {
	return t()?.locale ?? "es-MX";
}
//#endregion
export { r as useLocale, t as useSafeIntl, n as useT };

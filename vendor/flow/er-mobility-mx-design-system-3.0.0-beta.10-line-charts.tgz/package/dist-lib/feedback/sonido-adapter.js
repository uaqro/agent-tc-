//#region src/feedback/sonido-adapter.ts
var e = {
	confirm: {
		hz: [880],
		seg: .06
	},
	complete: {
		hz: [660, 990],
		seg: .09
	},
	alert: {
		hz: [440, 330],
		seg: .14
	}
}, t = .08, n = null, r = () => {
	if (n) return n;
	let e = globalThis, t = e.AudioContext ?? e.webkitAudioContext;
	return t ? (n = new t(), n) : null;
}, i = (n, r) => {
	let { hz: i, seg: a } = e[r];
	i.forEach((e, r) => {
		let i = n.currentTime + r * a, o = n.createOscillator(), s = n.createGain();
		o.type = "sine", o.frequency.value = e, s.gain.setValueAtTime(1e-4, i), s.gain.exponentialRampToValueAtTime(t, i + a * .15), s.gain.exponentialRampToValueAtTime(1e-4, i + a), o.connect(s).connect(n.destination), o.start(i), o.stop(i + a);
	});
};
function a(e = {}) {
	return { sound(t, n) {
		if (e.apagado?.()) return;
		let a = r();
		if (a) {
			if (a.state === "suspended") {
				a.resume?.().then(() => i(a, n.kind)).catch(() => {});
				return;
			}
			i(a, n.kind);
		}
	} };
}
//#endregion
export { a as sonidoAdapter };

//#region src/feedback/momentos.json
var e = "design", t = "El vocabulario de lo que el sistema comunica fuera de la pantalla. Una pieza NO inventa un zumbido: nombra un momento que vive aquí, y el producto decide si eso se siente, se oye o no pasa nada. Mismo trato que events.json: solo su dueño cambia un status.", n = {
	card_frozen: {
		description: "La tarjeta quedó congelada: no se puede pagar con ella.",
		kind: "confirm",
		status: "proposed",
		surfaces: ["wallet"]
	},
	card_freeze_settled: {
		description: "La escarcha terminó y la tarjeta quedó cerrada. Es el SEGUNDO tiempo del mismo gesto, no otro suceso.",
		kind: "complete",
		status: "proposed",
		surfaces: ["wallet"]
	},
	card_thawed: {
		description: "La tarjeta volvió a estar activa.",
		kind: "confirm",
		status: "proposed",
		surfaces: ["wallet"]
	},
	card_added: {
		description: "Una tarjeta nueva aterrizó en el monedero.",
		kind: "complete",
		status: "proposed",
		surfaces: ["wallet"]
	},
	card_removed: {
		description: "Una tarjeta se dio de baja. Irreversible.",
		kind: "alert",
		status: "proposed",
		surfaces: ["wallet"]
	}
}, r = {
	owner: e,
	$comment: t,
	momentos: n
};
//#endregion
export { t as $comment, r as default, n as momentos, e as owner };

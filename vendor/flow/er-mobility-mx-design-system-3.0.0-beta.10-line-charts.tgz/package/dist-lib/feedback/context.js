"use client";
import e from "./momentos.js";
import { jsx as t } from "react/jsx-runtime";
import { createContext as n, useCallback as r, useContext as i, useMemo as a } from "react";
//#region src/feedback/context.tsx
var o = e, s = n(null);
function c({ adapter: e, children: n }) {
	return /* @__PURE__ */ t(s.Provider, {
		value: e ?? null,
		children: n
	});
}
function l() {
	let e = i(s);
	return r((t, n) => {
		let r = o.momentos[t];
		r && (e?.haptic?.(t, r), e?.sound?.(t, r), e?.fx?.(t, r, n));
	}, [e]);
}
function u() {
	return a(() => o.momentos, []);
}
//#endregion
export { c as FlowFeedbackProvider, l as useFeedback, u as useMomentos };

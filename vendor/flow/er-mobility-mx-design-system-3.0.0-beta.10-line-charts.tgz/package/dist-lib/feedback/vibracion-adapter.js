//#region src/feedback/vibracion-adapter.ts
var e = {
	confirm: 12,
	complete: [
		10,
		60,
		18
	],
	alert: [
		22,
		50,
		22
	]
};
function t(t = {}) {
	let n = () => typeof window < "u" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
	return { haptic(r, i) {
		t.apagado?.() || n() || navigator.vibrate?.(e[i.kind]);
	} };
}
//#endregion
export { t as vibracionAdapter };

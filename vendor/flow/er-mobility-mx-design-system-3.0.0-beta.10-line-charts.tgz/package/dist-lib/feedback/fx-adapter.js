import { leerToken as e } from "../tokens/leerToken.js";
//#region src/feedback/fx-adapter.ts
var t = 120, n = null, r = null, i = [], a = null;
function o() {
	if (r) return r;
	if (typeof document > "u") return null;
	let t = document.createElement("canvas");
	t.setAttribute("aria-hidden", "true"), t.style.cssText = `position:fixed;inset:0;pointer-events:none;z-index:${e("--z-fx") || "1400"}`, document.body.appendChild(t);
	let i = t.getContext?.("2d");
	return i ? (n = t, r = i, s(), i) : null;
}
function s() {
	if (!n || !r) return;
	let e = typeof devicePixelRatio == "number" ? devicePixelRatio : 1, t = typeof innerWidth == "number" ? innerWidth : 0, i = typeof innerHeight == "number" ? innerHeight : 0;
	n.width = t * e, n.height = i * e, r.setTransform?.(e, 0, 0, e, 0, 0);
}
var c = (e, t) => e + Math.random() * (t - e);
function l(e, t) {
	t.beginPath(), e.forma === "barra" ? t.rect(-e.tam, -e.tam / 2.5, e.tam * 2, e.tam / 1.25) : e.forma === "diamante" ? (t.moveTo(0, -e.tam), t.lineTo(e.tam * .6, 0), t.lineTo(0, e.tam), t.lineTo(-e.tam * .6, 0), t.closePath()) : e.forma === "gota" ? t.ellipse(0, 0, e.tam * .6, e.tam * 1.5, 0, 0, Math.PI * 2) : t.arc(0, 0, e.tam, 0, Math.PI * 2), t.fill();
}
function u() {
	let e = r;
	if (!e || !n) return;
	let t = n.width, o = n.height;
	e.clearRect(0, 0, t, o), i = i.filter((e) => e.vida > 0);
	for (let t of i) {
		if (t.espera > 0) {
			--t.espera;
			continue;
		}
		t.vx *= t.roce, t.vy = t.vy * t.roce + t.g, t.x += t.vx, t.y += t.vy, t.giro += t.vg, --t.vida, e.globalAlpha = Math.max(0, Math.min(1, t.vida / (t.max * .4))), e.fillStyle = t.color, e.save(), e.translate(t.x, t.y), e.rotate(t.giro), l(t, e), e.restore();
	}
	if (e.globalAlpha = 1, !i.length) {
		e.clearRect(0, 0, t, o), a = null;
		return;
	}
	a = requestAnimationFrame(u);
}
var d = (e) => e?.getBoundingClientRect?.() ?? {
	x: 0,
	y: 0,
	width: 0,
	height: 0
};
function f(n, r) {
	if (!o()) return;
	let s = d(r), l = d(n.hacia), f = Math.min(n.cantidad ?? 36, t), p = n.tokens.map((t) => e(t)).filter(Boolean);
	if (!p.length) return;
	let m = n.forma ?? "punto", h = s.x + s.width / 2, g = s.y + s.height / 2;
	for (let e = 0; e < f; e++) {
		let t = c(30, 60), r = {
			color: p[e % p.length],
			forma: m,
			tam: c(1.5, 4),
			giro: c(0, 3),
			vg: c(-.1, .1),
			roce: .985,
			vida: t,
			max: t
		};
		if (n.patron === "llueve") i.push({
			...r,
			x: s.x + c(0, s.width),
			y: s.y + s.height,
			vx: c(-.3, .3),
			vy: c(0, 1.2),
			g: .24,
			roce: .99,
			espera: c(4, 34)
		});
		else if (n.patron === "fluye" && n.hacia) {
			let t = l.x + l.width / 2, n = l.y + l.height / 2;
			i.push({
				...r,
				x: h + c(-12, 12),
				y: g,
				vx: (t - h) / 34 + c(-2, 2),
				vy: (n - g) / 30 + c(-1.5, .5),
				g: .02,
				espera: e * .5
			});
		} else n.patron === "chispea" ? i.push({
			...r,
			x: s.x + c(0, s.width),
			y: s.y + c(0, s.height),
			vx: c(-1.6, 1.6),
			vy: c(-2, .6),
			g: .03,
			espera: c(14, 30)
		}) : i.push({
			...r,
			x: h,
			y: g,
			vx: c(-7, 7),
			vy: c(-12, -4),
			g: .28,
			roce: .97,
			espera: 0
		});
	}
	a === null && typeof requestAnimationFrame == "function" && (a = requestAnimationFrame(u));
}
function p(e) {
	let t = () => typeof window < "u" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
	return { fx(n, r, i) {
		if (e.apagado?.() || t()) return;
		let a = e.efectos[n];
		a && i && f(a, i);
	} };
}
//#endregion
export { p as fxAdapter };

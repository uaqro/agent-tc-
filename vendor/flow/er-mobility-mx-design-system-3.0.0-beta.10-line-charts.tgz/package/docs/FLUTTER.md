# Flow en Flutter — por dónde se empieza

Esta guía es para el equipo que va a implementar Flow en Flutter. No cuenta cómo
funciona Flow: cuenta **qué hay hoy, qué falta, y dónde mirar** para no tener que
preguntar.

## Lo que ya puedes usar

**Los tokens, como paquete de Dart.** Desde el 13-oct-2026 no son seis archivos
sueltos: son un paquete `flow_tokens` con su `pubspec.yaml` y su barril, así que
se importan con una línea.

```dart
import 'package:flow_tokens/flow_tokens.dart';
```

**Viaja en el paquete publicado de npm**, así que hoy se obtiene instalando
`@er-mobility-mx/design-system`, y el paquete está en

```
node_modules/@er-mobility-mx/design-system/generated/tokens/dart/
  pubspec.yaml          name: flow_tokens, con la versión del diccionario
  lib/flow_tokens.dart  el barril: exporta todas las clases de la tabla de abajo
  lib/flow_*.dart       una por clase
```

### El canal de entrega: lo decidido y lo que falta

Lo de arriba funciona pero es incómodo de verdad: **obliga a un proyecto Flutter
a instalar un paquete de npm** para obtener un paquete de Dart. Mientras todo
vivía en un repositorio no se notaba; con vuestro repositorio aparte es lo
primero con lo que vais a chocar.

**Y ya está decidido adónde va**, en la enmienda del 15-oct-2026 al
[RFC 0013](../../../docs/rfcs/0013-dos-repos-un-canon.md): el canon y la fuente
del diccionario se van a **un repositorio neutral** —`Flow-DesignData-HANA`, que
en Azure será `design-data`— y los dos se publican por el **mismo** mecanismo, un
Universal Package versionado en Azure Artifacts que un paso de pipeline descarga
y desempaqueta. En vuestro lado eso es una dependencia `path:` sobre un
directorio vendorizado.

Ninguno de los dos artefactos vive dentro de una implementación, y ése es el
punto: un repositorio de React no puede ser dueño de lo que vosotros tenéis que
consumir.

Dos cosas que el transporte **no** puede ser, medidas:

- **`pub.dev` está descartado, no sopesado.** Este paquete lleva dentro
  `fonts/edenred_black.otf` y su registro de licencia, porque Flutter no soporta
  woff2 y esa cara no se obtiene en otro sitio. Es de uso interno bajo contrato y
  NDA: publicarla en un registro público la incumple.
- **Azure Artifacts no tiene feed de `pub`.** Soporta npm, NuGet, Maven, Python,
  Cargo y Universal Packages, y `pub` no consume Universal. Por eso el mecanismo
  es Universal Package más un paso de descarga, y no un `hosted:` apuntando a un
  feed del Grupo.

### El puente, mientras no haya Azure

Hasta que exista ese repositorio y su feed, el diccionario se consume con una
dependencia `git` contra el repositorio de React, con el paquete emitido
commiteado en una rama dedicada —`main` sigue ignorando `generated/`, porque el
manifiesto se emite y uno escrito a mano no existiría en un clon limpio—:

```yaml
dependencies:
  flow_tokens:
    git:
      url: https://github.com/ER-Mobility-MX/FlowHANA.git
      ref: <etiqueta>
      path: generated/tokens/dart
```

Es acoplamiento y está acotado a propósito. El coste real es un `pub get` inicial
más lento, no un problema de gobierno: el diccionario es **salida generada**, no
un contrato del que alguien sea dueño. **Su condición de retiro** está escrita:
el puente desaparece el día que el diccionario se emita desde el repositorio
neutral y se publique desde ahí.

**Así que no arranquéis integrándolo desde `node_modules`.** El puente es una
rama de este repositorio, `flow-tokens-dart`, con el paquete emitido en su
**raíz**, y se consume así:

```yaml
dependencies:
  flow_tokens:
    git:
      url: https://github.com/ER-Mobility-MX/FlowHANA.git
      ref: tokens-v3.0.0-beta.9
      path: .
```

**Fijad la etiqueta, no la rama.** Es la diferencia entre que vosotros tiréis
del diccionario cuando os convenga y que un cambio aquí os cambie el build sin
avisar. Cada publicación lleva la suya, con la versión del diccionario —que no
es la de npm: son dos cosas distintas, y el RFC 0013 lo mide.

La rama la escribe **solo** `scripts/puente-dart.mjs`, que `release.mjs` invoca
**después** de la batería. No es ceremonia: el paquete lleva la cara Edenred, y
`fnt-1` y `fnt-4` —las rejas que comprueban que una fuente redistribuida tenga
su licencia declarada— corren en `main` y no en esa rama. Una escritura a mano
publicaría la fuente sin que nadie mirase.

Y cuando llegue Azure cambia esa línea y nada más.

(Dentro de este repo son los mismos, en `packages/flow-react/generated/tokens/dart/`,
y los regenera `npm run tokens:build`. El manifiesto se **emite**: `generated/`
está en `.gitignore`, así que uno escrito a mano no existiría en un clon limpio, y
su versión sale de `package.json`, que es la única que hay.)

**Y compila**, lo cual hay que decir porque hasta ese día no: `dart analyze` sobre
los seis archivos que ya viajaban daba **138 hallazgos**. Faltaban los imports de
`BoxShadow` y `Cubic`, una clase se citaba sin importarse, y seis `static const`
llamaban a un método —que en Dart no es una expresión constante—. `PL5` y `PL6`
estaban en verde porque leen el Dart como **texto**: que el texto diga el valor
correcto no dice que el archivo compile. Lo mide ahora `npm run check:dart`
(dt-1), y sin `dart` instalado lo dice en vez de salir en cero.

Un detalle que os afecta: **los seis colores de `color-mix` son `static final`, no
`const`** —`withValues` no es un constructor constante—, así que no se pueden usar
en un constructor `const`. Son `surfaceBackdrop`, `surfaceAccentSubtle` y los
cuatro `status*Bg` del modo oscuro.

Estas son las clases de constantes:

| Clase                          | Qué trae                                                                        |
| ------------------------------ | ------------------------------------------------------------------------------- |
| `FlowRef`                      | la escala cruda: espaciado, radios, rampas de color, duraciones                 |
| `FlowBrand`                    | la paleta de marca                                                              |
| `FlowSysLight`                 | las decisiones de interfaz en claro: superficies, texto, bordes, estado         |
| `FlowSysDark`                  | las mismas, en oscuro                                                           |
| `FlowSysScale`                 | lo que no cambia con el modo: espaciado semántico, tamaños, motion              |
| `FlowSysScaleTypography`       | las decisiones de tipo, con sus cuatro campos por nivel                         |
| `FlowSysCompact`               | lo que `compact` redefine: radios, padding de zona y de control, alturas, celda |
| `FlowSysCompactTypography`     | la escala de tipo de `compact`, con los mismos cuatro campos                    |
| `FlowSysComfortable`           | lo mismo para `comfortable`                                                     |
| `FlowSysComfortableTypography` | su escala de tipo                                                               |

La última es nueva, y antes **no existía**: hasta hoy a Dart le llegaba la escala
cruda de tipo —`FlowRef.refTypeSize16`, `refTypeWtBold`— y **ni una decisión**, o
sea que una app en Flutter tenía que reinventar la jerarquía entera a mano. No
era una omisión visible: la reja de paridad (PL5) tenía su lista de pares
**escrita a mano** y la pareja de tipografía estaba en el SCSS y no en el Dart,
así que los 21 tokens no estaban en la lista de cosas que comparar. Hoy la lista
se deriva de las salidas que hay.

Un `--type-*` es un shorthand de CSS y Dart no tiene shorthand, así que cada
nivel sale en los **cuatro campos que `TextStyle` pide** — y `height` de Flutter
es el `line-height` sin unidad de CSS, el mismo multiplicador, así que el valor
viaja tal cual:

```dart
TextStyle(
  fontWeight: FontWeight.w400,                       // typeBodyMdWeight
  fontSize: FlowSysScaleTypography.typeBodyMdSize,   // 16.0
  height: FlowSysScaleTypography.typeBodyMdHeight,   // 1.55
  fontFamily: 'Ubuntu',                              // typeBodyMdFamily (la pila completa)
)
```

**Las tres densidades están**, desde el 13-oct-2026. Hasta ese día `compact` y
`comfortable` vivían **solo en el CSS escrito a mano**: 35 y 33 tokens que no
llegaban ni a Dart ni a SCSS, y que `D6` —la reja cuyo trabajo es que el
diccionario y el CSS digan lo mismo— **tampoco comparaba**, porque su lector
saltaba los bloques `[data-density]` por nombre. Un `continue` con el nombre del
eje dentro.

Ahora son el tercer eje del diccionario, junto al modo, y salen en cuatro clases:

```dart
// el radio de un checkbox
FlowSysScale.radiusXs   // 8.0  — por defecto
FlowSysCompact.radiusXs // 4.0  — la escala baja un índice entera

// y la escala de tipo, con sus cuatro campos por nivel
FlowSysCompactTypography.typeBodyMdSize // 14.0 (por defecto son 16)
```

**Una clase de densidad solo declara lo que ESA densidad cambia**, así que leedla
con la base detrás: `FlowSysComfortable` trae tres radios —`radiusLg`, `radiusMd`
y `radiusXl`— y **no** `radiusXs`, porque el tramo bajo no sube y eso es
deliberado: «holgado» no significa redondear más un checkbox. La ausencia del
miembro **es** la afirmación. La consecuencia práctica: vuestra resolución lee el
miembro de la clase de densidad cuando existe y el de `FlowSysScale` cuando no.

Dos cosas que conviene saber de cómo está declarada: una densidad **reescribe la
decisión, no el paso** —la escala cruda de espacio (`refSpace*`) vale lo mismo en
las tres, a propósito—, y lo que decide de un tipo es el **tamaño y el
interlineado**: que el peso y la familia sigan siendo los de la base lo comprueba
`dns-3`.

Cada valor sale con su tipo de Flutter: `Color(0xAARRGGBB)`, `double`,
`Duration`, `Cubic`. Las referencias entre tokens salen resueltas y cualificadas
—`FlowBrand.flowGrey900.withValues(alpha: 0.4)`—, porque Dart no tiene `var()`.

**Y lo que esta guía escribe en Dart se contrasta con el paquete** (`dt-2`, dentro
de `npm run check:dart`): cada clase, cada miembro cualificado, cada método
invocado sobre un token y el `package:` del import de arriba tienen que existir en
lo emitido. Lo pedía un desfase de un día: el 13-oct-2026 el emisor pasó de
`withOpacity` a `withValues(alpha:)` —la primera está deprecada en el Flutter
actual— y esta página siguió enseñando la vieja. Si copiáis una línea de aquí y
no compila, es un fallo de este repo y no vuestro.

**Las sombras y el tracking ya no son cadenas de CSS** (13-oct-2026). Hasta ese
día salían como `String` con el valor de CSS dentro, así que para pintar una
sombra había que parsear CSS — y tres de las del modo claro llevan **dos capas**:

- **sombras** y el **anillo de foco** salen como `List<BoxShadow>`, con `offset`,
  `blurRadius`, `spreadRadius` y `color` por capa. El anillo es una sombra de solo
  spread (`0 0 0 3px` en CSS), así que entra por el mismo sitio;
- **tracking** sale como `double` con el valor en **em**: Flutter quiere
  `letterSpacing` en píxeles lógicos, así que lo multiplica por el tamaño de letra
  quien lo usa. No se precalcula por nivel a propósito — los tres tokens de
  tracking no están atados a un nivel de tipo (`typ-4` decide dónde se aplica cada
  uno), así que un `letterSpacing` por nivel sería inventarse la relación;
- el **desplazamiento del hover** (`--lift-hover`, `translateY(-3px)` en CSS)
  sale como el `dy` en píxeles lógicos: `FlowSysScale.liftHover == -3.0`;
- **familias tipográficas** siguen siendo `String`, y ahí es lo correcto — son las
  **únicas** que quedan, y lo comprueba `PL5` token a token.

```dart
Container(
  decoration: BoxDecoration(boxShadow: FlowSysLight.shadowRaised),
)
Text('ACTIVAS', style: TextStyle(
  fontSize: FlowSysScaleTypography.typeLabelSmSize,
  letterSpacing: FlowSysScaleTypography.typeLabelSmSize * FlowSysScale.trackingOverline,
))
```

`PL5` sigue comparando cada valor contra el CSS: recompone la `List<BoxShadow>` a
la forma de la sombra y los dos lados pasan por la misma forma normal, igual que
ya hacía con el shorthand de tipo.

Eso está declarado en `tokens/platforms.json`, no escondido: la plataforma `dart`
está **experimental**, con reja y sin consumidor. Sube a _soportada_ cuando
vuestro repo sea el consumidor.

## Las fuentes

Flutter **no soporta woff2**, así que las 35 caras de `public/fonts` no le sirven
de nada. El reparto se decidió midiendo, y cada familia sale por donde puede:

| Familia              | Cómo llega a vuestra app                                   |
| -------------------- | ---------------------------------------------------------- |
| **Edenred**          | viaja DENTRO de este paquete, en `fonts/edenred_black.otf` |
| **Ubuntu**           | la traéis vosotros (Ubuntu Font Licence)                   |
| **IBM Plex Mono**    | la traéis vosotros (OFL)                                   |
| **Material Symbols** | la traéis vosotros (Apache-2.0)                            |

### Edenred viaja, porque no se puede obtener en otro sitio

Es tipografía propietaria: su registro vive en `fonts/LICENSES/Edenred.txt` y
viaja **al lado del archivo** a propósito —una fuente de marca sin el documento
que dice bajo qué derecho se redistribuye es lo que `fnt-1` existe para impedir—.
Leedlo: la cara es de **uso interno** y **no es modificable**, así que no la
subseteéis ni la reinstanciéis. Si hiciera falta otra forma, la entrega la marca.

La marca entregó el `.otf` el 14-oct-2026. Hasta entonces el paquete os daba
tokens de tipografía y **ninguna tipografía**.

```dart
Text('Mi balance', style: TextStyle(
  fontFamily: 'Edenred',
  package: 'flow_tokens',                              // la declara ESTE paquete
  fontSize: FlowSysScaleTypography.typeHeadlineLgSize, // 28.0
  height: FlowSysScaleTypography.typeHeadlineLgHeight,
))
```

Hay **una sola cara**, la Black (peso 900), y es suficiente: el Core Team decidió
el 6-oct-2026 que los títulos se distinguen por **tamaño** y no por peso, así que
toda la escala de display es Black. Las otras dos caras que hubo se retiraron por
`fnt-2` —una cara sin consumidor es una fuente de marca que se redistribuye sin
motivo—.

El `weight: 900` del `pubspec.yaml` no está escrito a mano: sale del
`OS/2.usWeightClass` del propio archivo. **En esta familia el nombre del archivo
no dice el peso** —medido sobre los seis `.otf` de la entrega, `edenred.otf` es
peso 500 y `edenred_medium.otf` es 600—, así que un número a mano habría mentido
sin que nada lo contradijera. Lo comprueba `fnt-8` (`check:dart`), que además
exige que el archivo copiado sea byte a byte su origen y que el registro viaje.

### Las otras tres no viajan, y por qué

Las tres son redistribuibles, así que no es una cuestión de derecho sino de peso.
**Material Symbols** es el caso que se midió: su subset —el catálogo exacto que
Flow nombra— pesa **338 KB en woff2 y 1118 KB en truetype**, comprobado
emitiéndolo con el mismo subsetter. Meter eso aquí sería cobrarle a cada
consumidor de React, que es casi todos, el peso de una descarga pública que
dobla el tamaño del paquete.

Se descarga de [fonts.google.com/icons](https://fonts.google.com/icons?icon.set=Material+Symbols)
y, si la subseteáis, estos son los ejes con los que este sistema la pide:

| Eje    | Valor             |
| ------ | ----------------- |
| `opsz` | 24                |
| `wght` | 400               |
| `FILL` | 0 a 1 (defecto 0) |

`FILL` tiene que quedar **variable**: el icono activo se marca por relleno y no
por color (`ico-4`), así que una instancia fija a 0 se lleva ese estado por
delante. Y ojo con una diferencia de fondo respecto a `Icons.*` de Flutter: Flow
pide cada icono por **ligadura** —el texto `dashboard` dibuja el glifo—, así que
necesitáis la cara con `liga` y `rlig` activas, y `--tree-shake-icons` no os va a
ayudar: solo entiende `IconData`.

Ubuntu e IBM Plex Mono están en Google Fonts igual, y ahí el paquete `google_fonts`
os las resuelve sin bundlear nada. Las familias que el diccionario emite son
cadenas con la **pila completa** (`typeBodyMdFamily`), así que el nombre que
necesitáis es el primero de la pila.

## Qué piezas son vuestras

No es el catálogo entero. Una pieza declara su **form factor** en el canon
(`contracts/<id>.json`, campo `formFactor`), y el conjunto de móvil se comprueba
con:

```bash
npm run check:form-factor
```

Esa reja imprime cuántas piezas alcanza una pantalla móvil y cuántas lo declaran.
**Alcanzable** no es «sale en una pantalla»: si una pantalla monta `IdentityCheck`,
también necesitáis `BiometricPrompt` y `PasscodeKeypad`, que ninguna pantalla
nombra. La reja cuenta eso.

Para sacar la lista, sin leer código. **Y sale de vuestro propio manifiesto, no
de la ficha de React**: desde el 16-oct-2026 `items.json` ya no afirma nada de
Flutter — esa verdad la publicáis vosotros (RFC 0013 §3), que es el único sitio
donde tiene dueño:

```bash
node -e "const m=require('./manifest.json'); \
  console.log(Object.entries(m.items) \
    .filter(([,v])=>v.maturity && v.maturity!=='n/a') \
    .map(([id])=>id).sort().join('\n'))"
```

Cada entrada dice su estado con la escala oficial: **89 en `planned`**
—comprometido, sin código aún—, **4 en `n/a`** y **3 en `beta`**: `button`,
`field` e `input`, que ya tienen código y testigos. Según avancéis, las demás
pasan a `beta` y `stable` desde aquí, y nadie fuera puede escribirlo por
vosotros: `ff-4` exige que toda pieza de móvil tenga su estado publicado en este
manifiesto, y la AUSENCIA es un hallazgo — si de verdad no aplica, se dice con
`n/a`.

(El recuento lo vigila una reja. Decía 82 desde el 13-oct-2026, y entre tanto
entraron dos piezas más: una cifra con fecha al lado parece medida y es una
transcripción, que es justo lo que envejece sin que nadie se entere.)

## Qué contrato tiene cada pieza

En la rama `canonical`, `contracts/<id>.json`. Cada uno trae:

- **`api.members`** — las props, con tipo y nota. Es lo prometido, no lo que
  hace hoy una implementación.
- **`conformance`** — los criterios, con su id (`idc-1`, `sel-7`). Los marcados
  `automated` son los que un test debe citar por id; así se cuenta la cobertura.
- **`nonGoals`** — lo que la pieza **no** hace, que suele ahorrar más tiempo que
  lo que hace.
- **`deps`** — lo que hay que preparar antes: una librería, un global, un asset.

## Los flujos que todavía no tienen código

Hay recetas en el canon con contrato y criterios escritos y **sin
implementación** —`Passcode entry`, `Biometric unlock`, `QR station scan`,
`Fuel session`, `Toll passage`, `Points redemption`…—. En la ficha aparecen con
`platforms.web: "n/a"`, que hoy se lee como «no aplica en web» y significa otra
cosa: **su form factor es el vuestro**. Está discutido en el
[RFC 0010](../../../docs/rfcs/0010-la-superficie-es-un-eje.md).

Para vosotros son el mejor punto de partida por dos razones, y una de ellas
**hubo que construirla**: no hay una implementación web con la que discutir, y
**ocho de las doce ya tienen contrato** desde el 15-oct-2026 —`device-pairing`,
`qr-station-scan`, `toll-passage`, `fault-report`, `reward-catalogue`,
`points-redemption`, `referral-invite` y `notification-setup`—, con su API y sus
criterios escritos.

Hasta ese día esta guía decía que «el contrato ya está decidido» de las doce, y
era **falso**: ninguna lo tenía. Quedan cuatro sin él, y no por redacción
pendiente sino porque cada una es una decisión — `legacy-pin-login` está
retirada en 3.0, `passcode-entry` y `biometric-unlock` son lo que ya hacen
`identity-check` y `biometric`, y `fuel-session` tiene en `charge-session` la
misma receta con otra energía. Lo cuenta `ff-8` con trinquete en 4, y vuestro
manifiesto las marca con `sinContrato: true`.

## Lo que este repo espera de vuelta

Cuando vuestro repo consuma los tokens, dos cosas cambian aquí y conviene que
lleguen juntas:

1. `tokens/platforms.json` — `dart` declara **consumidor**, y pasa a `soportada`.
   La reja `check:platforms` (PL4) lo exige: sin consumidor no sube.
2. **Vuestro manifiesto deja de ser una semilla.** Desde el 15-oct-2026 el estado
   de Flutter lo publica vuestro repositorio en su `manifest.json`, no esta
   ficha: las madureces se declaran ahí y la cobertura se **deriva** de vuestra
   suite citando los ids de criterio. Aquí se lee y se compone, y `ff-7` exige
   que lo que diga vuestro manifiesto y lo que diga la ficha coincidan mientras
   los dos convivan.

# Migración desde Flow 1.x

Guía para quien llega del Flow viejo (`@flow/components` / `@flow/patterns`, 1.0.0-rc.x)
al sistema actual. Su trabajo es uno solo: que nadie busque una pieza o una prop del 1.x,
no la encuentre, y crea que falta. Todo lo que no cruzó el puente está aquí, con su
veredicto y su heredero.

Fuentes: diff de uniones viejo↔nuevo (V1–V12, plan de migración eOne §0-B) y censo
completo del inventario 1.x contra el canon (7-sep-2026: 56 componentes + 36 patterns
auditados pieza por pieza).

## Renombres — mismo trabajo, otro nombre

| 1.x                                                                                                                                                                                                 | Ahora                                                                                                       |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `FlowTag` (etiqueta de estado, 5 tonos)                                                                                                                                                             | `StatusPill` (o `Badge` con `tone` si no lleva dot); `variant="code"` → `InlineCode`                        |
| `FlowBadge` — punto sobre un control                                                                                                                                                                | contador de `IconButton` y `TabBar` — el contador no es pieza                                               |
| `FlowBadge` — estado con texto                                                                                                                                                                      | `StatusPill` (`label` + `tone`)                                                                             |
| `FlowBadge` — cifra o métrica con tono                                                                                                                                                              | `Badge` con `tone` (acepta `children`)                                                                      |
| `FlowDateRangePicker`                                                                                                                                                                               | `DatePicker` con `mode="range"` (`DateRangePicker` sigue como alias deprecado)                              |
| `FlowDataTable`                                                                                                                                                                                     | `DataTable` — el pattern que compone `Table`, `Pagination` y `ActiveFilters`                                |
| `FlowThemeProvider` / `useFlowTheme`                                                                                                                                                                | `FlowModeProvider` / `useFlowMode` (administra `data-mode` en `<html>`, resuelve `system`, expone `toggle`) |
| `FlowSnackbar`                                                                                                                                                                                      | `Toast` (+ `ToastHost`/`useToast`)                                                                          |
| `FlowTextInput` / `FlowTextArea`                                                                                                                                                                    | `Input` / `Textarea`                                                                                        |
| `FlowPhoneInput`                                                                                                                                                                                    | `InputPhone` (prefijo `ReactNode`: bandera + lada)                                                          |
| `FlowBottomNav`                                                                                                                                                                                     | `TabBar`                                                                                                    |
| `FlowBreadcrumbs`                                                                                                                                                                                   | `Breadcrumb`                                                                                                |
| `FlowToggleButton`                                                                                                                                                                                  | `ToggleControl`                                                                                             |
| `FlowSegmentedControl`                                                                                                                                                                              | `SegmentedControl`                                                                                          |
| `FlowTreeView`                                                                                                                                                                                      | `TableTree`                                                                                                 |
| `FlowKPICard` / `FlowKPITrendIndicator`                                                                                                                                                             | `StatTile` (con `delta` y `trend`)                                                                          |
| Props: Tag `status`→Badge `tone` · KPI `trend`→`tone` · Tabs `filled/line`→`pill/underline` · `iconPlacement`→`iconTrailing` · Input `inside`→`insetLabel` · Skeleton `circular/rect`→`circle/card` |                                                                                                             |

## Sin cambio salvo el prefijo

Estas conservan su nombre sin `Flow`. No estaban en esta guía y son **el grueso del uso
real**: en el piloto de eOne suman 152 usos en `main` y 193 en `aig/main`, concentrados
en `FlowCard` (50–76) y `FlowButton` (19–27).

| 1.x               | Ahora        | Capa       |
| ----------------- | ------------ | ---------- |
| `FlowAvatar`      | `Avatar`     | primitives |
| `FlowButton`      | `Button`     | primitives |
| `FlowCard`        | `Card`       | components |
| `FlowChip`        | `Chip`       | primitives |
| `FlowDialog`      | `Dialog`     | components |
| `FlowIconButton`  | `IconButton` | primitives |
| `FlowProgressBar` | `Progress`   | primitives |
| `FlowSelect`      | `Select`     | primitives |
| `FlowSidebar`     | `Sidebar`    | components |
| `FlowTabs`        | `Tabs`       | components |
| `FlowTopbar`      | `TopBar`     | components |

Ojo con `FlowTopbar`: la capitalización cambia — es `TopBar`, no `Topbar`.

### `Flag` pide dos líneas de hospedaje

`Flag` no cambia de nombre ni de props, pero **sus archivos los sirve tu app**. Desde el
[RFC 0012](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0012-una-bandera-no-es-un-activo-de-compilacion.md)
la imagen es dato de ejecución: `Flag` arma la URL al pintar, así que ningún empaquetador
la ve. Copia los códigos de tus países —`npx flow-banderas --codigos mx,us --destino public/flags`—
y declara dónde los sirves con `FlowFlagsProvider baseUrl="/flags"`. Es el mismo trato que
las fuentes autoalojadas, y por el mismo motivo: medido en la app de referencia, la hoja de
`flag-icons` metía 143 SVG y 3,8 MB en el build para pintar ocho banderas que pesan 170 KB.

Mientras no declares la base, `Flag` sigue funcionando por el camino 1.x —el entry
`@er-mobility-mx/design-system/flag`, que trae la hoja global— y te avisa en consola en
desarrollo. Ese entry se retira en 4.0.

### Valores de prop que también cambian

- **`status="error"` no existe.** La escala de tono del sistema es
  `success | warning | danger | info | neutral`: el mapeo es `error` → `danger`. Aparece
  en 3 de los 10 usos de badge del piloto, y uno ya lo esquiva con `as any`.
- **El significado no va dentro del texto.** «Aprobado ✓» y «Rechazado ✗» llevan el glifo
  en el label; en Flow lo dice el `tone` más un icono del sistema. Ningún emoji.

## Piezas propias de tu app — qué hacer con ellas

Quien viene del 1.x suele traer envoltorios propios. El caso medido en el piloto de eOne:

**`FlowIcon`** — 46 a 58 usos, el segundo componente más frecuente de la app, y **no es del
sistema**: vive en `src/components/FlowIcon.tsx` e incrusta a mano unos 25 paths SVG. Su
destino no es una pieza, es la ligadura:

```tsx
<span className="flow-symbol" aria-hidden="true">
  bolt
</span>
```

La sustitución es más barata de lo que parece, porque esos paths **ya son Material
Symbols** (`viewBox="0 -960 960 960"`) bajo nombres estilo Feather, y `mapEoneIcon`
traduce justo esos nombres. Dos avisos antes de correr el codemod:

- **No lo sustituyas por `IconButton`.** `FlowIcon` pinta un glifo inerte; `IconButton` es
  un control con `onClick`, `ariaLabel` obligatorio y objetivo de 44 px. Cambiar uno por
  otro convierte medio centenar de glifos decorativos en botones, y el lector de pantalla
  anuncia controles que no hacen nada.
- **El `color` se revisa uso por uso.** Hay hex crudos (`color="#ca0e00"`), que rompen el
  modo oscuro, y tokens 1.x con fallback hex (`var(--sys-info-primary, #0284c7)`), que
  `compat-eone.css` solo cubre a medias. El destino es `currentColor` heredado o un token
  semántico.

## Absorciones — el trabajo vive dentro de otra pieza

Esta tabla no se escribe a ojo: `check:absorciones` exige que **todo** lo que un
contrato declara haber absorbido (`supersedes`) aparezca aquí. Al conectar esa
reja faltaban 16 de 18 nombres — quien venía de un `FlowInputPassword` o un
`FlowTableDense` buscaba en esta guía y no encontraba nada.

| 1.x                                                        | Dónde vive ahora                                                                                                                                    |
| ---------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| `FlowAutocomplete`                                         | `Select` con `searchable`                                                                                                                           |
| `FlowCommandPalette`                                       | `GlobalSearch` (paleta con atajo, campo en línea o página)                                                                                          |
| `FlowConfirmationDialog`                                   | `Dialog` (las confirmaciones son su caso, no una variante)                                                                                          |
| `FlowColumnConfigurator`                                   | `DataGrid.columns` + `SavedViews`                                                                                                                   |
| `FlowSortControl`                                          | `sort`/`onSortChange` de `Table` y `DataGrid`                                                                                                       |
| `FlowVirtualDataTable`                                     | `DataGrid`                                                                                                                                          |
| `FlowAdvancedFilters`                                      | `FilterBar` + `ActiveFilters`                                                                                                                       |
| `FlowFullscreenSheet`                                      | `BottomSheet` con `fullscreen`                                                                                                                      |
| `FlowToolbar`                                              | repartida: `DataTable` (búsqueda, selección y lote en una sola franja) + `QuickActionBar` (acciones sueltas)                                        |
| `FlowCountrySelect`                                        | receta `country-select-pattern`: `Select searchable` + `Flag` + `renderOption`, lada sincronizada en `InputPhone` (pai-p5: el componente no vuelve) |
| `FlowInlineValidationMessage`                              | `Field` (inyecta `describedby`)                                                                                                                     |
| `FlowShortcutGrid`                                         | `QuickAction` / `QuickActionBar`                                                                                                                    |
| `FlowInputDate`                                            | `DatePicker` con `mode="single"`                                                                                                                    |
| `FlowInputPassword`                                        | `Input type="password" revealable` — el ojo es de la pieza, no un botón al lado                                                                     |
| `FlowInputEmail`                                           | `Input type="email" autoComplete="email"`                                                                                                           |
| `FlowSelectMultiple`                                       | `Select multiple` — con la prop, el valor es `string[]` (sel-8)                                                                                     |
| `FlowSelectCombo` / `FlowSelectWithInput` / `FlowCombobox` | `Select searchable`                                                                                                                                 |
| `FlowSelectCountry`                                        | receta `country-select-pattern`: `Select searchable` + `Flag` + `renderOption`                                                                      |
| `FlowTableDense`                                           | `Table density="compact"` — la densidad no es otra tabla                                                                                            |
| `FlowTableExpandable`                                      | `TableTree` (filas con `children`, piel de `DataGrid` con `tree`)                                                                                   |
| `FlowTableTimeline`                                        | `Timeline mode="events"`                                                                                                                            |
| `FlowLineChart`                                            | `FlowChart type="line"`                                                                                                                             |
| `FlowStackedBars100`                                       | `FlowChart type="stacked100"`                                                                                                                       |
| `FlowHeatmap`                                              | `FlowChart type="heatmap"` (pide `matrix`, ignora `series`)                                                                                         |
| `FlowWaterfallChart`                                       | `FlowChart type="waterfall"` (pide `series` y `totals`)                                                                                             |
| `FlowPolarChart`                                           | `FlowChart type="radar"` (pide `indicators` y `series`)                                                                                             |

## Muertes declaradas — props y ejes (V6–V12)

- **`intent` en Button/IconButton** (V6): colapsado en `variant="danger"`. El botón-warning
  no tuvo demanda medible (×0 en eOne); si aparece, se argumenta con pantalla, no se repone.
- **`tertiary` / `outlined`** (V7): absorción documentada — `tertiary`→`ghost`,
  `outlined`→`secondary`.
- **`xl` en los controles** (V8): muere global. El caso «grande» lo da `density="comfortable"`.
- **`size` por instancia en Badge/Switch/Tooltip/EmptyState/Skeleton/Stepper/Tabs/Dialog** (V9):
  decisión de arquitectura — la escala es de densidad global, no de cada pieza.
- **`Switch.labelPosition`** (V10): ×0 uso. Muere.
- **`Avatar shape="square"` y `status="away"`** (V11): ×0 uso. Mueren.
- **`Card variant="stat"` / `padding="container"` / `status="neutral"`** (V12): restos del
  Card multiuso. `stat` es `StatTile`; la escala de padding es `none/sm/md/lg`.
- **`Chip.tone` no nace** (V2, decidido 7-sep-2026): la frontera Chip/Badge es la
  interactividad, no el color. Un chip tintado de solo lectura es `Badge` con `tone`;
  un filtro interactivo no carga color semántico. Los `variants` viejos
  (`filled/filter/outlined/tonal`) mueren con él.
- **`Card.padding="xl"` no vuelve** (V3, decidido 7-sep-2026): reintroducir `xl` solo
  en Card contradiría la muerte global de `xl` (V8). Codemod `xl`→`lg` (×4 en eOne);
  para una excepción real existe el puente declarado: `padding` acepta un valor libre.
- **`tone="danger"` en Progress no nace** (V1, decidido 7-sep-2026): una barra "en
  peligro" es semánticamente un techo — trabajo de `LimitBar`, cuyo contrato deja
  declarado el color-por-porcentaje como enhancement a decidir con pantalla. Los tonos
  reales de Progress son `accent | success | warning | ink` (los que su contrato
  siempre prometió).

## Muertes declaradas — piezas (censo 7-sep-2026)

- **`FlowFAB`**: la acción principal vive en `PageHeader` o `QuickActionBar`; un botón
  flotante pelea con la `TabBar` en mobile.
- **`FlowHoverCard`**: el hover no existe en touch. Info breve → `Tooltip`; contenido
  rico → `Popover` (click).
- **`FlowSplitPane`**: `PageFrame`/`AutoGrid`. Renace solo si un template lo exige.
- **`FlowFieldset`**: agrupar campos es composición — `SectionHeader` + `Field` dentro
  del form, no componente.
- **`FlowDragSortableList`**: muere el genérico; reordenar es capacidad de la pieza dueña
  (kanban, `DataGrid`, `WidgetLibrary`). Misma política para el swipe (trw-5).
- **`FlowColorPicker`**: fuera de dominio.
- **`FlowRichTextEditor`**: fuera de dominio (`Textarea` lo declara nonGoal).

## Nacencias pendientes — existen como `planned`, aún sin código

Si vienes buscando una de estas, no falta: ya tiene contrato en el canon y espera su
pantalla. `planned` es un **compromiso**, no deuda: `check:conformance` cuenta aparte sus
criterios automatizados —no se puede escribir el test de algo que no existe— y la escala
oficial no tiene `proposed`, que es el estado de un EVENTO de growth y se coló aquí por el
camino.

- **`pull-to-refresh`** (ptr-1..3) — Wallet/Rutas mobile.
- **`transfer-list`** (trl-1..3) — asignación masiva: config-roles, fleet-assignment.
- **`avatar-group`** (avg-1..3) — extiende `avatar`; fleet-assignment.
- **Swipe en filas**: criterio trw-5 de `transaction-row` — el gesto es atajo, nunca
  única vía, y vive encapsulado en la pieza dueña.

La tabla V1–V12 quedó sin reintroducciones pendientes: V1 resultó deriva interna
(el contrato de Progress ya prometía `success`/`ink` y el código implementaba dos
tonos — cerrado en el código, no agregado por eOne) y V3 murió con V8. Solo V4
(Dialog form) y V5 (Stepper error por paso) siguen a prueba, atadas a sus tandas
de F3.

## Lista intermedia de estaciones

`PeekSheet` y `StationRow` se conservan exportados, pero están deprecados. En el flujo móvil, eliminar la lista intermedia y usar `StationFinder`: buscar o filtrar las estaciones, tocar su pin y abrir el detalle modal. No montar un peek permanente detrás de la navegación inferior.

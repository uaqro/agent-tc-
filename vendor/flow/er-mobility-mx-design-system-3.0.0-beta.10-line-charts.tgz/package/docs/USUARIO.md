# Flow — guía del usuario

Reglas para quien usa Flow **desde su propio repo** — humano o agente. La instalación
paso a paso vive en el README; esta página es el contrato de uso: lo que el sistema
te da resuelto y lo que espera de ti a cambio. Viaja en el paquete
(`node_modules/@er-mobility-mx/design-system/docs/USUARIO.md`) para que tu agente
la lea sin salir de tu repo.

## Lo mínimo que tu app monta

```tsx
import '@er-mobility-mx/design-system/styles.css' // tokens + componentes
import '@er-mobility-mx/design-system/reset.css' // opcional: solo si Flow es tu único DS
import { FlowIntlProvider } from '@er-mobility-mx/design-system'

;<FlowIntlProvider locale="es">
  <App />
</FlowIntlProvider>
```

Sin el provider de i18n, los patterns revientan con `Could not find required intl object`.
Fuentes e iconos: los `<link>` de Google Fonts del README, o las self-hosted para redes con CSP.

## Modo prototipo: la ruta corta

Si lo que necesitas es una pantalla para enseñar y discutir, no empieces por piezas sueltas:

1. **Elige la plantilla más cercana** en `docs/templates/` (viaja en este paquete) o pídesela a tu agente con `list_templates`.
2. **Copia sus archivos** y sustituye los datos de ejemplo por los tuyos.
3. **Cámbiale lo que sobre.** Son punto de partida, no API: puedes quitar secciones, reordenar y renombrar.
4. **No toques los interiores de las piezas** (regla 3 de abajo). Si una pieza no hace lo que necesitas, pídela: eso es una solicitud al sistema, con tu pantalla como evidencia.
5. **Pasa el checklist** del final antes de enseñarla.

Lo que el sistema ya te resuelve —modo oscuro, foco, teclado en overlays, densidad, i18n— lo tienes gratis si usas las piezas tal cual. Cada vez que lo reimplementas, lo pierdes.

## Las siete normas de quien consume

### 1. Tokens sí, hex no — también en TU CSS

Todo estilo propio que conviva con Flow usa los tokens semánticos
(`var(--surface-card)`, `var(--text-primary)`, `var(--space-4)`). El pago es
inmediato: modo oscuro gratis. Un hex tuyo se ve bien en claro y se rompe en
`data-mode="dark"`.

```html
<html data-mode="dark">
  <!-- ese atributo ES el contrato de theming -->
  <div data-density="compact"><!-- y este el de densidad --></div>
</html>
```

`FlowModeProvider`/`useFlowMode` administran `data-mode` por ti (resuelven
`system` y exponen `toggle`).

FilterSet deja que Select use su tamaño normal (`md`): su padding consume
`--pad-control-x/y` del contexto de densidad, sin forzar la variante `sm`.
Input hereda de ControlShell el interlineado de `--type-body-md`, además de
familia, peso y tamaño. Los filtros y la búsqueda del mismo contexto responden
así a la misma escala. Esto cambia la geometría anterior de FilterSet y de
Input; no fija una altura ni modifica los tokens del diccionario.

Select no ofrece limpiar un valor single ausente (`undefined` o `''`): al
limpiar emite `''` y vuelve al placeholder sin botón de limpieza. Se conserva
la compatibilidad con una opción declarada explícitamente con `value: ''`;
en ese caso su etiqueta sigue representando una selección. En modo multiple
el estado vacío continúa siendo `[]`. FilterSet usa esta misma mecánica.

### 2. Busca antes de construir

Hay **150 piezas** sobre 8 foundations. Antes de escribir un componente propio,
pregunta si ya existe: `list_inventory` y `get_contract` en el MCP, o las fichas en
`contracts`. Antes de armar una pantalla entera, mira si hay plantilla:
`docs/templates/` en este paquete, o `list_templates` y `get_template` en el MCP.
Una pieza que te falte de verdad es una petición al equipo del DS (issue de
Solicitud: demanda medida = prioridad), no una copia local.

### 3. No toques los interiores

Los class names de los CSS Modules de Flow son privados y cambian sin aviso.
Extender es: la prop `style` para el ajuste puntual, los tokens para el theming,
y `variant`/`size`/`tone` para lo previsto. Un selector tuyo contra `.flow-*` o
contra un hash de módulo es deuda que revienta en cualquier versión.

### 4. Overlays y foco vienen resueltos — no los reimplementes

`Dialog`, `Drawer`, `BottomSheet`, `Menu`, `Popover` traen el pacto completo:
foco que entra y vuelve al disparador, Tab atrapado dentro, Escape que cierra
solo la capa más alta. Un modal casero pierde las tres cosas y ningún test tuyo
lo va a notar. Compón los de Flow.

### 5. Formularios con nombre y autorrelleno

- `Field` etiqueta: su `htmlFor` apunta al `id` **real** del control (un
  `htmlFor` sin `id` es una etiqueta rota que se ve perfecta).
- El estado inválido se llama **`invalid`** en todo el sistema. En `Input`,
  `error` aún funciona como alias deprecado — migra: se retira en 4.0.
- Pasa `autoComplete` (`email`, `current-password`, `tel`): sin eso, el gestor
  de contraseñas de tus usuarios no funciona.

### 6. No hay componente Text — a propósito

La tipografía son roles consumidos con `font:` en CSS:

```css
.miTitulo {
  font: var(--type-title-lg);
}
.miDato {
  font: var(--type-data);
} /* horas, IDs, montos: familia de dato */
```

Si migras desde un sistema con `<Text>`, el puente es un shim **en tu app** que
mapea variantes a roles — no le pidas el componente al DS.

### 7. Gráficas por FlowChart, iconos por ligadura

- Nunca ECharts directo: `FlowChart` (o `Donut`, `Bars`, `ScatterPlot`,
  `Treemap`, `GanttChart`…) — traen carga perezosa, estados vacíos con texto,
  modo oscuro y teclado resueltos.
- Iconos: `<span className="flow-symbol" aria-hidden="true">nombre_snake</span>`.
  Nombres legacy estilo Feather: `mapEoneIcon('refresh-cw')`.

**El envoltorio de icono, si lo escribes: sin `color`.**

Repetir el `<span>` cincuenta veces invita a olvidar el `aria-hidden` o a meter un
`font-size` a mano, así que un envoltorio fino en tu app es legítimo. Este es el que
recomendamos, y lo que importa es lo que **no** lleva:

```tsx
export function Icon({ name, size = 'md' }: { name: string; size?: 'sm' | 'md' | 'lg' }) {
  return (
    <span className={`flow-symbol flow-symbol--${size}`} aria-hidden="true">
      {name}
    </span>
  )
}
```

Sin prop `color`, sin `style`, sin SVG. El color se hereda por `currentColor` del padre, y
esa ausencia es justo lo que lo hace seguro: **si no hay puerta para un hex, nadie mete un
hex.** Un `color` en el envoltorio es por donde entran los `#ca0e00` que rompen el modo
oscuro — lo hemos visto pasar.

Dos avisos más, por el mismo caso real:

- **No lo sustituyas por `IconButton`.** Un icono es un glifo inerte; `IconButton` es un
  control con `onClick`, `ariaLabel` obligatorio y objetivo de 44 px. Cambiar uno por otro
  convierte tus glifos decorativos en botones, y el lector de pantalla anuncia controles
  que no hacen nada.
- **Si el envoltorio crece más que eso, ya no es un envoltorio.** El caso que motiva esta
  receta empezó igual y acabó con 25 paths SVG incrustados a mano, reimplementando lo que
  la ligadura da gratis. Una regla de lint que prohíba `svg` y `path` en ese archivo cuesta
  un minuto y te ahorra el viaje.

### Navegación lateral adaptable

`Sidebar` conserva `collapsed` para un carril manual. Con `responsive`, usa
`useBreakpoint`: `expanded` muestra la navegación completa, `medium` el carril
de iconos y `compact` un cajón modal controlado por `open`/`onOpenChange`.
El shell conecta su botón de menú mediante `SidebarProvider`. El cajón reutiliza
`OverlayShell` para foco, Escape, backdrop y devolución de foco al cerrar.

Aplica `data-density` al ámbito común de navegación y contenido. Si el shell
usa `OverlayScope`, coloca ese atributo por encima del ámbito para que también
lo hereden las capas abiertas. Las filas usan `--pad-control-y`/`--pad-control-x`
y mantienen `--hit-target-min`; el ancho abierto es fluido, limitado por `--sidebar-width-min` y
`--sidebar-width-max` según densidad, y proporcionado al viewport mediante
`--sidebar-viewport-share`. `width` es un override explícito.

Los labels principales usan `--type-navigation-label` (14/16/20 px en
compact/default/comfortable) y sus iconos `--icon-navigation` (16/20/24 px).
Los rótulos de grupo usan `--type-navigation-group` (10/12/14 px),
conservando la caja alta y el tracking de la carcasa overline.
La marca usa `<FlowLogo variant="navigation" />`: 24/32/40 px de altura por
densidad, reducidos cuando el carril tiene menos espacio. El SVG conserva
su proporción y `height` explícito sigue disponible como override.

## Antipatrones que vemos y cómo se llaman

| Lo que hiciste                                  | Por qué duele                                                                 |
| ----------------------------------------------- | ----------------------------------------------------------------------------- |
| `color: #0F172A` en tu CSS                      | Se rompe en dark. Usa `--text-primary`                                        |
| `<div onClick>` como botón                      | Ni teclado ni lector. Usa `Button`/`IconButton` o `role`+`tabIndex` completos |
| Modal propio con `position: fixed`              | Sin trampa de foco ni Escape por capas. Usa `Dialog`                          |
| Sobrescribir `.flow-symbol { font-size: 13px }` | La escala es 16/20/24. Usa las clases de tamaño                               |
| `error={...}` en Input nuevo                    | Alias deprecado. Es `invalid`                                                 |
| Copiar una pieza de Flow para "ajustarla"       | Pide la variante al DS: una copia local queda huérfana de cada arreglo futuro |

## Qué te promete esta versión

Si vas a construir encima, esto es lo que puedes dar por estable y lo que no.

**Cubierto por SemVer** — si cambia, cambia el número de versión mayor:

- Lo que exporta el paquete y sus interfaces `Props`.
- Los tokens `sys`: las custom properties `--*`, su nombre y su significado.
- Las rutas de `exports`: `./styles.css`, `./tokens`, `./contracts`, `./specimens`, `./banderas`, `./fonts/*` — y `./flag`, deprecado.

> **`Flag` vive en el barril, y sus archivos los sirves tú.** Desde el [RFC 0012](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0012-una-bandera-no-es-un-activo-de-compilacion.md) una bandera es **dato de ejecución**: `Flag` arma la URL al pintar, así que ningún empaquetador la ve y tu build no emite ni un SVG. Medido en la app de referencia: `dist` de **7,9 a 3,7 MB** y el CSS del bundle de **609 a 188 KB**, porque la hoja de `flag-icons` nombra las 271 banderas con un `url()` y un `url()` dentro de CSS no se puede sacudir.
>
> Son dos pasos:
>
> ```bash
> npx flow-banderas --codigos mx,us,br --destino public/flags
> ```
>
> ```tsx
> import { Flag, FlowFlagsProvider } from '@er-mobility-mx/design-system'
>
> ;<FlowFlagsProvider baseUrl="/flags">…</FlowFlagsProvider>
> ```
>
> Qué códigos son **lo sabe tu producto**: un producto opera en N países y la pieza acepta cualquiera, así que recortar el catálogo dentro del paquete dejaría fuera al consumidor. Sin proveedor, `Flag` sigue funcionando por el camino 1.x —la hoja global del entry `./flag`— y avisa en consola en desarrollo. Ese entry se retira en 4.0.

**Privado** — cambia sin aviso, no construyas contra ello:

- Los class names de los CSS Modules (regla 3, arriba).
- Los tokens `ref`: la escala cruda. Su interfaz es `sys`.
- Cómo está compuesta una pieza por dentro.

**Mientras la versión diga `beta`, la API puede moverse entre betas.** Eso es lo que
significa la etiqueta. Aun así:

- Ningún cambio que rompa entra en silencio: lleva su entrada en el CHANGELOG con la ruta
  de migración.
- Nada se retira sin pasar antes por deprecado.
- Un token `sys` nunca cambia de significado sin cambiar de nombre — desaparecer avisa,
  cambiar de sentido no.

**Lo deprecado sigue funcionando toda la línea mayor**, marcado `@deprecated` en los tipos
para que tu editor te avise, y se retira solo en el siguiente MAJOR. Hoy, todos hasta 4.0:

| Deprecado                             | Usa                                                  | Dónde                                                                                                                                                                                                                                                                                                     |
| ------------------------------------- | ---------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `error`                               | `invalid`                                            | `Input`, `ControlShell`                                                                                                                                                                                                                                                                                   |
| `DateRangePicker`                     | `DatePicker mode="range"`                            | —                                                                                                                                                                                                                                                                                                         |
| `onClose`                             | `onOpenChange`                                       | `Dialog`, `Drawer`, `BottomSheet`                                                                                                                                                                                                                                                                         |
| `defaultOpen`                         | `defaultExpanded`                                    | `Accordion` — el viejo solo podía sembrar un panel                                                                                                                                                                                                                                                        |
| `expandedSections`, `onToggleSection` | `expandedKeys`, `onExpandedChange`                   | `Sidebar`                                                                                                                                                                                                                                                                                                 |
| `align`                               | `placement`                                          | `Popover` (`'left'` ≙ `bottom-start`)                                                                                                                                                                                                                                                                     |
| `pending`                             | `status`                                             | `TransactionRow` — el booleano solo podía decir una de las cuatro cosas: un cargo rechazado y uno fallido no son «no pendiente»                                                                                                                                                                           |
| `--bp-sm`, `--bp-md`                  | `--bp-compact`, `--bp-expanded`                      | Tokens. **Siguen valiendo 576 y 982**: solo cambia el nombre                                                                                                                                                                                                                                              |
| `--avatar-1` … `--avatar-6`           | `--identity-1` … `--identity-6`                      | Tokens. **Mismo valor**: solo cambia el nombre. La paleta distingue instancias y se llamaba por una de sus dos piezas consumidoras ([RFC 0007](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0007-el-nombre-y-el-nivel-de-un-token.md))                                                  |
| `--alpha-white-*`, `--alpha-black-*`  | `--ref-alpha-white-*`, `--ref-alpha-black-*`         | Tokens. **Mismo valor**: son rgba crudos sobre blanco y negro, o sea capa de referencia, y con el prefijo correcto la reja de modo oscuro los salta por construcción (RFC 0007)                                                                                                                           |
| `BulkActionsTable`                    | `DataTable` con `selectable` + `bulkActions`         | Hacía un trozo del flujo: quien la usaba no podía buscar, filtrar ni paginar ([RFC 0004](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0004-retiro-de-las-tablas-parciales.md))                                                                                                          |
| `./flag` (ruta de `exports`)          | `Flag` del barril + `FlowFlagsProvider`              | El entry existe solo por la hoja de `flag-icons`, y con la base declarada no hace falta ninguna hoja ([RFC 0012](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0012-una-bandera-no-es-un-activo-de-compilacion.md))                                                                      |
| `FilterableEditableTable`             | `DataTable` con columnas `editable` + `onCellEdit`   | Obligaba a elegir entre filtrar o editar. Los filtros por columna: `searchKeys`, o `FilterSet` en el slot `filters`                                                                                                                                                                                       |
| `PageFrame`                           | La regla en tu layout, no un envoltorio por pantalla | El ancho y el centrado del contenido los decide el contenedor con scroll: `.main > *` con `max-width: var(--content-max)` y `margin-inline: auto`. Envolver cada pantalla suma el padding de la pieza al del área de contenido y deja un solo hijo, así que se pierde el `gap` que separa a los de verdad |
| `PeekSheet`                           | `BottomSheet`                                        | Las listas y detalles que requieren interacción se abren como capas modales.                                                                                                                                                                                                                              |
| `StationRow`                          | Pines de `StationFinder` y detalle en `BottomSheet`  | La exploración de estaciones abre el detalle directamente desde el mapa.                                                                                                                                                                                                                                  |

Esa tabla no se escribe a mano: `check:deprecations` compara lo que el código marca
`@deprecated` contra lo que esta guía nombra, y rompe si se queda corta.

La línea pasa a `rc` —API congelada— cuando un consumidor real corra en producción sobre
ella y no quede ninguna ruptura ya decidida sin implementar. El detalle está en la
[governance](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/governance/overview.md#versionado).

## Para agentes

1. Conecta el **MCP server** — `npm i -D @er-mobility-mx/flow-mcp` y la configuración del README; lee del paquete instalado, sin clonar nada. Consulta antes de escribir:
   `get_contract("bottom-sheet")` te da la API con descripciones, cuándo usarla
   y cuándo no, y su madurez por plataforma.
2. Las 213 fichas también viajan en el paquete:
   `import contracts from '@er-mobility-mx/design-system/contracts'`.
3. Versionado y compatibilidad: SemVer desde 3.0 (la línea 1.x es el Flow
   anterior). Qué superficie es estable, qué es privada y cómo funcionan los
   deprecados está arriba, en «Qué te promete esta versión».
4. Si un componente de Flow parece incumplir su contrato, no lo parches en tu
   repo: repórtalo: cada criterio automatizado del canon tiene test que lo cita del lado del DS.
5. Para una pantalla completa, parte de una plantilla: `list_templates` y
   `get_template("auth")` en el MCP devuelven el código listo para copiar,
   compilado contra esta misma versión de la API.

## Migración desde Flow 1.x

La ruta completa (convivencia, `compat-eone.css`, mapa de iconos, renombres)
está en el README del paquete, sección «Migración desde Flow 1.x».

## Checklist visual por pantalla

Reglas de uso que ninguna reja puede verificar una sola vez — se revisan en CADA pantalla nueva o modificada:

1. **Un solo acento por vista** (btn-5, dsh-p1): un CTA `accent`/primario protagonista; dos acentos no jerarquizan nada.
2. **El rojo de marca no decora** (col-4): solo acción, estado vivo o foco — nunca color de serie ni adorno.
3. **Nada comunica solo por color** (a11y-3): todo estado va con texto, forma o icono.
4. **Cifras en familia de dato** (typ-1): montos, placas, IDs y KPIs en `--type-data`; el resto en la familia de texto.
5. **Tracking en su sitio** (typ-4): `--tracking-tight` solo en display/title; `--tracking-overline` solo en overlines.
6. **Padding por tokens de zona** (spc-4): `--pad-card`/`--pad-section`, no reescritos por pantalla.
7. **Pill solo donde la altura fija el radio** (shp-3): botones, chips, badges — no en tarjetas.
8. **Spring solo como respuesta** (mot-4): `--ease-spring` en toque/hover; `--ease-out` en lo que entra.
9. **Icono activo por relleno** (ico-4): `flow-symbol--fill`, no solo cambio de color.
10. **`live` solo en lo que cambia solo** (bdg-3): un badge de categoría que late, miente.
11. **Nada encima del área del control** (cs-6): accesorios en leading/trailing/footer.
12. **Texto sobre imagen con velo** (cmd-3): 4.5:1 garantizado por velo, no por suerte.

## Composición móvil compartida

Cabeceras contextuales con `TopBar` mobile y búsqueda con filtros en `FilterSet` sheet: [guía de composición móvil](mobile-composition.md). La wallet consume estas piezas del entry público; su lógica de UI no se copia desde el banco.

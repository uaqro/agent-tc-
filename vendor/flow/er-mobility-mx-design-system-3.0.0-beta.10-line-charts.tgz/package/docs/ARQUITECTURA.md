# Flow — cómo está armado

Esto es lo que conviene entender antes de construir una pantalla con Flow. Es la versión para quien **usa** el sistema; quien lo mantiene tiene las suyas en el repo.

## La cascada

`foundations → primitives → components → patterns → templates`

| Capa            | Qué es                                                                                    | Cómo se usa                                              |
| --------------- | ----------------------------------------------------------------------------------------- | -------------------------------------------------------- |
| **foundations** | Decisiones sin JSX: color, tipografía, espacio, forma, motion, iconografía, accesibilidad | Tokens CSS: `var(--surface-card)`. No se importan        |
| **primitives**  | Átomos: `Button`, `Input`, `Badge`, `Divider`                                             | `import { Button } from '@er-mobility-mx/design-system'` |
| **components**  | Conceptos de interfaz compuestos: `Card`, `Table`, `Dialog`, `Select`                     | Igual                                                    |
| **patterns**    | Conceptos de negocio: `AuthForm`, `PaymentCard`, `PageHeader`, `DataTable`                | Igual                                                    |
| **templates**   | Pantallas completas                                                                       | **Se copian**, no se importan: `docs/templates/`         |

Dos preguntas resuelven casi todas las dudas al elegir pieza:

- **¿Nombra un concepto de interfaz o de negocio?** `Dialog`, `Table` y `Drawer` son components. `PaymentCard`, `AuthForm` y `StationFinder` son patterns. Cada pieza citada aquí vive en la capa que dice la frase, y lo comprueba `afr-3` en cada `verify`.
- **¿Cambia la apariencia de los mismos datos, o agrega estado y flujo?** Lo primero es una prop. Lo segundo es otra pieza.

## Las cuatro reglas

- **Hacia abajo.** Una pieza solo usa piezas más simples que ella.
- **Una variante no es un componente.** Tres botones con distinto color son una prop `variant`, no tres piezas.
- **Una carcasa, un dueño.** Nadie redibuja borde, foco, radio de control ni backdrop: eso lo pone el sistema.
- **La composición no se filtra a la API.** Que `Select` esté hecho de `Popover` y `Listbox` es asunto interno; ninguna prop pública nombra sus partes.

## Lo que el sistema ya resuelve

No lo reimplementes:

- **Modo oscuro**, con los mismos tokens. Solo cambia `data-mode` en `<html>`.
- **Densidad** (`data-density`), para tablas apretadas o lectura relajada.
- **Foco visible** y objetivos de 44 px en todo lo operable.
- **Overlays**: Escape cierra la capa más alta, Tab queda atrapado dentro del diálogo, el panel vive en un portal.
- **Textos de las piezas** por `react-intl`: tu app monta `FlowIntlProvider`.
- **Gráficas** por `FlowChart`, que carga ECharts en diferido; **iconos** por ligadura Material Symbols con la clase `flow-symbol`.
- **El nombre accesible de un campo**: `Field` se lo inyecta al control, también a los que `<label for>` no alcanza —un `Select` renderiza un `<span role="combobox">`— y le pasa el error y el estado requerido.
- **El idioma nativo del formulario**: los controles aceptan `name`, `required`, `onBlur` y entregan su `ref`, así que `react-hook-form` los registra sin envolverlos.
- **El espacio dentro de una tarjeta**: `Card` separa a sus hijos con su propio `gap`. No le pongas márgenes.

## Convenciones de props

Los nombres son estables en todo el sistema: `variant`, `size`, `tone`, `icon`, `label`, `value` con `onChange`, `open` con `onOpenChange`, `expandedKeys` con `onExpandedChange`, `disabled`, `loading`, `invalid`. Si buscas un sinónimo, probablemente la prop ya existe con uno de estos nombres.

**El estado de interfaz se reporta al dueño.** Apertura, expansión, selección, página y consulta: si la pieza lo guarda y tú puedes necesitarlo, hay una prop que lo controla y un callback que lo emite. Sin la prop, la pieza funciona sola. Es el contrato `controlled-state` ([RFC 0002](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0002-contrato-de-estado-controlado.md)).

## Lo que no se importa del barrel principal

Lo que pesa solo lo paga quien lo usa.

| Entry                                     | Qué trae                         | Por qué aparte                                                                                                               |
| ----------------------------------------- | -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `@er-mobility-mx/design-system/specimens` | Los especímenes de documentación | No viajan a una pantalla de producto                                                                                         |
| `@er-mobility-mx/design-system/flag`      | `Flag` **con la hoja de 1.x**    | **Deprecado, se retira en 4.0.** `Flag` vive en el barril: su imagen es dato de ejecución y el entry solo existe por la hoja |
| `@er-mobility-mx/design-system/banderas`  | `copiarBanderas`, el ayudante    | Es un script de Node para tu `prebuild`, no código de pantalla                                                               |

**Una bandera no es un activo de compilación** ([RFC 0012](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0012-una-bandera-no-es-un-activo-de-compilacion.md)). `Flag` arma la URL de su imagen **al pintar**, desde la base que declara `FlowFlagsProvider`, así que ningún empaquetador la ve y tu build no emite ni un SVG. Los archivos los sirves tú —`npx flow-banderas`—, porque qué países son lo sabe tu producto: el catálogo entero son 271 banderas y 1,9 MB, y un `url()` dentro de una hoja de CSS no se puede sacudir. Medido en la app de referencia: `dist` de 7,9 a 3,7 MB.

## Separación entre encabezado y contenido

`PageHeader` administra el gap de sus filas internas y no añade margen externo.
El contenedor de la pantalla decide la separación con `--gap-stack` o con Stack:
no se suman el margen del encabezado y el gap de la página. Las pantallas con
contenedor propio declaran su gap; los hijos directos del shell lo heredan del
layout. Es la regla `spc-5`, aplicada también al encabezado.

## Espaciado de navegación y filtros

Estas composiciones usan las decisiones existentes del diccionario
`tokens/flow.tokens.json`; no añaden valores ni tokens por pantalla.

- **Sidebar:** el carril expandido usa `--space-2` de inset horizontal y
  `--space-3` vertical. El fondo activo y el hover quedan dentro del carril;
  el modo colapsado conserva su distribución centrada y el objetivo `sbr-3`.
- **Select múltiple:** una selección muestra su etiqueta; dos o más muestran
  el conteo traducido. El desplegable conserva las opciones y `insetLabel`
  conserva el nombre de la dimensión (`fst-6`).
- **FilterSet:** los controles comparten el espacio disponible y las acciones
  con SavedViews ocupan el grupo final. Cuando el espacio del patrón baja al corte expandido del diccionario
  (`flow.ref.bp.expanded`, 982 px), las acciones pasan a una fila alineada a la
  derecha; bajo el corte compacto (`flow.ref.bp.compact`, 576 px), los controles
  también envuelven. Las container queries miden el patrón, no toda la ventana:
  un sidebar o un panel puede reducir el espacio sin cambiar el viewport.
  Los cortes se repiten en CSS porque las queries no aceptan `var()` en la condición. El Divider rotula el bloque como «Filtros» solo cuando hay filtros aplicados.
  El periodo acompaña los chips y no cambia al limpiar (`fst-4`); el bloque completo
  desaparece si no hay filtros (`fst-5`).
- **ActiveFilters:** quitar conserva la dimensión y el valor (`af-1`). Limpiar
  pertenece al mismo flujo que los chips y aparece con dos o más filtros
  (`af-3`); no espera a que termine una lista envuelta para colocarse.
- **Chip removible:** el texto empieza con `--space-3` en `sm` y
  `--pad-control-x` en `md`. El extremo final no suma padding: la × tiene su
  propio objetivo `--hit-target-min`, centrado y separado del texto (`chp-1`).
  La densidad puede ajustar `--pad-control-x`; nunca reduce el objetivo de cierre.

El padding visual y el objetivo interactivo son decisiones distintas. Un icono
pequeño no justifica reducir su botón ni superponerlo al texto.

## Dónde seguir

- **Reglas de uso y antipatrones:** `docs/USUARIO.md`
- **Pantallas para copiar:** `docs/templates/`
- **La ficha de cada pieza** (API con descripciones, cuándo usarla y cuándo no): el export `@er-mobility-mx/design-system/contracts`, o `get_contract` en el servidor MCP
- **Tokens:** `@er-mobility-mx/design-system/tokens` (diccionario W3C) y la hoja `styles.css`

## Jerarquía de títulos en tableros

PageHeader nombra la página con h1. SectionHeader md nombra una sección de
la página, como Indicadores clave. Todos los paneles de gráficas y tablas
usan SectionHeader md: ni el ancho, ni la descripción, ni las acciones cambian
la tipografía o el padding. Los paneles actuales dependen directamente de la
página y usan h2. Un panel dentro de una sección con h2 debe usar h3 cuando
esa composición se incorpore al contrato.

WidgetFrame conserva la carga, visibilidad y personalización y compone Card
con SectionHeader; no mantiene una segunda implementación del título.
Sus valores chrome y panel, y los de WidgetGrid, son aliases de compatibilidad
sin diferencias visuales durante 3.x; se retiran en 4.0. El padding usa
--pad-card en todos los paneles. SectionHeader acepta ReactNode en su
descripción para conservar el contenido que ya admitían los widgets.

## Donut con leyenda de categorías

Donut usa rellenos sólidos y los colores semánticos que recibe de Flow. La
leyenda vertical tiene ancho intrínseco: icono, categoría y porcentaje quedan
juntos. Con icono y sin marcas de serie no se duplica la muestra de color;
sin icono se conserva la muestra. Las otras gráficas que usan marcas mantienen
su correspondencia entre lienzo y leyenda. Los nombres y porcentajes del donut
están visibles y también incluidos en su nombre accesible.

El tamaño inicial del lienzo es 240 px, configurable mediante la prop size.
En un espacio estrecho la leyenda pasa debajo; no se estira para consumir el
ancho sobrante de la tarjeta.

El donut sin leyenda interna y su texto superpuesto comparten el centro al 50 %.
Su grosor por defecto es un sexto del lienzo; thickness conserva el ajuste
explícito. La cifra central usa --type-data-xl y el contexto --type-body-sm.

Donut.formatValue aplica la misma unidad del producto al tooltip y al detalle
de la leyenda. Los datos mantienen su magnitud real: 182000 para $182,000,
no 182 con una escala en miles implícita. Sin formateador se conserva la
leyenda de porcentajes. ChartLegendItem.detail es el texto complementario
bajo la categoría, separado del porcentaje para no forzar ancho adicional.

## Tooltip de datos de gráficas

FlowChart comparte con Tooltip los tokens de radio, sombra y padding. Los
formateadores comunes usan clases con tipografía de texto para etiquetas y
--type-data-sm para números tabulares alineados al final, sin negrita numérica
ni tamaños o gaps literales. El tooltip circular muestra la categoría y su
icono semántico, una fila con valueLabel y otra con la proporción del total.
Donut reenvía valueLabel y formatValue: la unidad es dato del producto. Las
etiquetas del sistema se traducen. Los nombres y valores se escapan como
texto antes de insertarse en el HTML del renderer.

Bars admite height="fill" para usar el alto disponible del panel. Los días
usan --type-viz-category. El valor del hover se posiciona dentro de la barra sin
participar en el layout y usa --surface-inverse/--text-on-inverse para mantener
contraste. Si su alto medido no cabe en la barra, se coloca encima sin cambiar
la geometría. El área de trazado y las etiquetas ocupan zonas separadas.

## Auditoría de la cascada: navegación, filtros y dataviz

La categoría es el nombre principal que une una marca con su dato. Los días
junto a las barras y los productos de la leyenda principal comparten esa
función: consumen --type-viz-category y --viz-category-label. El diccionario
define su escala por densidad y el color por modo; las piezas no eligen esos
valores. --viz-label sigue siendo el contexto secundario de ejes y escalas.

La cascada de esta decisión es diccionario ref/sys → hojas y salidas generadas
CSS/SCSS/Dart → contratos bars y chart-legend → Bars/ChartLegend → Donut y
paneles → datos del dashboard. Los fallbacks también se regeneran. La paridad
se mide en claro/oscuro y densidades default/compact/comfortable.

La composición de Donut decide las dos zonas, el tamaño de runtime y el gap.
ChartLegend acepta width=fill y es dueña de la distribución de su contenido;
Donut no sobrescribe selectores de la primitiva. FlowChart decide el HTML de
sus tooltips y usa los tokens comunes, y el producto solo aporta unidad,
formateador, icono y datos. No se añade una paleta local ni un título duplicado.

Sidebar usa la escala de inset en su propio carril; PageHeader no impone
márgenes externos. FilterSet compone los controles, las acciones y los filtros
aplicados; su contenedor es dueño del espacio. El label Filtros y la fila de
chips desaparecen juntos. Los estados de widgets quedan en WidgetFrame,
que delega superficie y títulos a Card y SectionHeader.

Las propuestas de contrato se mantienen aparte hasta publicarse; las rejas
que leen el canon publicado no deben declararse verdes frente a contratos
locales que todavía no se han integrado.

FlowChart conecta los ejes categóricos con `--type-viz-category` y `--viz-category-label`. Las series de stacked100 pueden declarar `icon`; cuando todas lo declaran, las categorías usan iconografía y colores sólidos. El tooltip conserva esos iconos. Los valores se normalizan a 100% por entidad y `showValues` presenta porcentajes dentro de cada segmento, ocultando colisiones. El ancho responde a las categorías del eje, sin límite fijo de barra. SectionHeader permite que la descripción use el ancho disponible de su sección.

En stacked100, el hover de segmento utiliza tooltip de item y presenta solo esa categoría. El espacio del eje usa un soporte silencioso de valor cero para conservar el resumen de entidad, sin aportar datos ni modificar las proporciones. Las filas del tooltip comparten alineación central y una columna de icono definida por el token de tamaño.

MapCanvas obtiene la familia de iconografía de `.flow-symbol` mediante el lector de foundations, espera su carga y redibuja el canvas. Los tooltips consumen los roles tipográficos y el espaciado compartido; el hit-test sigue la cabeza de la gota. `cluster` agrupa únicamente pines de gota en pantalla y permite acercar un grupo mediante mouse o teclado, sin cambiar las coordenadas de los datos.

El heatmap usa la escala `--viz-scale-1..5`, compartida con ScaleLegend. `legend={false}` oculta su escala integrada cuando la composición ofrece ScaleLegend; por defecto conserva la escala integrada. Las filas muestran todos los días y el tooltip etiqueta la magnitud y admite `valueIcon`. La muestra del banco normaliza su fuente a `[hora, día, valor]`, conserva los ceros y calcula los extremos de la leyenda desde la misma matriz.

ChartMatrix declara `columnRole` para distinguir categorías textuales de números u horarios. FlowChart usa `--type-viz-value` y la familia mono en los ejes numéricos/temporales; los días mantienen `--type-viz-category`. SectionHeader compone título y descripción en un bloque, con el slot trailing centrado y alineado al extremo derecho; el layout puede envolver en anchos reducidos. La escala del heatmap vive en ese slot mediante WidgetFrame.actions, y el gráfico declara su altura mediante la API de FlowChart.

Las celdas de heatmap toman su separación visual de `--space-1` y su radio de `--radius-mark`; el estado de hover conserva ese espaciado para que la matriz no cambie de geometría al interactuar.

La tipografía principal de visualización se define como un par semántico en el diccionario: `--type-viz-category` (Ubuntu) y `--type-viz-value` (IBM Plex Mono), con tamaño e interlineado equivalentes en cada densidad. Bars, ChartLegend md y los ejes/labels principales de FlowChart consumen ese par; las anotaciones auxiliares conservan body-sm, y los totales destacados conservan data-xl. Los valores y detalles de ChartLegend reciben el shorthand completo, sin heredar la tipografía de la categoría.

El ritmo de dataviz usa los mandos existentes del diccionario: gap-stack entre bloques, filas principales y marca/etiqueta; gap-inline dentro de pares de texto y anotaciones. WidgetFrame separa encabezado y cuerpo y los elementos del cuerpo con gap-stack. Las marcas rectangulares de Bars y FlowChart y los remates de sectores usan radius-mark; las superficies mantienen los radios de Card y Tooltip. En barras apiladas, las uniones internas permanecen rectas para conservar la continuidad de los segmentos.

Las barras apiladas calculan su contorno desde el primer y último segmento no vacío de cada signo; las uniones internas permanecen rectas, tanto en orientación horizontal como vertical. En heatmap el radio de la geometría compensa la mitad del borde separador para conservar radius-mark en el relleno visible.

Las marcas de charts usan radius-viz-mark: 12px en densidad normal, 8px en compacta y 16px en cómoda. Este rol reutiliza pasos ref existentes y permanece por debajo del radio de las superficies de panel. radius-mark conserva su función de micromarca en escalas y swatches.

El donut termina los sectores con remates semicirculares: su radio se calcula como la mitad del grosor del anillo, y el renderer limita ese radio cuando un sector pequeño no admite el remate completo. No consume el radio de marcas rectangulares para esa geometría.

Los roles viz-category y viz-value usan 16px en densidad normal, 14px en compacta y 18px en cómoda, con tamaño e interlineado equivalentes. Los títulos de panel mantienen title-lg y los iconos icon-md para conservar jerarquía.

StatTile usa type-kpi-value para su cifra principal (36px normal, 32px compacta, 40px cómoda). Sparkline y delta consumen el mismo juicio deltaTone; la geometría de la línea sigue los datos, mientras el color expresa favorabilidad. El producto declara deltaTone en métricas donde reducir es favorable o donde aumentar no implica mejora. Sin trend no se dibuja una evolución inventada.

KpiBand y las rejillas de paneles comparten gap-stack como separación entre tarjetas. La densidad decide el gap; no se reduce por un breakpoint móvil independiente. Las rejillas no añaden margen inferior cuando el Stack padre ya separa los bloques.

Stack admite gap="stack" y gap="inline" como roles del diccionario, además de los pasos numéricos de la escala. Los dashboards y FilterSet usan el rol stack entre bloques; PageHeader, SectionHeader, StatTile y ActiveFilters separan grupos con stack y pares cercanos con inline. La densidad se resuelve en foundations, sin overrides de layout por tamaño de pantalla para esos gaps.

El contenido del banco adopta la densidad comfortable de Flow: gap-stack y pad-card se amplían conjuntamente, y el margen de la página usa pad-section. La Sparkline de StatTile puede encoger al ancho disponible manteniendo la cifra sin reducir y ambos elementos en la misma fila.

SmallMultiples limita las columnas al número de entidades para no reservar huecos vacíos. Compone nombre completo, último valor con unidad y SVG en filas separadas, con roles viz-category/viz-value y gap-stack/gap-inline. Usa separadores entre entidades y color semántico de dominio para series normales; viz-negative queda para anomalías explícitas. Todas las entidades mantienen una escala Y compartida.

SmallMultiples admite color para conectar las líneas con la categoría del producto; por defecto usa viz-1. Consumo por región recibe el token del dominio combustible.

SmallMultiples layout=rows organiza identidad y valor frente a una línea que aprovecha el ancho restante, con separadores horizontales. Las filas conservan altura y escala Y compartidas; el SVG se adapta al ancho sin escalar su trazo. FlowChart.axisLabels coloca los nombres del scatter con roles tipográficos y espacio derivado de la altura del numeral, la anotación y gap-stack, reservando espacio en el grid. ScatterPlot reenvía sus nombres por esta API.

WidgetGrid estira las superficies de una misma fila a su altura intrínseca máxima; el contenido conserva sus dimensiones y los paneles no fijan alturas en píxeles para emparejarse. En una columna, cada fila mantiene su altura propia.

FlowChart plotSurface=canvas añade la superficie del scatter desde el rectángulo de coordenadas resuelto por ECharts. El adaptador aplica radius-viz-mark a la superficie y al recorte de líneas de rejilla, sin recortar los textos de ejes ni las transformaciones de los símbolos de puntos. La geometría se actualiza al terminar renders y resize y se limpia al desmontar.

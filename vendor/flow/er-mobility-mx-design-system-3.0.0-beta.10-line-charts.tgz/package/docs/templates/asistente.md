# Plantilla: Asistente (chat con datos)

**Plantilla canónica:** `agent-chat-template` · en el banco: `apps/banco/src/pages/AgentChatPage.tsx`

Una conversación en la que el asistente no responde solo texto: responde **con el dato dibujado** — una tabla, unas barras, una cifra— dentro de su propio mensaje.

## Cuándo usarla

- Tu producto ya tiene los datos y la pregunta es cuál mirar: el chat ahorra construir diez pantallas de informe que nadie pidió.
- Las respuestas se entienden mejor **vistas** que leídas: comparativas, rankings, totales por categoría.
- No la uses como soporte al cliente —eso es un hilo con personas, no con datos— ni para una sola consulta fija, que es un filtro y un botón.

## Layout

```
┌──────────────────────────────────────────────────────────┐
│ PageHeader  Asistente de flota                           │
├──────────────────────────────────────────────────────────┤
│ Conversation                                             │
│                                                          │
│   ┌──────────────────────────────────┐                   │
│   │ EmptyState  ¿Qué quieres saber?  │   ← sin mensajes  │
│   └──────────────────────────────────┘                   │
│                                                          │
│                        ┌───────────────────────────────┐ │
│                        │ «¿Cuánto gasté este mes?»     │ │
│                        └───────────────────────────────┘ │
│   ┌──────────────────────────────────────────┐           │
│   │ ⟳ Consultando datos de flota             │           │
│   │ Gastaste $248,400. El 73% es combustible:│           │
│   │ ┌──────────────────────────────────────┐ │           │
│   │ │ Table · Unidad │ Conductor │ Gasto   │ │  ← content│
│   │ └──────────────────────────────────────┘ │           │
│   └──────────────────────────────────────────┘           │
│                                                          │
│  [sugerencia] [sugerencia] [sugerencia]                  │
│  ┌────────────────────────────────────────────┐ [Enviar] │
└──────────────────────────────────────────────────────────┘
```

## Piezas

- `Conversation`: el hilo entero — mensajes, compositor, sugerencias y estado vacío. **No dibujes tú las burbujas**: la pieza resuelve el orden de lectura, el desplazamiento y el anuncio al lector de pantalla.
- `ChatMsg`: la forma de un mensaje. `role` dice de quién es; `text` es lo que se lee; **`content` es el nodo que se pinta debajo**, y ahí va la pieza de dato.
- `tool`: el paso visible mientras el asistente trabaja —`label`, `icon`, `status`—. Mientras está en `running`, el envío se deshabilita y se anuncia (`ac-3`, `ac-4`): quien no mira la pantalla también se entera de que está pensando.
- `EmptyState`: el hilo sin mensajes. No es una pantalla en blanco con un cursor: dice qué se puede preguntar.
- `Table`, `Bars`, `StatTile`: lo que entra en `content`. Son las piezas del catálogo tal cual — el asistente no tiene gráficas propias.
- `PageHeader`: el nombre de la pantalla. Un chat sin encabezado deja la sección sin nombre para quien navega por encabezados.

## Código

```tsx
// Archivo: Asistente.tsx
import { useState, type ReactNode } from 'react'
import { Badge, Bars, Conversation, EmptyState, PageHeader, Table, type ChatMsg } from '@er-mobility-mx/design-system'
import css from './Asistente.module.css'

let n = 0
const id = () => `m${++n}`

/* La respuesta trae su TEXTO y, cuando aplica, el nodo que se pinta debajo.
   Aquí es un mapa de ejemplo; en tu producto es lo que devuelve tu API. */
const RESPUESTAS: Record<string, { texto: string; contenido?: () => ReactNode }> = {
  gasto: {
    texto: 'Este mes gastaste $248,400. Combustible es el 73% — estas son las unidades con mayor consumo:',
    contenido: () => (
      <Table
        rowKey="unidad"
        caption="Unidades con mayor consumo este mes"
        columns={[
          { key: 'unidad', label: 'Unidad', mono: true },
          { key: 'conductor', label: 'Conductor' },
          { key: 'gasto', label: 'Gasto', align: 'right' as const, mono: true },
          {
            key: 'estado',
            label: '',
            render: (fila) => {
              const r = fila as { alto: boolean }
              return <Badge tone={r.alto ? 'warning' : 'neutral'}>{r.alto ? 'Sobre promedio' : 'Normal'}</Badge>
            },
          },
        ]}
        rows={[
          { unidad: 'KTR-882-A', conductor: 'Luis Prieto', gasto: '$4,820', alto: true, estado: '' },
          { unidad: 'MVD-101-C', conductor: 'Rosa Duarte', gasto: '$3,910', alto: false, estado: '' },
        ]}
      />
    ),
  },
  comparativa: {
    texto: 'Tu gasto de combustible por mes. Abril es el más alto:',
    contenido: () => (
      /* `Bars` es una serie: para comparar dos, el acento marca la que
         importa en vez de meter una segunda barra por categoría — y si de
         verdad necesitas dos series, eso es `FlowChart type="bar"`. */
      <Bars
        highlightMax
        format={(v) => `$${v}k`}
        data={[
          { label: 'Ene', value: 180 },
          { label: 'Feb', value: 174 },
          { label: 'Mar', value: 169 },
          { label: 'Abr', value: 181 },
        ]}
      />
    ),
  },
}

const elegir = (texto: string) =>
  /mes a mes|por mes|tendencia/i.test(texto)
    ? RESPUESTAS.comparativa
    : /gast|cuánto|cuanto/i.test(texto)
      ? RESPUESTAS.gasto
      : { texto: 'Todavía no sé responder eso. Prueba con gasto del mes o una comparativa.' }

export function Asistente() {
  const [mensajes, setMensajes] = useState<ChatMsg[]>([])
  const [borrador, setBorrador] = useState('')
  const [ocupado, setOcupado] = useState(false)

  const preguntar = (texto: string) => {
    if (ocupado) return
    const idHerramienta = id()
    setMensajes((m) => [
      ...m,
      { id: id(), role: 'user', text: texto },
      /* El paso visible mientras trabaja. Nace en `running` y se cierra en
         `done` con la respuesta: el mensaje es el MISMO, no uno nuevo. */
      { id: idHerramienta, role: 'agent', tool: { label: 'Consultando datos', icon: 'search', status: 'running' } },
    ])
    setBorrador('')
    setOcupado(true)

    // Aquí va tu llamada real.
    setTimeout(() => {
      const r = elegir(texto)
      setMensajes((m) =>
        m.map((x) =>
          x.id === idHerramienta
            ? { ...x, tool: { ...x.tool!, status: 'done' as const }, text: r.texto, content: r.contenido?.() }
            : x,
        ),
      )
      setOcupado(false)
    }, 900)
  }

  return (
    <div className={css.pantalla}>
      <PageHeader title="Asistente de flota" description="Pregunta sobre unidades, gastos y comparativas" />

      <Conversation
        messages={mensajes}
        value={borrador}
        onChange={setBorrador}
        onSend={preguntar}
        busy={ocupado}
        emptyState={
          <EmptyState
            icon="forum"
            title="¿Qué quieres saber de tu flota?"
            description="Pregunta en lenguaje natural — responde con datos, no solo con texto."
          />
        }
        suggestions={mensajes.length === 0 ? ['¿Cuánto gasté este mes?', 'Enséñame el gasto por mes'] : []}
      />
    </div>
  )
}
```

```css
/* Archivo: Asistente.module.css */
.pantalla {
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
  height: 100%;
  min-height: 0;
  padding: var(--pad-section);
}
```

## Personalización

- **La respuesta con dato** es el punto de la plantilla: `content` acepta cualquier nodo, así que ahí va `Table`, `Bars`, `StatTile`, `Donut` o lo que tu respuesta pida. No inventes una gráfica para el chat: usa la del catálogo, que ya trae modo oscuro, estado vacío y nombre accesible.
- **El paso de herramienta** puede ser más de uno: encadena mensajes con `tool` si tu agente consulta varias fuentes. Cada uno pasa de `running` a `done`; si falla, `error` con el motivo en `text`.
- **Las sugerencias** solo valen al principio: con el hilo empezado estorban. Por eso aquí salen con `mensajes.length === 0`.
- **El historial** es tuyo. `Conversation` no lo guarda: si quieres que sobreviva a un recargado, persiste `mensajes` — y recuerda que `content` es un nodo de React y **no se serializa**: guarda el dato y vuelve a pintarlo al cargar.

## Responsive

`Conversation` se encarga: las burbujas se ajustan al ancho y el compositor se queda abajo. Lo único que decide esta plantilla es que la pantalla ocupe el alto disponible (`height: 100%` con `min-height: 0`, para que el hilo pueda desplazarse dentro en vez de estirar la página). Bajo 576 px, baja el padding de sección a `--pad-card` si tu layout no lo hace ya.

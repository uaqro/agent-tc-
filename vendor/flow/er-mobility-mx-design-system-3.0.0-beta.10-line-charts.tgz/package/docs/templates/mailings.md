# Plantilla: Mailings (correos transaccionales)

**Plantilla canónica:** `mailings-templates` · en el banco: `apps/banco/src/pages/MailingsPage.tsx`

Los correos que tu producto manda —alta, verificación, aviso de gasto, recuperación— y la pantalla desde la que se revisan. Son el único sitio donde **Flow no viaja**: el correo se escribe en HTML de tablas con estilos en línea, y aun así tiene que parecerse al producto.

## Cuándo usarla

- Vas a escribir correos transaccionales y quieres que no se vean de otro sistema.
- Necesitas revisarlos antes de mandarlos, en escritorio y en teléfono.
- No la uses para contenido dentro de la app —ahí sí hay componentes— ni para campañas de marketing, que viven en su herramienta.

## Lo primero, porque cambia todo lo demás

**Un correo no puede usar el CSS de Flow.** Ningún cliente de correo garantiza hojas externas, y la mitad no resuelve `var(--token)`: Outlook de escritorio ni siquiera usa un motor web. Así que:

- **estructura con `<table>`**, no con flex ni grid;
- **estilos en línea**, no en una hoja;
- **los valores de los tokens se copian**, no se referencian. El diccionario viaja en el paquete (`tokens/flow.tokens.json`), así que el valor sale de ahí y no del ojo de quien escribe el correo;
- **modo oscuro**: no lo intentes con `prefers-color-scheme` y confía en colores que funcionen en los dos — un fondo claro con tinta oscura se lee en todas partes.

Esto no es una excepción a la regla de «solo tokens»: es que el token no llega. Lo que sí llega es su **valor**, y por eso se saca de la fuente en vez de escribirlo a mano.

## Layout

```
┌──────────────────────────────────────────────────────────────┐
│ PageHeader  Mailings                                         │
├────────────────────┬─────────────────────────────────────────┤
│ ListRow  Alta      │  SegmentedControl  [Escritorio][Móvil]  │
│ ListRow  Código ✓  │  ┌───────────────────────────────────┐  │
│ ListRow  Gasto     │  │                                   │  │
│ ListRow  Recuperar │  │   <iframe> con el HTML del correo │  │
│                    │  │                                   │  │
│                    │  └───────────────────────────────────┘  │
└────────────────────┴─────────────────────────────────────────┘
```

## Piezas

- `PageHeader`: el nombre de la pantalla y qué son estos correos.
- `ListRow`: cada plantilla de correo en la columna izquierda. Es la fila del sistema: trae su objetivo táctil, su estado seleccionado y su nombre accesible — no la dibujes con un `<button>` y una clase.
- `SegmentedControl`: escritorio o teléfono. Es **un** tab stop con flechas dentro y exige su `ariaLabel`; un par de botones a mano no lo es.
- `Card`: la superficie del previsualizador.
- `EmptyState`: cuando no hay ninguno seleccionado.

## Código

```tsx
// Archivo: Mailings.tsx
import { useEffect, useRef, useState } from 'react'
import { Card, EmptyState, ListRow, PageHeader, SegmentedControl, Stack } from '@er-mobility-mx/design-system'
import { CORREOS } from './correos'
import css from './Mailings.module.css'

export function Mailings() {
  const [activo, setActivo] = useState<string | null>(CORREOS[0]?.id ?? null)
  const [ancho, setAncho] = useState('escritorio')
  const marco = useRef<HTMLIFrameElement>(null)

  const correo = CORREOS.find((c) => c.id === activo)

  /* El HTML del correo se escribe en el iframe en vez de pasarlo por `src`:
     así se previsualiza sin servirlo, y `sandbox` lo deja sin scripts. */
  useEffect(() => {
    const doc = marco.current?.contentDocument
    if (!doc || !correo) return
    doc.open()
    doc.write(correo.html)
    doc.close()
  }, [correo])

  return (
    <div className={css.pantalla}>
      <PageHeader
        title="Mailings"
        description="Correos transaccionales: HTML de tablas y estilos en línea — aquí Flow no viaja, viajan sus valores."
      />

      <div className={css.columnas}>
        <nav className={css.lista} aria-label="Plantillas de correo">
          {CORREOS.map((c) => (
            <ListRow
              key={c.id}
              title={c.titulo}
              subtitle={c.asunto}
              selected={c.id === activo}
              onClick={() => setActivo(c.id)}
            />
          ))}
        </nav>

        <Stack direction="column" gap={3}>
          <SegmentedControl
            ariaLabel="Ancho de la vista previa"
            value={ancho}
            onChange={setAncho}
            items={[
              { value: 'escritorio', label: 'Escritorio' },
              { value: 'movil', label: 'Móvil' },
            ]}
          />

          <Card>
            {correo ? (
              <iframe
                ref={marco}
                title={`Vista previa: ${correo.titulo}`}
                sandbox="allow-same-origin"
                className={css.marco}
                data-ancho={ancho}
              />
            ) : (
              <EmptyState icon="mail" title="Elige un correo" description="Se previsualiza aquí, sin mandarlo." />
            )}
          </Card>
        </Stack>
      </div>
    </div>
  )
}
```

```tsx
// Archivo: correos.ts
/* El correo es HTML de tablas con estilos en línea. Los VALORES salen del
   diccionario que viaja en el paquete —`tokens/flow.tokens.json`— y se copian
   aquí, porque `var()` no llega a un cliente de correo. Si el valor cambia en
   el diccionario, cambia aquí: es la única copia que el sistema acepta, y por
   eso vive en una constante y no repartida por el HTML. */
const T = {
  tinta: '#0F172A',
  tintaSuave: '#5C6B80',
  superficie: '#FFFFFF',
  lienzo: '#F1F7FF',
  borde: '#DEE4EC',
  accion: '#0F172A',
  sobreAccion: '#FFFFFF',
  radio: '16px',
  cuerpo: "16px/1.55 'Ubuntu', 'Helvetica Neue', Arial, sans-serif",
  titulo: "900 28px/1.25 'Edenred', 'Helvetica Neue', Arial, sans-serif",
}

const envoltorio = (titulo: string, cuerpo: string, cta?: { texto: string; url: string }) => `
<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${titulo}</title></head>
<body style="margin:0;padding:24px 0;background:${T.lienzo};font:${T.cuerpo};color:${T.tinta}">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
             style="max-width:560px;background:${T.superficie};border:1px solid ${T.borde};border-radius:${T.radio}">
        <tr><td style="padding:32px">
          <h1 style="margin:0 0 16px;font:${T.titulo};color:${T.tinta}">${titulo}</h1>
          <p style="margin:0 0 24px;font:${T.cuerpo};color:${T.tintaSuave}">${cuerpo}</p>
          ${
            cta
              ? `<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>
                   <td style="background:${T.accion};border-radius:999px">
                     <a href="${cta.url}" style="display:inline-block;padding:14px 28px;color:${T.sobreAccion};text-decoration:none;font:${T.cuerpo}">${cta.texto}</a>
                   </td></tr></table>`
              : ''
          }
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`

export const CORREOS = [
  {
    id: 'alta',
    titulo: 'Bienvenida',
    asunto: 'Tu cuenta está lista',
    html: envoltorio('Tu cuenta está lista', 'Ya puedes entrar y empezar a usar tu tarjeta.', {
      texto: 'Entrar',
      url: 'https://example.com',
    }),
  },
  {
    id: 'codigo',
    titulo: 'Código de verificación',
    asunto: 'Tu código es 418 205',
    /* Sin botón a propósito: un código no se pulsa, se copia. Un CTA aquí
       invita a hacer clic en un correo que la gente debería desconfiar. */
    html: envoltorio('Tu código de verificación', 'Escribe <b>418 205</b> en la app. Caduca en 10 minutos.'),
  },
  {
    id: 'gasto',
    titulo: 'Aviso de gasto',
    asunto: 'Cargo de $850.00 en tu tarjeta',
    html: envoltorio('Cargo de $850.00', 'Gasolinera Pemex #412, hoy a las 14:23, con tu tarjeta ···· 4821.', {
      texto: 'Ver movimiento',
      url: 'https://example.com',
    }),
  },
]
```

```css
/* Archivo: Mailings.module.css */
.pantalla {
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
  padding: var(--pad-section);
  max-width: var(--content-max);
  margin-inline: auto;
}

.columnas {
  display: grid;
  grid-template-columns: var(--sidebar-width) 1fr;
  gap: var(--gap-stack);
  align-items: start;
}

.lista {
  display: flex;
  flex-direction: column;
}

/* El ancho de la vista previa es lo único que cambia con el conmutador: el
   marco es el mismo. */
.marco {
  width: 100%;
  min-height: 520px;
  border: 0;
  background: var(--surface-canvas);
  border-radius: var(--radius-md);
}

.marco[data-ancho='movil'] {
  width: 375px;
  max-width: 100%;
  margin-inline: auto;
  display: block;
}

@media (max-width: 982px) {
  .columnas {
    grid-template-columns: 1fr;
  }
}
```

## Personalización

- **La tabla `T` es la única copia permitida.** Sácala del diccionario, no del ojo: `tokens/flow.tokens.json` viaja en el paquete y dice el valor exacto de cada token. Si cambia la paleta, esto cambia con ella — y si lo repartes por el HTML, no vas a encontrarlo.
- **Un correo de código no lleva botón**, a propósito: un código se copia, y un CTA en ese correo enseña a pulsar enlaces en mensajes que la gente debería mirar con desconfianza.
- **Ancho máximo 560 px** y una sola columna: es lo que sobrevive a todos los clientes. Si necesitas dos columnas, que apilen con `<table>` anidadas, no con media queries.
- **Prueba de verdad** antes de mandar: Outlook de escritorio, Gmail web y Mail de iOS. La vista previa de aquí usa el motor del navegador, así que es fiel a Gmail y a Apple Mail, **no a Outlook**.
- **El `sandbox`** del iframe deja el HTML sin scripts. No lo quites para «ver bien» un correo: si necesita un script, el correo está mal.

## Responsive

La pantalla pasa a una columna bajo 982 px y la lista queda arriba. El correo en sí no es responsive por media queries: es una tabla de 560 px con `max-width`, que es lo que entienden todos los clientes. El conmutador de ancho solo estrecha el marco de la vista previa — no cambia el HTML.

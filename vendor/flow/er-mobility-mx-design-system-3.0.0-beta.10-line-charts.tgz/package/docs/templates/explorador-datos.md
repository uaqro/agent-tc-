# Plantilla: Explorador de datos

**Plantilla canónica:** `fleet-dashboard-t` · en el banco: `apps/banco/src/pages/UnitsPage.tsx`

Tabla de una entidad (aquí, unidades de una flota) con filtros visibles, búsqueda, orden y paginación coordinados, y el detalle de la fila elegida en un panel lateral.

## Cuándo usarla

- Pantallas de catálogo o inventario: unidades, conductores, clientes, pedidos, estaciones.
- Cuando el usuario necesita encontrar un registro (buscar, filtrar, ordenar) y consultarlo sin perder la lista de vista.
- Con datos locales o que caben en memoria. Si filtras y paginas en servidor, `DataTable` ya no aplica: usa `Table` + `Pagination` y controla tú la consulta (ver «Personalización»).
- Para editar en línea, marca la columna `editable` y pasa `onCellEdit`; para acciones masivas, `selectable` + `bulkActions`. Todo en la misma pieza.

## Layout

```
┌──────────────────────────────────────────────────────────────┐
│ Flota › Unidades                                             │
│ Unidades                                                     │  PageHeader
│ [Estado ▾] [Tipo ▾]          (Exportar) [Importar] [+ Agregar]│  filters · actions
├──────────────────────────────────────────────────────────────┤
│ (Estado: En ruta ✕) (Tipo: Van ✕)  Limpiar filtros           │  ActiveFilters
├──────────────────────────────────────────────────────────────┤
│ [🔍 Buscar placa o conductor…]   3 de 9                      │  DataTable
│ Placa ▴   Conductor        Tipo    Viajes    Km    Estado    │   · búsqueda
│ MX-482A   (A) Ana Ruiz     Van         12   184    ● En ruta │   · orden
│ ...                                                          │   · filas
│                         1–10 de 13  ‹ 1 2 ›  [10 ▾]          │   · paginación
└──────────────────────────────────────────────────────────────┘
                                   ┌──────────────────────────┐
                                   │ MX-482A               ✕  │  Drawer
                                   │ ● En ruta                │  (al elegir fila)
                                   │ Conductor     Ana Ruiz   │  DetailRow ×4
                                   │ Combustible ▓▓▓▓▓░ 72 %  │  Progress
                                   │     [Ver historial][Editar]│  footer
                                   └──────────────────────────┘
```

## Piezas

- `PageHeader` — identidad de la pantalla (migas, título, descripción); su ranura `filters` lleva los filtros y `actions` las acciones en énfasis ascendente.
- `Select` (con `insetLabel`) — cada filtro: la etiqueta viaja dentro del control y le da el nombre accesible.
- `ActiveFilters` — los filtros aplicados como chips que se quitan uno a uno; «Limpiar filtros» aparece con dos o más.
- `DataTable` — búsqueda, orden y paginación coordinados sobre `Table`; trae su propio estado sin resultados para la búsqueda.
- `EmptyState` — cuando los filtros dejan la lista vacía (la búsqueda ya lo resuelve `DataTable`).
- `Avatar` — identifica al conductor en la celda.
- `StatusPill` — el estado de la unidad con punto y texto: nunca solo color.
- `Drawer` — panel lateral del detalle, con foco atrapado, Escape y retorno del foco resueltos.
- `DetailRow` — pares etiqueta-valor del detalle; `mono` para cifras.
- `Progress` — nivel de combustible con su valor en texto.
- `Button` — acciones de la cabecera y del pie del panel.

## Código

```tsx
// Archivo: ExploradorUnidades.tsx
import { useMemo, useState } from 'react'
import {
  ActiveFilters,
  Avatar,
  Button,
  DataTable,
  DetailRow,
  Drawer,
  EmptyState,
  PageHeader,
  Progress,
  Select,
  StatusPill,
  type ActiveFilter,
  type GridColumn,
  type StatusPillProps,
} from '@er-mobility-mx/design-system'
import css from './ExploradorUnidades.module.css'

type Estado = 'ruta' | 'taller' | 'inactiva'

type Unidad = {
  id: string
  placa: string
  conductor: string
  tipo: string
  estado: Estado
  viajes: number
  km: number
  combustible: number
}

// Datos de ejemplo — reemplaza con tu fuente de datos.
const UNIDADES: Unidad[] = [
  {
    id: 'u01',
    placa: 'MX-482A',
    conductor: 'Ana Ruiz',
    tipo: 'Van',
    estado: 'ruta',
    viajes: 12,
    km: 184,
    combustible: 72,
  },
  {
    id: 'u02',
    placa: 'MX-219C',
    conductor: 'Luis Ortega',
    tipo: 'Sedán',
    estado: 'ruta',
    viajes: 9,
    km: 142,
    combustible: 35,
  },
  {
    id: 'u03',
    placa: 'MX-730F',
    conductor: 'Marta Díaz',
    tipo: 'Pickup',
    estado: 'taller',
    viajes: 0,
    km: 0,
    combustible: 58,
  },
  {
    id: 'u04',
    placa: 'MX-114B',
    conductor: 'Jorge Peña',
    tipo: 'Van',
    estado: 'inactiva',
    viajes: 0,
    km: 0,
    combustible: 90,
  },
  {
    id: 'u05',
    placa: 'MX-905D',
    conductor: 'Sofía Luna',
    tipo: 'Sedán',
    estado: 'ruta',
    viajes: 15,
    km: 221,
    combustible: 44,
  },
  {
    id: 'u06',
    placa: 'MX-361E',
    conductor: 'Raúl Nava',
    tipo: 'Camión',
    estado: 'ruta',
    viajes: 4,
    km: 310,
    combustible: 28,
  },
  {
    id: 'u07',
    placa: 'MX-548G',
    conductor: 'Elena Soto',
    tipo: 'Van',
    estado: 'taller',
    viajes: 0,
    km: 0,
    combustible: 66,
  },
  {
    id: 'u08',
    placa: 'MX-677H',
    conductor: 'Iván Cruz',
    tipo: 'Pickup',
    estado: 'ruta',
    viajes: 7,
    km: 118,
    combustible: 81,
  },
  {
    id: 'u09',
    placa: 'MX-802J',
    conductor: 'Paula Ríos',
    tipo: 'Sedán',
    estado: 'inactiva',
    viajes: 0,
    km: 0,
    combustible: 12,
  },
  {
    id: 'u10',
    placa: 'MX-233K',
    conductor: 'Diego Mora',
    tipo: 'Camión',
    estado: 'ruta',
    viajes: 3,
    km: 276,
    combustible: 53,
  },
  {
    id: 'u11',
    placa: 'MX-419L',
    conductor: 'Carla Vega',
    tipo: 'Van',
    estado: 'ruta',
    viajes: 11,
    km: 167,
    combustible: 39,
  },
  {
    id: 'u12',
    placa: 'MX-590M',
    conductor: 'Óscar León',
    tipo: 'Sedán',
    estado: 'taller',
    viajes: 0,
    km: 0,
    combustible: 47,
  },
  {
    id: 'u13',
    placa: 'MX-846N',
    conductor: 'Nadia Paz',
    tipo: 'Pickup',
    estado: 'ruta',
    viajes: 8,
    km: 132,
    combustible: 64,
  },
]

const ESTADOS: Record<Estado, { label: string; tone: NonNullable<StatusPillProps['tone']> }> = {
  ruta: { label: 'En ruta', tone: 'success' },
  taller: { label: 'En taller', tone: 'warning' },
  inactiva: { label: 'Inactiva', tone: 'neutral' },
}

const TODOS = 'todos'
const OPC_ESTADO = [
  { value: TODOS, label: 'Todos' },
  ...(Object.keys(ESTADOS) as Estado[]).map((e) => ({ value: e, label: ESTADOS[e].label })),
]
const OPC_TIPO = [
  { value: TODOS, label: 'Todos' },
  ...[...new Set(UNIDADES.map((u) => u.tipo))].map((t) => ({ value: t, label: t })),
]

const COLUMNAS: GridColumn<Unidad>[] = [
  { key: 'placa', label: 'Placa', mono: true },
  {
    key: 'conductor',
    label: 'Conductor',
    render: (u) => (
      <span className={css.conductor}>
        <Avatar name={u.conductor} size="sm" />
        {u.conductor}
      </span>
    ),
  },
  { key: 'tipo', label: 'Tipo', priority: 3 },
  { key: 'viajes', label: 'Viajes', align: 'right', mono: true, priority: 2 },
  { key: 'km', label: 'Km', align: 'right', mono: true, priority: 3, render: (u) => u.km.toLocaleString('es-MX') },
  { key: 'estado', label: 'Estado', render: (u) => <StatusPill {...ESTADOS[u.estado]} /> },
]

/** Select de un solo valor: normaliza el `string | string[]` de su onChange. */
const unValor = (v: string | string[]) => (Array.isArray(v) ? v[0] : v) || TODOS

export function ExploradorUnidades() {
  const [estado, setEstado] = useState(TODOS)
  const [tipo, setTipo] = useState(TODOS)
  const [seleccion, setSeleccion] = useState<string | null>(null)

  const filas = useMemo(
    () => UNIDADES.filter((u) => (estado === TODOS || u.estado === estado) && (tipo === TODOS || u.tipo === tipo)),
    [estado, tipo],
  )
  // Derivados, no espejos: los chips y el panel salen del estado de arriba.
  const unidad = UNIDADES.find((u) => u.id === seleccion)
  const activos: ActiveFilter[] = [
    ...(estado !== TODOS
      ? [{ id: 'estado', dimension: 'Estado', label: OPC_ESTADO.find((o) => o.value === estado)?.label ?? estado }]
      : []),
    ...(tipo !== TODOS ? [{ id: 'tipo', dimension: 'Tipo', label: tipo }] : []),
  ]

  const quitarFiltro = (id: string) => (id === 'estado' ? setEstado(TODOS) : setTipo(TODOS))
  const limpiarFiltros = () => {
    setEstado(TODOS)
    setTipo(TODOS)
  }
  const exportar = () => {
    // Reemplaza con tu lógica
  }
  const importar = () => {
    // Reemplaza con tu lógica
  }
  const agregar = () => {
    // Reemplaza con tu lógica
  }
  const verHistorial = (u: Unidad) => {
    // Reemplaza con tu lógica
    void u
  }
  const editar = (u: Unidad) => {
    // Reemplaza con tu lógica
    void u
  }

  return (
    <div className={css.pagina}>
      <PageHeader
        breadcrumb={['Flota', 'Unidades']}
        title="Unidades"
        description="Todas las unidades de la flota y su estado de hoy."
        filters={
          <>
            <Select insetLabel="Estado" options={OPC_ESTADO} value={estado} onChange={(v) => setEstado(unValor(v))} />
            <Select insetLabel="Tipo" options={OPC_TIPO} value={tipo} onChange={(v) => setTipo(unValor(v))} />
          </>
        }
        actions={
          <>
            <Button variant="ghost" icon="download" onClick={exportar}>
              Exportar
            </Button>
            <Button variant="secondary" icon="upload" onClick={importar}>
              Importar
            </Button>
            <Button variant="primary" icon="add" onClick={agregar}>
              Agregar unidad
            </Button>
          </>
        }
      />

      <ActiveFilters filters={activos} onRemove={quitarFiltro} onClearAll={limpiarFiltros} />

      {filas.length === 0 ? (
        <EmptyState
          icon="filter_alt_off"
          title="Ninguna unidad con estos filtros"
          description="Quita un filtro para ver más unidades."
          action={
            <Button variant="secondary" onClick={limpiarFiltros}>
              Limpiar filtros
            </Button>
          }
        />
      ) : (
        <DataTable<Unidad>
          caption="Unidades"
          columns={COLUMNAS}
          rows={filas}
          rowKey="id"
          searchKeys={['placa', 'conductor']}
          searchPlaceholder="Buscar placa o conductor…"
          pageSize={10}
          pageSizeOptions={[10, 25, 50]}
          onRowClick={(u) => setSeleccion(u.id)}
          selectedKey={seleccion ?? undefined}
          emptyLabel="Ninguna placa ni conductor coincide con «{q}»"
        />
      )}

      <Drawer
        open={!!unidad}
        onClose={() => setSeleccion(null)}
        title={unidad?.placa}
        width={420}
        footer={
          unidad && (
            <>
              <Button variant="secondary" icon="history" onClick={() => verHistorial(unidad)}>
                Ver historial
              </Button>
              <Button variant="primary" icon="edit" onClick={() => editar(unidad)}>
                Editar unidad
              </Button>
            </>
          )
        }
      >
        {unidad && (
          <div className={css.detalle}>
            <StatusPill {...ESTADOS[unidad.estado]} />
            <DetailRow label="Conductor" value={unidad.conductor} />
            <DetailRow label="Tipo" value={unidad.tipo} />
            <DetailRow label="Viajes hoy" value={unidad.viajes} mono />
            <DetailRow label="Km hoy" value={unidad.km.toLocaleString('es-MX')} mono />
            <Progress
              label="Combustible"
              value={unidad.combustible}
              showValue
              tone={unidad.combustible < 40 ? 'warning' : 'success'}
            />
          </div>
        )}
      </Drawer>
    </div>
  )
}
```

```css
/* Archivo: ExploradorUnidades.module.css */
.pagina {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  padding: var(--pad-section);
  min-width: 0;
}

.conductor {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
}

.detalle {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}
```

## Personalización

- **Tu app monta lo mínimo**: `import '@er-mobility-mx/design-system/styles.css'` y `<FlowIntlProvider locale="es">` alrededor de tu árbol. `ActiveFilters`, `DataTable` y `Select` usan i18n: sin el provider revientan con `Could not find required intl object`. La plantilla no los trae a propósito — van una sola vez en la raíz de tu app.
- **Tus datos**: cambia el tipo `Unidad` y `UNIDADES` por tu entidad. Debe ser un `type` (no `interface`) para que encaje con el genérico de `DataTable`. Si llegan de una API, sustituye la constante por tu `fetch`/query y deja `filas` derivado de ella.
- **Columnas**: edita `COLUMNAS`. `mono` para placas, IDs y cifras; `align: 'right'` para números; `render` para celdas compuestas; `priority` 2 o 3 para columnas que pueden retirarse en pantallas estrechas.
- **Estados**: el mapa `ESTADOS` traduce tu dominio a `tone` de `StatusPill` (`success`, `warning`, `danger`, `info`, `neutral`). El texto siempre acompaña al color.
- **Filtros**: un `Select` con `insetLabel` por dimensión, más su entrada en `activos` y en `quitarFiltro`. Si tienes más de tres dimensiones, considera `SavedViews` para guardar combinaciones.
- **Búsqueda**: `searchKeys` define dónde busca; `emptyLabel` interpola `{q}` con la consulta. Con `searchable={false}` quitas la caja si ya filtras la consulta en otra parte.
- **Paginación**: `pageSize` es el tamaño inicial; `pageSizeOptions` muestra el selector y el rango «X–Y de Z». Quítalo si tus listas son cortas.
- **Datos en servidor**: `DataTable` filtra, ordena y pagina en memoria. Si tu backend lo hace, usa `Table` (con `sort`/`onSortChange`) + `Pagination` y un `Input` de búsqueda propio.
- **Detalle**: el cuerpo del `Drawer` es tuyo — agrega `DetailRow`, `Accordion` para secciones largas o `Timeline` para el historial. Las acciones del pie van en énfasis ascendente: `secondary` primero, `primary` al cierre.
- **Acciones**: los handlers `exportar`, `importar`, `agregar`, `verHistorial` y `editar` están vacíos con `// Reemplaza con tu lógica`. Si una acción es destructiva, confírmala con `Dialog` (`tone="danger"`).

## Responsive

- **Cabecera**: bajo 576 px, `PageHeader` pasa filtros y acciones a filas completas y los envuelve; no hace falta CSS tuyo.
- **Columnas**: `priority: 3` (tipo, km) se retira bajo 982 px (`--bp-expanded`) y `priority: 2` (viajes) bajo 576 px. Placa, conductor y estado quedan siempre visibles; el resto se sigue viendo en el panel de detalle.
- **Búsqueda y paginación**: la barra de búsqueda y el pie de `Pagination` ocupan el ancho de la tabla y se acomodan solos.
- **Detalle**: el `Drawer` mide 420 px y nunca pasa del 90 % del ancho de la ventana, así que en móvil cubre casi toda la pantalla con su botón de cierre de 44 px. Si en móvil prefieres una hoja inferior, cambia `Drawer` por `BottomSheet` (mismas `open`, `onClose`, `title`) con tu propia media query; el paquete no exporta un hook de breakpoint.
- **Objetivos táctiles**: los botones y los `Select` usan tamaño `md` para mantener objetivos ≥ 44 px; no bajes a `sm` en pantallas táctiles.

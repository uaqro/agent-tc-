# Plantilla: Consola interna

**Plantilla canónica:** `internal-tools-t` · en el banco: `apps/banco/src/pages/internal-tools/ITResumenPage.tsx`

Herramienta para equipos internos (soporte, facturación, pricing): un armazón con navegación lateral de secciones y, dentro, la sección de trabajo con sus contadores, su cola en tabla y el detalle de la fila en un panel lateral.

## Cuándo usarla

- Back-office y herramientas internas: mesa de soporte, cola de aprobaciones, administración de cuentas, reglas de precios. Varias secciones que comparten un mismo armazón y una misma persona que salta entre ellas todo el día.
- Cuando la navegación es **de la herramienta**, no de la página: la lista de secciones vive siempre a la vista, con sus pendientes, y cambiar de sección no cambia el marco.
- No la uses para una sola pantalla de catálogo con filtros y detalle: eso es `explorador-datos`, sin armazón. Esta plantilla aporta lo que aquella no tiene — el armazón lateral, el cambio de sección y los contadores de cola.
- No la uses como navegación de producto para clientes finales (para eso están `TopBar` y `TabBar`), ni para una consola de una sola sección: si nunca habrá una segunda, la barra lateral sobra.

## Layout

```
┌──────────────┬───────────────────────────────────────────────────┐
│ Consola      │ Consola interna                       PageHeader  │
│ interna      │ Tickets                                           │
│              │        (Actualizar) [Exportar] [+ Nuevo ticket]   │
│ OPERACIÓN    │          ghost      secondary        primary      │
│ ▸Tickets  7  │ ┌───────────┐┌───────────┐┌───────────┐           │
│  Cuentas     │ │ Abiertos 7││Sin agente2││Prioridad 3│ StatTile  │
│              │ └───────────┘└───────────┘└───────────┘ (AutoGrid)│
│ FINANZAS     │ ┌───────────────────────────────────────────────┐ │
│  Factura… 3  │ │ [🔍 Buscar folio, asunto o cuenta…]           │ │
│  Pricing     │ │ Folio   Asunto        Cuenta   Prio   Estado  │ │
│              │ │ TK-1042 No carga…     Vidal    alta ● En curso│ │
│              │ │ …                          1–8 de 8           │ │
│ [◧ colapsar] │ └───────────────────────────────────────────────┘ │
└──────────────┴───────────────────────────────────────────────────┘
  Sidebar                            ┌──────────────────────────┐
  · caption por grupo                │ TK-1042 · No carga…   ✕  │ Drawer
  · badge = pendientes               │ ● En curso   (alta)      │ (al elegir
  · activeId = sección               │ ( Detalle )( Actividad 2)│  fila)
  · collapsed = icon rail            │ Cuenta        Vidal      │ Tabs
                                     │ Canal         Correo     │ DetailRow
                                     │  [Esperar cliente][Cerrar]│ footer
                                     └──────────────────────────┘
```

## Piezas

- `Sidebar` — la navegación de la consola. Sus `items` aceptan grupos (`caption: true`, rótulo no interactivo cuyos hijos se listan siempre), `icon`, y `badge` numérico para los pendientes de cada cola. `activeId` marca la sección viva con `aria-current="page"`; `collapsed` la reduce a un riel de iconos con tooltip.
- `SidebarProvider` — el armazón publica su toggle y `PageHeader` pinta solo entonces el botón de menú, que aparece bajo 982 px. Es el cable entre el armazón y el encabezado: sin él no hay hamburguesa.
- `PageHeader` — identidad de la sección viva (`overline` + `title` + `description`) y sus acciones en énfasis ascendente.
- `StatTile` — los contadores de la cola. `deltaTone` da el juicio: en una cola, subir es malo.
- `DataTable` — la cola: búsqueda, orden y paginación coordinados sobre `Table`, con `selectedKey` para que la fila abierta se vea elegida.
- `StatusPill` — el estado del ticket, con punto y texto.
- `Badge` — la prioridad, que es una etiqueta del registro, no su estado de avance.
- `Drawer` — el detalle de la fila, con foco atrapado, Escape y retorno del foco ya resueltos.
- `Tabs` — dentro del panel, separa los datos del ticket de su historial; `count` lleva el número al rótulo.
- `DetailRow` — pares etiqueta-valor del detalle; `mono` para folios y fechas.
- `Timeline` con `mode="events"` — el historial del ticket.
- `EmptyState` — el cuerpo de las secciones que todavía no construyes.
- `Button` / `IconButton` — acciones del encabezado y del pie del panel; el `IconButton` del pie de la barra colapsa la navegación.

## Código

El armazón: la barra, el cambio de sección y el hueco donde se monta la sección viva.

```tsx
// Archivo: ConsolaInterna.tsx
import { useState } from 'react'
import { EmptyState, IconButton, Sidebar, SidebarProvider, type SidebarProps } from '@er-mobility-mx/design-system'
import { SeccionTickets } from './SeccionTickets'
import css from './ConsolaInterna.module.css'

type SeccionId = 'tickets' | 'cuentas' | 'facturacion' | 'pricing'

// Pendientes por cola — reemplaza con los contadores de tu API.
const PENDIENTES: Record<SeccionId, number> = { tickets: 7, cuentas: 0, facturacion: 3, pricing: 0 }

// `SidebarItem` no se exporta por su nombre: el tipo de la lista se toma de las props.
const NAV: SidebarProps['items'] = [
  {
    id: 'grupo-operacion',
    label: 'Operación',
    caption: true,
    children: [
      { id: 'tickets', label: 'Tickets', icon: 'confirmation_number', badge: PENDIENTES.tickets },
      { id: 'cuentas', label: 'Cuentas', icon: 'apartment' },
    ],
  },
  {
    id: 'grupo-finanzas',
    label: 'Finanzas',
    caption: true,
    children: [
      { id: 'facturacion', label: 'Facturación', icon: 'receipt_long', badge: PENDIENTES.facturacion },
      { id: 'pricing', label: 'Pricing', icon: 'sell' },
    ],
  },
]

const PENDIENTE: Record<Exclude<SeccionId, 'tickets'>, string> = {
  cuentas: 'Cuentas',
  facturacion: 'Facturación',
  pricing: 'Pricing',
}

export function ConsolaInterna() {
  const [seccion, setSeccion] = useState<SeccionId>('tickets')
  const [colapsada, setColapsada] = useState(false)
  const [navMovil, setNavMovil] = useState(false)

  const navegar = (id: string) => {
    setSeccion(id as SeccionId)
    setNavMovil(false)
  }

  return (
    // El armazón publica su toggle: con él, PageHeader pinta el botón de menú bajo 982 px.
    <SidebarProvider value={() => setNavMovil((v) => !v)}>
      <div className={css.consola}>
        <div className={css.lateral} data-abierta={navMovil || undefined}>
          <Sidebar
            items={NAV}
            activeId={seccion}
            collapsed={colapsada}
            onNavigate={navegar}
            headerContent={
              <span data-overline className={css.marca}>
                {colapsada ? 'CI' : 'Consola interna'}
              </span>
            }
            footerActions={
              <IconButton
                icon={colapsada ? 'left_panel_open' : 'left_panel_close'}
                ariaLabel={colapsada ? 'Expandir navegación' : 'Colapsar navegación'}
                onClick={() => setColapsada((v) => !v)}
              />
            }
            style={{ height: '100%' }}
          />
        </div>

        {navMovil && (
          <button
            type="button"
            className={css.velo}
            aria-label="Cerrar navegación"
            onClick={() => setNavMovil(false)}
          />
        )}

        <main className={css.trabajo}>
          {seccion === 'tickets' ? (
            <SeccionTickets />
          ) : (
            <EmptyState
              icon="construction"
              title={`${PENDIENTE[seccion]} aún no está construida`}
              description="Copia SeccionTickets.tsx como punto de partida: mismo encabezado, misma cola, mismo panel de detalle."
            />
          )}
        </main>
      </div>
    </SidebarProvider>
  )
}
```

La sección de trabajo: contadores, cola y detalle de la fila.

```tsx
// Archivo: SeccionTickets.tsx
import { useState } from 'react'
import {
  AutoGrid,
  Badge,
  Button,
  DataTable,
  DetailRow,
  Drawer,
  PageHeader,
  StatTile,
  StatusPill,
  Tabs,
  Timeline,
  type BadgeProps,
  type GridColumn,
  type StatusPillProps,
} from '@er-mobility-mx/design-system'
import css from './ConsolaInterna.module.css'

type Estado = 'nuevo' | 'curso' | 'espera' | 'cerrado'
type Prioridad = 'alta' | 'media' | 'baja'

type Ticket = {
  id: string
  asunto: string
  cuenta: string
  canal: string
  prioridad: Prioridad
  estado: Estado
  agente: string
  actualizado: string
  actividad: { title: string; timestamp: string }[]
}

const ESTADOS: Record<Estado, { label: string; tone: NonNullable<StatusPillProps['tone']> }> = {
  nuevo: { label: 'Nuevo', tone: 'info' },
  curso: { label: 'En curso', tone: 'success' },
  espera: { label: 'Esperando cliente', tone: 'warning' },
  cerrado: { label: 'Cerrado', tone: 'neutral' },
}

const PRIORIDADES: Record<Prioridad, NonNullable<BadgeProps['tone']>> = {
  alta: 'danger',
  media: 'warning',
  baja: 'neutral',
}

const SIN_AGENTE = 'Sin asignar'

// Datos de ejemplo — reemplaza con tu fuente de datos.
const TICKETS: Ticket[] = [
  {
    id: 'TK-1042',
    asunto: 'No carga el estado de cuenta',
    cuenta: 'Transportes Vidal',
    canal: 'Correo',
    prioridad: 'alta',
    estado: 'curso',
    agente: 'Ana Ruiz',
    actualizado: '12 min',
    actividad: [
      { title: 'Ana Ruiz respondió', timestamp: 'Hace 12 min' },
      { title: 'Ticket creado', timestamp: 'Hoy 09:14' },
    ],
  },
  {
    id: 'TK-1041',
    asunto: 'Cobro duplicado en febrero',
    cuenta: 'Logística Nava',
    canal: 'Teléfono',
    prioridad: 'alta',
    estado: 'nuevo',
    agente: SIN_AGENTE,
    actualizado: '38 min',
    actividad: [{ title: 'Ticket creado', timestamp: 'Hoy 08:48' }],
  },
  {
    id: 'TK-1039',
    asunto: 'Alta de conductor rechazada',
    cuenta: 'Rutas del Bajío',
    canal: 'Chat',
    prioridad: 'media',
    estado: 'espera',
    agente: 'Luis Ortega',
    actualizado: '2 h',
    actividad: [
      { title: 'Se pidió comprobante', timestamp: 'Hoy 07:20' },
      { title: 'Ticket creado', timestamp: 'Ayer 18:02' },
    ],
  },
  {
    id: 'TK-1036',
    asunto: 'Factura sin complemento de pago',
    cuenta: 'Grupo Medina',
    canal: 'Correo',
    prioridad: 'media',
    estado: 'curso',
    agente: 'Marta Díaz',
    actualizado: '3 h',
    actividad: [{ title: 'Marta Díaz tomó el ticket', timestamp: 'Hoy 06:10' }],
  },
  {
    id: 'TK-1033',
    asunto: 'Tarifa nocturna mal aplicada',
    cuenta: 'Transportes Vidal',
    canal: 'Chat',
    prioridad: 'alta',
    estado: 'nuevo',
    agente: SIN_AGENTE,
    actualizado: '5 h',
    actividad: [{ title: 'Ticket creado', timestamp: 'Hoy 04:31' }],
  },
  {
    id: 'TK-1030',
    asunto: 'Cambiar correo de contacto',
    cuenta: 'Paquetería Soto',
    canal: 'Correo',
    prioridad: 'baja',
    estado: 'curso',
    agente: 'Ana Ruiz',
    actualizado: '1 d',
    actividad: [{ title: 'Ana Ruiz respondió', timestamp: 'Ayer 15:40' }],
  },
  {
    id: 'TK-1028',
    asunto: 'Acceso al portal bloqueado',
    cuenta: 'Logística Nava',
    canal: 'Teléfono',
    prioridad: 'media',
    estado: 'espera',
    agente: 'Luis Ortega',
    actualizado: '2 d',
    actividad: [{ title: 'Se pidió confirmación', timestamp: 'Lunes 11:05' }],
  },
  {
    id: 'TK-1021',
    asunto: 'Reembolso de viaje cancelado',
    cuenta: 'Grupo Medina',
    canal: 'Chat',
    prioridad: 'baja',
    estado: 'cerrado',
    agente: 'Marta Díaz',
    actualizado: '4 d',
    actividad: [{ title: 'Ticket cerrado', timestamp: 'Sábado 10:22' }],
  },
]

const COLUMNAS: GridColumn<Ticket>[] = [
  { key: 'id', label: 'Folio', mono: true },
  { key: 'asunto', label: 'Asunto' },
  { key: 'cuenta', label: 'Cuenta', priority: 2 },
  { key: 'canal', label: 'Canal', priority: 3 },
  { key: 'agente', label: 'Agente', priority: 3 },
  { key: 'prioridad', label: 'Prioridad', render: (t) => <Badge tone={PRIORIDADES[t.prioridad]}>{t.prioridad}</Badge> },
  { key: 'estado', label: 'Estado', render: (t) => <StatusPill {...ESTADOS[t.estado]} /> },
  { key: 'actualizado', label: 'Actualizado', align: 'right', mono: true, priority: 2 },
]

export function SeccionTickets() {
  const [tickets, setTickets] = useState(TICKETS)
  const [seleccion, setSeleccion] = useState<string | null>(null)
  const [pestana, setPestana] = useState('detalle')

  // Derivados, no espejos: el panel y los contadores salen del estado de arriba.
  const ticket = tickets.find((t) => t.id === seleccion) ?? null
  const abiertos = tickets.filter((t) => t.estado !== 'cerrado')
  const sinAgente = abiertos.filter((t) => t.agente === SIN_AGENTE).length
  const urgentes = abiertos.filter((t) => t.prioridad === 'alta').length

  const abrir = (t: Ticket) => {
    setSeleccion(t.id)
    setPestana('detalle')
  }
  const cambiarEstado = (id: string, estado: Estado) => {
    setTickets((ts) => ts.map((t) => (t.id === id ? { ...t, estado } : t)))
    setSeleccion(null)
    // Reemplaza con tu lógica: aquí va la llamada a tu API.
  }
  const actualizar = () => {
    // Reemplaza con tu lógica
  }
  const exportar = () => {
    // Reemplaza con tu lógica
  }
  const nuevoTicket = () => {
    // Reemplaza con tu lógica
  }

  return (
    <>
      <PageHeader
        overline="Consola interna"
        title="Tickets"
        description="Cola de soporte de hoy: lo que entra por correo, teléfono y chat."
        actions={
          <>
            <Button variant="ghost" icon="refresh" onClick={actualizar}>
              Actualizar
            </Button>
            <Button variant="secondary" icon="download" onClick={exportar}>
              Exportar
            </Button>
            <Button variant="primary" icon="add" onClick={nuevoTicket}>
              Nuevo ticket
            </Button>
          </>
        }
      />

      <AutoGrid minWidth="200px" gap="var(--space-3)">
        <StatTile
          label="Tickets abiertos"
          value={abiertos.length}
          delta="+3 hoy"
          deltaTone="danger"
          icon="confirmation_number"
        />
        <StatTile
          label="Sin agente"
          value={sinAgente}
          delta="por asignar"
          deltaTone="neutral"
          deltaArrow={false}
          icon="person_alert"
        />
        <StatTile
          label="Prioridad alta"
          value={urgentes}
          delta="dentro de SLA"
          deltaTone="neutral"
          deltaArrow={false}
          icon="priority_high"
        />
      </AutoGrid>

      <DataTable<Ticket>
        caption="Tickets de soporte"
        columns={COLUMNAS}
        rows={tickets}
        rowKey="id"
        searchKeys={['id', 'asunto', 'cuenta']}
        searchPlaceholder="Buscar folio, asunto o cuenta…"
        pageSize={10}
        onRowClick={abrir}
        selectedKey={seleccion ?? undefined}
        emptyLabel="Ningún ticket coincide con «{q}»"
      />

      <Drawer
        open={!!ticket}
        onClose={() => setSeleccion(null)}
        title={ticket ? `${ticket.id} · ${ticket.asunto}` : undefined}
        width={480}
        footer={
          ticket && ticket.estado !== 'cerrado' ? (
            <>
              <Button variant="secondary" icon="schedule" onClick={() => cambiarEstado(ticket.id, 'espera')}>
                Esperar cliente
              </Button>
              <Button variant="primary" icon="check" onClick={() => cambiarEstado(ticket.id, 'cerrado')}>
                Cerrar ticket
              </Button>
            </>
          ) : undefined
        }
      >
        {ticket && (
          <div className={css.detalle}>
            <div className={css.encabezadoPanel}>
              <StatusPill {...ESTADOS[ticket.estado]} />
              <Badge tone={PRIORIDADES[ticket.prioridad]}>Prioridad {ticket.prioridad}</Badge>
            </div>

            <Tabs
              value={pestana}
              onChange={setPestana}
              items={[
                { value: 'detalle', label: 'Detalle' },
                { value: 'actividad', label: 'Actividad', count: ticket.actividad.length },
              ]}
            />

            {pestana === 'detalle' ? (
              <div className={css.detalle}>
                <DetailRow label="Folio" value={ticket.id} mono />
                <DetailRow label="Cuenta" value={ticket.cuenta} />
                <DetailRow label="Canal" value={ticket.canal} />
                <DetailRow label="Agente" value={ticket.agente} />
                <DetailRow label="Última actualización" value={`Hace ${ticket.actualizado}`} mono />
              </div>
            ) : (
              <Timeline mode="events" items={ticket.actividad.map((a) => ({ ...a, status: 'done' as const }))} />
            )}
          </div>
        )}
      </Drawer>
    </>
  )
}
```

```css
/* Archivo: ConsolaInterna.module.css */
.consola {
  display: flex;
  align-items: stretch;
  min-height: 100vh;
  background: var(--surface-canvas);
}

.lateral {
  flex: none;
  position: sticky;
  top: 0;
  height: 100vh;
  z-index: var(--z-header);
}

/* El tracking, la caja alta y la tinta los pone `data-overline`: es un reset
   con dueño y reescribirlo a mano es lo que caza dup-8. Aquí solo queda lo
   propio de esta plantilla. */
.marca {
  white-space: nowrap;
}

.velo {
  display: none;
}

.trabajo {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
  padding: var(--pad-section);
}

.detalle {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  min-width: 0;
}

.encabezadoPanel {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

/* Bajo 982 px la barra sale del flujo: PageHeader ya pinta ahí su botón de menú. */
@media (max-width: 982px) {
  .lateral {
    position: fixed;
    inset-block: 0;
    inset-inline-start: 0;
    z-index: var(--z-overlay);
    transform: translateX(-100%);
    transition: transform var(--dur-base) var(--ease-out);
  }

  .lateral[data-abierta] {
    transform: none;
  }

  .velo {
    display: block;
    position: fixed;
    inset: 0;
    z-index: var(--z-header);
    border: none;
    padding: 0;
    background: var(--surface-backdrop);
    cursor: pointer;
  }
}
```

## Personalización

- **Tu app monta lo mínimo**: `import '@er-mobility-mx/design-system/styles.css'` y `<FlowIntlProvider locale="es">` alrededor de tu árbol. `Sidebar`, `PageHeader`, `DataTable` y `Drawer` usan i18n: sin el provider revientan con `Could not find required intl object`. La plantilla no lo trae a propósito — va una sola vez en la raíz de tu app.
- **Tus secciones**: agrega el id a `SeccionId`, su entrada en `NAV` y su caso en el `main`. Mientras no exista, el `EmptyState` de la plantilla es el placeholder honesto. Cada sección nueva se escribe como `SeccionTickets.tsx`: encabezado, contadores, cola, panel.
- **Grupos del nav**: un item con `caption: true` es rótulo, no destino — no tabula ni recibe clic, y sus hijos se listan siempre (colapsada, el rótulo se reduce a un separador). Si tu consola tiene cinco secciones o menos, quita los grupos y deja la lista plana.
- **Contadores del nav**: `badge` acepta un número (pasa a «99+») o `true` para un punto vivo. Sustituye `PENDIENTES` por los contadores de tu API; un badge que no cambia solo miente, así que ponlo únicamente en las colas que crecen.
- **Rutas**: la plantilla cambia de sección con estado local para que se pueda copiar tal cual. Con router, `onNavigate` recibe `(id, href)`: pon el `href` en cada item y navega ahí; `activeId` pasa a salir de la ruta activa.
- **Permisos por rol**: filtra `NAV` antes de pasarlo (`NAV.filter(...)`) y decide qué sección es la inicial. No pintes una sección que la persona no puede abrir — y si entra por URL a una prohibida, responde con `EmptyState icon="lock"`, no con una pantalla en blanco.
- **Colapsar**: `collapsed` reduce la barra a un riel de 60 px con tooltip al pasar el puntero. Si quieres que sobreviva a la recarga, guarda el booleano en `localStorage` y úsalo como estado inicial.
- **Tu cola**: cambia el tipo `Ticket` y `TICKETS`. Debe ser un `type` (no `interface`) para que encaje con el genérico de `DataTable`. Edita `COLUMNAS`: `mono` para folios y tiempos, `align: 'right'` para cifras, `priority` 2 o 3 para lo que puede retirarse en pantallas estrechas.
- **Estado y prioridad no son lo mismo**: el estado es dónde va el ticket (`StatusPill`, con punto y texto); la prioridad es una etiqueta del registro (`Badge`). Si los pintas iguales, la persona deja de distinguirlos de un vistazo.
- **Contadores**: `deltaTone` es el juicio, no la dirección. En una cola, subir es malo: por eso «+3 hoy» va en `danger`. Cuando el delta es una nota sin juicio («por asignar»), usa `deltaTone="neutral"` y `deltaArrow={false}` para que no aparezca una flecha que no significa nada.
- **Detalle**: el cuerpo del `Drawer` es tuyo. Las `Tabs` separan datos de historial; si agregas una tercera (adjuntos, notas internas), lleva su `count`. La conversación completa no se arma a mano: es `Conversation`, que lleva el hilo, el compositor, el estado vacío y el layout que los enlaza —el hilo crece y hace scroll, el compositor se queda abajo, y `busy` lo deshabilita mientras el agente responde—.
- **Acciones**: `actualizar`, `exportar` y `nuevoTicket` están vacíos con `// Reemplaza con tu lógica`. Si una acción es destructiva (borrar una cuenta, revertir un cobro), confírmala con `Dialog` (`tone="danger"`) y confirma el resultado con `Toast` dentro de un `ToastStack` montado en el armazón.
- **Densidad**: una consola se pasa el día en tablas. `data-density="compact"` en el contenedor del armazón aprieta filas y padding sin tocar tu CSS.

## Responsive

- **Bajo 982 px** la barra sale del flujo y entra desde la izquierda sobre un velo. Quien la abre es el botón de menú de `PageHeader`, que solo existe si el armazón publicó su toggle con `SidebarProvider` — por eso el provider envuelve todo. Elegir una sección cierra la barra.
- **El velo** es un `<button>` con nombre accesible («Cerrar navegación»), no un `<div>`: se cierra con clic y con teclado. `Escape` aquí es tuyo si lo quieres; el `Drawer` sí lo trae resuelto.
- **Columnas**: `priority: 3` (canal, agente) se retira bajo 982 px y `priority: 2` (cuenta, actualizado) bajo 576 px. Folio, asunto, prioridad y estado quedan siempre visibles; el resto se sigue leyendo en el panel de detalle.
- **Encabezado**: bajo 576 px, `PageHeader` pasa las acciones a una fila completa y las envuelve; no hace falta CSS tuyo.
- **Contadores**: `AutoGrid` con `minWidth="200px"` baja de tres columnas a dos y a una sola sin media queries.
- **Detalle**: el `Drawer` mide 480 px y nunca pasa del 90 % del ancho de la ventana, así que en móvil cubre casi toda la pantalla con su botón de cierre de 44 px. Si prefieres una hoja inferior en móvil, cambia `Drawer` por `BottomSheet` (mismas `open`, `onClose`, `title`) con tu propia media query; el paquete no exporta un hook de breakpoint.
- **Objetivos táctiles**: los items de `Sidebar`, los botones y el `IconButton` de colapsar usan el mínimo de 44 px del sistema; no bajes a `size="sm"` en pantallas táctiles.

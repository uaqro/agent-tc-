# Plantilla: Alta en pasos

**Plantilla canónica:** `wizard-t` · en el banco: `apps/banco/src/pages/WizardPage.tsx`

Captura larga partida en pasos: vehículo → conductor → confirmación. Cada paso valida lo suyo antes de dejar avanzar, y el último es un resumen que devuelve a cualquier paso para corregir.

## Cuándo usarla

- Úsala cuando dar de alta algo pide más campos de los que caben sin scroll, y esos campos se agrupan en etapas con sentido propio («la unidad», «quién la opera»).
- Úsala cuando la decisión final merece revisarse: el último paso muestra lo capturado y envía una sola vez.
- No la uses para tres campos: un `Card` con un formulario y un botón «Guardar» es más rápido y honesto.
- No la uses si cada paso se guarda por separado en tu backend (borradores, expedientes que se retoman días después): eso es una lista de tareas, no un asistente; el usuario espera poder irse a la mitad.
- No la uses para un flujo con ramas («si es moto, salta el paso 2»): el `Stepper` promete un camino recto de longitud conocida.

## Layout

```
┌──────────────────────────────────────────────────────────────┐
│ Flota › Unidades › Alta de unidad      PageHeader [Descartar] │
│ Alta de unidad                                                │
├──────────────────────────────────────────────────────────────┤
│ Card                                                          │
│  ①━━━━━━━━━━━━━②───────────────③              Wizard/Stepper │
│  Vehículo       Conductor       Confirmación                  │
│  Datos unidad   Quién la opera  Revisar y enviar              │
│  ───────────────────────────────────────────────────────────  │
│  Paso 1                                                       │
│  ┌───────────────────────┬───────────────────────┐            │
│  │ Placa *        [    ] │ VIN            [    ] │  Field+Input│
│  │ ⚠ La placa es obliga… │ Número de identific…  │            │
│  ├───────────────────────┼───────────────────────┤            │
│  │ Marca *        [    ] │ Modelo *       [    ] │            │
│  ├───────────────────────┼───────────────────────┤            │
│  │ Año *       [    ▾]   │ Tipo *      [    ▾]   │  Field+Select│
│  └───────────────────────┴───────────────────────┘            │
│  ───────────────────────────────────────────────────────────  │
│  [ ‹ Volver ]                          [ Siguiente › ]        │
└──────────────────────────────────────────────────────────────┘
        ↓ paso 3: el mismo marco, con el resumen dentro
│  Vehículo                                        [ Editar ]   │
│  Placa                                          ABC-123-X     │
│  Marca / Modelo                              Toyota Corolla   │
│  Conductor                                       [ Editar ]   │
│  Nombre                                          Juan Pérez   │
│  ───────────────────────────────────────────────────────────  │
│  [ ‹ Volver ]                      [ Registrar unidad ]       │
```

El pie del asistente es fijo: «Volver» a la izquierda (oculto en el primer paso) y una sola acción de avance a la derecha, que en el último paso **es otro botón** —envío— y no el mismo cambiado de nombre. Eso lo resuelve `Wizard`; tú no montas ese pie.

## Piezas

- `PageHeader`: título, migas de pan y la acción de salida («Descartar»), que vive fuera del asistente porque no pertenece al camino.
- `Card`: la superficie que contiene el asistente entero.
- `Wizard`: el flujo. Recibe los pasos, el índice actual y los tres manejadores (`onBack`, `onNext`, `onSubmit`); dibuja el `Stepper` arriba y el pie de acciones abajo, y cambia «Siguiente» por el botón de envío al llegar al último paso. `submitting` pone el botón en carga y bloquea «Volver».
- `Stepper` (dentro de `Wizard`, vía `StepperStep`): el mapa del flujo. Marca hecho / actual / pendiente con número y palomita —no solo con color— y anuncia «Paso N de M» a los lectores de pantalla.
- `Field`: el modelo del campo — etiqueta con `htmlFor`, `required`, `help` y `error`. Inyecta `aria-describedby`, `aria-invalid` y `aria-required` en el control que envuelve; por eso cada control lleva un `id` real.
- `Input`: los campos de texto. El estado inválido se llama `invalid` (`error` es alias deprecado).
- `Select`: las opciones cerradas (año, tipo de unidad). También acepta `invalid` e `id`.
- `WizardSummary` / `WizardSummarySection` / `WizardSummaryRow`: el resumen del último paso, con «Editar» por sección que devuelve a su paso.
- `Button`: la acción de descarte en el encabezado y las del diálogo. Las del pie las pone `Wizard`.
- `Dialog`: confirma el descarte de la captura; trae trampa de foco, Escape y retorno del foco al disparador.

## Código

```tsx
// Archivo: AltaEnPasos.tsx
import { useState } from 'react'
import {
  Button,
  Card,
  Dialog,
  Field,
  Input,
  PageHeader,
  Select,
  Wizard,
  WizardSummary,
  WizardSummaryRow,
  WizardSummarySection,
  type StepperStep,
} from '@er-mobility-mx/design-system'
import css from './AltaEnPasos.module.css'

const PASOS: StepperStep[] = [
  { label: 'Vehículo', description: 'Datos de la unidad' },
  { label: 'Conductor', description: 'Quién la opera' },
  { label: 'Confirmación', description: 'Revisar y enviar' },
]

/** Datos de ejemplo: reemplaza los campos por los de tu alta. */
export interface DatosAlta {
  placa: string
  vin: string
  marca: string
  modelo: string
  anio: string
  tipo: string
  conductor: string
  licencia: string
  telefono: string
  correo: string
}

const VACIO: DatosAlta = {
  placa: '',
  vin: '',
  marca: '',
  modelo: '',
  anio: '',
  tipo: '',
  conductor: '',
  licencia: '',
  telefono: '',
  correo: '',
}

type Campo = keyof DatosAlta
type Errores = Partial<Record<Campo, string>>

/* Ids reales de cada control: son los que `Field htmlFor` necesita para que la
   etiqueta apunte a algo, y los que usamos para llevar el foco al primer error. */
const ID: Record<Campo, string> = {
  placa: 'alta-placa',
  vin: 'alta-vin',
  marca: 'alta-marca',
  modelo: 'alta-modelo',
  anio: 'alta-anio',
  tipo: 'alta-tipo',
  conductor: 'alta-conductor',
  licencia: 'alta-licencia',
  telefono: 'alta-telefono',
  correo: 'alta-correo',
}

const ANIOS = Array.from({ length: 10 }, (_, i) => String(new Date().getFullYear() - i))
const TIPOS = [
  { value: 'sedan', label: 'Sedán' },
  { value: 'van', label: 'Van' },
  { value: 'moto', label: 'Moto' },
  { value: 'camion', label: 'Camión' },
]

/* Qué exige cada paso. El índice del arreglo es el paso. */
const OBLIGATORIOS: Array<Array<[Campo, string]>> = [
  [
    ['placa', 'La placa es obligatoria.'],
    ['marca', 'La marca es obligatoria.'],
    ['modelo', 'El modelo es obligatorio.'],
    ['anio', 'Elige el año de la unidad.'],
    ['tipo', 'Elige el tipo de unidad.'],
  ],
  [
    ['conductor', 'El nombre es obligatorio.'],
    ['licencia', 'La licencia es obligatoria.'],
    ['telefono', 'El teléfono es obligatorio.'],
  ],
  [],
]

function validar(paso: number, datos: DatosAlta): Errores {
  const errores: Errores = {}
  for (const [campo, mensaje] of OBLIGATORIOS[paso] ?? []) {
    if (!datos[campo].trim()) errores[campo] = mensaje
  }
  if (paso === 1 && datos.correo.trim() && !datos.correo.includes('@')) {
    errores.correo = 'Escribe un correo válido o deja el campo vacío.'
  }
  return errores
}

export interface AltaEnPasosProps {
  /** Se llama con la unidad ya registrada: navega, avisa o refresca tu lista. */
  onRegistrada?: (datos: DatosAlta) => void
  /** Se llama cuando el usuario descarta la captura. */
  onDescartada?: () => void
}

export function AltaEnPasos({ onRegistrada, onDescartada }: AltaEnPasosProps) {
  const [paso, setPaso] = useState(0)
  const [datos, setDatos] = useState<DatosAlta>(VACIO)
  const [errores, setErrores] = useState<Errores>({})
  const [enviando, setEnviando] = useState(false)
  const [confirmarDescarte, setConfirmarDescarte] = useState(false)

  const escribir = (campo: Campo) => (valor: string) => {
    setDatos((d) => ({ ...d, [campo]: valor }))
    // El error de un campo se retira en cuanto el usuario lo toca, no al reenviar.
    setErrores((e) => {
      if (!e[campo]) return e
      const siguiente = { ...e }
      delete siguiente[campo]
      return siguiente
    })
  }

  function avanzar() {
    const encontrados = validar(paso, datos)
    const primero = Object.keys(encontrados)[0] as Campo | undefined
    if (primero) {
      setErrores(encontrados)
      document.getElementById(ID[primero])?.focus()
      return
    }
    setErrores({})
    setPaso((p) => p + 1)
  }

  function retroceder() {
    setErrores({})
    setPaso((p) => p - 1)
  }

  function enviar() {
    setEnviando(true)
    // Reemplaza con tu lógica: POST a tu API y maneja el error del servidor.
    window.setTimeout(() => {
      setEnviando(false)
      onRegistrada?.(datos)
    }, 1200)
  }

  const texto = (
    campo: Campo,
    label: string,
    extra: { requerido?: boolean; ayuda?: string; marcador?: string; tipo?: string; autoComplete?: string } = {},
  ) => (
    <Field label={label} htmlFor={ID[campo]} required={extra.requerido} help={extra.ayuda} error={errores[campo]}>
      <Input
        id={ID[campo]}
        value={datos[campo]}
        onChange={escribir(campo)}
        placeholder={extra.marcador}
        type={extra.tipo}
        autoComplete={extra.autoComplete}
        invalid={Boolean(errores[campo])}
      />
    </Field>
  )

  const opciones = (campo: Campo, label: string, lista: Array<string | { value: string; label: string }>) => (
    <Field label={label} htmlFor={ID[campo]} required error={errores[campo]}>
      <Select
        id={ID[campo]}
        options={lista}
        value={datos[campo]}
        onChange={(v) => escribir(campo)(v as string)}
        placeholder="Seleccionar…"
        invalid={Boolean(errores[campo])}
      />
    </Field>
  )

  return (
    <>
      <PageHeader
        breadcrumb={['Flota', 'Unidades', 'Alta de unidad']}
        title="Alta de unidad"
        actions={
          <Button variant="ghost" onClick={() => setConfirmarDescarte(true)}>
            Descartar
          </Button>
        }
      />

      <Card>
        <Wizard
          steps={PASOS}
          current={paso}
          onBack={retroceder}
          onNext={avanzar}
          onSubmit={enviar}
          submitting={enviando}
          submitLabel="Registrar unidad"
        >
          {paso === 0 && (
            <div className={css.pila}>
              <div className={css.fila}>
                {texto('placa', 'Placa', { requerido: true, marcador: 'ABC-123-X' })}
                {texto('vin', 'VIN', {
                  ayuda: 'Número de identificación vehicular (opcional).',
                  marcador: '1HGBH41JXMN109186',
                })}
              </div>
              <div className={css.fila}>
                {texto('marca', 'Marca', { requerido: true, marcador: 'Toyota' })}
                {texto('modelo', 'Modelo', { requerido: true, marcador: 'Corolla' })}
              </div>
              <div className={css.fila}>
                {opciones('anio', 'Año', ANIOS)}
                {opciones('tipo', 'Tipo de unidad', TIPOS)}
              </div>
            </div>
          )}

          {paso === 1 && (
            <div className={css.pila}>
              {texto('conductor', 'Nombre completo', { requerido: true, marcador: 'Juan Pérez', autoComplete: 'name' })}
              <div className={css.fila}>
                {texto('licencia', 'Número de licencia', { requerido: true, marcador: 'LIC-12345' })}
                {texto('telefono', 'Teléfono', {
                  requerido: true,
                  marcador: '+52 55 1234 5678',
                  tipo: 'tel',
                  autoComplete: 'tel',
                })}
              </div>
              {texto('correo', 'Correo electrónico', {
                ayuda: 'Opcional. Se usará para notificaciones.',
                marcador: 'juan@ejemplo.com',
                tipo: 'email',
                autoComplete: 'email',
              })}
            </div>
          )}

          {paso === 2 && (
            <WizardSummary>
              <WizardSummarySection title="Vehículo" onEdit={() => setPaso(0)}>
                <WizardSummaryRow label="Placa" value={datos.placa} />
                <WizardSummaryRow label="Marca / Modelo" value={`${datos.marca} ${datos.modelo}`} />
                <WizardSummaryRow label="Año" value={datos.anio} />
                <WizardSummaryRow label="Tipo" value={TIPOS.find((t) => t.value === datos.tipo)?.label ?? '—'} />
                {datos.vin && <WizardSummaryRow label="VIN" value={datos.vin} />}
              </WizardSummarySection>
              <WizardSummarySection title="Conductor" onEdit={() => setPaso(1)}>
                <WizardSummaryRow label="Nombre" value={datos.conductor} />
                <WizardSummaryRow label="Licencia" value={datos.licencia} />
                <WizardSummaryRow label="Teléfono" value={datos.telefono} />
                {datos.correo && <WizardSummaryRow label="Correo" value={datos.correo} />}
              </WizardSummarySection>
            </WizardSummary>
          )}
        </Wizard>
      </Card>

      <Dialog
        open={confirmarDescarte}
        onClose={() => setConfirmarDescarte(false)}
        tone="danger"
        title="Descartar el alta"
        description="Se perderá lo capturado en los pasos anteriores. Esta acción no se puede deshacer."
        actions={
          <>
            <Button variant="ghost" onClick={() => setConfirmarDescarte(false)}>
              Seguir capturando
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                setConfirmarDescarte(false)
                setDatos(VACIO)
                setErrores({})
                setPaso(0)
                onDescartada?.()
              }}
            >
              Descartar
            </Button>
          </>
        }
      />
    </>
  )
}
```

```css
/* Archivo: AltaEnPasos.module.css */
.pila {
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
}

.fila {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--gap-stack);
  align-items: start;
}

@media (max-width: 768px) {
  .fila {
    grid-template-columns: 1fr;
  }
}
```

## Personalización

- **Tus campos:** edita `DatosAlta`, `VACIO` e `ID` — los tres tienen las mismas claves, así que TypeScript te avisa si olvidas una. Cada campo nuevo necesita su entrada en `ID` para que su etiqueta apunte a un control real.
- **Tus pasos:** `PASOS` manda. Agrega un `StepperStep` y su bloque `paso === N`, y añade al arreglo `OBLIGATORIOS` una entrada en la misma posición (aunque sea vacía). El pie del asistente se reacomoda solo: «Volver» aparece desde el paso 2 y el botón de envío solo en el último. Si tu flujo pide más de cuatro pasos, pártelo en dos altas encadenadas antes que alargar el `Stepper`.
- **Tus reglas:** `validar()` es el único lugar donde se decide si se puede avanzar; hoy solo exige lo obligatorio y revisa el correo. Ahí van tus formatos (placa, VIN, longitud de licencia). Devuelve el mensaje que verá el usuario, en su idioma y diciendo qué hacer, no qué falló.
- **Errores del servidor:** cuando tu API rechace el envío, vuelve al paso del campo problemático (`setPaso`), pon el mensaje en `errores` y lleva el foco con `document.getElementById(ID[campo])?.focus()` — el mismo camino que usa `avanzar()`. Un error de envío que no mueve al usuario a donde puede arreglarlo es un callejón.
- **El botón de envío:** `submitLabel` nombra la acción final («Registrar unidad»), y `nextLabel` la de avance si «Siguiente» no te sirve. No pongas un solo botón que cambie de intención según el paso: eso lo resuelve `Wizard` cambiando de botón, que es distinto.
- **La salida:** «Descartar» vive en `PageHeader`, fuera del pie, porque no es parte del camino; confirma en un `Dialog` y limpia el estado. Si tu producto guarda borradores, cambia ese diálogo por «Guardar y salir».
- **Después del alta:** `onRegistrada` recibe los datos ya capturados; desde tu pantalla navega a la lista, refresca la consulta o muestra un aviso. La plantilla no navega: no sabe cómo es tu ruteo.
- **Lo que tu app monta una sola vez** (no va dentro de la plantilla): `styles.css` y `FlowIntlProvider`; sin el provider, los textos del sistema («Volver», «Seleccionar…») revientan. Por ejemplo:

```tsx
// Archivo: main.tsx
import { createRoot } from 'react-dom/client'
import { FlowIntlProvider } from '@er-mobility-mx/design-system'
import '@er-mobility-mx/design-system/styles.css'
import { AltaEnPasos } from './AltaEnPasos'

createRoot(document.getElementById('root')!).render(
  <FlowIntlProvider locale="es">
    <AltaEnPasos onRegistrada={(datos) => console.log('alta', datos.placa)} />
  </FlowIntlProvider>,
)
```

- **Estilo propio:** el CSS de la plantilla solo reparte espacio con `--gap-stack`. Cualquier regla que agregues usa tokens semánticos (`var(--surface-card)`, `var(--text-primary)`, `var(--space-4)`); un hex tuyo se ve bien en claro y se rompe en `data-mode="dark"`.

## Responsive

- Las parejas de campos viven en `.fila` (dos columnas) y caen a una sola columna a 768 px; los campos que van solos (nombre, correo) ya ocupan el ancho completo.
- `Stepper` se muestra en horizontal con `justify-content: space-between`; con tres pasos y descripciones cortas entra bien desde 360 px. Si tus etiquetas son largas, acórtalas antes que reducir la tipografía: la descripción es opcional y se puede omitir en móvil.
- `Input`, `Select` y `Button` respetan `--hit-target-min` (44 px) sin que hagas nada; no les fijes alturas menores.
- El pie del asistente mantiene «Volver» y la acción de avance en extremos opuestos de la misma línea a cualquier ancho: en móvil siguen siendo dos objetivos separados, difíciles de confundir con el pulgar.
- El `Dialog` de descarte se adapta solo al ancho de pantalla; no le fijes `width`.
- Un paso que no cabe sin scroll en 1280 px pide partirse: el asistente existe justamente para que cada paso quepa de un vistazo.

# Plantilla: Roles y permisos

**Plantilla canónica:** `config-roles` · en el banco: `apps/banco/src/pages/ConfigRolesPage.tsx`

Quién puede hacer qué, en una matriz que se lee de un vistazo, y el equipo que ocupa cada rol. Dos secciones bajo un mismo encabezado, porque son la misma pregunta vista de dos lados.

## Cuándo usarla

- Tu producto tiene más de dos roles y la gente pregunta «¿y éste qué puede hacer?»: la matriz responde sin abrir cinco pantallas.
- Hay que **cambiar** permisos, no solo consultarlos, y cada cambio importa lo suficiente para dejar rastro.
- No la uses para un único interruptor de «es administrador» —eso es un `Switch` en [Ajustes](./ajustes.md)— ni para gestionar personas sin permisos, que es una tabla y ya.

## Layout

```
┌────────────────────────────────────────────────────────────────┐
│ PageHeader  Configuración                                      │
│ filters: Tabs  [Roles y permisos] [Equipo (12)]                │
├────────────────────────────────────────────────────────────────┤
│ TabPanel «roles»                                               │
│  texto de contexto                              [+ Nuevo rol]  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ RoleMatrix        Admin │ Ops │ Finanzas │ Driver        │  │
│  │ Flota                                                     │  │
│  │   Ver unidades      ■   │  ■  │    ■     │   □           │  │
│  │   Editar unidades   ■   │  ■  │    □     │   □           │  │
│  │ Tarjetas                                                  │  │
│  │   Congelar          ■   │  □  │    □     │   □           │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│ TabPanel «equipo»                              [+ Invitar]     │
│  DataTable  Miembro │ Rol │ Unidad │ Estado                    │
└────────────────────────────────────────────────────────────────┘
```

## Piezas

- `Tabs` + `TabPanel`: las dos secciones. Van en el slot `filters` del encabezado, no sueltas bajo el título: así el nombre de la pantalla no cambia al cambiar de pestaña. Es **una** parada de tab con flechas dentro, y `TabPanel` monta solo el panel activo.
- `RoleMatrix`: la matriz. Cada celda es un interruptor con `aria-pressed` —on/off, independiente de sus vecinos— y la rejilla entera cuesta **una** parada de tab con flechas en dos dimensiones, no una por celda (`rmx-1`).
- `DataTable`: el equipo, con búsqueda y columnas que se retiran por prioridad. Trae su `caption` para el lector de pantalla.
- `Badge`: el estado de cada miembro con texto, nunca solo color.
- `Dialog`: crear un rol o invitar a alguien. Atrapa el foco, cicla con Tab y cierra con Escape; no lo reimplementes.
- `Toast` + `ToastHost`: el acuse de cada cambio. Un permiso que se activa sin decir nada parece que no se guardó.

## Código

```tsx
// Archivo: RolesYPermisos.tsx
import { useState } from 'react'
import {
  Badge,
  Button,
  DataTable,
  Dialog,
  Field,
  Input,
  PageHeader,
  RoleMatrix,
  Select,
  Stack,
  TabPanel,
  Tabs,
  Toast,
  ToastHost,
} from '@er-mobility-mx/design-system'
import css from './RolesYPermisos.module.css'

const ROLES = [
  /* `locked` protege al rol que no se puede dejar sin permisos: la matriz
     pinta su columna inerte en vez de confiar en que nadie la toque. */
  { id: 'admin', label: 'Admin', locked: true },
  { id: 'ops', label: 'Operaciones' },
  { id: 'finanzas', label: 'Finanzas' },
  { id: 'driver', label: 'Conductor' },
]

const PERMISOS = [
  { id: 'verFlota', label: 'Ver unidades y viajes', group: 'Flota' },
  { id: 'editarUnidades', label: 'Editar unidades', group: 'Flota' },
  { id: 'congelarTarjetas', label: 'Congelar tarjetas', group: 'Tarjetas' },
  { id: 'verMovimientos', label: 'Ver movimientos', group: 'Tarjetas' },
  { id: 'exportar', label: 'Exportar reportes', group: 'Finanzas' },
]

const INICIALES: Record<string, Record<string, boolean>> = {
  verFlota: { admin: true, ops: true, finanzas: true, driver: true },
  editarUnidades: { admin: true, ops: true, finanzas: false, driver: false },
  congelarTarjetas: { admin: true, ops: true, finanzas: false, driver: false },
  verMovimientos: { admin: true, ops: true, finanzas: true, driver: false },
  exportar: { admin: true, ops: false, finanzas: true, driver: false },
}

const EQUIPO = [
  { id: '1', nombre: 'Rosa Duarte', rol: 'Operaciones', unidad: 'MVD-101-C', estado: 'activo' },
  { id: '2', nombre: 'Luis Prieto', rol: 'Conductor', unidad: 'KTR-882-A', estado: 'activo' },
  { id: '3', nombre: 'Ana Sierra', rol: 'Finanzas', unidad: '—', estado: 'pendiente' },
]

export function RolesYPermisos() {
  const [tab, setTab] = useState('roles')
  const [permisos, setPermisos] = useState(INICIALES)
  const [nuevoRol, setNuevoRol] = useState(false)
  const [invitar, setInvitar] = useState(false)
  const [aviso, setAviso] = useState<string | null>(null)

  return (
    <div className={css.pantalla}>
      <PageHeader
        title="Configuración"
        description="Quién puede hacer qué, y quién ocupa cada rol."
        filters={
          <Tabs
            id="config"
            ariaLabel="Secciones de configuración"
            value={tab}
            onChange={setTab}
            items={[
              { value: 'roles', label: 'Roles y permisos' },
              { value: 'equipo', label: `Equipo (${EQUIPO.length})` },
            ]}
          />
        }
      />

      <TabPanel tabsId="config" value="roles" active={tab === 'roles'}>
        <Stack direction="column" gap={3}>
          <div className={css.encabezadoSeccion}>
            <p className={css.contexto}>
              El rol <b>Admin</b> está bloqueado. Cada cambio queda en la bitácora.
            </p>
            <Button variant="secondary" size="sm" icon="add" onClick={() => setNuevoRol(true)}>
              Nuevo rol
            </Button>
          </div>

          <RoleMatrix
            roles={ROLES}
            permissions={PERMISOS}
            values={permisos}
            onChange={(siguiente) => {
              setPermisos(siguiente)
              setAviso('Permiso actualizado. Registrado en bitácora.')
            }}
          />
        </Stack>
      </TabPanel>

      <TabPanel tabsId="config" value="equipo" active={tab === 'equipo'}>
        <Stack direction="column" gap={3}>
          <div className={css.encabezadoSeccion}>
            <p className={css.contexto}>Quién tiene acceso y con qué rol.</p>
            <Button variant="primary" size="sm" icon="person_add" onClick={() => setInvitar(true)}>
              Invitar
            </Button>
          </div>

          <DataTable
            rowKey="id"
            caption="Equipo con acceso"
            searchKeys={['nombre', 'rol', 'unidad']}
            searchPlaceholder="Buscar por nombre, rol o unidad…"
            columns={[
              { key: 'nombre', label: 'Miembro' },
              { key: 'rol', label: 'Rol' },
              { key: 'unidad', label: 'Unidad', mono: true, priority: 2 },
              {
                key: 'estado',
                label: 'Estado',
                render: (fila) => {
                  const r = fila as { estado: string }
                  return (
                    <Badge tone={r.estado === 'activo' ? 'success' : 'warning'}>
                      {r.estado === 'activo' ? 'Activo' : 'Pendiente'}
                    </Badge>
                  )
                },
              },
            ]}
            rows={EQUIPO}
          />
        </Stack>
      </TabPanel>

      <Dialog open={nuevoRol} onOpenChange={setNuevoRol} title="Nuevo rol">
        <Stack direction="column" gap={3}>
          <Field label="Nombre del rol" htmlFor="rol-nombre" required>
            <Input id="rol-nombre" placeholder="Supervisor de patio" />
          </Field>
          <Field label="Copiar permisos de" htmlFor="rol-base" help="Podrás ajustarlos después en la matriz.">
            <Select
              id="rol-base"
              options={ROLES.map((r) => ({ value: r.id, label: r.label }))}
              placeholder="Empezar en blanco"
            />
          </Field>
          <Button variant="primary" onClick={() => setNuevoRol(false)}>
            Crear rol
          </Button>
        </Stack>
      </Dialog>

      <Dialog open={invitar} onOpenChange={setInvitar} title="Invitar a alguien">
        <Stack direction="column" gap={3}>
          <Field label="Correo" htmlFor="inv-correo" required>
            <Input id="inv-correo" type="email" autoComplete="email" placeholder="persona@empresa.com" />
          </Field>
          <Field label="Rol" htmlFor="inv-rol" required>
            <Select id="inv-rol" options={ROLES.map((r) => ({ value: r.id, label: r.label }))} />
          </Field>
          <Button variant="primary" onClick={() => setInvitar(false)}>
            Enviar invitación
          </Button>
        </Stack>
      </Dialog>

      {/* Un permiso que cambia sin decir nada parece que no se guardó. */}
      <ToastHost>
        {aviso && <Toast tone="success" message={aviso} duration={4000} onDismiss={() => setAviso(null)} />}
      </ToastHost>
    </div>
  )
}
```

```css
/* Archivo: RolesYPermisos.module.css */
.pantalla {
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
  padding: var(--pad-section);
  max-width: var(--content-max);
  margin-inline: auto;
}

/* El texto de contexto y la acción de la sección, en la misma línea; con poco
   ancho, el gap del contenedor los apila sin media query. */
.encabezadoSeccion {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
}

.contexto {
  font: var(--type-body-sm);
  color: var(--text-secondary);
  margin: 0;
  max-width: 60ch;
}
```

## Personalización

- **Los grupos de la matriz** salen de `group` en cada permiso: ordena por lo que tu producto hace, no por cómo está tu API. Un grupo de más de siete filas ya no se lee de un vistazo — pártelo.
- **`locked`** protege la columna que no puede quedarse sin permisos. Es un dato del rol, no un `disabled` que pongas tú celda a celda.
- **El acuse importa** porque un interruptor que cambia en silencio parece que falló. El mensaje va en `message` —acepta nodos, así que la cifra puede ir en su familia— y `duration` necesita su `onDismiss`: sin él el aviso no se iría nunca. Si tu guardado es asíncrono, deja el `Toast` para cuando responda el servidor y revierte la celda si falla: lo que no se guardó no puede quedarse encendido.
- **La bitácora**: si registras cada cambio, el tercer argumento de `onChange` te dice **qué permiso y qué rol** cambió, sin que tengas que comparar el objeto entero.
- **Invitar** aquí es un `Dialog` porque son dos campos. Si tu alta pide más, es un paso aparte — mira [Alta en pasos](./alta-en-pasos.md).

## Responsive

`PageHeader` envuelve sus pestañas cuando no caben, y `DataTable` retira las columnas por `priority` —aquí la unidad cae bajo 576 px—. `RoleMatrix` no se puede estrechar sin volverse ilegible: por debajo de 982 px se desplaza en horizontal dentro de su contenedor, que es preferible a partir la rejilla. Si tu producto se usa de verdad en teléfono, enseña los permisos **por rol** en una lista en vez de la matriz.

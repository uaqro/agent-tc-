# Plantillas de Flow

Pantallas completas para copiar, pegar y adaptar. Viajan en el paquete (`node_modules/@er-mobility-mx/design-system/docs/templates/`) y el servidor MCP las sirve con `list_templates` y `get_template`.

Cada una es la versión portable de una plantilla del canon: el banco del repo la implementa y la prueba con datos reales; aquí va sin router, sin datos del banco y sin layout de aplicación — solo React y el paquete.

| Plantilla                                                  | Para                                                                           | Plantilla canónica    |
| ---------------------------------------------------------- | ------------------------------------------------------------------------------ | --------------------- |
| [Auth](./auth.md)                                          | Ingreso, registro, recuperación y traspaso a un proveedor (SSO)                | `auth-t`              |
| [Dashboard](./dashboard.md)                                | Indicadores, una gráfica y la actividad reciente                               | `dashboards-6`        |
| [Ajustes](./ajustes.md)                                    | Preferencias por secciones, tema y zona peligrosa                              | `settings-t`          |
| [Explorador de datos](./explorador-datos.md)               | Tabla con búsqueda, filtros, orden y detalle de la fila                        | `fleet-dashboard-t`   |
| [Alta en pasos](./alta-en-pasos.md)                        | Un alta larga partida en pasos, con validación en cada uno                     | `wizard-t`            |
| [Onboarding de cuenta](./onboarding-cuenta.md)             | Datos de la empresa, verificación e invitación del equipo                      | `onboarding-fm`       |
| [Consola interna](./consola-interna.md)                    | Herramienta para equipos internos: navegación de secciones, tabla y detalle    | `internal-tools-t`    |
| [Wallet (móvil)](./wallet.md)                              | Monedero de teléfono: tarjetas, acciones rápidas y movimientos                 | `wallet`              |
| [Onboarding del conductor (móvil)](./onboarding-driver.md) | Alta en el teléfono: bienvenida, verificación, NIP y biométrico                | `onboarding-driver`   |
| [Asistente](./asistente.md)                                | Chat que responde con el dato dibujado, no solo con texto                      | `agent-chat-template` |
| [Roles y permisos](./roles-y-permisos.md)                  | Matriz de permisos por rol y el equipo que los ocupa                           | `config-roles`        |
| [Mailings](./mailings.md)                                  | Correos transaccionales y su vista previa — el único sitio donde Flow no viaja | `mailings-templates`  |

## Cómo usarla

1. Monta lo mínimo en tu app — `FlowIntlProvider` y `styles.css` ([guía del usuario](../USUARIO.md)).
2. Copia los archivos de la sección «Código».
3. Sustituye los datos de ejemplo por los tuyos: los puntos están en «Personalización».
4. Quita lo que no necesites.

## Reglas

- Son punto de partida, no API: el paquete no las exporta y puedes cambiarlas.
- Tokens semánticos, nunca hex; objetivos ≥ 44 px; nombres accesibles.
- `npm run check:templates` las compila contra la API actual en cada `verify`: si una prop cambia, la plantilla se actualiza en el mismo PR.

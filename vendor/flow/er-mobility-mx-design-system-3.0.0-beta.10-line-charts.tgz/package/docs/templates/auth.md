# Plantilla: Auth

**Plantilla canónica:** `auth-t` · en el banco: `apps/banco/src/pages/AuthPage.tsx`

Pantalla de acceso de escritorio: panel de marca en tinta a la izquierda y, a la derecha, un solo `AuthForm` que cambia entre entrar, crear cuenta y recuperar contraseña —o que, con un proveedor de identidad, se vuelve un traspaso SSO sin campos—.

## Cuándo usarla

- La puerta de entrada de una app con cuentas propias: login, registro y recuperación en la misma ruta, sin recargar.
- Una app que **no** recoge credenciales porque autentica un proveedor externo (Edenred Connect, Azure AD, Google): pásale `ssoProvider` y la misma pantalla se vuelve un traspaso con un solo botón.
- **No** la uses para el segundo factor: eso es `OTPInput` o `BiometricPrompt` compuestos en la misma carcasa, después de este paso.
- **No** la uses dentro de un diálogo sobre una pantalla ya abierta: para reautenticar compón `AuthForm` dentro de `Dialog`, sin el panel de marca.

## Layout

```
┌──────────────────────────────┬──────────────────────────────┐
│ PANEL DE MARCA (inverso)     │ PANEL DEL FORMULARIO (lienzo)│
│                              │                              │
│  Flow                        │      Entrar                  │
│                              │      ¿Primera vez? Crea tu…  │
│                              │      ┌────────────────────┐  │
│  Todo tu día,                │      │ Correo             │  │
│  en movimiento.              │      ├────────────────────┤  │
│  Gestiona tu flota…          │      │ Contraseña    👁   │  │
│                              │      └────────────────────┘  │
│                              │      ☑ Recordarme  ¿Olvidaste│
│                              │      [      Entrar       ]   │
│  © 2026 Tu empresa           │      Términos · Privacidad   │
└──────────────────────────────┴──────────────────────────────┘
                                          ToastStack (esquina) ▸

≤ 768 px: los paneles se apilan — marca compacta arriba, formulario debajo.
```

## Piezas

- `AuthForm` — el flujo completo: título, campos por modo (`login` · `signup` · `recover` · `sso`), validación de correo y contraseña, foco al campo inválido y botón de envío con `loading`.
- `AuthMode` / `AuthSubmitData` — los tipos del modo y de lo que `onSubmit` te entrega (`email`, `password`, `name`, `mode`).
- `Button` (`variant="link"`) — los saltos entre modos («Crea tu cuenta», «¿Olvidaste tu contraseña?», «Volver»): son acciones, no navegación, así que van en botón y no en `<a href="#">`; conservan el objetivo de 44 px.
- `Checkbox` — «Recordarme», compuesto como `children` del formulario, entre los campos y el botón de envío.
- `ToastStack` + `Toast` — la confirmación o el error del servidor, con auto-descarte por `duration` (el temporizador se pausa con puntero o foco encima).

## Código

```tsx
// Archivo: AuthScreen.tsx
import { useState, type ReactNode } from 'react'
import {
  AuthForm,
  Button,
  Checkbox,
  Toast,
  ToastStack,
  type AuthMode,
  type AuthSubmitData,
} from '@er-mobility-mx/design-system'
import css from './AuthScreen.module.css'

/* ── Contenido de ejemplo: reemplázalo con el tuyo ── */
const MARCA = {
  nombre: 'Flow',
  titular: 'Todo tu día, en movimiento.',
  lema: 'Gestiona tu flota, tus conductores y tus viajes desde un solo lugar.',
  legal: '© 2026 Tu empresa',
}

type Aviso = { tono: 'success' | 'danger'; mensaje: string }

export interface AuthScreenProps {
  /** Si tu app autentica con un proveedor externo, su nombre: la pantalla se
      vuelve un traspaso SSO sin campos. */
  ssoProvider?: string
}

export function AuthScreen({ ssoProvider }: AuthScreenProps) {
  const [modo, setModo] = useState<AuthMode>(ssoProvider ? 'sso' : 'login')
  const [recordar, setRecordar] = useState(true)
  const [cargando, setCargando] = useState(false)
  const [aviso, setAviso] = useState<Aviso | null>(null)

  const enlace = (texto: string, destino: AuthMode) => (
    <Button variant="link" size="sm" onClick={() => setModo(destino)}>
      {texto}
    </Button>
  )

  const alEnviar = async (datos: AuthSubmitData) => {
    setCargando(true)
    try {
      // Reemplaza con tu lógica: llama a tu API según datos.mode.
      //   login   → autentica con datos.email + datos.password (+ recordar)
      //   signup  → crea la cuenta con datos.name, datos.email, datos.password
      //   recover → envía el correo de restablecimiento a datos.email
      //   sso     → redirige a tu proveedor (window.location.assign(urlDelProveedor))
      await new Promise((r) => setTimeout(r, 900))
      setAviso({
        tono: 'success',
        mensaje:
          datos.mode === 'recover'
            ? 'Si existe una cuenta con ese correo, recibirás instrucciones para restablecer tu contraseña.'
            : datos.mode === 'signup'
              ? 'Cuenta creada. Revisa tu correo.'
              : 'Bienvenida de vuelta.',
      })
    } catch {
      // Reemplaza con tu lógica: traduce el error de tu API a un mensaje.
      setAviso({ tono: 'danger', mensaje: 'No pudimos completar la solicitud. Intenta de nuevo.' })
    } finally {
      setCargando(false)
    }
  }

  const subtitulo: Record<AuthMode, ReactNode> = {
    login: <>¿Primera vez aquí? {enlace('Crea tu cuenta', 'signup')}</>,
    signup: <>¿Ya tienes cuenta? {enlace('Entra', 'login')}</>,
    recover: 'Ingresa tu correo y te enviaremos instrucciones.',
    sso: `Te llevaremos a ${ssoProvider ?? 'tu proveedor'} para confirmar quién eres.`,
  }

  const legal = (
    <p className={css.legal}>
      {/* `data-link` es el reset del enlace, con dueño: quita el subrayado del
          navegador y hereda la tinta. El COLOR no entra en el reset — aquí lo
          pone `.legal`, que es la decisión de esta plantilla. */}
      Al continuar aceptas los{' '}
      <a data-link href="/terminos">
        Términos
      </a>{' '}
      y el{' '}
      <a data-link href="/privacidad">
        Aviso de privacidad
      </a>
      .
    </p>
  )

  return (
    <div className={css.root}>
      <section className={css.brand} aria-label={MARCA.nombre}>
        <span className={css.wordmark}>{MARCA.nombre}</span>
        <div>
          <p className={css.headline}>{MARCA.titular}</p>
          <p className={css.tagline}>{MARCA.lema}</p>
        </div>
        <small className={css.copyright}>{MARCA.legal}</small>
      </section>

      <main className={css.formPanel}>
        <AuthForm
          mode={modo}
          loading={cargando}
          onSubmit={alEnviar}
          subtitle={subtitulo[modo]}
          submitLabel={modo === 'sso' ? `Continuar con ${ssoProvider}` : undefined}
          submitIcon={modo === 'sso' ? 'lock' : undefined}
          footer={
            modo === 'recover' ? <p className={css.legal}>{enlace('Volver al inicio de sesión', 'login')}</p> : legal
          }
        >
          {(modo === 'login' || modo === 'signup') && (
            <div className={css.options}>
              <Checkbox checked={recordar} onChange={setRecordar} label="Recordarme" />
              {modo === 'login' && enlace('¿Olvidaste tu contraseña?', 'recover')}
            </div>
          )}
        </AuthForm>
      </main>

      <ToastStack>
        {aviso && (
          <Toast
            tone={aviso.tono}
            message={aviso.mensaje}
            duration={aviso.mensaje.length > 60 ? 5000 : 3500}
            onDismiss={() => setAviso(null)}
          />
        )}
      </ToastStack>
    </div>
  )
}
```

```css
/* Archivo: AuthScreen.module.css */
.root {
  display: flex;
  min-height: 100vh;
}

/* ── Panel de marca ── */
.brand {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: var(--space-6);
  padding: var(--space-12);
  background: var(--surface-inverse);
  color: var(--text-on-inverse);
  box-sizing: border-box;
}

.wordmark {
  font: var(--type-title-lg);
  letter-spacing: var(--tracking-tight);
}

.headline {
  font: var(--type-display-md);
  letter-spacing: var(--tracking-tight);
  max-width: 28ch;
  margin: 0;
}

.tagline {
  font: var(--type-body-md);
  max-width: 40ch;
  margin: var(--space-4) 0 0;
}

.copyright {
  font: var(--type-body-sm);
}

/* ── Panel del formulario ── */
.formPanel {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-10);
  background: var(--surface-canvas);
}

.options {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-4);
  flex-wrap: wrap;
}

.legal {
  font: var(--type-body-sm);
  color: var(--text-muted);
  text-align: center;
  margin: 0;
}

.legal a {
  color: var(--text-link);
}

@media (max-width: 768px) {
  .root {
    flex-direction: column;
  }

  .brand {
    flex: none;
    padding: var(--space-6);
  }

  .headline {
    font: var(--type-title-lg);
  }

  .formPanel {
    padding: var(--space-6);
  }
}
```

## Personalización

- **Montaje de la app (fuera de la plantilla):** tu raíz importa `@er-mobility-mx/design-system/styles.css` y envuelve todo en `<FlowIntlProvider locale="es">`. Sin el provider, `AuthForm` y `Toast` revientan con `Could not find required intl object`.
- **Marca:** edita el objeto `MARCA` (nombre, titular, lema, pie legal). Si prefieres un logo, cambia el `<span className={css.wordmark}>` por tu `<img alt="…">`; asegúrate de que se lea sobre `--surface-inverse` en claro y en oscuro.
- **Lógica de acceso:** todo pasa por `alEnviar`. `datos.mode` te dice qué hacer; `recordar` vive en el estado de la pantalla porque `AuthSubmitData` no lo trae. Si tu API responde con error, lanza una excepción y el `catch` lo muestra en un `Toast` `danger`.
- **SSO:** monta `<AuthScreen ssoProvider="Edenred Connect" />`. En ese modo no hay campos ni validación: `onSubmit` llega con los campos vacíos y tu trabajo es redirigir al proveedor.
- **Enlaces legales:** cambia `/terminos` y `/privacidad` por tus rutas (o por el `Link` de tu router).
- **Textos por defecto:** títulos y botones de `AuthForm` salen del catálogo de i18n; sobrescríbelos con `title` y `submitLabel` si tu producto habla distinto.
- **Segundo factor:** tras un login exitoso que lo requiera, cambia el contenido del panel derecho por `OTPInput` o `BiometricPrompt`; no lo metas dentro de `AuthForm`.

## Responsive

- **> 768 px:** dos paneles al 50 %, formulario centrado vertical y horizontalmente.
- **≤ 768 px:** los paneles se apilan; el panel de marca se compacta (`--space-6`, titular en `--type-title-lg`) y el formulario ocupa el ancho disponible.
- La fila «Recordarme / ¿Olvidaste tu contraseña?» hace `flex-wrap`: en pantallas estrechas el enlace baja a su propia línea en lugar de encimarse.
- Todos los controles (campos, casilla, botones de enlace y botón de envío) conservan el objetivo mínimo de 44 px del sistema.

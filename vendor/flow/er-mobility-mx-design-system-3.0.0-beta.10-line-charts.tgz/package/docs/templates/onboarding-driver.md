# Plantilla: Onboarding del conductor (móvil)

**Plantilla canónica:** `onboarding-driver` · en el banco: `apps/banco/src/pages/mobile/OnboardingDriverScreen.tsx`

El alta de quien va a conducir, en su teléfono: le cuentas para qué sirve la app, le pides lo mínimo, verificas que el número es suyo y le dejas una forma de entrar que no sea escribir una contraseña.

## Cuándo usarla

- El primer arranque de una app de consumidor en teléfono, cuando quien entra **no eligió** el producto: se lo dio su empresa, así que hay que explicar antes de pedir.
- Hay una verificación por código y una forma de entrada rápida (NIP o biométrico) que configurar.
- No la uses para el alta de un gestor de flota en escritorio —eso es [Onboarding de cuenta](./onboarding-cuenta.md)— ni para un formulario de registro suelto, donde basta [Auth](./auth.md).

## Layout

```
 carousel        datos          código         nip           biométrico      listo
┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐
│          │   │ Título   │   │ Título   │   │ Título   │   │          │   │          │
│ Onboard. │   │          │   │          │   │          │   │ Biometric│   │ Status   │
│ Carousel │   │ Field    │   │ OTPInput │   │ Passcode │   │ Prompt   │   │ View     │
│  ● ○ ○   │   │ Field    │   │ ▢▢▢▢▢▢   │   │ Keypad   │   │   ◉      │   │   ✓      │
│          │   │ Input    │   │          │   │ 1 2 3    │   │          │   │          │
│ [Omitir] │   │ Phone    │   │ Reenviar │   │ 4 5 6    │   │ [Activar]│   │ [Entrar] │
│ [Seguir] │   │ [Seguir] │   │          │   │ 7 8 9    │   │ [Ahora no]│  │          │
└──────────┘   └──────────┘   └──────────┘   └──────────┘   └──────────┘   └──────────┘
```

## Piezas

- `OnboardingCarousel`: las diapositivas de bienvenida. Los puntos son un `tablist` —una parada de tab, flechas dentro— y `onSkip` existe en **todas** las diapositivas (`onb-3`): quien ya sabe para qué sirve no tiene que pasar tres pantallas.
- `Field` + `Input` + `InputPhone`: los datos. `InputPhone` trae el teclado telefónico y formatea mientras se escribe, así que no escribas `type="tel"` a mano (`tel-3`).
- `OTPInput`: el código de verificación. `onComplete` dispara al llenarse —no hace falta botón— y el campo real va oculto tras las casillas, que es por qué no lleva el reset de campo.
- `PasscodeKeypad`: el NIP. Teclado propio en vez del del sistema, para que el número no pase por el autocompletado ni por el portapapeles.
- `BiometricPrompt`: la propuesta de entrada con cara o huella. Su `state` es tuyo: `idle`, `scanning`, `success`, `error`.
- `StatusView`: el cierre. Un estado de pantalla completa con su acción primaria, no un `Toast` que se va.
- `Button`: avanzar. La salida del biométrico **no** la dibuja esta plantilla: la publica `BiometricPrompt` con `onFallback`.

## Código

```tsx
// Archivo: OnboardingDriver.tsx
import { useState } from 'react'
import {
  BiometricPrompt,
  Button,
  Field,
  Input,
  InputPhone,
  OnboardingCarousel,
  OTPInput,
  PasscodeKeypad,
  StatusView,
} from '@er-mobility-mx/design-system'
import css from './OnboardingDriver.module.css'

const SLIDES = [
  {
    title: 'Controla cada litro',
    description: 'Monitorea cargas, rutas y consumos desde tu teléfono.',
    icon: 'local_gas_station',
  },
  {
    title: 'Paga sin efectivo',
    description: 'Una tarjeta para gasolina, casetas y servicios. Sin vales, sin recibos.',
    icon: 'credit_card',
  },
  { title: 'Entra sin contraseña', description: 'Con tu cara o tu NIP. Nada que recordar.', icon: 'fingerprint' },
]

const PASOS = ['bienvenida', 'datos', 'codigo', 'nip', 'biometrico', 'listo'] as const
type Paso = (typeof PASOS)[number]

export function OnboardingDriver() {
  const [paso, setPaso] = useState<Paso>('bienvenida')
  const [slide, setSlide] = useState(0)
  const [nombre, setNombre] = useState('')
  const [telefono, setTelefono] = useState('')
  const [codigo, setCodigo] = useState('')
  const [nip, setNip] = useState('')
  const [bio, setBio] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle')
  const [errores, setErrores] = useState<{ nombre?: string; telefono?: string }>({})

  const siguiente = () => setPaso(PASOS[Math.min(PASOS.indexOf(paso) + 1, PASOS.length - 1)])

  const validarDatos = () => {
    const e: typeof errores = {}
    if (!nombre.trim()) e.nombre = 'Escribe tu nombre.'
    if (telefono.replace(/\D/g, '').length < 10) e.telefono = 'El teléfono va a 10 dígitos.'
    setErrores(e)
    if (!Object.keys(e).length) siguiente()
  }

  return (
    <div className={css.pantalla}>
      {paso === 'bienvenida' && (
        <OnboardingCarousel
          slides={SLIDES}
          index={slide}
          onIndexChange={setSlide}
          onSkip={siguiente}
          onDone={siguiente}
        />
      )}

      {paso === 'datos' && (
        <form
          className={css.paso}
          onSubmit={(e) => {
            e.preventDefault()
            validarDatos()
          }}
        >
          <h1 className={css.titulo}>¿Cómo te llamas?</h1>
          <p className={css.bajada}>Lo usamos para identificarte en los viajes.</p>

          <Field label="Nombre completo" htmlFor="od-nombre" required error={errores.nombre}>
            <Input id="od-nombre" value={nombre} onChange={setNombre} autoComplete="name" invalid={!!errores.nombre} />
          </Field>

          <Field label="Teléfono" htmlFor="od-tel" required error={errores.telefono} help="Te enviamos un código.">
            {/* No lleva `autoComplete`: lo pone la pieza, y con el valor
                correcto. `InputPhone` emite `autoComplete="tel-national"`
                porque la lada vive FUERA del valor (tel-1), así que el número
                guardado del sistema se ofrece sin el código de país. El teclado
                telefónico también es suyo — las dos cosas son `tel-3`. */}
            <InputPhone id="od-tel" value={telefono} onChange={setTelefono} invalid={!!errores.telefono} />
          </Field>

          <Button type="submit" variant="primary" size="lg">
            Continuar
          </Button>
        </form>
      )}

      {paso === 'codigo' && (
        <div className={css.paso}>
          <h1 className={css.titulo}>Escribe el código</h1>
          <p className={css.bajada}>Lo mandamos al {telefono || 'tu teléfono'}.</p>
          {/* onComplete avanza solo: pedir un botón después de teclear los seis
              dígitos es un paso que nadie necesita. */}
          <OTPInput length={6} value={codigo} onChange={setCodigo} onComplete={siguiente} autoFocus />
          <Button variant="ghost" onClick={() => setCodigo('')}>
            Reenviar código
          </Button>
        </div>
      )}

      {paso === 'nip' && (
        <div className={css.paso}>
          <h1 className={css.titulo}>Crea tu NIP</h1>
          <p className={css.bajada}>Cuatro dígitos para entrar y autorizar pagos.</p>
          {/* Teclado propio y no el del sistema: así el NIP no pasa por el
              autocompletado ni por el portapapeles. */}
          <PasscodeKeypad
            value={nip}
            onChange={(v) => {
              setNip(v)
              if (v.length === 4) siguiente()
            }}
          />
        </div>
      )}

      {paso === 'biometrico' && (
        <div className={css.paso}>
          <BiometricPrompt
            method="face"
            state={bio}
            title="Entra con tu cara"
            description={bio === 'success' ? 'Listo. Entrarás sin teclear.' : 'Más rápido que el NIP, y solo tuyo.'}
            fallbackLabel="Ahora no"
            onUse={() => {
              setBio('scanning')
              setTimeout(() => {
                setBio('success')
                siguiente()
              }, 1200)
            }}
            onFallback={siguiente}
          />
        </div>
      )}

      {paso === 'listo' && (
        <StatusView
          status="success"
          title="Todo listo"
          description="Ya puedes usar tu tarjeta desde la app."
          primaryAction={
            <Button variant="primary" size="lg" onClick={() => {}}>
              Entrar
            </Button>
          }
        />
      )}
    </div>
  )
}
```

```css
/* Archivo: OnboardingDriver.module.css */
.pantalla {
  display: flex;
  flex-direction: column;
  min-height: 100%;
  background: var(--surface-canvas);
}

/* Un paso es una columna que ocupa la pantalla y empuja su acción al pie:
   el pulgar llega abajo, no arriba. */
.paso {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
  padding: var(--pad-section) var(--pad-card);
}

.titulo {
  font: var(--type-headline-lg);
  color: var(--text-primary);
  margin: 0;
}

/* La bajada es la línea subordinada del título: se separa con el paso más
   pequeño que hay, que es lo que dice que las dos son un bloque. */
.bajada {
  font: var(--type-body-md);
  color: var(--text-secondary);
  margin: 0;
  margin-top: var(--space-hairline);
}
```

## Personalización

- **Las diapositivas** son tuyas: tres o cuatro, con un icono de Material Symbols cada una. Si tu producto no necesita explicarse, borra el paso `bienvenida` — `onSkip` existe justo porque mucha gente lo va a saltar.
- **La verificación**: `onComplete` de `OTPInput` dispara al llenarse. Si tu API tarda, pon el paso en carga antes de avanzar; si rechaza, `invalid` marca las casillas **y** el mensaje va en texto, no solo en color.
- **El NIP**: `PasscodeKeypad` no decide la longitud ni valida; eso es tuyo. Si pides confirmarlo, repite el paso con otro título en vez de inventar una segunda pieza.
- **El biométrico es opcional por ley de producto**, y la salida la trae la pieza: `onFallback` con su `fallbackLabel`. No la dibujes aparte — `BiometricPrompt` ya la pinta con su objetivo de 44 px, y un segundo botón al lado es la misma acción dos veces.
- **El cierre**: `StatusView` ocupa la pantalla porque terminar un alta merece una pantalla. Si prefieres volver directo al inicio, borra el paso y navega.

## Responsive

Es una columna de teléfono y no lleva media queries. Las piezas que podrían desbordar —el teclado y las casillas del código— ya se ajustan al ancho disponible. En una tablet, limita el ancho del contenedor (`max-width: 420px; margin-inline: auto`) en lugar de repartir los pasos en dos columnas: un alta se lee de arriba abajo.

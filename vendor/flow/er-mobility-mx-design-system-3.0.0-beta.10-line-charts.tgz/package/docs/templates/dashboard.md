# Plantilla: Dashboard

**Plantilla canónica:** `dashboards-6` · en el banco: `apps/banco/src/pages/DashboardPage.tsx`

Vista general de una operación: cuatro cifras clave, una gráfica de tendencia y la actividad más reciente, bajo un encabezado con las acciones de la página.

## Cuándo usarla

- La primera pantalla de un producto o de un módulo: la persona entra para saber «cómo vamos hoy» antes de ir al detalle.
- Tienes de 2 a 4 indicadores que se leen de un vistazo y una serie en el tiempo que los explica.
- No la uses para capturar o editar datos (eso es un formulario o una tabla editable), ni para comparar muchas series a la vez (eso es una vista de análisis con varias gráficas).

## Layout

```
┌──────────────────────────────────────────────────────────────────┐
│ PageFrame (main)                                                 │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ PageHeader  Tablero · Resumen                                │ │
│ │ Resumen de la flota        [Compartir] [Exportar ▾] [+ Agregar]│ │
│ │                              ghost      secondary    primary │ │
│ └──────────────────────────────────────────────────────────────┘ │
│ AutoGrid (KPIs, máximo 4 por fila)                               │
│ ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────┐      │
│ │ StatTile   │ │ StatTile   │ │ StatTile   │ │ StatTile   │      │
│ └────────────┘ └────────────┘ └────────────┘ └────────────┘      │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ Card · SectionHeader «Viajes por día»                        │ │
│ │ FlowChart (barras, carga ECharts en diferido)                │ │
│ └──────────────────────────────────────────────────────────────┘ │
│ ┌──────────────────────────────────────────────────────────────┐ │
│ │ Card · SectionHeader «Actividad reciente»                    │ │
│ │ Table  Unidad │ Evento │ Estado (Badge) │ Monto │ Cuándo     │ │
│ └──────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

## Piezas

- `PageFrame`: marco de la página; centra el contenido al ancho máximo del sistema y pone el padding de sección.
- `PageHeader`: título, migas y la fila de acciones de la página (`actions`); el slot `filters` queda libre para el periodo.
- `Button`: las tres acciones del encabezado, con jerarquía ghost → secondary → primary.
- `Menu`: despliega los formatos de «Exportar»; trae foco y teclado resueltos.
- `AutoGrid`: rejilla fluida de los KPIs; colapsa sola a menos columnas sin media queries.
- `StatTile`: cada KPI con icono, cifra, delta y tendencia; el color del delta lo decide el componente.
- `Card`: superficie de la gráfica y de la tabla.
- `SectionHeader`: título real (`h2`) y bajada de cada bloque.
- `FlowChart`: la gráfica; carga ECharts en diferido y trae modo oscuro, estado vacío y nombre accesible.
- `Table`: la actividad reciente, con `caption` para el lector de pantalla y columnas que se retiran por `priority`.
- `Badge`: el estado de cada evento, con icono y texto (nunca solo color).

## Código

```tsx
// Archivo: Dashboard.tsx
import {
  AutoGrid,
  Badge,
  Button,
  Card,
  FlowChart,
  Menu,
  PageFrame,
  PageHeader,
  SectionHeader,
  StatTile,
  Table,
  type BadgeProps,
  type GridColumn,
} from '@er-mobility-mx/design-system'
import css from './Dashboard.module.css'

/* ── Datos de ejemplo: reemplázalos por los de tu API ─────────────── */

type Kpi = {
  id: string
  label: string
  value: string
  delta?: string
  trend?: number[]
  icon: string
}

type Estado = 'completado' | 'pendiente' | 'atencion'

type Actividad = {
  id: string
  unidad: string
  evento: string
  estado: Estado
  monto: string
  cuando: string
}

const KPIS: Kpi[] = [
  {
    id: 'activas',
    label: 'Unidades activas',
    value: '128',
    delta: '+4 vs ayer',
    trend: [98, 104, 112, 109, 118, 124, 128],
    icon: 'local_taxi',
  },
  {
    id: 'viajes',
    label: 'Viajes hoy',
    value: '412',
    delta: '+12% vs ayer',
    trend: [290, 340, 310, 365, 388, 395, 412],
    icon: 'navigation',
  },
  {
    id: 'ingreso',
    label: 'Ingreso del mes',
    value: '$612k',
    delta: '+8% vs mes pasado',
    trend: [540, 571, 558, 590, 601, 612],
    icon: 'payments',
  },
  { id: 'puntualidad', label: 'Entregas a tiempo', value: '94%', delta: '−2 pts vs semana pasada', icon: 'schedule' },
]

const DIAS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']
const VIAJES_POR_DIA = [288, 342, 315, 371, 412, 389, 214]

const ACTIVIDAD: Actividad[] = [
  {
    id: 'a1',
    unidad: 'JMX-214-B',
    evento: 'Carga de combustible',
    estado: 'completado',
    monto: '$989.80',
    cuando: 'Hoy 14:32',
  },
  {
    id: 'a2',
    unidad: 'KTR-882-A',
    evento: 'Consumo alto de combustible',
    estado: 'atencion',
    monto: '—',
    cuando: 'Hoy 12:10',
  },
  {
    id: 'a3',
    unidad: 'PLQ-472-D',
    evento: 'Renovar tag de peaje',
    estado: 'pendiente',
    monto: '$450.00',
    cuando: 'Hoy 09:05',
  },
  {
    id: 'a4',
    unidad: 'MVD-101-C',
    evento: 'Servicio de 40,000 km',
    estado: 'pendiente',
    monto: '$3,200.00',
    cuando: 'Ayer 18:40',
  },
  {
    id: 'a5',
    unidad: 'TWN-559-F',
    evento: 'Carga eléctrica',
    estado: 'completado',
    monto: '$214.50',
    cuando: 'Ayer 16:02',
  },
]

/* El estado se dice con texto e icono; el tono solo lo refuerza. */
const ESTADO: Record<Estado, { label: string; tone: BadgeProps['tone']; icon: string }> = {
  completado: { label: 'Completado', tone: 'success', icon: 'check_circle' },
  pendiente: { label: 'Pendiente', tone: 'warning', icon: 'schedule' },
  atencion: { label: 'Revisar', tone: 'danger', icon: 'error' },
}

const COLUMNAS: GridColumn<Actividad>[] = [
  { key: 'unidad', label: 'Unidad', mono: true },
  { key: 'evento', label: 'Evento' },
  {
    key: 'estado',
    label: 'Estado',
    render: (fila) => {
      const e = ESTADO[fila.estado]
      return (
        <Badge tone={e.tone} icon={e.icon}>
          {e.label}
        </Badge>
      )
    },
  },
  { key: 'monto', label: 'Monto', align: 'right', mono: true, priority: 3 },
  { key: 'cuando', label: 'Cuándo', priority: 2 },
]

/* ── Handlers ─────────────────────────────────────────────────────── */

function compartir() {
  // Reemplaza con tu lógica
}

function exportar(formato: 'csv' | 'pdf') {
  // Reemplaza con tu lógica
  void formato
}

function agregarUnidad() {
  // Reemplaza con tu lógica
}

function abrirActividad(fila: Actividad) {
  // Reemplaza con tu lógica
  void fila
}

/* ── Pantalla ─────────────────────────────────────────────────────── */

export function Dashboard() {
  return (
    <PageFrame as="main">
      <PageHeader
        title="Resumen de la flota"
        breadcrumb={['Tablero', 'Resumen']}
        description="Cómo va tu operación hoy."
        actions={
          <>
            <Button variant="ghost" icon="share" onClick={compartir}>
              Compartir
            </Button>
            <Menu
              align="right"
              trigger={
                <Button variant="secondary" icon="download" iconTrailing="expand_more">
                  Exportar
                </Button>
              }
              items={[
                { label: 'Hoja de cálculo (CSV)', icon: 'table', onClick: () => exportar('csv') },
                { label: 'Documento PDF', icon: 'picture_as_pdf', onClick: () => exportar('pdf') },
              ]}
            />
            <Button variant="primary" icon="add" onClick={agregarUnidad}>
              Agregar unidad
            </Button>
          </>
        }
      />

      <div className={css.secciones}>
        <AutoGrid minWidth="220px">
          {KPIS.map((k) => (
            <StatTile key={k.id} label={k.label} value={k.value} delta={k.delta} trend={k.trend} icon={k.icon} />
          ))}
        </AutoGrid>

        <Card padding="md">
          <SectionHeader size="sm" description="Viajes iniciados en los últimos 7 días.">
            Viajes por día
          </SectionHeader>
          <FlowChart
            type="bar"
            height={240}
            labels={DIAS}
            series={[{ label: 'Viajes', values: VIAJES_POR_DIA }]}
            legend={false}
            ariaLabel="El viernes es el día con más viajes (412) y el domingo el de menos (214)"
          />
        </Card>

        <Card padding="md">
          <SectionHeader size="sm">Actividad reciente</SectionHeader>
          <Table<Actividad>
            caption="Actividad reciente de la flota"
            columns={COLUMNAS}
            rows={ACTIVIDAD}
            rowKey="id"
            onRowClick={abrirActividad}
          />
        </Card>
      </div>
    </PageFrame>
  )
}
```

```css
/* Archivo: Dashboard.module.css */
/* Separación vertical entre bloques del tablero: un solo token de zona. */
.secciones {
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
}
```

## Personalización

- **Montaje de la app (una vez, fuera de la plantilla):** importa `@er-mobility-mx/design-system/styles.css` y envuelve tu árbol en `<FlowIntlProvider locale="es">`. Sin el provider, los patterns fallan con `Could not find required intl object`.
- **Datos:** `KPIS`, `DIAS`/`VIAJES_POR_DIA` y `ACTIVIDAD` son de ejemplo; conecta tu API y conserva los tipos. Mientras llegan los datos, pasa `loading` a `StatTile` y a `FlowChart`.
- **Acciones del encabezado:** los cuatro handlers llevan `// Reemplaza con tu lógica`. Si cambias las acciones, conserva el orden: ghost al extremo lejano, secondary junto al primary y el primary cerrando la fila. Una sola acción primaria por vista.
- **Periodo:** el slot `filters` de `PageHeader` recibe tu selector de rango. Al usarlo, las acciones bajan a una segunda fila, a la derecha.
- **KPIs:** hasta 4. Escribe el delta con signo (`+`, `−`): `StatTile` pinta verde lo que sube, rojo lo que baja, y la flecha coincide. No pases `deltaTone`, `deltaArrow` ni `tone`: los iconos quedan en gris uniforme. Si una etiqueta no cabe, reescríbela más corta.
- **Gráfica:** cambia `type` (`line`, `area`, `stackedBar`…) según la pregunta que respondes. Escribe `ariaLabel` como la conclusión que se lee en la gráfica, no como su título.
- **Tabla:** agrega o quita columnas en `COLUMNAS`. Con `priority` decides qué columna se retira primero en pantallas angostas. Si la lista crece y necesitas buscar o paginar, cambia `Table` por `DataTable` (mismas `columns`; pide `caption` y `rowKey`).
- **Estilos propios:** solo tokens semánticos (`var(--space-*)`, `var(--text-*)`, `var(--surface-*)`), nunca hex, para que el modo oscuro funcione sin tocar nada.

## Responsive

- **Encabezado:** en escritorio, título a la izquierda y acciones juntas a la derecha. Bajo 576 px las acciones pasan a su propia fila a todo el ancho, en el mismo orden.
- **KPIs:** `AutoGrid` con mínimo de 220 px: 4 columnas en escritorio, 2 en tableta y 1 en móvil, sin media queries propias. Con 4 tarjetas nunca hay más de 4 por fila.
- **Gráfica:** ocupa el ancho de su tarjeta y se redibuja al cambiar el tamaño; la altura fija (240 px) mantiene el ritmo de la página.
- **Tabla:** bajo 982 px se retira «Monto» (`priority: 3`) y bajo 576 px «Cuándo» (`priority: 2`). Unidad, evento y estado siempre quedan visibles; si aun así no cabe, la tabla se desplaza en horizontal dentro de su tarjeta.
- **Objetivos táctiles:** los botones del encabezado miden al menos 44 px de alto. La tabla usa la densidad normal a propósito: sus filas se tocan (`onRowClick`). Si pasas `density="compact"`, quita `onRowClick` y lleva la acción a un botón.

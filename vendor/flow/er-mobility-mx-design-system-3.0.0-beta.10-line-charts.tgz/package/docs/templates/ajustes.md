# Plantilla: Ajustes

**Plantilla canónica:** `settings-t` · en el banco: `apps/banco/src/pages/SettingsPage.tsx`

Pantalla de ajustes de una organización: tabs por sección, filas con switches y selects, un selector de tema que aplica de verdad y una zona peligrosa que confirma con `Dialog`.

## Cuándo usarla

- Es el punto de partida para la pantalla de ajustes de tu producto: preferencias de organización, notificaciones y seguridad.
- Úsala cuando cada ajuste se aplica al instante (switch o select), con un aviso breve que confirma el cambio.
- No la uses para permisos por rol: para eso está la plantilla `config-roles`.
- No la uses para un formulario largo que se guarda con un botón «Guardar»: eso es un formulario, no una lista de ajustes.

## Layout

```
┌──────────────────────────────────────────────────────────────┐
│ Flota › Ajustes                                  PageHeader  │
│ Ajustes                                                      │
├──────────────────────────────────────────────────────────────┤
│ ( General )( Notificaciones )( Seguridad )             Tabs  │
├──────────────────────────────────────────────────────────────┤
│ Card                                                         │
│  Organización ───────────────────────────  SettingsSection   │
│  Nombre de la organización           [ Transportes Vidal ]   │
│  Se muestra en reportes…                                     │
│  ─────────────────────────────────────────────────────────── │
│  Zona horaria                         [ Ciudad de México ▾]  │
│                                                              │
│  Apariencia ─────────────────────────────────────────────── │
│  Tema                                 [ Según el sistema ▾]  │
│                                                              │
│  Operación ──────────────────────────────────────────────── │
│  Asignación automática                              [ ●━ ]   │
│  Alertas de mantenimiento                           [ ●━ ]   │
│                                                              │
│  ━━ Zona peligrosa ━━━━━━━━━━━━━━━━━━━  SettingsDangerZone   │
│  Exportar todos los datos…                [ Exportar datos ] │
│  Eliminar la organización…          [ Eliminar organización ]│
└──────────────────────────────────────────────────────────────┘
       ↓ los botones de la zona peligrosa abren un Dialog
┌───────────────── Dialog (tone="danger") ─────────────────┐
│ Eliminar organización                                    │
│ Esta acción eliminará…                                   │
│                              [ Cancelar ] [ Eliminar ]   │
└──────────────────────────────────────────────────────────┘
```

## Piezas

- `PageHeader`: título y migas de pan de la pantalla.
- `Tabs`: cambia entre secciones (General, Notificaciones, Seguridad).
- `Card`: la superficie que contiene la sección activa.
- `Settings`: el contenedor del flujo de ajustes; da el ritmo vertical entre secciones.
- `SettingsSection`: agrupa filas bajo un título.
- `SettingsRow`: fila con etiqueta, descripción y control; asocia la etiqueta al control inyectándole `aria-labelledby`.
- `SettingsDangerZone` / `SettingsDangerRow`: bloque final de acciones destructivas, separado visualmente.
- `Switch`: ajuste booleano que se aplica al instante.
- `Select`: ajuste con opciones cerradas (zona horaria, tema, tiempo de sesión).
- `Input`: ajuste de texto libre (nombre de la organización).
- `Button`: dispara las acciones de la zona peligrosa y las de los diálogos.
- `Dialog`: confirma cada acción de la zona peligrosa; trae trampa de foco y Escape.
- `useToast`: aviso breve que confirma cada cambio (necesita `ToastHost` arriba).
- `useFlowMode`: lee y cambia el tema (`light` / `dark` / `system`); necesita `FlowModeProvider` arriba.

## Código

```tsx
// Archivo: Ajustes.tsx
import { useState } from 'react'
import {
  Button,
  Card,
  Dialog,
  Input,
  PageHeader,
  Select,
  Settings,
  SettingsDangerRow,
  SettingsDangerZone,
  SettingsRow,
  SettingsSection,
  Switch,
  Tabs,
  TabPanel,
  useFlowMode,
  useToast,
  type FlowMode,
  type TabItem,
} from '@er-mobility-mx/design-system'

type Seccion = 'general' | 'notificaciones' | 'seguridad'

const TABS: TabItem[] = [
  { value: 'general', label: 'General', icon: 'tune' },
  { value: 'notificaciones', label: 'Notificaciones', icon: 'notifications' },
  { value: 'seguridad', label: 'Seguridad', icon: 'shield' },
]

/** Datos de ejemplo: reemplázalos con lo que devuelva tu API. */
interface Preferencias {
  nombre: string
  zonaHoraria: string
  asignacionAutomatica: boolean
  alertasMantenimiento: boolean
  correo: boolean
  push: boolean
  sonido: string
  reporteSemanal: boolean
  dosFactores: boolean
  tiempoSesion: string
}

const INICIALES: Preferencias = {
  nombre: 'Transportes Vidal',
  zonaHoraria: 'America/Mexico_City',
  asignacionAutomatica: true,
  alertasMantenimiento: true,
  correo: true,
  push: false,
  sonido: 'default',
  reporteSemanal: true,
  dosFactores: false,
  tiempoSesion: '30',
}

const ZONAS = [
  { value: 'America/Mexico_City', label: 'Ciudad de México (GMT-6)' },
  { value: 'America/Bogota', label: 'Bogotá (GMT-5)' },
  { value: 'America/Santiago', label: 'Santiago (GMT-4)' },
  { value: 'Europe/Madrid', label: 'Madrid (GMT+1)' },
]
const TEMAS: Array<{ value: FlowMode; label: string }> = [
  { value: 'system', label: 'Según el sistema' },
  { value: 'light', label: 'Claro' },
  { value: 'dark', label: 'Oscuro' },
]
const SONIDOS = [
  { value: 'default', label: 'Predeterminado' },
  { value: 'chime', label: 'Campanada' },
  { value: 'none', label: 'Sin sonido' },
]
const SESIONES = [
  { value: '15', label: '15 minutos' },
  { value: '30', label: '30 minutos' },
  { value: '60', label: '1 hora' },
]

const ANCHO_CONTROL = { width: 240, maxWidth: '100%' }

export function Ajustes() {
  const toast = useToast()
  const { mode, setMode } = useFlowMode()
  const [seccion, setSeccion] = useState<Seccion>('general')
  const [prefs, setPrefs] = useState<Preferencias>(INICIALES)
  const [dialogo, setDialogo] = useState<'exportar' | 'eliminar' | null>(null)

  function cambiar<K extends keyof Preferencias>(clave: K, valor: Preferencias[K], aviso?: string) {
    setPrefs((p) => ({ ...p, [clave]: valor }))
    // Reemplaza con tu lógica: persiste el ajuste en tu API.
    if (aviso) toast.show({ message: aviso, tone: 'success' })
  }

  const interruptor = (
    clave: 'asignacionAutomatica' | 'alertasMantenimiento' | 'correo' | 'push' | 'reporteSemanal' | 'dosFactores',
    nombre: string,
  ) => (
    <Switch
      checked={prefs[clave]}
      onChange={(v) => cambiar(clave, v, `${nombre}: ${v ? 'activado' : 'desactivado'}`)}
    />
  )

  function exportar() {
    setDialogo(null)
    // Reemplaza con tu lógica: encola la exportación en tu backend.
    toast.show({ message: 'Exportación iniciada. Te enviaremos un correo cuando esté lista.', tone: 'info' })
  }

  function eliminar() {
    setDialogo(null)
    // Reemplaza con tu lógica: elimina la organización y cierra la sesión.
    toast.show({ message: 'Organización eliminada', tone: 'danger' })
  }

  return (
    <>
      <PageHeader breadcrumb={['Flota', 'Ajustes']} title="Ajustes" />
      {/* El contenedor separa; ninguna pieza se pone su propio margen. */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-6)' }}>
        <Tabs
          id="ajustes"
          ariaLabel="Secciones de ajustes"
          items={TABS}
          value={seccion}
          onChange={(v) => setSeccion(v as Seccion)}
        />

        <Card>
          {/* TabPanel pone role, id y el aria-labelledby de vuelta a su pestaña. */}
          <TabPanel tabsId="ajustes" value={seccion} active>
            {seccion === 'general' && (
              <Settings>
                <SettingsSection title="Organización">
                  <SettingsRow
                    label="Nombre de la organización"
                    description="Se muestra en reportes y documentos exportados."
                    control={
                      <Input
                        ariaLabel="Nombre de la organización"
                        value={prefs.nombre}
                        onChange={(v) => cambiar('nombre', v)}
                        style={ANCHO_CONTROL}
                      />
                    }
                  />
                  <SettingsRow
                    label="Zona horaria"
                    description="Afecta los horarios en reportes y programaciones."
                    control={
                      <Select
                        options={ZONAS}
                        value={prefs.zonaHoraria}
                        onChange={(v) => cambiar('zonaHoraria', v as string, 'Zona horaria actualizada')}
                        style={ANCHO_CONTROL}
                      />
                    }
                  />
                </SettingsSection>

                <SettingsSection title="Apariencia">
                  <SettingsRow
                    label="Tema"
                    description="«Según el sistema» sigue la preferencia de tu dispositivo."
                    control={
                      <Select
                        options={TEMAS}
                        value={mode}
                        onChange={(v) => setMode(v as FlowMode)}
                        style={ANCHO_CONTROL}
                      />
                    }
                  />
                </SettingsSection>

                <SettingsSection title="Operación">
                  <SettingsRow
                    label="Asignación automática"
                    description="Asigna conductores a unidades disponibles cuando inician turno."
                    control={interruptor('asignacionAutomatica', 'Asignación automática')}
                  />
                  <SettingsRow
                    label="Alertas de mantenimiento"
                    description="Avisa cuando una unidad alcanza su próximo servicio programado."
                    control={interruptor('alertasMantenimiento', 'Alertas de mantenimiento')}
                  />
                </SettingsSection>

                <SettingsDangerZone>
                  <SettingsDangerRow
                    description="Exportar todos los datos de la organización en formato CSV."
                    action={
                      <Button variant="secondary" onClick={() => setDialogo('exportar')}>
                        Exportar datos
                      </Button>
                    }
                  />
                  <SettingsDangerRow
                    description="Eliminar la organización y todos sus datos. Esta acción no se puede deshacer."
                    action={
                      <Button variant="danger" onClick={() => setDialogo('eliminar')}>
                        Eliminar organización
                      </Button>
                    }
                  />
                </SettingsDangerZone>
              </Settings>
            )}

            {seccion === 'notificaciones' && (
              <Settings>
                <SettingsSection title="Canales">
                  <SettingsRow
                    label="Correo electrónico"
                    description="Recibe los avisos importantes por correo."
                    control={interruptor('correo', 'Correo electrónico')}
                  />
                  <SettingsRow
                    label="Notificaciones push"
                    description="Recibe alertas en tiempo real en tu dispositivo."
                    control={interruptor('push', 'Notificaciones push')}
                  />
                  <SettingsRow
                    label="Sonido de alerta"
                    description="Se reproduce cuando llega una alerta crítica."
                    control={
                      <Select
                        options={SONIDOS}
                        value={prefs.sonido}
                        onChange={(v) => cambiar('sonido', v as string, 'Sonido actualizado')}
                        style={ANCHO_CONTROL}
                      />
                    }
                  />
                </SettingsSection>
                <SettingsSection title="Resúmenes">
                  <SettingsRow
                    label="Reporte semanal"
                    description="Resumen de operaciones enviado cada lunes por la mañana."
                    control={interruptor('reporteSemanal', 'Reporte semanal')}
                  />
                </SettingsSection>
              </Settings>
            )}

            {seccion === 'seguridad' && (
              <Settings>
                <SettingsSection title="Autenticación">
                  <SettingsRow
                    label="Autenticación de dos factores"
                    description="Añade una capa extra de seguridad al iniciar sesión."
                    control={interruptor('dosFactores', 'Autenticación de dos factores')}
                  />
                  <SettingsRow
                    label="Tiempo de sesión"
                    description="Minutos de inactividad antes de cerrar la sesión."
                    control={
                      <Select
                        options={SESIONES}
                        value={prefs.tiempoSesion}
                        onChange={(v) => cambiar('tiempoSesion', v as string, 'Tiempo de sesión actualizado')}
                        style={ANCHO_CONTROL}
                      />
                    }
                  />
                </SettingsSection>
              </Settings>
            )}
          </TabPanel>
        </Card>
      </div>

      <Dialog
        open={dialogo === 'exportar'}
        onClose={() => setDialogo(null)}
        title="Exportar datos"
        description="Generaremos un archivo CSV con todos los datos de la organización y te enviaremos un correo cuando esté listo."
        actions={
          <>
            <Button variant="ghost" onClick={() => setDialogo(null)}>
              Cancelar
            </Button>
            <Button variant="primary" onClick={exportar}>
              Exportar
            </Button>
          </>
        }
      />
      <Dialog
        open={dialogo === 'eliminar'}
        onClose={() => setDialogo(null)}
        tone="danger"
        title="Eliminar organización"
        description="Se eliminarán unidades, conductores, viajes y reportes. Esta acción no se puede deshacer."
        actions={
          <>
            <Button variant="ghost" onClick={() => setDialogo(null)}>
              Cancelar
            </Button>
            <Button variant="danger" onClick={eliminar}>
              Eliminar
            </Button>
          </>
        }
      />
    </>
  )
}
```

## Personalización

- **Tus ajustes:** edita `Preferencias` e `INICIALES` con los campos reales de tu producto; carga los valores desde tu API en lugar de la constante. Cada fila debe ser un ajuste que tu producto tenga de verdad.
- **Persistencia:** `cambiar()` es el único punto donde se guarda un ajuste; ahí va tu llamada a la API (marcada con `// Reemplaza con tu lógica`). Si la llamada falla, revierte el estado y muestra `toast.show({ message, tone: 'danger' })`.
- **Nombre de la organización:** hoy actualiza el estado en cada tecla sin aviso; guarda en tu API con _debounce_ para no disparar una petición por tecla.
- **Secciones:** agrega o quita entradas en `TABS` y en el tipo `Seccion`, y su bloque `seccion === '…'`.
- **Zona peligrosa:** cada acción destructiva abre su propio `Dialog`; nunca cambies el texto o el color del botón en su sitio para pedir la confirmación. Pon tu lógica en `exportar()` y `eliminar()`.
- **Migas y título:** ajusta `breadcrumb` y `title` de `PageHeader` a tu navegación.
- **Lo que tu app monta una sola vez** (no va dentro de la plantilla): `styles.css`, `FlowIntlProvider` (sin él los patterns revientan), `FlowModeProvider` (sin él `useFlowMode` lanza un error; `defaultMode` acepta `'light' | 'dark' | 'system'`, por defecto `'system'`) y `ToastHost` (sin él `useToast` lanza un error). Por ejemplo:

```tsx
// Archivo: main.tsx
import { createRoot } from 'react-dom/client'
import { FlowIntlProvider, FlowModeProvider, ToastHost } from '@er-mobility-mx/design-system'
import '@er-mobility-mx/design-system/styles.css'
import { Ajustes } from './Ajustes'

createRoot(document.getElementById('root')!).render(
  <FlowIntlProvider locale="es">
    <FlowModeProvider defaultMode="system">
      <ToastHost>
        <Ajustes />
      </ToastHost>
    </FlowModeProvider>
  </FlowIntlProvider>,
)
```

- **Tema:** el selector usa `setMode`, que escribe `data-mode` en `<html>`; todo tu CSS propio debe usar tokens semánticos para que el tema oscuro funcione sin tocarlo. Si prefieres guardarlo por usuario, persiste `mode` en tu API o en `localStorage` y pásalo como `defaultMode`.

## Responsive

- En pantallas de hasta 768 px, `SettingsRow` y `SettingsDangerRow` apilan la etiqueta encima del control, así que el control ocupa todo el ancho; no hace falta CSS propio.
- Los controles fijan `width: 240` con `maxWidth: '100%'`: en escritorio conservan un ancho estable y en móvil nunca desbordan la fila.
- `Tabs` se mantiene en una línea; si agregas más de tres secciones o etiquetas largas, prueba en 360 px o usa etiquetas cortas.
- Cada fila mide al menos `--hit-target-min` (44 px) de alto y `Button` respeta ese mínimo. Ojo: el `Switch` del paquete mide 44 × 24 px sin área táctil ampliada, así que en táctil queda por debajo de 44 px de alto; no lo encojas más.
- Los `Dialog` se adaptan solos al ancho de la pantalla; no les fijes `width` salvo que el contenido lo pida.

# Plantilla: Wallet (móvil)

**Plantilla canónica:** `wallet` · en el banco: `apps/banco/src/pages/mobile/WalletAppScreen.tsx`

El monedero de quien lleva la tarjeta en el bolsillo: sus tarjetas, lo que puede hacer con ellas y en qué se le va el dinero. Pensada para una pantalla de teléfono, con navegación inferior y las hojas que suben desde abajo.

## Cuándo usarla

- La pantalla de inicio de una app de consumidor que lleva una o varias tarjetas: saldo, acciones rápidas y movimientos recientes.
- Hay **más de una** tarjeta y la persona cambia entre ellas: el carrusel es lo que hace que no haya que elegir en un menú.
- No la uses para la vista de un gestor de flota —eso es un tablero con tabla, no un monedero— ni para una sola tarjeta sin movimientos, donde basta `PaymentCard` sobre una `Card`.

## Layout

```
┌──────────────────────────────┐
│ Avatar · título · campana     │
│ Hero                         │
│  ┌────────────────────────┐  │
│  │ CardCarousel           │  │
│  │  PaymentCard  ·  ·  ·  │  │
│  └────────────────────────┘  │
│  QuickActionBar              │
│   [≡] [***] [❄] [🗑]         │
├──────────────────────────────┤
│ SectionHeader «Movimientos»  │
│  TransactionRow              │
│  TransactionRow              │
│  TransactionRow              │
│  [Ver todo]                  │
├──────────────────────────────┤
│ TabBar  Inicio · Actividad   │
└──────────────────────────────┘
        ↑ BottomSheet con el detalle
```

## Cabeceras y exploración de actividad

La pantalla consume `TopBar` con su presentación `mobile` existente. La altura, la zona segura, las columnas simétricas, el título multilínea y la ausencia de acciones inventadas pertenecen al paquete. Inicio pasa avatar y campana; Actividad y Rutas pasan solamente su título. El mapa de Rutas ocupa el lienzo completo y hospeda el header y los filtros como controles flotantes.

Actividad y Rutas consumen el MISMO `FilterSet` con `presentation="sheet"`. El paquete posee búsqueda e icon button, chips compactos, copia del borrador, cierre sin aplicar, selección táctil, restablecimiento y aplicación. La wallet solo pasa dimensiones y valores, filtra sus datos y calcula `applyLabel` con el borrador recibido. Rutas pasa tipo de estación; Actividad pasa producto, estado, cargo/abono y fecha. No se comparten criterios de negocio entre dominios.

`StationFinder` posee pines con color e icono y el flujo pin → detalle → cómo llegar, sin lista intermedia. `BottomSheet` y `OverlayShell` poseen la capa modal sobre la navegación, altura fullscreen, zona segura, cierre y títulos largos. `TransactionGroup` posee `Divider` con label y separación antes de las filas.

La demo solo conserva sus tarjetas y movimientos de ejemplo, agrupación por fecha, filtrado de datos y posición de los controles sobre el mapa. Esas reglas de producto no pertenecen a los controles del sistema. Véase [composición móvil](../mobile-composition.md) para reutilizar los patrones.

## Piezas

- `CardCarousel`: el cambio entre tarjetas. Es **un** tab stop con flechas dentro, no una parada por tarjeta (`cc-4`), y el scroll-snap centra la activa.
- `PaymentCard`: el arte de la tarjeta, con titular, últimos cuatro, vigencia y saldo. El saldo se oculta con `hidden` y el ojo lo controla el consumidor (`onToggleHidden`); el arte **no cambia** con el modo claro/oscuro, porque una tarjeta física tampoco.
- `QuickActionBar` + `QuickAction`: la fila de acciones sobre la tarjeta activa. `active` marca el estado vivo —congelada— con forma y no solo con color.
- `TransactionRow`: cada movimiento. Usa verde semántico para ingresos y rojo semántico para egresos en Inicio y Actividad; escribe su **signo** además de colorearlo (`wl-2`) y su nombre accesible compone título, subtítulo y el importe hablado.
- `TransactionGroup`: agrupa por día en la pestaña de actividad; el rótulo del grupo va con su overline.
- `BottomSheet` + `SheetBody`: el detalle del movimiento. Al cerrar, **el foco vuelve a la fila** que la abrió — eso lo hace `OverlayShell` por dentro, no lo escribas tú (`wl-3`).
- `DetailRow`: cada par etiqueta/valor del detalle.
- `Badge`: el estado del movimiento (pendiente, cargo, abono) con texto, no solo color.
- `EmptyState`: la tarjeta sin movimientos. El vacío lo pone la pieza, nunca una rejilla hueca.
- `TabBar`: la navegación inferior. Es un `tablist`: una parada de tab y flechas dentro.
- `SectionHeader`: el rótulo de cada bloque, con `h2` real.

## Código

```tsx
// Archivo: Wallet.tsx
import { useState } from 'react'
import {
  Badge,
  BottomSheet,
  CardCarousel,
  DetailRow,
  EmptyState,
  PaymentCard,
  QuickAction,
  QuickActionBar,
  SectionHeader,
  SheetBody,
  TabBar,
  TransactionGroup,
  TransactionRow,
  useLocale,
} from '@er-mobility-mx/design-system'
import css from './Wallet.module.css'

type Movimiento = {
  id: string
  category: 'fuel' | 'toll' | 'service' | 'transfer'
  title: string
  subtitle: string
  amount: number
  pending?: boolean
}

const TARJETAS = [
  {
    key: 'fuel',
    holder: 'RICARDO M.',
    last4: '4821',
    variant: 'fuel' as const,
    label: 'Combustible',
    icon: 'local_gas_station',
    expires: '09/28',
    balance: '$4,820.50',
  },
  {
    key: 'sand',
    holder: 'RICARDO M.',
    last4: '7310',
    variant: 'sand' as const,
    label: 'Viáticos',
    icon: 'restaurant',
    expires: '03/27',
    balance: '$1,250.00',
  },
]

const MOVIMIENTOS: Movimiento[] = [
  { id: '1', category: 'fuel', title: 'Gasolinera Pemex #412', subtitle: 'Hoy, 14:23', amount: -850 },
  { id: '2', category: 'toll', title: 'Caseta Tepotzotlán', subtitle: 'Hoy, 09:05', amount: -195 },
  { id: '3', category: 'transfer', title: 'Recarga de saldo', subtitle: 'Ayer, 18:40', amount: 2000 },
  { id: '4', category: 'service', title: 'Taller mecánico', subtitle: 'Ayer, 11:12', amount: -620, pending: true },
]

const TABS = [
  { id: 'inicio', label: 'Inicio', icon: 'account_balance_wallet' },
  { id: 'actividad', label: 'Actividad', icon: 'receipt_long' },
]

const porDia = (movs: Movimiento[]) => {
  const grupos = new Map<string, Movimiento[]>()
  for (const m of movs) {
    const dia = m.subtitle.split(',')[0]
    grupos.set(dia, [...(grupos.get(dia) ?? []), m])
  }
  return [...grupos].map(([label, items]) => ({ label, items }))
}

export function Wallet() {
  const locale = useLocale()
  const [tarjeta, setTarjeta] = useState(0)
  const [tab, setTab] = useState('inicio')
  const [saldoOculto, setSaldoOculto] = useState(false)
  const [congelada, setCongelada] = useState(false)
  const [detalle, setDetalle] = useState<Movimiento | null>(null)

  const activa = TARJETAS[tarjeta]
  const movimientos = MOVIMIENTOS

  return (
    <div className={css.pantalla}>
      <div className={css.contenido}>
        {tab === 'inicio' && (
          <>
            <section className={css.hero}>
              <CardCarousel activeIndex={tarjeta} onChange={setTarjeta}>
                {TARJETAS.map((t) => (
                  <PaymentCard
                    key={t.key}
                    holder={t.holder}
                    last4={t.last4}
                    variant={t.variant}
                    label={t.label}
                    icon={t.icon}
                    expires={t.expires}
                    balance={t.balance}
                    hidden={saldoOculto}
                    onToggleHidden={() => setSaldoOculto((v) => !v)}
                  />
                ))}
              </CardCarousel>

              <QuickActionBar>
                <QuickAction icon="receipt_long" label="Estado de cuenta" onClick={() => setTab('actividad')} />
                <QuickAction icon="password" label="Ver NIP" onClick={() => {}} />
                <QuickAction
                  icon="ac_unit"
                  label={congelada ? 'Descongelar' : 'Congelar'}
                  active={congelada}
                  onClick={() => setCongelada((v) => !v)}
                />
              </QuickActionBar>
            </section>

            <section className={css.bloque}>
              <SectionHeader>Movimientos recientes</SectionHeader>
              {movimientos.length === 0 ? (
                <EmptyState
                  icon="credit_card_off"
                  title="Sin movimientos"
                  description={`Cuando uses la tarjeta ${activa.label} los verás aquí.`}
                />
              ) : (
                movimientos
                  .slice(0, 3)
                  .map((m) => (
                    <TransactionRow
                      key={m.id}
                      category={m.category}
                      title={m.title}
                      subtitle={m.subtitle}
                      amount={m.amount}
                      pending={m.pending}
                      onClick={() => setDetalle(m)}
                    />
                  ))
              )}
            </section>
          </>
        )}

        {tab === 'actividad' && (
          <section className={css.bloque}>
            <SectionHeader>Actividad</SectionHeader>
            {porDia(movimientos).map((g) => (
              <TransactionGroup key={g.label} label={g.label}>
                {g.items.map((m) => (
                  <TransactionRow
                    key={m.id}
                    category={m.category}
                    title={m.title}
                    subtitle={m.subtitle}
                    amount={m.amount}
                    pending={m.pending}
                    onClick={() => setDetalle(m)}
                  />
                ))}
              </TransactionGroup>
            ))}
          </section>
        )}
      </div>

      <TabBar items={TABS} activeId={tab} onChange={setTab} />

      {/* El foco vuelve solo a la fila que abrió la hoja: lo hace OverlayShell
          por dentro. No lo repitas aquí — duplicarlo es lo que tapa el fallo
          cuando una de las dos mitades se rompe. */}
      <BottomSheet
        open={!!detalle}
        onOpenChange={(abierto) => {
          if (!abierto) setDetalle(null)
        }}
        title="Detalle del movimiento"
        fixed={false}
      >
        {detalle && (
          <SheetBody>
            <span className={css.importe}>
              {detalle.amount < 0 ? '−' : '+'}$
              {Math.abs(detalle.amount).toLocaleString(locale, { minimumFractionDigits: 2 })}
            </span>
            <div className={css.etiquetas}>
              {detalle.pending && <Badge tone="warning">Pendiente</Badge>}
              <Badge tone={detalle.amount < 0 ? 'danger' : 'success'}>{detalle.amount < 0 ? 'Cargo' : 'Abono'}</Badge>
            </div>
            <DetailRow label="Comercio" value={detalle.title} />
            <DetailRow label="Cuándo" value={detalle.subtitle} />
            <DetailRow label="Tarjeta" value={`${activa.label} ···· ${activa.last4}`} />
          </SheetBody>
        )}
      </BottomSheet>
    </div>
  )
}
```

```css
/* Archivo: Wallet.module.css */
.pantalla {
  display: flex;
  flex-direction: column;
  min-height: 100%;
  background: var(--surface-canvas);
}

/* La barra inferior es fija, así que el contenido reserva su alto en vez de
   escribir un número: si --height-bar cambia, esto lo sigue. */
.contenido {
  flex: 1;
  overflow-y: auto;
  padding-bottom: calc(var(--height-bar) + var(--space-8));
}

.hero {
  display: flex;
  flex-direction: column;
  gap: var(--gap-stack);
  padding: var(--pad-card);
}

.bloque {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  padding-inline: var(--pad-card);
}

/* El importe del detalle es dato: familia mono y su tamaño grande (typ-1). */
.importe {
  font: var(--type-data-lg);
  color: var(--text-primary);
}

.etiquetas {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
}
```

## Personalización

- **Las tarjetas**: `variant` decide el arte (`fuel`, `sand`, `ink`, `accent`). El arte es el mismo de día y de noche a propósito —una tarjeta física no cambia—, así que su tinta sale de `--card-fg-on-*` y no de `--text-primary`.
- **El saldo oculto** vive en tu estado, no en la pieza: `hidden` más `onToggleHidden`. Con `hidden`, el valor **no está en el DOM** ni en el nombre accesible, así que una captura de pantalla tampoco lo filtra.
- **Las acciones rápidas** son tuyas: `QuickActionBar` solo las alinea. Si una acción es destructiva, no la pintes de rojo —el rojo de marca no decora—: pide confirmación en una `BottomSheet`.
- **El detalle** puede llevar lo que quieras dentro de `SheetBody`. Si añades una acción de disputa, va como `Button` al pie, no como enlace dentro del texto.
- **Los grupos por día** salen de tu dato. Si tu API ya los agrupa, borra `porDia` y mapea directo.

## Responsive

Está pensada para una sola columna de teléfono y no necesita media queries: `CardCarousel` se desplaza con el dedo, `TabBar` se queda abajo y el contenido reserva su alto con `calc()`. Si la montas en una tablet, dale un ancho máximo al contenedor —`max-width: 480px; margin-inline: auto`— en vez de reescribir los bloques: el monedero es una columna, no una rejilla.

Los movimientos de Inicio y Actividad muestran fecha y hora cuando están completados; solo pendiente y rechazado reemplazan esos datos; estas se consultan en el detalle. La iconografía usa la paleta de su producto en ambas vistas. `pending` sigue siendo compatible, sin atenuar toda la fila.

### Zona segura de cabeceras móviles

Las cabeceras de Inicio y de las pestañas reservan `--inset-safe-top`. La cabecera fullscreen de `BottomSheet` reserva el máximo entre ese token, `env(safe-area-inset-top)` y su espaciado normal; permanece fuera del scroll. Los títulos usan `--type-title-md`, también en `NavBar`, y los grupos de filtros usan `--type-body-sm-strong` con nivel h3. El notch no determina el tamaño de letra ni se compensa con márgenes del contenido.

# Plantilla: Onboarding de cuenta

**Plantilla canónica:** `onboarding-fm` · en el banco: `apps/banco/src/pages/OnboardingPage.tsx`

Alta de cuenta completa en una sola ruta: una bienvenida que se desliza, un asistente de cuatro pasos (datos de la empresa, verificación del correo, invitación al equipo y primer paso de producto) y una pantalla de cierre que dice qué sigue.

## Cuándo usarla

- Es el primer contacto de alguien que acaba de decidir usar tu producto: hay que pedirle lo mínimo para crear la cuenta y llevarlo a su primer resultado útil.
- Úsala cuando el alta tiene **fases con orden**: unos datos habilitan al siguiente paso (sin correo no hay código que verificar) y conviene mostrar cuánto falta.
- Los pasos que no bloquean el alta —invitar al equipo, cargar la primera unidad— se pueden saltar y retomar después desde el producto.
- **No** la uses para entrar a una cuenta que ya existe: eso es la plantilla `auth`.
- **No** la uses para un formulario de un solo envío, aunque sea largo: sin fases, el asistente solo añade clics. Un `Card` con `Field` alcanza.
- **No** la uses para el alta de una persona conductora en móvil: para eso está `onboarding-driver`.

## Layout

```
Fase 1 — bienvenida                    Fase 2 — asistente
┌───────────────────────────┐          ┌──────────────────────────────────────────┐
│                    Omitir │          │ Crea tu cuenta                           │
│      ╭───────────╮        │          │                                          │
│      │     ⬤     │        │          │ ①─────②─────③─────④           Wizard     │
│      ╰───────────╯        │          │ Empresa  Correo  Equipo  Unidad          │
│                           │          │ ┌──────────────────────────────────────┐ │
│   Bienvenida a Flow       │          │ │ Nombre de la empresa *               │ │
│   Tu plataforma para…     │  ─────▶  │ │ [🏢 Transportes Vidal SA           ] │ │
│                           │          │ │ ┌─────────────────┬────────────────┐ │ │
│      ● ○ ○                │          │ │ │ Tamaño de flota │ Correo de … *  │ │ │
│   [     Continuar     ]   │          │ │ │ [1–10 unidades▾]│ [✉ marta@…   ] │ │ │
│                           │          │ │ └─────────────────┴────────────────┘ │ │
│   OnboardingCarousel      │          │ │ Teléfono   [🇲🇽 +52 │ 55 1234 5678 ] │ │
└───────────────────────────┘          │ └──────────────────────────────────────┘ │
                                       │ [ ← Volver ]              [ Continuar → ]│
                                       └──────────────────────────────────────────┘
                                                          │
                                                          ▼  al enviar el último paso
                                       ┌──────────────────────────────────────────┐
                                       │                   ✔                      │
                                       │            ¡Cuenta creada!               │
                                       │   Transportes Vidal ya está lista…       │
                                       │        [ Ir a mi panel ]     StatusView  │
                                       └──────────────────────────────────────────┘

Cuerpo de cada paso, dentro del Wizard:
  ② Verificación   texto + OTPInput de 6 casillas + «Reenviar en 0:42»
  ③ Equipo         [correo ] [ Agregar ] + Chip por invitación + «Saltar este paso»
  ④ Primera unidad [placa  ] + FileUpload (tarjeta de circulación) + «Saltar este paso»
```

## Piezas

- `OnboardingCarousel` — la bienvenida: diapositivas con ilustración, puntos de posición, deslizamiento táctil, «Omitir» siempre visible y un botón final con la etiqueta que le pongas (`doneLabel`).
- `Wizard` — el asistente entero: pinta el `Stepper`, el cuerpo del paso y la barra de acciones (Volver / Continuar / botón de envío con `loading`). Es lo que evita rehacer a mano la navegación del alta.
- `StepperStep` — el tipo de cada paso (`label` y `description`); el `Stepper` lo pinta por dentro y anuncia «Paso 2 de 4» al lector de pantalla.
- `Card` — la superficie que sostiene el asistente.
- `Field` — etiqueta, marca de obligatorio, texto de ayuda y mensaje de error de cada campo; conecta el mensaje al control y le pone `aria-invalid`.
- `Input` — nombre de la empresa, correo de trabajo, correo a invitar y placa.
- `Select` — el tamaño de flota: opciones cerradas y pocas.
- `InputPhone` — el teléfono de contacto: la lada con bandera va como adorno fijo, fuera del valor, y el número se formatea solo mientras se escribe. La bandera la dibuja la pieza con `country`; la lada es dato tuyo y llega por `prefix` (tel-6).
- `OTPInput` — el código de seis dígitos del correo: casillas, pegado del código completo y `onComplete`.
- `Chip` — cada invitación agregada, con su botón de quitar.
- `FileUpload` — la tarjeta de circulación de la primera unidad: arrastrar o elegir, con lista de lo cargado.
- `Badge` — la confirmación en sitio de que la unidad quedará creada con la cuenta.
- `Button` — «Reenviar código», «Agregar», «Saltar este paso» y la acción final de la pantalla de cierre.
- `StatusView` — el cierre: icono de éxito, qué pasó y a dónde ir ahora.

## Código

```tsx
// Archivo: Onboarding.tsx
import { useEffect, useState } from 'react'
import {
  Badge,
  Button,
  Card,
  Chip,
  Field,
  FileUpload,
  Input,
  InputPhone,
  OTPInput,
  OnboardingCarousel,
  Select,
  StatusView,
  Wizard,
  type StepperStep,
  type UploadedFile,
} from '@er-mobility-mx/design-system'
import css from './Onboarding.module.css'

/* ── Contenido de ejemplo: reemplázalo con el tuyo ── */
const PASOS: StepperStep[] = [
  { label: 'Empresa', description: 'Datos básicos' },
  { label: 'Correo', description: 'Confirma tu correo' },
  { label: 'Equipo', description: 'Opcional' },
  { label: 'Primera unidad', description: 'Opcional' },
]

const DIAPOSITIVAS = [
  {
    icon: 'rocket_launch',
    title: 'Bienvenida a Flow',
    description: 'Tu plataforma para gestionar flotas y operaciones en tiempo real.',
  },
  {
    icon: 'map',
    title: 'Seguimiento en vivo',
    description: 'Mira dónde está cada unidad, con datos que se actualizan solos.',
  },
  {
    icon: 'insights',
    title: 'Reportes que se entienden',
    description: 'Consumo, rutas y tiempos, listos para compartir con tu equipo.',
  },
]

const TAMANOS = [
  { value: 's', label: '1–10 unidades' },
  { value: 'm', label: '11–50 unidades' },
  { value: 'l', label: 'Más de 50 unidades' },
]

interface Cuenta {
  empresa: string
  tamano: string
  correo: string
  telefono: string
  codigo: string
  invitaciones: string[]
  placa: string
  documentos: UploadedFile[]
}

const INICIAL: Cuenta = {
  empresa: '',
  tamano: '',
  correo: '',
  telefono: '',
  codigo: '',
  invitaciones: [],
  placa: '',
  documentos: [],
}

/** Cuenta atrás antes de poder pedir otro código. */
function Reenviar() {
  const [restan, setRestan] = useState(42)
  useEffect(() => {
    if (restan === 0) return
    const t = window.setTimeout(() => setRestan((s) => s - 1), 1000)
    return () => window.clearTimeout(t)
  }, [restan])

  if (restan > 0)
    return <span className={css.espera}>Puedes pedir otro código en 0:{String(restan).padStart(2, '0')}</span>
  return (
    <Button
      variant="link"
      size="sm"
      onClick={() => {
        setRestan(42) /* Reemplaza con tu lógica: vuelve a enviar el código. */
      }}
    >
      Reenviar código
    </Button>
  )
}

export function Onboarding() {
  const [fase, setFase] = useState<'bienvenida' | 'alta' | 'listo'>('bienvenida')
  const [diapositiva, setDiapositiva] = useState(0)
  const [paso, setPaso] = useState(0)
  const [datos, setDatos] = useState<Cuenta>(INICIAL)
  const [errores, setErrores] = useState<Record<string, string>>({})
  const [enviando, setEnviando] = useState(false)
  const [correoInvitado, setCorreoInvitado] = useState('')

  const editar = <K extends keyof Cuenta>(clave: K, valor: Cuenta[K]) => {
    setDatos((d) => ({ ...d, [clave]: valor }))
    setErrores(({ [clave as string]: _quitado, ...resto }) => resto)
  }

  /** Al pulsar Continuar se dice qué falta, campo por campo: un botón apagado
      sin mensaje deja a la persona adivinando. */
  const faltantes = (): Record<string, string> => {
    if (paso === 0) {
      const e: Record<string, string> = {}
      if (!datos.empresa.trim()) e.empresa = 'Escribe el nombre de tu empresa.'
      if (!datos.correo.includes('@')) e.correo = 'Escribe un correo válido, como marta@flota.mx.'
      return e
    }
    if (paso === 1 && datos.codigo.length < 6) return { codigo: 'El código tiene 6 dígitos.' }
    return {}
  }

  const avanzar = () => {
    const e = faltantes()
    setErrores(e)
    if (!Object.keys(e).length) setPaso((p) => p + 1)
  }

  const saltar = () => (paso === PASOS.length - 1 ? crearCuenta() : setPaso((p) => p + 1))

  const crearCuenta = async () => {
    const e = faltantes()
    setErrores(e)
    if (Object.keys(e).length) return
    setEnviando(true)
    try {
      // Reemplaza con tu lógica: crea la cuenta en tu API con `datos`.
      await new Promise((r) => setTimeout(r, 1200))
      setFase('listo')
    } catch {
      // Reemplaza con tu lógica: traduce el error de tu API a un mensaje.
      setErrores({ empresa: 'No pudimos crear la cuenta. Intenta de nuevo.' })
    } finally {
      setEnviando(false)
    }
  }

  const agregarInvitacion = () => {
    if (!correoInvitado.includes('@') || datos.invitaciones.includes(correoInvitado)) return
    editar('invitaciones', [...datos.invitaciones, correoInvitado])
    setCorreoInvitado('')
  }

  if (fase === 'bienvenida') {
    return (
      <div className={css.bienvenida}>
        <OnboardingCarousel
          slides={DIAPOSITIVAS}
          index={diapositiva}
          onIndexChange={setDiapositiva}
          onSkip={() => setFase('alta')}
          onDone={() => setFase('alta')}
          doneLabel="Crear mi cuenta"
          style={{ width: '100%', maxWidth: 420, height: 520 }}
        />
      </div>
    )
  }

  if (fase === 'listo') {
    return (
      <div className={css.bienvenida}>
        <StatusView
          status="success"
          title="¡Cuenta creada!"
          description={`${datos.empresa || 'Tu empresa'} ya está lista. Te enviamos un correo a ${datos.correo} con los siguientes pasos.`}
          primaryAction={
            <Button
              variant="primary"
              icon="dashboard"
              onClick={() => {
                /* Reemplaza con tu lógica: lleva a la persona a su panel. */
              }}
            >
              Ir a mi panel
            </Button>
          }
        />
      </div>
    )
  }

  return (
    <div className={css.root}>
      <h1 className={css.titulo}>Crea tu cuenta</h1>
      <Card>
        <Wizard
          steps={PASOS}
          current={paso}
          onBack={() => setPaso((p) => p - 1)}
          onNext={avanzar}
          onSubmit={crearCuenta}
          submitting={enviando}
          nextLabel="Continuar"
          submitLabel="Crear cuenta"
        >
          {paso === 0 && (
            <div className={css.campos}>
              <Field label="Nombre de la empresa" htmlFor="alta-empresa" required error={errores.empresa}>
                <Input
                  id="alta-empresa"
                  value={datos.empresa}
                  onChange={(v) => editar('empresa', v)}
                  icon="apartment"
                  placeholder="Transportes Vidal SA"
                  invalid={!!errores.empresa}
                  autoComplete="organization"
                />
              </Field>
              <div className={css.dos}>
                <Field label="Tamaño de flota" htmlFor="alta-tamano" help="Nos ayuda a preparar tu panel.">
                  <Select
                    id="alta-tamano"
                    options={TAMANOS}
                    value={datos.tamano}
                    onChange={(v) => editar('tamano', String(v))}
                    placeholder="Elige un rango"
                  />
                </Field>
                <Field label="Correo de trabajo" htmlFor="alta-correo" required error={errores.correo}>
                  <Input
                    id="alta-correo"
                    value={datos.correo}
                    onChange={(v) => editar('correo', v)}
                    type="email"
                    icon="mail"
                    placeholder="marta@flota.mx"
                    invalid={!!errores.correo}
                    autoComplete="email"
                  />
                </Field>
              </div>
              <Field
                label="Teléfono de contacto"
                htmlFor="alta-telefono"
                help="Solo lo usamos si hay un problema con tu cuenta."
              >
                <InputPhone
                  id="alta-telefono"
                  value={datos.telefono}
                  onChange={(v) => editar('telefono', v)}
                  country="mx"
                  prefix="+52"
                />
              </Field>
            </div>
          )}

          {paso === 1 && (
            <div className={css.verificar}>
              <p className={css.ayuda}>
                Enviamos un código de 6 dígitos a <b>{datos.correo}</b>. Escríbelo aquí para confirmar que el correo es
                tuyo.
              </p>
              <OTPInput
                length={6}
                value={datos.codigo}
                onChange={(v) => editar('codigo', v)}
                invalid={!!errores.codigo}
                autoFocus
              />
              {errores.codigo && (
                <p className={css.error} role="alert">
                  {errores.codigo}
                </p>
              )}
              <Reenviar />
            </div>
          )}

          {paso === 2 && (
            <div className={css.campos}>
              <Field
                label="Invita a tu equipo"
                htmlFor="alta-invitado"
                help="Recibirán un correo para entrar. Puedes hacerlo más tarde."
              >
                <div className={css.fila}>
                  <Input
                    id="alta-invitado"
                    value={correoInvitado}
                    onChange={setCorreoInvitado}
                    type="email"
                    icon="mail"
                    placeholder="persona@flota.mx"
                    autoComplete="off"
                    style={{ flex: 1 }}
                  />
                  <Button
                    variant="secondary"
                    icon="add"
                    disabled={!correoInvitado.includes('@')}
                    onClick={agregarInvitacion}
                  >
                    Agregar
                  </Button>
                </div>
              </Field>
              {datos.invitaciones.length > 0 && (
                <ul data-list className={css.chips} aria-label="Personas invitadas">
                  {datos.invitaciones.map((correo) => (
                    <li key={correo}>
                      <Chip
                        label={correo}
                        onRemove={() =>
                          editar(
                            'invitaciones',
                            datos.invitaciones.filter((c) => c !== correo),
                          )
                        }
                      />
                    </li>
                  ))}
                </ul>
              )}
              <Button variant="ghost" onClick={saltar}>
                Saltar este paso
              </Button>
            </div>
          )}

          {paso === 3 && (
            <div className={css.campos}>
              <Field
                label="Placa de tu primera unidad"
                htmlFor="alta-placa"
                help="Si la registras ahora, la verás en tu panel desde el primer día."
              >
                <Input
                  id="alta-placa"
                  value={datos.placa}
                  onChange={(v) => editar('placa', v)}
                  icon="local_shipping"
                  placeholder="JMX-214-B"
                  mono
                />
              </Field>
              <FileUpload
                files={datos.documentos}
                onChange={(f) => editar('documentos', f)}
                accept=".pdf,image/*"
                multiple={false}
                label="Tarjeta de circulación"
                hint="Arrastra el archivo o elígelo. PDF o imagen, opcional."
              />
              {datos.placa.trim().length >= 5 && (
                <Badge tone="success" icon="check">
                  La unidad se creará junto con tu cuenta
                </Badge>
              )}
              <Button variant="ghost" onClick={saltar} disabled={enviando}>
                Saltar este paso
              </Button>
            </div>
          )}
        </Wizard>
      </Card>
      <p className={css.pie}>Puedes completar lo que falte después, desde tu panel.</p>
    </div>
  )
}
```

```css
/* Archivo: Onboarding.module.css */
.root {
  max-width: 760px;
  margin: 0 auto;
  padding: var(--space-10) var(--space-6) var(--space-16);
}

.bienvenida {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-6);
}

.titulo {
  font: var(--type-headline-lg);
  letter-spacing: var(--tracking-tight);
  color: var(--text-primary);
  margin: 0 0 var(--space-7);
}

.campos {
  display: flex;
  flex-direction: column;
  gap: var(--space-5);
  align-items: stretch;
}

.dos {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--gap-stack);
}

.fila {
  display: flex;
  gap: var(--space-2);
  align-items: flex-start;
}

.verificar {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--gap-stack);
  text-align: center;
  padding: var(--space-2) 0;
}

.ayuda {
  font: var(--type-body-sm);
  color: var(--text-secondary);
  margin: 0;
}

.error {
  font: var(--type-body-sm);
  color: var(--status-danger-text);
  margin: 0;
}

.espera {
  font: var(--type-body-sm);
  color: var(--text-muted);
  min-height: var(--hit-target-min);
  display: inline-flex;
  align-items: center;
}

/* Las viñetas y los márgenes del navegador los quita `data-list`, que es un
   reset con dueño; aquí solo va la disposición, que sí es de esta plantilla. */
.chips {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
}

.pie {
  font: var(--type-body-sm);
  color: var(--text-muted);
  text-align: center;
  margin-top: var(--space-4);
}

@media (max-width: 768px) {
  .root {
    padding: var(--space-6) var(--space-4) var(--space-10);
  }

  .dos {
    grid-template-columns: 1fr;
  }

  .fila {
    flex-direction: column;
    align-items: stretch;
  }
}
```

## Personalización

- **Tus pasos:** `PASOS` manda. Quita o agrega entradas y su bloque `paso === n`; el `Wizard` sabe solo cuál es el último y cambia «Continuar» por «Crear cuenta». Regla al agregar: un paso que no cambia lo que la cuenta puede hacer no merece un paso.
- **Tus datos:** cambia la interfaz `Cuenta` e `INICIAL` por los campos reales de tu producto. Todo el estado vive en un objeto, así que enviarlo a tu API es una sola llamada dentro de `crearCuenta()`.
- **Validación:** `faltantes()` es el único sitio donde se decide qué falta; devuelve un mensaje por campo y `Field` lo muestra y lo conecta al control. El botón «Continuar» nunca se apaga a propósito: al pulsarlo, la pantalla explica qué falta. Si tu backend valida (un correo ya registrado, por ejemplo), escribe su respuesta en `errores` con la misma forma.
- **Verificación del correo:** `OTPInput` también acepta `onComplete`, que dispara al llenar la última casilla; úsalo si quieres verificar contra tu API sin que la persona pulse Continuar. `Reenviar` trae la cuenta atrás; ahí va tu llamada de reenvío.
- **Teléfono:** `InputPhone` formatea el número mientras se escribe y deja la lada fuera del valor, como adorno no borrable. La bandera la pone la pieza con `country`. Si operas en varios países, pon un `Select` de país junto al campo (`renderOption` acepta cualquier nodo, así que ahí la bandera se pinta con `Flag`) y alimenta `country` y `prefix` con el país elegido y su lada. Y sirve esas banderas: `npx flow-banderas --codigos mx,us --destino public/flags` y `FlowFlagsProvider baseUrl="/flags"` en la raíz (RFC 0012). Ojo con el HALLAZGO de abajo: el formateo interno es de 10 dígitos.
- **Pasos opcionales:** el botón «Saltar este paso» vive dentro del cuerpo del paso, no en la barra del `Wizard` —que solo tiene volver y avanzar—. Si un paso es obligatorio, quítale ese botón.
- **Tamaño de los controles:** todos los campos usan el tamaño por defecto (`md`). Si cambias uno a `sm` o `lg`, cámbialos todos: una fila con controles de alturas distintas se lee como un error.
- **Pantalla de cierre:** `StatusView` acepta también `secondaryAction` («Invitar a más personas», «Ver la guía rápida») y `fullScreen` si quieres que ocupe la ventana completa sin tu contenedor.
- **Lo que tu app monta una sola vez** (no va dentro de la plantilla): la hoja `@er-mobility-mx/design-system/styles.css` y `FlowIntlProvider` —sin él, `Wizard`, `OnboardingCarousel` y `FileUpload` revientan al pedir sus textos—. Por ejemplo:

```tsx
// Archivo: main.tsx
import { createRoot } from 'react-dom/client'
import { FlowIntlProvider } from '@er-mobility-mx/design-system'
import '@er-mobility-mx/design-system/styles.css'
import { Onboarding } from './Onboarding'

createRoot(document.getElementById('root')!).render(
  <FlowIntlProvider locale="es">
    <Onboarding />
  </FlowIntlProvider>,
)
```

## Responsive

- Hasta 768 px, la rejilla de dos columnas (`.dos`) pasa a una sola y la fila de invitación (`.fila`) se apila, así que el campo de correo y el botón «Agregar» ocupan el ancho completo en lugar de apretarse.
- El `Stepper` del `Wizard` es horizontal y con cuatro pasos entra en 360 px porque las descripciones son cortas; si tus etiquetas son largas, acórtalas antes de agregar CSS propio.
- El carrusel de bienvenida fija `maxWidth: 420` y se centra: en móvil ocupa el ancho disponible y responde al deslizamiento táctil; en escritorio no se estira a media pantalla.
- Los objetivos táctiles cumplen los 44 px (`--hit-target-min`): `Button`, `Chip`, las casillas del `OTPInput` y la zona de carga de `FileUpload`. El enlace «Reenviar código» es un `Button variant="link"`, no un `<a href="#">`, justo para conservar ese mínimo y el foco por teclado.
- El contenedor limita el ancho a 760 px: en pantallas grandes el formulario no se estira hasta volverse ilegible.

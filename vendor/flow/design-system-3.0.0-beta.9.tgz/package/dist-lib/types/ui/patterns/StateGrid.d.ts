import type { CSSProperties, ReactNode } from 'react';
export interface StateGridItem {
    label: string;
    specimen: ReactNode;
}
export interface StateGridProps {
    states: StateGridItem[];
    columns?: number;
    style?: CSSProperties;
}
export declare function StateGrid({ states, columns, style }: StateGridProps): import("react").JSX.Element;

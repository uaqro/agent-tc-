import type { CSSProperties } from 'react';
export interface PaymentCardProps {
    holder: string;
    last4: string;
    variant?: 'ink' | 'accent' | 'sand' | 'fuel' | 'ev' | 'maintenance' | 'toll';
    frozen?: boolean;
    label?: string;
    icon?: string;
    expires?: string;
    balance?: string;
    hidden?: boolean;
    onToggleHidden?: () => void;
    onClick?: () => void;
    style?: CSSProperties;
}
export declare function PaymentCard({ holder, last4, variant, frozen, label, icon, expires, balance, hidden, onToggleHidden, onClick, style, }: PaymentCardProps): import("react").JSX.Element;

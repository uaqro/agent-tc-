import { type CSSProperties, type ReactNode } from 'react';
import { type TransactionCategory } from '../components/TransactionRow';
export interface SpendLimit {
    label: string;
    current: number;
    max: number;
}
/** Tipo propio de la receta, no las props de TransactionRow: que las filas se
    dibujen con esa pieza es asunto interno (R4). */
export interface CardMovement {
    category?: TransactionCategory;
    title: string;
    subtitle?: string;
    amount?: number;
    pending?: boolean;
}
export interface CardControlsProps {
    /** Estado congelado. Controlado: la receta no lo guarda, lo pide y lo devuelve (cctl-2). */
    frozen?: boolean;
    onFrozenChange?: (frozen: boolean) => void;
    /** Dígitos que NipReveal enseña con temporizador. Sin esto la acción de NIP
        no se dibuja: un control que se ve y no actúa miente más que uno ausente (cctl-1). */
    nip?: string;
    nipWarning?: string;
    /** Límites de gasto. Sin esto la acción de límites no se dibuja (cctl-1). */
    limits?: SpendLimit[];
    movements?: CardMovement[];
    /** Acciones extra del producto, DENTRO de la misma barra (cctl-3): la barra es
        una fila de objetivos de 44px y una acción fuera de ella no se alcanza igual. */
    actions?: ReactNode;
    /** Los cuatro últimos, para que la confirmación de baja pueda nombrar la
        tarjeta (cctl-6). Nunca el PAN (pc-2). */
    last4?: string;
    /** Dar de baja. Controlado como `frozen`: la receta no da de baja, pide la
        confirmación y al confirmar llama. Necesita `last4` para poder nombrarla,
        y sin uno de los dos la acción no se dibuja (cctl-8). */
    onDelete?: () => void;
    style?: CSSProperties;
}
export declare function CardControls({ frozen, onFrozenChange, nip, nipWarning, limits, movements, actions, last4, onDelete, style, }: CardControlsProps): import("react").JSX.Element;

import { type CSSProperties, type ReactNode } from 'react';
export interface FilterDimension {
    id: string;
    label: string;
    options: {
        value: string;
        label: string;
    }[];
    multiple?: boolean;
}
/** Una vista guardada LLEVA sus filtros. `SavedView` solo tiene `{id, name}`,
    y por eso aplicar una vista no aplicaba nada (fst-2). */
export interface FilterView {
    id: string;
    name: string;
    value: Record<string, string[]>;
}
export interface FilterSetProps {
    dimensions: FilterDimension[];
    /** Filtros aplicados por dimensión. Controlado. */
    value?: Record<string, string[]>;
    /** Siembra cuando no está controlado (cst-3). */
    defaultValue?: Record<string, string[]>;
    onChange?: (value: Record<string, string[]>) => void;
    /** Periodo vigente: acompaña los chips; no se borra al limpiar (fst-4). */
    period?: string;
    views?: FilterView[];
    activeViewId?: string | null;
    onViewsChange?: (views: FilterView[]) => void;
    onActiveViewChange?: (id: string | null) => void;
    maxViews?: number;
    /** Lo que la pantalla añade al cinturón: frescura del dato, exportar… */
    trailing?: ReactNode;
    style?: CSSProperties;
}
export declare function FilterSet({ dimensions, value, defaultValue, onChange, period, views, activeViewId, onViewsChange, onActiveViewChange, maxViews, trailing, style, }: FilterSetProps): import("react").JSX.Element;

import { type CSSProperties } from 'react';
import { type StationKind } from '../components/StationRow';
import { type BadgeTone } from '../primitives/Badge';
export interface Station {
    id: string;
    /** Casa con el `value` de un filtro, y es el union que StationRow dibuja: si
        la receta aceptara un string suelto habría que castear al pasarlo, y un
        `as never` es una pregunta sin responder, no una respuesta. */
    kind: StationKind;
    name: string;
    lat: number;
    lon: number;
    /** Lo que el pin canta en el mapa: un precio, una potencia. */
    label?: string;
    icon?: string;
    dist?: string;
    eta?: string;
    open?: string;
    prices?: [string, string][];
    /** La insignia del detalle. No se deriva del filtro: ahí dice «Eléctrico» y
        aquí «Electrolinera», y una receta no inventa el vocabulario de un negocio
        que no conoce. */
    kindLabel?: string;
    tone?: BadgeTone;
    services?: string[];
}
export interface StationFilter {
    value: string;
    label: string;
    icon?: string;
}
export interface StationFinderProps {
    stations: Station[];
    /** Sin filtros la barra no se dibuja: un control que no filtra nada miente. */
    filters?: StationFilter[];
    /** Dónde está quien busca: centro inicial, y adonde vuelve el botón de ubicación. */
    me: [number, number];
    /** La polilínea por estación. Sin la de una estación, su botón de ir no se dibuja. */
    routes?: Record<string, [number, number][]>;
    zoom?: number;
    onStationSelect?: (id: string | null) => void;
    style?: CSSProperties;
}
export declare function StationFinder({ stations, filters, me, routes, zoom, onStationSelect, style, }: StationFinderProps): import("react").JSX.Element;

import type { ReactNode, CSSProperties } from 'react';
export interface BottomSheetProps {
    open: boolean;
    /** @deprecated Alias de `onOpenChange(false)`. Se retira en 4.0 (RFC 0002). */
    onClose?: () => void;
    /** La apertura se reporta al dueño. Convención única del sistema (cst-6). */
    onOpenChange?: (open: boolean) => void;
    title?: string;
    children?: ReactNode;
    height?: string | number;
    fixed?: boolean;
    /** Absorbe FlowFullscreenSheet (1.x): pantalla completa, sin radio superior,
        con cabecera de navegación en vez de asa. */
    fullscreen?: boolean;
    /** Con fullscreen: flecha atrás en la cabecera. Por defecto cae en onClose. */
    onBack?: () => void;
    /** Acciones a la derecha de la cabecera en fullscreen. */
    headerActions?: ReactNode;
    style?: CSSProperties;
}
export declare function BottomSheet({ open, onClose, onOpenChange, title, children, height, fixed, fullscreen, onBack, headerActions, style, }: BottomSheetProps): import("react").JSX.Element;

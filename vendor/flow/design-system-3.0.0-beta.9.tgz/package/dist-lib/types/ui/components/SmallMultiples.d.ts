import { type CSSProperties } from 'react';
export interface SmallMultiplesItem {
    id: string;
    label: string;
    /** smm-1: todas las celdas comparten la misma escala Y — comparar formas
        con escalas distintas es una trampa visual. */
    values: number[];
}
export interface SmallMultiplesProps {
    items: SmallMultiplesItem[];
    layout?: 'grid' | 'rows';
    color?: string;
    height?: number;
    columns?: number;
    isOutlier?: (item: SmallMultiplesItem) => boolean;
    format?: (value: number) => string | number;
    onSelect?: (item: SmallMultiplesItem) => void;
    selectedId?: string;
    style?: CSSProperties;
}
export declare function SmallMultiples({ items, height, color, layout, columns, isOutlier, format, onSelect, selectedId, style, }: SmallMultiplesProps): import("react").JSX.Element;

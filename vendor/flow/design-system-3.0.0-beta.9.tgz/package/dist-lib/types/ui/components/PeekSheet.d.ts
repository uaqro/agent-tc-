import type { CSSProperties, ReactNode } from 'react';
export interface PeekSheetProps {
    title: string;
    children: ReactNode;
    style?: CSSProperties;
}
export declare function PeekSheet({ title, children, style }: PeekSheetProps): import("react").JSX.Element;

import type { CSSProperties, ReactNode } from 'react';
export interface StatTileProps {
    label: string;
    value: string | number;
    delta?: string;
    trend?: number[];
    icon?: string;
    tone?: 'neutral' | 'success' | 'warning' | 'danger';
    /** JUICIO del delta — el color verde/rojo. Sin él, se deriva del signo
        («+» sube = success), que solo vale cuando subir es bueno: en un KPI de
        gasto o consumo, «+330%» pintaba success (cazado en eOne). La flecha
        sigue diciendo la DIRECCIÓN por el signo; esto dice si es buena. */
    deltaTone?: 'success' | 'danger' | 'neutral';
    /** Glifo de tendencia junto al delta. Con `deltaTone` en juego puede
        CONTRADECIR al color — trending_up (culturalmente «mejora») junto a un
        danger rojo manda dos señales opuestas (cazado en eOne: «↗ +325 %» en
        rojo). El signo del texto ya dice la dirección (stt-2); `false` deja
        signo + color, sin glifo que dispute. */
    deltaArrow?: boolean;
    /** Acción de la tarjeta en la esquina del encabezado — un IconButton
        (ajustar, abrir detalle). Nació de eOne: sus objetivos editables
        viven como StatTiles con el engrane a la vista. */
    action?: ReactNode;
    /** stt-8: la cifra SIN su tarjeta, para composiciones que ya tienen
        superficie propia — una fila de cifras dentro de un panel, una ficha
        dentro de una lámina. Sin esto el consumidor tenía dos salidas malas:
        anidar tarjeta dentro de tarjeta, o copiar a mano rótulo+cifra+nota
        (eOne lo hizo cinco veces en su organigrama y otras tantas en la ficha
        de estación, calcando estas mismas declaraciones). Mismo escape que
        `LimitBar.bare`. */
    bare?: boolean;
    description?: string;
    loading?: boolean;
    style?: CSSProperties;
}
export declare function StatTile({ label, value, delta, trend, icon, tone, deltaTone, deltaArrow, action, bare, description, loading, style, }: StatTileProps): import("react").JSX.Element;

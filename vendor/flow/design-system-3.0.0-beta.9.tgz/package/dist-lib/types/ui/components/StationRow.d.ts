import type { CSSProperties } from 'react';
export type StationKind = 'gas' | 'ev' | 'toll' | 'service';
export interface StationRowProps {
    /** Tipo de punto: decide icono y tono. Default 'gas'. */
    kind?: StationKind;
    title: string;
    /** Distancia y tiempo: «1.8 km · 6 min». */
    subtitle?: string;
    /** Precio o cifra destacada. Se pinta en la familia de dato (str-1). */
    value?: string;
    /** Ligadura Material Symbols que sustituye a la del tipo. */
    icon?: string;
    selected?: boolean;
    /** Sin onClick la fila no finge ser interactiva (str-3). */
    onClick?: () => void;
    style?: CSSProperties;
}
export declare function StationRow({ kind, title, subtitle, value, icon, selected, onClick, style }: StationRowProps): import("react").JSX.Element;

import type { CSSProperties, ReactNode } from 'react';
export interface SpecimenProps {
    grid?: boolean;
    centered?: boolean;
    children?: ReactNode;
    style?: CSSProperties;
}
export declare function Specimen({ grid, centered, children, style }: SpecimenProps): import("react").JSX.Element;

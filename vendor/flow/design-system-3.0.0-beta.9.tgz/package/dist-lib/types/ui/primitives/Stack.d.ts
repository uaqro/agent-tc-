import type { CSSProperties, ReactNode } from 'react';
/** Pasos de la escala de espacio. Un número crudo no entra: stk-1. */
export type StackGap = 'inline' | 'stack' | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 10 | 12 | 16;
export interface StackProps {
    /** Eje principal. Default 'row'. */
    direction?: 'row' | 'column';
    /** Paso de la escala de espacio. Sin gap, la pieza no impone separación. */
    gap?: StackGap;
    /** Eje cruzado. */
    align?: 'start' | 'center' | 'end' | 'stretch' | 'baseline';
    /** Eje principal. */
    justify?: 'start' | 'center' | 'end' | 'between';
    /** Permite que los hijos salten de línea. */
    wrap?: boolean;
    /** Elemento renderizado: cambia el rol accesible, nunca el layout (stk-3). */
    as?: 'div' | 'section' | 'nav' | 'ul' | 'ol' | 'li' | 'header' | 'footer';
    children: ReactNode;
    style?: CSSProperties;
}
export declare function Stack({ direction, gap, align, justify, wrap, as: Tag, children, style }: StackProps): import("react").JSX.Element;

import type { CSSProperties, ReactNode } from 'react';
export interface DetailRowProps {
    label: ReactNode;
    value: ReactNode;
    mono?: boolean;
    style?: CSSProperties;
}
export declare function DetailRow({ label, value, mono, style }: DetailRowProps): import("react").JSX.Element;

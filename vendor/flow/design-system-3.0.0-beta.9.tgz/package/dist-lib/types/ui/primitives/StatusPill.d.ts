import type { CSSProperties } from 'react';
export interface StatusPillProps {
    label: string;
    tone?: 'success' | 'warning' | 'danger' | 'info' | 'neutral';
    style?: CSSProperties;
}
export declare function StatusPill({ label, tone, style }: StatusPillProps): import("react").JSX.Element;

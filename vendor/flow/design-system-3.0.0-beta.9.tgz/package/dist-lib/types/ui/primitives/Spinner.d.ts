import type { CSSProperties } from 'react';
export interface SpinnerProps {
    size?: number;
    color?: string;
    label?: string;
    style?: CSSProperties;
}
export declare function Spinner({ size, color, label, style }: SpinnerProps): import("react").JSX.Element;

import type { CSSProperties } from 'react';
export interface SparklineProps {
    values?: number[];
    width?: number;
    height?: number;
    color?: string;
    showDot?: boolean;
    style?: CSSProperties;
}
export declare function Sparkline({ values, width, height, color, showDot, style }: SparklineProps): import("react").JSX.Element | null;

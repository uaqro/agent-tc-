//#region src/ui/components/TopBar.module.css
var e = "w4gM8G_breadcrumbCurrent", t = "w4gM8G_breadcrumbLink", n = "w4gM8G_breadcrumbNav", r = "w4gM8G_breadcrumbSep", i = "w4gM8G_entityBtn", a = "w4gM8G_entityOption", o = "w4gM8G_inner", s = "w4gM8G_logoCenter", c = "w4gM8G_logoWrap", l = "w4gM8G_menuBtn", u = "w4gM8G_navLink", d = "w4gM8G_navWrap", f = "w4gM8G_notifCount", p = "w4gM8G_notifWrap", m = "w4gM8G_root", h = "w4gM8G_spacer", g = "w4gM8G_trailingWrap", _ = "w4gM8G_versionBadge", v = {
	breadcrumbCurrent: e,
	breadcrumbLink: t,
	breadcrumbNav: n,
	breadcrumbSep: r,
	entityBtn: i,
	entityOption: a,
	inner: o,
	logoCenter: s,
	logoWrap: c,
	menuBtn: l,
	navLink: u,
	navWrap: d,
	notifCount: f,
	notifWrap: p,
	root: m,
	spacer: h,
	trailingWrap: g,
	versionBadge: _
};
//#endregion
export { e as breadcrumbCurrent, t as breadcrumbLink, n as breadcrumbNav, r as breadcrumbSep, v as default, i as entityBtn, a as entityOption, o as inner, s as logoCenter, c as logoWrap, l as menuBtn, u as navLink, d as navWrap, f as notifCount, p as notifWrap, m as root, h as spacer, g as trailingWrap, _ as versionBadge };

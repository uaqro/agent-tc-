"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { useRovingTabs as t } from "../../hooks/useRovingTabs.js";
import n from "./CardCarousel.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
import { Children as a, useCallback as o, useEffect as s, useRef as c, useState as l } from "react";
//#region src/ui/components/CardCarousel.tsx
function u({ children: u, activeIndex: d, onChange: f, style: p }) {
	let m = e(), h = a.toArray(u), [g, _] = l(0), v = d ?? g, y = c(null), b = c(!1), x = o((e) => {
		_(e), f?.(e);
	}, [f]), { alTeclado: S, pestana: C } = t(h.map((e, t) => String(t)), String(v), (e) => x(Number(e)));
	s(() => {
		let e = y.current;
		if (!e) return;
		let t = e.children[v];
		if (!t) return;
		b.current = !0;
		let n = t.offsetLeft - (e.clientWidth - t.offsetWidth) / 2;
		e.scrollTo?.({
			left: n,
			behavior: "smooth"
		});
		let r = setTimeout(() => {
			b.current = !1;
		}, 350);
		return () => clearTimeout(r);
	}, [v]);
	let w = o(() => {
		if (b.current) return;
		let e = y.current;
		if (!e) return;
		let t = e.scrollLeft + e.clientWidth / 2, n = 0, r = Infinity;
		for (let i = 0; i < e.children.length; i++) {
			let a = e.children[i], o = a.offsetLeft + a.offsetWidth / 2, s = Math.abs(t - o);
			s < r && (r = s, n = i);
		}
		n !== v && x(n);
	}, [v, x]);
	return /* @__PURE__ */ i("div", {
		className: n.root,
		style: p,
		children: [/* @__PURE__ */ r("div", {
			ref: y,
			className: n.track,
			onScroll: w,
			children: h.map((e, t) => /* @__PURE__ */ r("div", {
				className: n.slide,
				"data-active": t === v || void 0,
				children: e
			}, t))
		}), h.length > 1 && /* @__PURE__ */ r("div", {
			className: n.dots,
			role: "tablist",
			onKeyDown: S,
			children: h.map((e, t) => /* @__PURE__ */ r("button", {
				...C(String(t)),
				type: "button",
				"data-bare": "",
				className: n.dot,
				"data-active": t === v || void 0,
				role: "tab",
				"aria-selected": t === v,
				"aria-label": m("carousel.card", "Tarjeta {n}", { n: t + 1 }),
				onClick: () => x(t)
			}, t))
		})]
	});
}
//#endregion
export { u as CardCarousel };

//#region src/ui/components/MapCanvas.module.css
var e = "AfLFwa_canvas", t = "AfLFwa_controls", n = "AfLFwa_pinLayer", r = "AfLFwa_pinTarget", i = "AfLFwa_root", a = {
	canvas: e,
	controls: t,
	pinLayer: n,
	pinTarget: r,
	root: i
};
//#endregion
export { e as canvas, t as controls, a as default, n as pinLayer, r as pinTarget, i as root };

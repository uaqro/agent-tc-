"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { leerFuenteSimbolos as t, leerToken as n } from "../../tokens/leerToken.js";
import { IconButton as r } from "../primitives/IconButton.js";
import i from "./MapCanvas.module.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
import { useCallback as s, useEffect as c, useMemo as l, useRef as u, useState as d } from "react";
//#region src/ui/components/MapCanvas.tsx
function f(e) {
	return !e || e.length === 0 ? [] : Array.isArray(e[0][0]) ? e : [e];
}
var p = 256;
function m(e, t) {
	return (e + 180) / 360 * 2 ** t;
}
function h(e, t) {
	let n = e * Math.PI / 180;
	return (1 - Math.log(Math.tan(n) + 1 / Math.cos(n)) / Math.PI) / 2 * 2 ** t;
}
function g(e, t) {
	for (; e.size > t;) {
		let t = e.keys().next().value;
		if (t === void 0) break;
		e.delete(t);
	}
	return e;
}
function _(e, t) {
	let n = e.get(t);
	if (n !== void 0) return e.delete(t), e.set(t, n), n;
}
function v(e, t) {
	return e / 2 ** t * 360 - 180;
}
function y(e, t) {
	let n = Math.PI - 2 * Math.PI * e / 2 ** t;
	return 180 / Math.PI * Math.atan(.5 * (Math.exp(n) - Math.exp(-n)));
}
function b(e) {
	return /^var\(/.test(e) && n(e.slice(4, -1)) || e;
}
var x = {
	scale: 1,
	shadowBlur: 4,
	shadowY: 1,
	glowAlpha: 0
}, S = {
	scale: 1.08,
	shadowBlur: 14,
	shadowY: 4,
	glowAlpha: .12
}, C = {
	scale: 1.18,
	shadowBlur: 22,
	shadowY: 6,
	glowAlpha: .25
}, w = 24, T = 20, E = 28, ee = 3.5, D = 10, O = .14, k = .01;
function A(e, t) {
	let n = t - e;
	return Math.abs(n) < k ? t : e + n * O;
}
function te(e, t) {
	let n = {
		scale: A(e.scale, t.scale),
		shadowBlur: A(e.shadowBlur, t.shadowBlur),
		shadowY: A(e.shadowY, t.shadowY),
		glowAlpha: A(e.glowAlpha, t.glowAlpha)
	};
	return {
		val: n,
		done: n.scale === t.scale && n.shadowBlur === t.shadowBlur && n.shadowY === t.shadowY && n.glowAlpha === t.glowAlpha
	};
}
function ne(e, t) {
	let n = [];
	for (let r of e) {
		if (r.size != null) {
			n.push([r]);
			continue;
		}
		let e = n.find((e) => e[0].size == null && e.some((e) => Math.hypot((m(e.lon, t) - m(r.lon, t)) * p, (h(e.lat, t) - h(r.lat, t)) * p) < 48));
		e ? e.push(r) : n.push([r]);
	}
	return n;
}
function re() {
	let [e, t] = d(() => typeof document > "u" ? "" : document.documentElement.dataset.mode ?? "");
	return c(() => {
		let e = new MutationObserver(() => t(document.documentElement.dataset.mode ?? ""));
		return e.observe(document.documentElement, {
			attributes: !0,
			attributeFilter: ["data-mode"]
		}), () => e.disconnect();
	}, []), e;
}
function j({ surface: O = "card", center: k, zoom: A = 13, pins: j = [], cluster: ie = !1, selectedPin: M, onPinClick: ae, route: oe, routeColor: N, fitBounds: P, style: se, tone: ce = "mono", tileUrl: le = "https://tile.openstreetmap.org/{z}/{x}/{y}.png", attribution: ue = "© OpenStreetMap contributors", onViewportChange: F, tileCacheMax: de = 256 }) {
	let I = e(), fe = re(), L = u(null), R = u(null), [z, pe] = d({
		w: 600,
		h: 400
	}), [B, V] = d(A), me = l(() => ie ? ne(j, B) : j.map((e) => [e]), [
		j,
		ie,
		B
	]), H = l(() => me.map((e) => e.length === 1 ? e[0] : {
		id: `cluster:${e.map((e) => e.id).join(",")}`,
		lat: e.reduce((e, t) => e + t.lat, 0) / e.length,
		lon: e.reduce((e, t) => e + t.lon, 0) / e.length,
		label: I("map.cluster", "{n} puntos · acercar para explorar", { n: e.length }),
		details: e.map((e) => e.label || e.id)
	}), [me, I]), [U, he] = d({
		x: 0,
		y: 0
	}), [ge, _e] = d(!1), [W, G] = d(null), K = u(null), q = u({
		x: 0,
		y: 0
	}), J = s((e) => {
		q.current = e, he(e);
	}, []), ve = u(/* @__PURE__ */ new Map()), Y = u(/* @__PURE__ */ new Map()), ye = u(0), X = u(void 0);
	c(() => {
		let e = R.current;
		if (!e || typeof ResizeObserver > "u") return;
		let t = new ResizeObserver((e) => {
			let { width: t, height: n } = e[0].contentRect;
			pe({
				w: Math.round(t),
				h: Math.round(n)
			});
		});
		return t.observe(e), () => t.disconnect();
	}, []);
	let Z = m(k[1], B) * p + U.x, Q = h(k[0], B) * p + U.y, be = `${k[0]},${k[1]}`;
	c(() => {
		J({
			x: 0,
			y: 0
		});
	}, [be, J]);
	let xe = u(z);
	xe.current = z;
	let Se = (() => {
		if (!P || P.length === 0) return "";
		let e = Infinity, t = -Infinity, n = Infinity, r = -Infinity;
		for (let [i, a] of P) i < e && (e = i), i > t && (t = i), a < n && (n = a), a > r && (r = a);
		return `${P.length}|${e.toFixed(4)},${n.toFixed(4)},${t.toFixed(4)},${r.toFixed(4)}`;
	})(), Ce = u(P);
	Ce.current = P;
	let we = u(k);
	we.current = k;
	let Te = s(() => {
		let e = Ce.current;
		if (!e || e.length === 0) {
			let e = {
				x: 0,
				y: 0
			};
			return V(A), J(e), {
				z: A,
				off: e
			};
		}
		let t = Infinity, n = -Infinity, r = Infinity, i = -Infinity;
		for (let [a, o] of e) a < t && (t = a), a > n && (n = a), o < r && (r = o), o > i && (i = o);
		let { w: a, h: o } = xe.current, s = 18;
		for (; s > 2; s--) {
			let e = (m(i, s) - m(r, s)) * p, c = (h(t, s) - h(n, s)) * p;
			if (e <= a - 96 && c <= o - 96) break;
		}
		let c = (t + n) / 2, l = (r + i) / 2, [u, d] = we.current;
		V(s);
		let f = {
			x: (m(l, s) - m(d, s)) * p,
			y: (h(c, s) - h(u, s)) * p
		};
		return J(f), {
			z: s,
			off: f
		};
	}, [A]);
	c(() => {
		Se && Te();
	}, [Se]);
	let Ee = s((e, t) => {
		let n = ve.current, r = _(n, e);
		if (r) return r.complete ? r : null;
		let i = new Image();
		return i.crossOrigin = "anonymous", i.src = t, i.onload = () => X.current?.(), n.set(e, i), g(n, de), null;
	}, [de]);
	c(() => {
		let e = !0, r = R.current ? t(R.current) : "", i = !1, a = `${T}px ${r}`;
		r && document.fonts && (i = document.fonts.check(a), document.fonts.load(a).then(() => {
			e && (i = !0, X.current?.());
		}).catch(() => {}));
		let o = () => {
			let e = L.current;
			if (!e) return;
			let t = e.getContext("2d");
			if (!t) return;
			let a = window.devicePixelRatio || 1;
			e.width = z.w * a, e.height = z.h * a, t.scale(a, a);
			let o = z.w / 2 - Z, s = z.h / 2 - Q, c = document.documentElement.dataset.mode === "dark", l = 2 ** B, u = Math.max(0, Math.floor(-o / p)), d = Math.min(l - 1, Math.floor((-o + z.w) / p)), g = Math.max(0, Math.floor(-s / p)), _ = Math.min(l - 1, Math.floor((-s + z.h) / p));
			t.fillStyle = n("--surface-canvas"), t.fillRect(0, 0, z.w, z.h);
			let v = le;
			t.filter = {
				mono: c ? "grayscale(1) invert(1) brightness(0.85) contrast(0.95)" : "grayscale(1) contrast(0.95) brightness(1.03)",
				color: c ? "invert(1) hue-rotate(180deg) brightness(0.92) contrast(0.9)" : "none"
			}[ce];
			for (let e = u; e <= d; e++) for (let n = g; n <= _; n++) {
				let r = `osm/${B}/${e}/${n}`, i = v.replace("{z}", String(B)).replace("{x}", String(e)).replace("{y}", String(n)), a = Ee(r, i);
				a && t.drawImage(a, o + e * p, s + n * p, p, p);
			}
			t.filter = "none";
			let y = n("--surface-card"), S = n("--text-primary");
			n("--border-subtle");
			let C = n("--viz-accent"), E = n("--viz-1"), O = n("--font-body");
			n("--font-mono");
			let k = f(oe);
			for (let e of k) e.length < 2 || (t.beginPath(), e.forEach(([e, n], r) => {
				let i = o + m(n, B) * p, a = s + h(e, B) * p;
				r === 0 ? t.moveTo(i, a) : t.lineTo(i, a);
			}), t.strokeStyle = N ? b(N) : E, t.lineWidth = 4, t.lineJoin = "round", t.lineCap = "round", t.stroke(), t.setLineDash([8, 6]), t.strokeStyle = n("--map-route"), t.lineWidth = 4, t.stroke(), t.setLineDash([]));
			let A = (e, a, o, s) => {
				if (!e.label) return;
				let c = parseFloat(n("--space-2")), l = o - s - c, u = e.details ?? (e.subtitle ? [e.subtitle] : []), d = n("--surface-inverse"), f = n("--text-on-inverse"), p = n("--type-body-md-medium"), m = n("--type-body-sm");
				t.font = p;
				let h = e.icon && i ? parseFloat(n("--icon-lg")) + c : 0, g = t.measureText(e.label).width + h;
				t.font = m;
				for (let e of u) g = Math.max(g, t.measureText(e).width);
				let _ = parseFloat(n("--space-4")), v = parseFloat(n("--space-3")), y = parseFloat(n("--icon-lg")), b = parseFloat(n("--icon-lg")), x = g + _ * 2, S = v * 2 + y + u.length * b + (u.length > 0 ? 3 : 0), C = parseFloat(n("--radius-sm")), w = Math.max(c, Math.min(z.w - x - c, a - x / 2)), T = Math.max(c, l - S);
				t.save(), t.shadowColor = n("--map-pin-shadow"), t.shadowBlur = 16, t.shadowOffsetY = 4, t.fillStyle = d, t.beginPath(), t.roundRect(w, T, x, S, C), t.fill(), t.beginPath(), t.moveTo(a - 5, T + S), t.lineTo(a, T + S + 5), t.lineTo(a + 5, T + S), t.fill(), t.restore(), t.textAlign = "left", t.textBaseline = "middle", t.font = p, t.fillStyle = f, t.fillText(e.label, w + _ + h, T + v + y / 2), h && e.icon && (t.font = `${parseFloat(n("--icon-lg"))}px ${r}`, t.fillText(e.icon, w + _, T + v + y / 2)), t.font = m, t.globalAlpha = .72, u.forEach((e, n) => {
					t.fillText(e, w + _, T + v + y + 3 + b * n + b / 2);
				}), t.globalAlpha = 1;
			};
			[...H].sort((e, t) => (e.id === M ? 2 : +(e.id === W)) - (t.id === M ? 2 : +(t.id === W))).forEach((e) => {
				let a = o + m(e.lon, B) * p, c = s + h(e.lat, B) * p, l = M === e.id, u = b(e.color || (l ? C : E)), d = Y.current.get(e.id) || { ...x };
				if (e.size != null) {
					let o = l || W === e.id, s = o ? e.size * 1.8 : e.size;
					t.save(), t.beginPath(), t.arc(a, c, s, 0, Math.PI * 2), t.fillStyle = u, t.globalAlpha = .88, t.fill(), t.globalAlpha = 1, t.lineWidth = o ? 2 : 1, t.strokeStyle = o ? S : y, t.stroke(), e.icon && i && (t.font = `${Math.round(s * 1.35)}px ${r}`, t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = n("--text-on-accent"), t.fillText(e.icon, a, c)), t.restore(), e.label && (l || W === e.id) && A(e, a, c, s + 2);
					return;
				}
				let f = w * d.scale, g = c - D * d.scale - f, _ = (e) => {
					t.beginPath(), t.arc(a, g, e, Math.PI * .65, Math.PI * .35, !1), t.lineTo(a, c), t.closePath();
				};
				if (t.save(), d.glowAlpha > .005) {
					t.beginPath(), t.arc(a, g, f + 10, 0, Math.PI * 2);
					let e = Math.round(d.glowAlpha * 255).toString(16).padStart(2, "0");
					t.fillStyle = u + e, t.fill();
				}
				if (t.shadowColor = n("--map-pin-shadow"), t.shadowBlur = d.shadowBlur, t.shadowOffsetY = d.shadowY, _(f), t.fillStyle = u, t.fill(), t.shadowColor = "transparent", t.shadowBlur = 0, t.shadowOffsetY = 0, t.strokeStyle = y, t.lineWidth = ee, t.stroke(), e.id.startsWith("cluster:") && (t.font = n("--type-data-md"), t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = n("--text-on-accent"), t.fillText(String(e.details?.length || 0), a, g)), e.icon && i) {
					let i = Math.round(T * d.scale);
					t.font = `${i}px ${r}`, t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = n("--text-on-accent"), t.fillText(e.icon, a, g);
				}
				t.restore(), e.label && (l || W === e.id) && A(e, a, c, D + f * 2 + ee);
			}), t.font = `500 9px ${O}`, t.fillStyle = n("--map-attribution"), t.textAlign = "right", t.fillText(ue, z.w - 6, z.h - 6);
		};
		X.current = o;
		let s = new Set(H.map((e) => e.id));
		for (let e of Y.current.keys()) s.has(e) || Y.current.delete(e);
		let c = () => {
			if (!e) return;
			let t = !1;
			H.forEach((e) => {
				let n = M === e.id, r = W === e.id, i = n ? C : r ? S : x, { val: a, done: o } = te(Y.current.get(e.id) || { ...x }, i);
				Y.current.set(e.id, a), o || (t = !0);
			}), o(), t && (ye.current = requestAnimationFrame(c));
		};
		return c(), () => {
			e = !1, cancelAnimationFrame(ye.current);
		};
	}, [
		Z,
		Q,
		B,
		z,
		H,
		M,
		W,
		oe,
		N,
		Ee,
		fe,
		ce
	]);
	let De = (e) => {
		let t = Math.max(2, Math.min(18, e));
		if (t === B) return;
		let n = 2 ** (t - B), r = {
			x: q.current.x * n,
			y: q.current.y * n
		};
		J(r), V(t), $(t, r);
	}, Oe = (e) => {
		e.preventDefault(), De(B + (e.deltaY < 0 ? 1 : -1));
	}, ke = (e) => {
		K.current = {
			sx: e.clientX,
			sy: e.clientY,
			ox: U.x,
			oy: U.y
		}, _e(!0), e.currentTarget.setPointerCapture?.(e.pointerId), L.current && (L.current.style.cursor = "");
	}, Ae = (e) => {
		if (K.current) {
			let t = {
				x: K.current.ox + (e.clientX - K.current.sx),
				y: K.current.oy + (e.clientY - K.current.sy)
			};
			J(t);
			return;
		}
		let t = L.current;
		if (!t || j.length === 0) {
			W && G(null);
			return;
		}
		let n = t.getBoundingClientRect(), r = e.clientX - n.left, i = e.clientY - n.top, a = z.w / 2 - Z, o = z.h / 2 - Q, s = null, c = E;
		for (let e of H) {
			let t = a + m(e.lon, B) * p, n = o + h(e.lat, B) * p - (e.size == null ? 34 : 0), l = Math.hypot(r - t, i - n);
			l < c && (c = l, s = e.id);
		}
		s !== W && G(s), t.style.cursor = s ? "pointer" : "";
	}, $ = s((e, t) => {
		if (!F) return;
		let n = m(k[1], e) * p - t.x;
		F({
			center: [y((h(k[0], e) * p - t.y) / p, e), v(n / p, e)],
			zoom: e
		});
	}, [F, k]), je = () => {
		K.current = null, _e(!1), $(B, q.current);
	}, Me = () => {
		W && G(null);
	}, Ne = (e) => {
		if (!e.id.startsWith("cluster:")) {
			ae?.(e.id);
			return;
		}
		let t = Math.min(18, B + 1), n = {
			x: (m(e.lon, t) - m(k[1], t)) * p,
			y: (h(e.lat, t) - h(k[0], t)) * p
		};
		J(n), V(t), G(null), F?.({
			center: [e.lat, e.lon],
			zoom: t
		});
	};
	return /* @__PURE__ */ o("div", {
		ref: R,
		className: i.root,
		"data-surface": O,
		"data-dragging": ge || void 0,
		style: se,
		children: [
			/* @__PURE__ */ a("canvas", {
				ref: L,
				className: i.canvas,
				onWheel: Oe,
				onPointerDown: ke,
				onPointerMove: Ae,
				onPointerUp: je,
				onPointerCancel: je,
				onPointerLeave: Me,
				onClick: (e) => {
					if (H.length === 0) return;
					let t = L.current;
					if (!t) return;
					let n = t.getBoundingClientRect(), r = e.clientX - n.left, i = e.clientY - n.top, a = z.w / 2 - Z, o = z.h / 2 - Q, s = null, c = E;
					for (let e of H) {
						let t = a + m(e.lon, B) * p, n = o + h(e.lat, B) * p - (e.size == null ? 34 : 0), l = Math.hypot(r - t, i - n);
						l < c && (c = l, s = e);
					}
					s && Ne(s);
				}
			}),
			H.some((e) => e.size == null) && /* @__PURE__ */ a("div", {
				className: i.pinLayer,
				"aria-label": I("map.pins", "Puntos en el mapa"),
				role: "group",
				children: H.filter((e) => e.size == null).map((e) => {
					let t = z.w / 2 - Z + m(e.lon, B) * p, n = z.h / 2 - Q + h(e.lat, B) * p;
					return t < -22 || n < -22 || t > z.w + 22 || n > z.h + 22 ? null : /* @__PURE__ */ a("button", {
						type: "button",
						"data-bare": "",
						className: i.pinTarget,
						style: {
							left: t,
							top: n - D - w
						},
						"aria-label": `${e.label ?? e.id}${e.subtitle ? `, ${e.subtitle}` : ""}`,
						"aria-pressed": M == null ? void 0 : e.id === M,
						onClick: () => Ne(e),
						onFocus: () => G(e.id),
						onBlur: () => G((t) => t === e.id ? null : t)
					}, e.id);
				})
			}),
			/* @__PURE__ */ o("div", {
				className: i.controls,
				children: [
					/* @__PURE__ */ a(r, {
						variant: "secondary",
						icon: "add",
						ariaLabel: I("map.zoomIn", "Acercar"),
						onClick: () => De(B + 1)
					}),
					/* @__PURE__ */ a(r, {
						variant: "secondary",
						icon: "remove",
						ariaLabel: I("map.zoomOut", "Alejar"),
						onClick: () => De(B - 1)
					}),
					/* @__PURE__ */ a(r, {
						variant: "secondary",
						icon: "recenter",
						ariaLabel: I("map.recenter", "Centrar el mapa"),
						onClick: () => {
							let { z: e, off: t } = Te();
							$(e, t);
						}
					})
				]
			})
		]
	});
}
//#endregion
export { j as MapCanvas, ne as agruparPins, g as podarCache, _ as tocarCache };

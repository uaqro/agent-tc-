import e from "./DetailRow.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/primitives/DetailRow.tsx
function r({ label: r, value: i, mono: a, style: o }) {
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: o,
		children: [/* @__PURE__ */ t("span", {
			className: e.label,
			children: r
		}), /* @__PURE__ */ t("span", {
			className: e.value,
			"data-mono": a || void 0,
			children: i
		})]
	});
}
//#endregion
export { r as DetailRow };

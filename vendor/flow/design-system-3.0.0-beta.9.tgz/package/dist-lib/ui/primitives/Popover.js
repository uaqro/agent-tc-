"use client";
import "./avisoControlado.js";
import e from "./Popover.module.js";
import { Fragment as t, jsx as n, jsxs as r } from "react/jsx-runtime";
import { useCallback as i, useEffect as a, useLayoutEffect as o, useRef as s, useState as c } from "react";
import { createPortal as l } from "react-dom";
//#region src/ui/primitives/Popover.tsx
function u(e) {
	let [t, n] = e.split("-");
	return [t, n ?? (t === "top" || t === "bottom" ? "start" : "center")];
}
var d = 8, f = {
	top: "bottom",
	bottom: "top",
	left: "right",
	right: "left"
};
function p({ trigger: p, fillTrigger: m, selfAlign: h, align: g, placement: _, offset: v = 6, anchorRef: y, matchAnchorWidth: b = !1, minWidth: x, surface: S = "card", layer: C = "popover", interactive: w = !0, returnFocusRef: T, children: E, open: D, onOpenChange: O }) {
	let [k, A] = c(!1), j = D === void 0 ? k : D, M = D === void 0 ? A : O, N = s(null), P = s(null), [F, I] = c(null), [L, R] = c(null), [z, B] = c(null), [V, H] = u(_ ?? (g === "right" ? "bottom-end" : "bottom-start")), U = i(() => {
		M?.(!1), w && (T?.current ?? N.current?.querySelector("button, [tabindex], input, a"))?.focus();
	}, [
		M,
		T,
		w
	]);
	a(() => {
		if (!j) return;
		let e = () => {
			let e = y?.current ?? N.current;
			e && I(e.getBoundingClientRect());
		};
		return e(), window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0), I(null), R(null), B(null);
		};
	}, [j, y]), a(() => {
		if (!j || !w) return;
		let e = (e) => {
			N.current?.contains(e.target) || P.current?.contains(e.target) || y?.current?.contains(e.target) || U();
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, [
		j,
		U,
		y,
		w
	]), a(() => {
		if (!j) return;
		let e = (e) => {
			e.key === "Escape" && !e.defaultPrevented && (e.preventDefault(), U());
		};
		return document.addEventListener("keydown", e, !0), () => document.removeEventListener("keydown", e, !0);
	}, [j, U]), o(() => {
		if (!j || !F || !P.current) return;
		let e = P.current.offsetWidth, t = P.current.offsetHeight, n = window.innerWidth, r = window.innerHeight, i = {
			top: F.top - v,
			bottom: r - F.bottom - v,
			left: F.left - v,
			right: n - F.right - v
		}, a = (n) => (n === "top" || n === "bottom" ? t : e) <= i[n], o = V;
		!a(o) && i[f[o]] > i[o] && (o = f[o]);
		let s = { position: "fixed" };
		if (o === "bottom" && (s.top = F.bottom + v), o === "top" && (s.bottom = r - F.top + v), o === "left" && (s.right = n - F.left + v), o === "right" && (s.left = F.right + v), a(o) || (o === "top" || o === "bottom" ? (s.maxHeight = Math.max(0, i[o]), s.overflowY = "auto") : (s.maxWidth = Math.max(0, i[o]), s.overflowX = "auto")), o === "top" || o === "bottom") {
			let t = H === "start" ? F.left : H === "end" ? F.right - e : F.left + F.width / 2 - e / 2;
			s.left = Math.min(Math.max(t, d), Math.max(d, n - e - d));
		} else {
			let e = H === "start" ? F.top : H === "end" ? F.bottom - t : F.top + F.height / 2 - t / 2;
			s.top = Math.min(Math.max(e, d), Math.max(d, r - t - d));
		}
		b && (s.width = F.width), x !== void 0 && (s.minWidth = x), R(s), B(o);
	}, [
		j,
		F,
		V,
		H,
		v,
		b,
		x
	]);
	let W = L ?? {
		position: "fixed",
		top: 0,
		left: 0,
		visibility: "hidden",
		...x === void 0 ? {} : { minWidth: x },
		...b && F ? { width: F.width } : {}
	}, G = j && typeof document < "u" ? l(/* @__PURE__ */ n("div", {
		ref: P,
		className: e.drop,
		"data-side": z ?? V,
		"data-cross": H,
		"data-surface": S,
		"data-layer": C,
		"data-interactive": w || void 0,
		style: W,
		children: typeof E == "function" ? E({ close: U }) : E
	}), document.body) : null;
	return p ? /* @__PURE__ */ r("div", {
		className: e.root,
		"data-fill": m || void 0,
		style: h ? { alignSelf: h } : void 0,
		children: [/* @__PURE__ */ n("span", {
			ref: N,
			className: e.trigger,
			"data-fill": m || void 0,
			onClick: () => M?.(!j),
			children: p
		}), G]
	}) : /* @__PURE__ */ n(t, { children: G });
}
//#endregion
export { p as Popover };

//#region src/ui/primitives/FlowChart.module.css
var e = "SxBAxq_empty", t = "SxBAxq_emptyIcon", n = "SxBAxq_emptyInner", r = "SxBAxq_tipHeading", i = "SxBAxq_tipIcon", a = "SxBAxq_tipLabel", o = "SxBAxq_tipNumber", s = "SxBAxq_tipRow", c = {
	empty: e,
	emptyIcon: t,
	emptyInner: n,
	tipHeading: r,
	tipIcon: i,
	tipLabel: a,
	tipNumber: o,
	tipRow: s
};
//#endregion
export { c as default, e as empty, t as emptyIcon, n as emptyInner, r as tipHeading, i as tipIcon, a as tipLabel, o as tipNumber, s as tipRow };

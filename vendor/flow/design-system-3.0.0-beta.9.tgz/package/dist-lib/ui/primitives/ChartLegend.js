import { capasDeTrama as e, capasDeTrazo as t, tramaDeSerie as n, trazoDeSerie as r } from "../../dataviz/marcas.js";
import { leerToken as i } from "../../tokens/leerToken.js";
import a from "./ChartLegend.module.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
//#region src/ui/primitives/ChartLegend.tsx
function c({ items: c, marks: l, size: u = "sm", width: d = "content", direction: f = "horizontal", style: p }) {
	let m = i("--ref-alpha-black-20");
	return /* @__PURE__ */ o("div", {
		className: a.root,
		"data-direction": f,
		"data-size": u,
		"data-width": d,
		style: p,
		children: c.map((i, u) => /* @__PURE__ */ s("span", {
			className: a.item,
			children: [
				i.icon && /* @__PURE__ */ o("span", {
					className: `flow-symbol ${a.icon}`,
					"aria-hidden": "true",
					style: { color: i.color },
					children: i.icon
				}),
				(!i.icon || l) && /* @__PURE__ */ o("span", {
					className: a.swatch,
					"aria-hidden": "true",
					"data-shape": l === "line" ? "line" : i.shape || void 0,
					"data-marcado": l || void 0,
					style: {
						backgroundColor: l === "line" ? void 0 : i.color,
						...l === "line" ? t(r(u, c.length), i.color) : l === "fill" ? e(n(u, c.length), m) : {}
					}
				}),
				/* @__PURE__ */ s("span", {
					className: a.labelGroup,
					children: [/* @__PURE__ */ o("span", {
						"data-truncate": "",
						className: a.label,
						children: i.label
					}), i.detail && /* @__PURE__ */ o("span", {
						className: a.detail,
						children: i.detail
					})]
				}),
				i.value && /* @__PURE__ */ o("span", {
					className: a.value,
					children: i.value
				})
			]
		}, i.label))
	});
}
//#endregion
export { c as ChartLegend };

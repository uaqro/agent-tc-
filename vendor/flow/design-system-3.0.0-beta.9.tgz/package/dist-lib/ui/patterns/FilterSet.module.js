//#region src/ui/patterns/FilterSet.module.css
var e = "tCIaia_actions", t = "tCIaia_root", n = "tCIaia_toolbar", r = {
	actions: e,
	"flow-filter-set": "tCIaia_flow-filter-set",
	root: t,
	toolbar: n
};
//#endregion
export { e as actions, r as default, t as root, n as toolbar };

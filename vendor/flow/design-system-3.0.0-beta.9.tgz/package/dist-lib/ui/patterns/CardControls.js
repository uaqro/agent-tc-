"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Button as t } from "../primitives/Button.js";
import { LimitBar as n } from "../primitives/LimitBar.js";
import { SectionHeader as r } from "../primitives/SectionHeader.js";
import { SheetBody as i } from "../primitives/SheetBody.js";
import { BottomSheet as a } from "../components/BottomSheet.js";
import { QuickAction as o } from "../components/QuickAction.js";
import { QuickActionBar as s } from "../components/QuickActionBar.js";
import { TransactionRow as c } from "../components/TransactionRow.js";
import { NipReveal as l } from "../components/NipReveal.js";
import u from "./CardControls.module.js";
import { jsx as d, jsxs as f } from "react/jsx-runtime";
import { useState as p } from "react";
//#region src/ui/patterns/CardControls.tsx
function m({ frozen: m = !1, onFrozenChange: h, nip: g, nipWarning: _, limits: v, movements: y, actions: b, last4: x, onDelete: S, style: C }) {
	let w = e(), [T, E] = p(!1), [D, O] = p(!1), [k, A] = p(!1);
	return /* @__PURE__ */ f("div", {
		className: u.root,
		style: C,
		children: [
			/* @__PURE__ */ f(s, { children: [
				/* @__PURE__ */ d(o, {
					icon: "ac_unit",
					label: m ? w("cardControls.unfreeze", "Descongelar") : w("cardControls.freeze", "Congelar"),
					active: m,
					onClick: () => h?.(!m)
				}),
				g && /* @__PURE__ */ d(o, {
					icon: "pin",
					label: w("cardControls.nip", "Ver NIP"),
					onClick: () => E(!0)
				}),
				v && v.length > 0 && /* @__PURE__ */ d(o, {
					icon: "speed",
					label: w("cardControls.limits", "Límites"),
					onClick: () => O(!0)
				}),
				b
			] }),
			y && y.length > 0 && /* @__PURE__ */ f("div", {
				className: u.movements,
				children: [/* @__PURE__ */ d(r, {
					size: "sm",
					children: w("cardControls.movements", "Movimientos de esta tarjeta")
				}), y.map((e, t) => /* @__PURE__ */ d(c, {
					category: e.category,
					title: e.title,
					subtitle: e.subtitle,
					amount: e.amount,
					status: e.pending ? "pending" : void 0
				}, t))]
			}),
			S && x && /* @__PURE__ */ d("div", {
				className: u.danger,
				children: /* @__PURE__ */ d(t, {
					variant: "danger",
					size: "lg",
					fullWidth: !0,
					onClick: () => A(!0),
					children: w("cardControls.delete", "Dar de baja esta tarjeta")
				})
			}),
			g && /* @__PURE__ */ d(a, {
				open: T,
				onOpenChange: E,
				title: w("cardControls.nipSheet", "NIP de la tarjeta"),
				fixed: !1,
				children: /* @__PURE__ */ d(l, {
					digits: g,
					warning: _
				})
			}),
			v && v.length > 0 && /* @__PURE__ */ d(a, {
				open: D,
				onOpenChange: O,
				title: w("cardControls.limitsSheet", "Límites de gasto"),
				fixed: !1,
				children: /* @__PURE__ */ f(i, { children: [v.map((e) => /* @__PURE__ */ d(n, {
					label: e.label,
					current: e.current,
					max: e.max
				}, e.label)), /* @__PURE__ */ d("div", {
					className: u.sheetAction,
					children: /* @__PURE__ */ d(t, {
						variant: "primary",
						size: "lg",
						fullWidth: !0,
						onClick: () => O(!1),
						children: w("cardControls.close", "Cerrar")
					})
				})] })
			}),
			S && x && /* @__PURE__ */ d(a, {
				open: k,
				onOpenChange: A,
				title: w("cardControls.deleteSheet", "Dar de baja la tarjeta"),
				fixed: !1,
				children: /* @__PURE__ */ f(i, { children: [
					/* @__PURE__ */ d("p", {
						className: u.dangerLead,
						children: w("cardControls.deleteLead", "La tarjeta ·{last4} se da de baja y no se puede recuperar.", { last4: x })
					}),
					/* @__PURE__ */ d("p", {
						className: u.dangerNote,
						children: w("cardControls.deleteKeepsHistory", "Sus movimientos se quedan en tu actividad: lo que desaparece es la tarjeta.")
					}),
					/* @__PURE__ */ f("div", {
						className: u.sheetAction,
						children: [/* @__PURE__ */ d(t, {
							variant: "danger",
							size: "lg",
							fullWidth: !0,
							onClick: () => {
								A(!1), S?.();
							},
							children: w("cardControls.deleteConfirm", "Dar de baja")
						}), /* @__PURE__ */ d(t, {
							variant: "ghost",
							size: "lg",
							fullWidth: !0,
							onClick: () => A(!1),
							children: w("cardControls.deleteCancel", "Conservarla")
						})]
					})
				] })
			})
		]
	});
}
//#endregion
export { m as CardControls };

//#region src/ui/patterns/TransactionGroup.module.css
var e = "Gz7oqq_label", t = "Gz7oqq_root", n = {
	label: e,
	root: t
};
//#endregion
export { n as default, e as label, t as root };

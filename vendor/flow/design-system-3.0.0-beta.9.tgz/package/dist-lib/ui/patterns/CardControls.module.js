//#region src/ui/patterns/CardControls.module.css
var e = "_9NXYXW_danger", t = "_9NXYXW_dangerLead", n = "_9NXYXW_dangerNote", r = "_9NXYXW_movements", i = "_9NXYXW_root", a = "_9NXYXW_sheetAction", o = {
	danger: e,
	dangerLead: t,
	dangerNote: n,
	movements: r,
	root: i,
	sheetAction: a
};
//#endregion
export { e as danger, t as dangerLead, n as dangerNote, o as default, r as movements, i as root, a as sheetAction };

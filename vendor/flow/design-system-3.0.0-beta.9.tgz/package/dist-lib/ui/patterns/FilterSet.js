"use client";
import { useT as e } from "../../i18n/useSafeIntl.js";
import { Divider as t } from "../primitives/Divider.js";
import { Select as n } from "../primitives/Select.js";
import { Stack as r } from "../primitives/Stack.js";
import { FilterBar as i } from "../components/FilterBar.js";
import { ActiveFilters as a } from "../components/ActiveFilters.js";
import { SavedViews as o } from "../components/SavedViews.js";
import s from "./FilterSet.module.js";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
import { useState as u } from "react";
//#region src/ui/patterns/FilterSet.tsx
var d = {};
function f({ dimensions: f, value: p, defaultValue: m, onChange: h, period: g, views: _, activeViewId: v, onViewsChange: y, onActiveViewChange: b, maxViews: x = 12, trailing: S, style: C }) {
	let w = e(), T = p !== void 0, [E, D] = u(m ?? d), O = T ? p : E, k = (e, t) => {
		T || D(e), h?.(e), t === void 0 ? v && b?.(null) : b?.(t);
	}, A = f.flatMap((e) => (O[e.id] ?? []).map((t) => ({
		id: `${e.id}:${t}`,
		dimension: e.label,
		label: e.options.find((e) => e.value === t)?.label ?? t
	})));
	return /* @__PURE__ */ c("div", {
		className: s.root,
		style: C,
		children: /* @__PURE__ */ l(r, {
			direction: "column",
			gap: "stack",
			children: [
				/* @__PURE__ */ l("div", {
					className: s.toolbar,
					children: [/* @__PURE__ */ c(i, { children: f.map((e) => /* @__PURE__ */ c(n, {
						multiple: e.multiple,
						options: e.options,
						value: e.multiple ? O[e.id] ?? [] : O[e.id]?.[0] ?? "",
						onChange: (t) => k({
							...O,
							[e.id]: Array.isArray(t) ? t : t ? [t] : []
						}),
						insetLabel: e.label,
						size: "sm",
						clearable: !0
					}, e.id)) }), /* @__PURE__ */ l("div", {
						className: s.actions,
						children: [S, _ && /* @__PURE__ */ c(o, {
							views: _.map((e) => ({
								id: e.id,
								name: e.name
							})),
							activeId: v ?? null,
							max: x,
							onApply: (e) => {
								let t = _.find((t) => t.id === e);
								t && k(t.value, e);
							},
							onSave: (e) => y?.([..._, {
								id: `v${Date.now()}`,
								name: e,
								value: { ...O }
							}]),
							onDelete: (e) => y?.(_.filter((t) => t.id !== e))
						})]
					})]
				}),
				A.length > 0 && /* @__PURE__ */ c(t, { label: w("filterSet.label", "Filtros") }),
				A.length > 0 && /* @__PURE__ */ c(r, {
					gap: "stack",
					align: "center",
					wrap: !0,
					children: /* @__PURE__ */ c(a, {
						filters: A,
						period: g,
						onRemove: (e) => {
							let [t, n] = e.split(":");
							k({
								...O,
								[t]: (O[t] ?? []).filter((e) => e !== n)
							});
						},
						onClearAll: A.length > 0 ? () => k({}) : void 0
					})
				})
			]
		})
	});
}
//#endregion
export { f as FilterSet };

import e from "./TransactionGroup.module.js";
import { jsx as t, jsxs as n } from "react/jsx-runtime";
//#region src/ui/patterns/TransactionGroup.tsx
function r({ label: r, children: i, style: a }) {
	return /* @__PURE__ */ n("div", {
		className: e.root,
		style: a,
		children: [/* @__PURE__ */ t("span", {
			"data-overline": "",
			className: e.label,
			children: r
		}), i]
	});
}
//#endregion
export { r as TransactionGroup };

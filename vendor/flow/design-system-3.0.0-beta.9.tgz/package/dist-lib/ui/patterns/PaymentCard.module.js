//#region src/ui/patterns/PaymentCard.module.css
var e = "I4rO2a_bottom", t = "I4rO2a_chip", n = "I4rO2a_dots", r = "I4rO2a_expires", i = "I4rO2a_frozenIcon", a = "I4rO2a_frozenLabel", o = "I4rO2a_frozenOverlay", s = "I4rO2a_holder", c = "I4rO2a_label", l = "I4rO2a_last4", u = "I4rO2a_number", d = "I4rO2a_productRow", f = "I4rO2a_root", p = "I4rO2a_top", m = {
	bottom: e,
	chip: t,
	dots: n,
	expires: r,
	frozenIcon: i,
	frozenLabel: a,
	frozenOverlay: o,
	holder: s,
	label: c,
	last4: l,
	number: u,
	productRow: d,
	root: f,
	top: p
};
//#endregion
export { e as bottom, t as chip, m as default, n as dots, r as expires, i as frozenIcon, a as frozenLabel, o as frozenOverlay, s as holder, c as label, l as last4, u as number, d as productRow, f as root, p as top };

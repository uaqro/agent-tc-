"use client";
import { Badge as e } from "../primitives/Badge.js";
import { useT as t } from "../../i18n/useSafeIntl.js";
import { Button as n } from "../primitives/Button.js";
import { Card as r } from "../primitives/Card.js";
import { Chip as i } from "../primitives/Chip.js";
import { DetailRow as a } from "../primitives/DetailRow.js";
import { IconButton as o } from "../primitives/IconButton.js";
import { SheetBody as s } from "../primitives/SheetBody.js";
import { BottomSheet as c } from "../components/BottomSheet.js";
import { FilterBar as l } from "../components/FilterBar.js";
import { MapCanvas as u } from "../components/MapCanvas.js";
import { PeekSheet as d } from "../components/PeekSheet.js";
import { StationRow as f } from "../components/StationRow.js";
import { RouteBanner as p } from "../components/RouteBanner.js";
import m from "./StationFinder.module.js";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
import { useCallback as _, useMemo as v, useState as y } from "react";
//#region src/ui/patterns/StationFinder.tsx
var b = "todas";
function x({ stations: x, filters: S, me: C, routes: w, zoom: T = 14, onStationSelect: E, style: D }) {
	let O = t(), [k, A] = y(b), j = () => [C[0], C[1]], [M, N] = y(j), [P, F] = y(null), [I, L] = y(!1), R = v(() => x.filter((e) => k === b || e.kind === k), [x, k]), z = x.find((e) => e.id === P), B = v(() => R.map((e) => ({
		id: e.id,
		lat: e.lat,
		lon: e.lon,
		label: e.label,
		color: e.id === P ? "var(--viz-accent)" : void 0
	})), [R, P]), V = _((e) => {
		F(e), L(!1), E?.(e);
	}, [E]), H = _((e) => {
		A(e), e === b || z && z.kind === e || V(null);
	}, [z, V]), U = I && P ? w?.[P] : void 0;
	return /* @__PURE__ */ g("div", {
		className: m.root,
		style: D,
		children: [
			/* @__PURE__ */ h(u, {
				center: M,
				zoom: T,
				pins: B,
				selectedPin: P,
				onPinClick: V,
				route: U,
				surface: "none",
				style: { flex: 1 }
			}),
			S && S.length > 0 && /* @__PURE__ */ g(l, {
				variant: "floating",
				children: [S.map(({ value: e, label: t, icon: n }) => /* @__PURE__ */ h(i, {
					label: t,
					icon: n,
					selected: k === e,
					onClick: () => H(e),
					style: { boxShadow: "var(--shadow-raised)" }
				}, e)), /* @__PURE__ */ h(o, {
					icon: "my_location",
					ariaLabel: O("stationFinder.myLocation", "Mi ubicación"),
					onClick: () => N(j()),
					variant: "tonal",
					size: "sm",
					style: {
						marginLeft: "auto",
						boxShadow: "var(--shadow-raised)"
					}
				})]
			}),
			I && z && /* @__PURE__ */ h(p, {
				title: O("stationFinder.towards", "Hacia {name}", { name: z.name }),
				subtitle: [z.dist, z.eta && O("stationFinder.eta", "llegas en {eta}", { eta: z.eta })].filter(Boolean).join(" · "),
				onClose: () => L(!1)
			}),
			!P && !I && /* @__PURE__ */ h(d, {
				title: O("stationFinder.nearby", "{n} estaciones cerca", { n: R.length }),
				children: R.slice(0, 3).map((e) => /* @__PURE__ */ h(f, {
					kind: e.kind,
					icon: e.icon,
					title: e.name,
					subtitle: [e.dist, e.eta].filter(Boolean).join(" · "),
					value: e.prices?.[0]?.[1],
					onClick: () => V(e.id)
				}, e.id))
			}),
			/* @__PURE__ */ h(c, {
				open: !!z && !I,
				onOpenChange: (e) => !e && V(null),
				title: z?.name,
				fixed: !1,
				children: z && /* @__PURE__ */ g(s, { children: [
					/* @__PURE__ */ g("div", {
						className: m.badgeRow,
						children: [
							z.kindLabel && /* @__PURE__ */ h(e, {
								tone: z.tone ?? "neutral",
								icon: z.icon,
								children: z.kindLabel
							}),
							z.open && /* @__PURE__ */ h(e, {
								icon: "schedule",
								children: z.open
							}),
							z.dist && /* @__PURE__ */ h(e, {
								icon: "near_me",
								children: z.dist
							})
						]
					}),
					z.prices && z.prices.length > 0 && /* @__PURE__ */ h(r, {
						padding: 16,
						children: /* @__PURE__ */ h("div", {
							className: m.priceList,
							children: z.prices.map(([e, t]) => /* @__PURE__ */ h(a, {
								label: e,
								value: t,
								mono: !0
							}, e))
						})
					}),
					z.services && z.services.length > 0 && /* @__PURE__ */ h("div", {
						className: m.serviceRow,
						children: z.services.map((t) => /* @__PURE__ */ h(e, {
							tone: "neutral",
							children: t
						}, t))
					}),
					w?.[z.id] && /* @__PURE__ */ h(n, {
						variant: "primary",
						size: "lg",
						icon: "navigation",
						fullWidth: !0,
						onClick: () => L(!0),
						children: z.eta ? O("stationFinder.goEta", "Cómo llegar · {eta}", { eta: z.eta }) : O("stationFinder.go", "Cómo llegar")
					})
				] })
			})
		]
	});
}
//#endregion
export { x as StationFinder };

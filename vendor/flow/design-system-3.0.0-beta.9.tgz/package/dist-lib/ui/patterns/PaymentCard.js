import { useT as e } from "../../i18n/useSafeIntl.js";
import { BalanceDisplay as t } from "../components/BalanceDisplay.js";
import n from "./PaymentCard.module.js";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/ui/patterns/PaymentCard.tsx
function a(e) {
	return e.replace(/\S/g, "•");
}
function o({ holder: o, last4: s, variant: c = "ink", frozen: l, label: u, icon: d, expires: f, balance: p, hidden: m, onToggleHidden: h, onClick: g, style: _ }) {
	let v = e();
	return /* @__PURE__ */ i(g ? "button" : "div", {
		className: n.root,
		"data-variant": c,
		"data-frozen": l || void 0,
		onClick: g,
		type: g ? "button" : void 0,
		style: _,
		"aria-label": l ? v("card.labelFrozen", "Tarjeta {holder} terminación {last4}, congelada", {
			holder: o,
			last4: s
		}) : v("card.label", "Tarjeta {holder} terminación {last4}", {
			holder: o,
			last4: s
		}),
		children: [
			/* @__PURE__ */ r("div", {
				className: n.top,
				children: p ? /* @__PURE__ */ r(t, {
					variant: "art",
					value: p,
					hidden: m,
					onToggleHidden: h
				}) : /* @__PURE__ */ r("span", {})
			}),
			/* @__PURE__ */ i("div", {
				className: n.productRow,
				children: [/* @__PURE__ */ r("span", {
					className: n.chip,
					children: /* @__PURE__ */ r("span", {
						className: "flow-symbol flow-symbol--sm",
						"aria-hidden": "true",
						children: d ?? "sim_card"
					})
				}), u && /* @__PURE__ */ r("span", {
					"data-overline": "",
					className: n.label,
					children: u
				})]
			}),
			/* @__PURE__ */ i("div", {
				className: n.number,
				children: [
					/* @__PURE__ */ r("span", {
						className: n.dots,
						children: "••••"
					}),
					/* @__PURE__ */ r("span", {
						className: n.dots,
						children: "••••"
					}),
					/* @__PURE__ */ r("span", {
						className: n.dots,
						children: "••••"
					}),
					/* @__PURE__ */ r("span", {
						className: n.last4,
						children: m ? "••••" : s
					})
				]
			}),
			/* @__PURE__ */ i("div", {
				className: n.bottom,
				children: [/* @__PURE__ */ r("div", {
					"data-overline": "",
					className: n.holder,
					children: m ? a(o) : o
				}), f && /* @__PURE__ */ r("div", {
					className: n.expires,
					children: m ? "••/••" : f
				})]
			}),
			l && /* @__PURE__ */ i("div", {
				className: n.frozenOverlay,
				"aria-hidden": "true",
				children: [/* @__PURE__ */ r("span", {
					className: `flow-symbol ${n.frozenIcon}`,
					children: "ac_unit"
				}), /* @__PURE__ */ r("span", {
					"data-overline": "",
					className: n.frozenLabel,
					children: v("card.frozen", "Congelada")
				})]
			})
		]
	});
}
//#endregion
export { o as PaymentCard };

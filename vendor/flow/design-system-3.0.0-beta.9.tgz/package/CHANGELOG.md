# Changelog — @er-mobility-mx/design-system

Formato: [Keep a Changelog](https://keepachangelog.com/es/1.1.0/) · versionado [SemVer](https://semver.org/lang/es/).
La regla de la casa: toda prop nace en el contrato canónico antes que en el código; lo que aparece aquí ya pasó por esa puerta.

## [Unreleased]

- `FlowLogo.variant="navigation"` comparte una escala de marca de 24/32/40 px por densidad y se ajusta al carril sin deformarse. Ambos shells la consumen (#415).

- Sidebar: roles semánticos `type-navigation-label`, `type-navigation-group` e `icon-navigation` amplían y coordinan la escala por densidad de labels e iconos (#415).

- Sidebar: ancho por defecto fluido según viewport, con límites por densidad; carril más amplio en comfortable y cajón ajustado al espacio disponible. `width` conserva el override explícito.

- Sidebar: `responsive`, `open` y `onOpenChange` comparten navegación completa, carril y cajón modal entre shells. Padding sensible a densidad, ancho semántico y foco/teclado mediante OverlayShell (#410).

- Dataviz: roles tipográficos emparejados `type-viz-category` y `type-viz-value` en las tres densidades. Categorías Ubuntu y numerales IBM Plex Mono mantienen tamaño e interlineado equivalentes en Bars, ChartLegend y FlowChart.

### Añadido

- Ámbito `OverlayScope` para overlays de superficies embebidas: el teléfono del banco contiene sus hojas sin perder el foco ni el cierre por teclado.
- `KanbanBoard.renderActions` permite componer un menú de acciones por tarjeta. Growth incorpora avanzar y eliminar, 46 cuentas de ejemplo y columnas más anchas.
- Wallet unifica iconografía por producto, estados y colores de importes entre Inicio y Actividad; el detalle separa comercio y concepto, usa fecha absoluta y últimos cuatro dígitos, y ofrece Compartir.
- Roles tipográficos semánticos para movimientos y recibos; filas con padding lateral, feedback pressed y motion de Flow con movimiento reducido.

- **Tratamiento semántico de categorías dataviz.** El diccionario incorpora
  `--viz-category-label` y `--type-viz-category`, compartidos por Bars y la
  leyenda principal de ChartLegend. Conserva `--viz-label` para ejes y contexto
  secundario. Se generan CSS, SCSS y Dart y se verifica paridad por modo y densidad.
- **ChartLegend.width** distingue ancho de contenido y ancho de zona (`fill`),
  evitando que Donut sobrescriba selectores de la primitiva.

- **`BrandHero` gana `eyebrow`.** La etiqueta que rotula de qué va la pantalla, encima del titular: una portada dice el tema antes de afirmar nada. Va como `data-overline`, así que el tracking y la caja alta los pone el reset con dueño y no la pieza (`bh-5`). El acceso no la lleva.

- **`BrandHero` y `BrandCanvas` — la cara de marca de una pantalla, con su escena.** `BrandHero` es el panel: superficie de producto, logo, titular de portada y pie. `BrandCanvas` es el arte que lleva detrás — las trayectorias de una flota vistas por una cámara que respira, con una señal recorriendo cada vertical de negocio y su tarjeta colgando de ella.

  Es una **migración** de la portada de eOne, no un dibujo nuevo: la geometría y los tiempos son los medidos allí y los mecanismos son los de Flow. Lo que hace que una línea se sienta orgánica son dos senos de frecuencia distinta por ruta, curvas en tres dimensiones, y un giro y una inclinación que oscilan con periodos que no son múltiplos — así el encuadre no se repite.

  Tres decisiones donde esta versión se separa de su referencia, y las tres por una medición:

  - **Las tarjetas son DOM, no pintura.** La referencia las dibuja en el lienzo con `500 11px Ubuntu` escrito a mano; aquí llevan tipografía de token y texto que el producto traduce.
  - **Los puntos son círculos de verdad.** El lienzo se estira sin conservar proporción a propósito —es lo que hace que las curvas barran de borde a borde—, y dentro de ese estirón un `<circle>` sale elipse; la referencia lo tapaba dibujando elipses pre-aplastadas.
  - **El nombre de la vertical va en tinta semántica.** En la referencia va en el color de su servicio y medido no se sostiene: el naranja da **2.28** sobre la tarjeta, con 4.5 de mínimo para texto. El color se queda en el icono, que es decorativo —`aria-hidden`, y no dice nada que su etiqueta no diga al lado—.

  La escena no depende de que corra un frame: con `prefers-reduced-motion`, con `paused`, en una pestaña oculta o fuera de vista, lo que se ve es la escena **completa**. El reloj vive una sola vez en `motion/useEscena`.

  ```tsx
  <BrandHero
    title="Todo tu día,"
    accent="en movimiento."
    description="Gestiona tu flota, tus conductores y tus viajes desde un solo lugar."
    signals={[{ name: 'Combustible', detail: 'Carga registrada · 42 L', unit: 'Unidad 0427' }]}
  />
  ```

  El texto es tuyo: sin `signals` la escena se dibuja sin una sola letra.

- **`Wizard` gana saltar un paso e inhabilitar avanzar** (`onSkip`, `skipLabel`, `nextDisabled`). La receta existía y **no la montaba nadie**: el alta de cuenta reimplementaba su stepper y su botonera a mano porque le faltaban estas dos cosas. Saltar acompaña a la acción primaria, nunca la sustituye (`wz-5`), y `nextDisabled` solo frena avanzar — volver y saltar siguen vivos (`wz-6`).

### Cambiado

- **Encabezados de panel consistentes (`wf-4`).** WidgetFrame compone
  SectionHeader sm con un heading real y usa el mismo padding en todos los
  paneles. chrome y panel quedan como aliases deprecados sin diferencias
  visuales; la carga, visibilidad y personalización siguen disponibles.
  WidgetGrid conserva esos aliases y los consumidores del banco dejan de
  elegirlos. SectionHeader.description admite ReactNode para conservar las
  descripciones existentes. No hay cambios de nombres de tokens.

- **PageHeader deja la separación externa al layout (`spc-5`).** El margen de
  24 px se sumaba al gap de 16 px del dashboard. Se retira ese margen y las
  pantallas con contenedor propio usan `--gap-stack`, evitando dos dueños de
  la misma separación.

- **Navegación y filtros usan un layout consistente con el diccionario.** Sidebar
  separa sus destinos de los bordes con `--space-2`. Select múltiple resume dos
  o más valores con un conteo traducido. FilterSet reúne las acciones y vistas
  a la derecha de los controles y rotula los filtros aplicados con Divider; cuando el contenedor baja al corte
  expandido las acciones pasan a su propia fila. ActiveFilters mantiene limpiar
  en el flujo de los chips. Chip removible elimina el padding duplicado tras
  la ×, preservando su objetivo propio de 44 px (`chp-1`). No cambia la API pública.

- **`Sidebar` deja de pintarse con estilos inline, y tres de sus medidas vuelven a la escala.** El aire de la cabecera, de la lista, del item y del pie estaba en el `.tsx` con números literales tras un ternario, invisible para las rejas de CSS. Ahora va en la hoja por `data-collapsed`. Cambian tres valores, a propósito: el ancho colapsado de **60 a 64 px** —`--sidebar-collapsed` siempre dijo 64 y la pieza escribía 60—, el `gap` del item de 10 a 8 (`--gap-inline`) y el padding del pie de 14 a 12 (`--space-3`). 10 y 14 no son pasos del sistema.

- **`BrandHero` no va al lado de una pieza que se declara a pantalla completa.** Un carrusel de bienvenida o una vista de estado dicen, con esas palabras, que son la pantalla; ponerlas en media pantalla junto al panel deja dos portadas con dos titulares del mismo nivel y dos paletas de marca que por diseño no comparten un valor. Queda escrito en los `nonGoals` del contrato.

- **`PageFrame` queda deprecada y se retira en 4.0.** El ancho y el centrado del contenido los decide el **layout**, no un envoltorio por pantalla: la regla son dos declaraciones en el contenedor con scroll —`.main > *` con `max-width: var(--content-max)` y `margin-inline: auto`—. Envolver cada pantalla suma el padding de la pieza al del área de contenido y deja un solo hijo, así que se pierde el `gap` que separa a los de verdad. Medido: no la montaba nadie, y al mirar por qué resultó que no era olvido. La tabla de deprecaciones de `USUARIO.md` dice qué poner en su lugar.

- **La fuente de iconos ya no se pide a Google: la declara el sistema.** `tokens/fonts.css` trae su propio `@font-face` —familia `Flow Symbols`, el mismo archivo que ya viajaba en `public/fonts`— con **`font-display: block`**.

  El porqué: un icono se pide por **ligadura**, así que mientras la fuente no llega el navegador pinta la **palabra** —«mail», «visibility»— con la cara de respaldo. Medido: el respaldo ocupa 85px donde el glifo mide 24. Quien decide eso es `font-display`, y hasta ahora vivía en una línea del **HTML de cada app**: el `<link>` que enseñaba el README pedía `swap`. Arreglar el README no arregla a quien ya lo copió, porque ese HTML no viaja en el paquete.

  **Qué tienes que hacer:** copiar las fuentes, que es el paso que ya hacías para la de marca —ahora trae también la de iconos—:

  ```bash
  cp -r node_modules/@er-mobility-mx/design-system/public/fonts public/
  ```

  Y borrar de tu `index.html` el `<link>` de **Material Symbols** (solo ese: los de Ubuntu e IBM Plex se quedan, y ahí `swap` es lo correcto porque la cara de respaldo **es** el texto). Si lo dejas **no se rompe nada**: la familia del sistema se pide primero y la de Google queda de respaldo. Lo vigila `fnt-7`.

  Una petición menos a un tercero, que es la misma razón por la que el sistema autoaloja sus fuentes.

### Arreglado

- **`FLUTTER.md` enseñaba un método deprecado, y nace `dt-2` para que no vuelva.** La guía citaba `FlowBrand.flowGrey900.withOpacity(0.4)` mientras el emisor ya producía `withValues(alpha: 0.4)` —`withOpacity` está deprecada en el Flutter actual—, y nada contrastaba el Dart que esa página publica. Ahora cada clase, cada miembro cualificado, cada método invocado sobre un token y el `package:` del import tienen que existir en el paquete **emitido**. Vive en `check:dart` y no junto a `dnm-6` porque `generated/` está gitignored y la batería construye los tokens mucho después de `check:docs-numbers`: la regla va donde está su dato. Un identificador suelto queda fuera a propósito —el único discriminador mecánico acusaría `fontWeight`, `fontSize` y `fontFamily`, que son de `TextStyle` y están bien escritos—.

- **`dt-1` dependía del estado de la máquina.** Llamaba a `dart pub get`, y el pubspec emitido declara `flutter: sdk: flutter`: `dart pub get` no sabe resolver eso y lo dice el propio comando. No fallaba siempre —el `dart` de una instalación de Flutter aprende a resolverlo en cuanto algo ha arrancado `flutter` antes—, así que la misma reja sobre el mismo commit salía verde o roja según lo que hubiera pasado antes en esa máquina, y caía del lado cómodo. El comando sale ahora del manifiesto emitido, y el OMITIDO dice cuál de los dos binarios falta.

## [3.0.0-beta.9] — 2026-10-08

### Añadido

- **Una bandera dejó de ser un activo de compilación** ([RFC 0012](https://github.com/ER-Mobility-MX/FlowHANA/blob/main/docs/rfcs/0012-una-bandera-no-es-un-activo-de-compilacion.md), aceptado el 8-oct-2026). `FlowFlagsProvider baseUrl="…"` dice dónde sirve tu producto sus banderas, y `Flag` arma la URL **al pintar**: ningún empaquetador la ve, así que tu build no emite ni un SVG. Medido en la app de referencia: `dist` de **7,9 a 3,7 MB** y el CSS del bundle de **609 a 188 KB** — la hoja de `flag-icons` nombra las 271 banderas con un `url()`, y un `url()` dentro de CSS no se puede sacudir, así que se empaquetaban **143 archivos y 3,8 MB para pintar ocho banderas que pesan 170 KB**.

  Los archivos los sirves tú, porque **qué países son lo sabe tu producto**: `npx flow-banderas --codigos mx,us --destino public/flags` (también como export `./banderas`). Meter el catálogo en el tarball se lo cobraría a quien no monta ninguna bandera, y recortarlo por uso dentro del paquete es el error que ya se revirtió con los iconos — un design system es de mundo abierto.

  **Nada se rompe en 3.x**: sin proveedor, `Flag` sigue por el camino 1.x —la hoja global del entry `./flag`— y avisa una vez por documento en desarrollo. En 4.0 ese camino desaparece.

- **`Flag` vuelve al barril principal.** `flg-2` se reescribió para decir lo que de verdad protege —que nadie pague las banderas que no pinta—, y eso lo decide **la hoja**, no dónde se exporta la pieza.

- **`InputPhone` dibuja su bandera con `country`** (Solicitud #330, `tel-6`). Dos pantallas la ensamblaban a mano dentro de `prefix`, con el glifo a 16 en una y a 18 en la otra: la misma decisión del sistema tomada dos veces distinta. La pieza **no guarda ningún mapa país→lada** —ese dato es del producto, igual que la lista del selector de país— así que la lada sigue llegando por `prefix`.

- **`check:banderas`** — `bnd-1` sobre el **artefacto**: el build de un consumidor que declara su base no emite ningún SVG de bandera. Es donde vive el defecto: la suite monta la pieza y ve un `<img>` correcto mientras el empaquetador emite 3,8 MB al lado. `bnd-2`: todo código de país que una pantalla pinta está servido. Nació midiendo que el propio RFC decía seis países y la app pinta **ocho** — `cl` y `es` salen de la lista del onboarding del conductor, y la prueba de concepto no los sirvió: dos banderas rotas dentro de una medición que presumía de estar medida.

### Deprecado

- **El entry `./flag` se retira en 4.0.** Usa `Flag` del barril con `FlowFlagsProvider`. El marcador vive en el módulo del entry, y `check:deprecations` aprendió a leer una **ruta** de `exports` deprecada: no es ni una prop ni una función, así que estaba marcada en el código con la reja en verde — el defecto que dep-1 existe para cerrar.

## [3.0.0-beta.8] — 2026-10-07

Una tanda de **lo que el paquete le entrega a quien lo instala**: las fuentes y su licencia, el peso que descarga, lo que se le instala en el árbol de dependencias, y los tokens que llegan a las plataformas que no son web. Casi todo salió de medir lo que nadie medía, así que la mitad de la entrada son rejas nuevas: **catorce reglas**, y la batería pasa de 60 a 62 pasos.

### Cambiado — rompe

- **El fichero de la fuente de iconos cambia de nombre y deja de ser variable.** Era `sykd-zNym6…woff2`, la cara variable de Google con el eje `wght 300 600`; ahora es `material-symbols-rounded.woff2`, instanciada en `opsz=24` y `wght=400`, con **FILL** como único eje que queda (es el que usa `ico-4`). **Rompe a quien autoalojara el fichero por su nombre** o cambiara el trazo de un icono con `font-weight`. A cambio: el catálogo que viaja es **completo** —4.277 glifos, los que la fuente puede dibujar de verdad— en 338 KB, contra los 3.019 KB de la variable entera.

  El intento anterior fue subsetear **por uso** y estaba mal de raíz: un design system es de mundo abierto, así que recortar a lo que este repo usa deja fuera al consumidor. Medido antes de descartarlo: el inventario se quedaba corto en 30 iconos, aparecieron **siete formas distintas** de nombrar uno, y cinco huecos solo salieron pintando el banco.

- **Toda la escala de títulos pasa a Edenred Black (900).** `--type-display-lg`, `--type-display-md` y `--type-headline-lg` iban en 700. Decisión del Core Team (6-oct-2026) y la tomó una medición: el reparto real era **7 sitios en 700 contra 31 en 900**, o sea que el Black ya era la norma y el Bold la excepción heredada. El que importaba es `--type-headline-lg`, que es `PageHeader` y por tanto el título de **toda** pantalla del shell. **Los títulos se distinguen por tamaño, no por peso.**

- **Las caras Edenred 400 y 700 ya no viajan.** Al migrar, las dos se quedaron sin consumidor y `fnt-2` las marcó. La carpeta de fuentes pasa de **3,4 MB a 760 KB**, y el tarball a **1,0 MB**. **Rompe a quien declarara su propio `@font-face` apuntando a `edenred-webfont.woff2` o `edenred_bold-webfont.woff2`.**

- **`material-symbols-rounded-subset.woff2` sale del paquete.** Era un resto de la build anterior —4.299 glifos, el conteo crudo de antes de intersectar con el cmap de la fuente— que **ninguna hoja nombraba** y que el consumidor descargaba igual: **338 KB muertos**, una cuarta parte del paquete.

- **El canon renombra 39 criterios.** De 30 ids que nombraban **dos** criterios distintos en contratos diferentes: `cc`→`cctl` (card-controls), `lb`→`lbx` (listbox), `sh`→`shh` (sheet-header), `wz`→`wzt` (wizard-t), `pc`→`pgc` (playground-canvas), `dc`→`dlc`, `df`→`dfo`, `sb`→`shb`, `txa`→`txac`, `wl`→`wlib`, `spc`→`spe`, `inp-*`→`ina-*`/`inph-*`, y el `dg-11` que estaba repetido **dentro de data-grid** pasa a `dg-20`. **Rompe a quien cite esos ids en sus tests de conformance.**

### Añadido

- **Los tokens de tipografía llegan a Dart.** `FlowSysScaleTypography` trae los 21 niveles en los **cuatro campos que pide `TextStyle`** —peso, tamaño, `height` y familia—, 84 constantes. Antes a Flutter le llegaba la escala **cruda** (34 constantes de tamaño, interlineado y peso) y **ni una decisión**: una app tenía que reinventar la jerarquía entera a mano. El `height` de Flutter **es** el `line-height` sin unidad de CSS, así que el valor viaja tal cual. Son los de la densidad por defecto: `compact` y `comfortable` viven solo en el CSS a mano y la densidad en Flutter queda como decisión del consumidor.

- **El Dart y el SCSS viajan en el paquete** (`generated/tokens/dart` y `/scss`, 72 KB). `FLUTTER.md` mandaba al equipo a una ruta que su consumidor no tiene: `generated/` está gitignored. Ahora se instalan con el paquete y `check:package-files` lo exige. Nace `_brand.scss`, que **no existía** — el consumidor de Angular no tenía la paleta de marca.

- **Cada familia tipográfica viaja con su licencia** en `public/fonts/LICENSES/`: UFL-1.0 (Ubuntu), OFL-1.1 (IBM Plex), Apache-2.0 (Material Symbols) y el registro de la de marca. Las tres primeras **exigen el texto al redistribuir** y no había ninguno. Lo vigila `fnt-1`.

- **`check:seguridad`** — lo que este paquete le **instala** a quien lo usa. `sec-1`: cero vulnerabilidades en lo que viaja, **sin trinquete**. `sec-2`: las de herramienta, con tope. `sec-3`: toda dependencia de producción con licencia redistribuible, leída del lock, y la lista **excluye la copyleft fuerte** a propósito.

- **`check:fuentes`** — `fnt-1` (licencia por familia), `fnt-2` (ninguna cara sin consumidor), `fnt-3` (el subset al día), `fnt-4` (la familia que **no se puede modificar** viaja byte a byte como la entregó la marca y fuera del subsetter) y `fnt-5` (ningún `.woff2` que no nombre una hoja).

- **`can-1`** (`check:canon`) — un criterio, un id. Es la gemela de `mrd-2` un nivel abajo, y como ERROR estructural: un id que nombra dos cosas no nombra ninguna.

- **`typ-11`** — la cara de un título sale de su `--type-*`; ninguna hoja declara `font-family: var(--font-display)`. Un tamaño fluido encima sigue valiendo.

- **`dnm-5` y `dnm-6`** — todo valor de token publicado en la documentación resuelve a lo que dice el diccionario (45 valores), y la tabla de clases Dart de `FLUTTER.md` **es** el inventario emitido, no una copia.

- **`doc-3`** — todo comando que la documentación enseña existe. Medido: de 75 scripts declarados, había uno fantasma.

- **`ico-6`** — todo nombre en una ranura de icono existe en el catálogo, y distingue los dos casos: el que no existe y el que **sí está** en el catálogo upstream pero no tiene glifo en la cara que viaja (son 22).

### Arreglado

- **Cuatro criterios del canon no tenían ningún testigo y se contaban verdes por el id de otra pieza.** `spe-1` (Specimen) lo cubría `spc-1`, que es el invariante de la escala de espacio; `wl-2` y `wl-3` (Wallet) los cubrían los tests de `WidgetLibrary`; y `wzt-4` lo cubría `wz-4`, un criterio del _pattern_ Wizard. Medido al deshacer el renombrado: la cobertura cae de 611 a **587** y los items sin un solo criterio cubierto suben de 3 a **11**. Los cuatro tienen test y se han visto fallar. Hoy **616/616** y los **166 items completos**.

- **La paridad de plataformas tenía un punto ciego del tamaño de una familia entera.** `PL5` compara cada salida contra el CSS token a token, pero su lista de pares estaba **escrita a mano**: el SCSS tenía su pareja de tipografía y el Dart no, así que los 21 `--type-*` no estaban en la lista de cosas que comparar. La lista se **deriva** ahora de las salidas emitidas, y el día que se derivó cazó la segunda ausencia: `brand.css` sin par en SCSS.

- **`prepack` fallaba en un clon limpio.** `build:lib` copia un archivo de `generated/`, que está gitignored, y nadie lo construía antes: funcionaba solo porque `verify` corre `tokens:build` en la misma sesión. Medido borrando el directorio: `npm pack` y `npm publish` salían 1.

- **Una vulnerabilidad alta en lo que viaja** —el SDK del MCP, en un paquete que se publica— y ocho de herramienta, todas de una dependencia (`style-dictionary` 4 → `patch-package` → `micromatch` → `braces`). Las dos cerradas. La subida de style-dictionary a 5 es un mayor y se aceptó porque **la salida generada es byte a byte idéntica**, comprobado antes.

- **`MapCanvas`: centrar el mapa no reportaba el encuadre.** El botón de recentrar movía el lienzo y no emitía `onViewportChange`, así que un consumidor que sincronice otra vista con el mapa se quedaba desfasado hasta el siguiente gesto (`mc-15`).

- **`InstallCard` dimensionaba texto con `--icon-md`**, un token de la escala de **iconos**. Por eso su etiqueta no cambiaba con la densidad, que es justo lo que la escala de tipo sí hace.

- **El contador de `TabBar` se pintaba con `white`** sobre el rojo de marca (3.99 y 2.48 de contraste), y `white` era un literal que `col-1` no veía porque buscaba `#hex` y `rgb(`. Ahora **un color con nombre también es un literal**.

- **88 valores de foundations publicados en la documentación no salían de su fuente**, y `exc-2` medía una muestra en vez del registro entero.

- **`WalletAppScreen` duplicaba el pacto del shell**: devolvía el foco a la fila al cerrar la hoja, cosa que `OverlayShell` ya hace, y además llamaba a `focus()` **sin condición** — un `onOpenChange` de apertura habría arrancado el foco de vuelta a la fila.

### Retirado

- **El arnés de criterios del canon (#301–#308), revertido entero en #311.** Buscaba exigir que todo criterio `automated` se hubiera visto fallar, no solo que un test citara su id. Lo que lo cerró es una medición, no un cansancio: de los 214 criterios sin propuesta, **151 son de AUSENCIA** —«no dibuja X», «no acepta Y»— y un defecto de ausencia no se puede introducir mutando una línea, así que la vía automática no existe. Por el camino costó llevar `verify` de 3 a 13,7 minutos, con una reja corriendo dentro de otra. Se revierte completo y se deja la medición escrita para quien lo retome.

## [3.0.0-beta.7] — 2026-10-03

### Cambiado — rompe

- **`Badge.tone`: `'default'` pasa a llamarse `'neutral'`, y nace `'accent'`.** El contrato y la ficha prometían los dos nombres **desde siempre**; el código decía `default` y no tenía acento, y las tres rejas del triángulo estaban en verde porque el tipo de la prop es un alias nombrado (`BadgeTone`) y `C8` se saltaba los tipos nombrados. Quien escribía `tone="default"` usaba una API que la documentación nunca publicó; quien escribía `tone="accent"` leyendo la ficha no compilaba. El acento es **identidad, no estado**: va con `--surface-accent-subtle` y `--text-accent`.

- **`Toast` sin tono ya no es un éxito.** El contrato promete `neutral` por defecto y el código traía `success`, así que un aviso como «Exportando 6 conductores…» salía con su palomita verde afirmando algo que nadie había dicho. Nace el tono `neutral` (glifo neutro, tinta del cuerpo) y pasa a ser el default; `info`, que el código aceptaba sin que nadie lo prometiera, entra al contrato y a la ficha.

- **`StationFinderStation.tone` es `BadgeTone`**, no una copia de su lista. La tenía escrita a mano y por eso decía `default` cuando el contrato de Badge ya decía `neutral`: una lista copiada es una divergencia futura.

- **Los puntos de `OnboardingCarousel` son un `tablist`.** Eran N botones sueltos sin rol: cuatro diapositivas costaban cuatro paradas de tab para pasar de largo y las flechas no hacían nada. Ahora son **una** parada con flechas dentro, con `role="tab"` y `aria-selected`, usando el dueño declarado de la mecánica (`useRovingTabs`).

  **Rompe los tests que buscaran los puntos con `getByRole('button')`**: son `getByRole('tab')`. Es la misma rotura que tuvo `Switch` al ganar su `role="switch"`, y por el mismo motivo: el rol que la pieza no declaraba era el correcto.

### Añadido

- **`RideOffer`, la propuesta de viaje con cuenta atrás y dos salidas** (Solicitud #293). La pantalla del conductor la dibujaba con **siete clases locales** —superficie de acento, realce, overline, los dos puntos de parada, la fila de meta y la rejilla de CTAs—: el banco construyendo en vez de componer. La receta lleva el orden de lectura (qué viaje, de dónde a dónde, cuánto, cuánto queda para decidir), compone `CircularProgress` para la cuenta atrás —que **se anuncia**: `role="progressbar"` con su valor— y `Button` para las dos salidas. El origen y el destino se distinguen **por la forma de su marca**, no por el color: sobre el acento las dos tintas son la misma (`rof-2`).

- **`CircularProgress` gana el centro, el nombre y la tinta** (Solicitud #273): `children` es lo que va **dentro** del anillo —`showValue` solo sabía pintar el porcentaje, y una cuenta atrás enseña los segundos que quedan—; `ariaLabel` separa los dos trabajos que hacía `label` (texto visible bajo el anillo / nombre accesible del progressbar), y sin él `label` sigue nombrando; y `tone="inherit"` saca el arco, la pista y el centro de `currentColor`, para un anillo sobre superficie de acento, donde el acento del sistema no se distingue del fondo. Las tres salieron de una pantalla que se dibujaba su propio anillo de 20 líneas de SVG: ya no. Criterios `cpr-5`, `cpr-6` y `cpr-7`.

- **`[data-count]`, la marca numérica con dueño.** Una cifra sobre acento sólido, en pastilla —cuántos avisos tiene un item de navegación o una pestaña, qué número de parte es este—, y sin cifra, el punto de que hay algo. La dibujaban **cuatro bloques en tres tamaños** (18 en `Sidebar`, 16 en `TabBar`, 24 en `AnatomyView`), dos degradando a un punto de 8px por su cuenta, y la de `TabBar` con un `font-size` que pisaba el token de dato desde una perilla que no ponía nadie. **No entran el tamaño ni la posición**: se pisan con `--count-alto` y con la hoja de cada pieza. Es una carcasa y no un componente porque `TabBar` vive en `primitives` y un primitive no importa de su propia capa. Lo vigila `dup-13`.

- **`[data-link]`, el reset del enlace con dueño.** Un `<a href>` de Flow empieza sin el subrayado del navegador y heredando la tinta. Estaba escrito a mano en **once sitios** —cinco piezas y seis pantallas— con `text-decoration: none` repetido nueve veces. **El color no entra**: los once usaban cuatro decisiones distintas (`--text-link`, `--text-secondary`, `--text-accent`, `inherit`) y las cuatro son legítimas en su sitio. Lo vigila `dup-12`.

### Arreglado

- **Una pestaña no seleccionada apuntaba a un panel que no está en el DOM.** `TabPanel` monta **solo** el panel activo —por diseño—, así que `aria-controls` de las demás señalaba ids inexistentes: una referencia que no resuelve es una referencia rota. Ahora solo apunta la seleccionada (`tab-7`). **Nadie lo había visto porque ninguna pantalla montaba el par**: siete usaban `Tabs` sin panel.

- **La ficha de a11y publicaba un anillo de foco rojo**, y `--focus-ring` resuelve al azul de acento desde que existe. Otra frase heredada de Flow 1.x, en el campo `dos`, que ninguna reja leía.

- **El campo `tokens` de las siete foundations no lo miraba nadie**: `fch-4` solo buscaba las fuentes bajo `src/ui` y sus hojas viven en `src/tokens`. Dentro había tres **rangos** escritos como si fueran un token —`--space-1..16`, que el sitio publica como una fila de la tabla y cuenta como uno donde hay once—, dos **clases** (`.flow-symbol`), una **frase entera** publicada como fila en mono, y dos tokens cuya hoja es otra: las sombras son de `elevation.css`, así que la foundation de forma declara sus dos hojas.

- **Las variantes publicadas de `Card`, `typography` e `icons` eran de Flow 1.x.** El campo `variants` de la ficha viaja en el paquete y el sitio lo publica dos veces —la tabla de soporte por variante y el conmutador del playground, que pasa esos valores **como props**—, y no lo contrastaba nada. `Card` ofrecía «default / minimal / elevated / ghost» cuando su eje es `surface: elevated | outlined | inverse`; `typography` listaba nombres y cifras de otro sistema —56/40px, weight 800, «texto por defecto 14px»— y nombraba **JetBrains Mono**, que este sistema no carga; `icons` publicaba la escala «18/20/24/32px» cuando la de UI es 16/20/24. Lo vigila **C15**. De paso caen las otras dos menciones a las fuentes de Flow 1.x (Sora, JetBrains) que quedaban dentro de las fichas.

- **`SettingsRow` pisaba el nombre propio de su control.** Asociaba la etiqueta clonando el control e inyectando `aria-labelledby` **sin la guarda que `Field` ya tenía** (fld-6), y `aria-labelledby` gana sobre `aria-label`: un control con nombre propio —un `IconButton` con su `ariaLabel`— acababa anunciándose con el texto de la fila. La guarda vive ahora una sola vez, en `hooks/useNombrePorReferencia`, y la usan las dos.

## [3.0.0-beta.6] — 2026-10-02

### Añadido

- **`DataTable` acepta que el listado lo sirva el backend** (Solicitud #256). `manual` apaga el procesamiento local —buscar, ordenar y paginar—, `page`/`onPageChange` controlan la página, `total` dice cuántas filas tiene el conjunto y `sort`/`onSortChange` llevan el orden, con la misma semántica que `DataGrid`.

  Es **una** bandera y no tres: paginar fuera y ordenar dentro ordena la página en vez del conjunto. Sin `manual`, nada cambia respecto a beta.5.

- **`Select` busca contra un catálogo que no cabe en memoria** (Solicitud #257): `onSearch` y `loading`. Con `onSearch`, la pieza **no filtra** —`options` es la respuesta a la consulta—, y abre su campo de búsqueda sin pedir `searchable`. El debounce es del consumidor.

- **`Calendar` y `DatePicker` admiten el mes visible controlado** (Solicitudes #258 y #259): `month` / `onMonthChange`, en `'YYYY-MM'`. Reabrir un filtro guardado abre en el mes de su fecha, y se puede pedir al backend la disponibilidad del mes que se ve. Navegar con flechas también lo reporta.

- **`FileUpload` dice lo que no entra y pone límites** (Solicitud #260): `maxSize`, `maxFiles` y `onReject(rejected)` con el archivo y un motivo —`'accept' | 'maxSize' | 'maxFiles'`—, en una sola llamada por intento. Se exportan `RejectedFile` y `RejectReason`.

- **`Select` implementa `creatable`**, que estaba declarada en la interfaz y no se leía en ninguna línea: con texto que no coincide con ninguna opción, la lista ofrece crearlo.

- **`ChartLegend` gana `marks`** (`'line' | 'fill'`): el swatch repite la marca de su serie —trazo o trama— en vez de depender solo del color. Entra por omisión apagada.

- **`FlowIntlProvider` admite locale con región** (`es-MX`, `pt-BR`): el idioma decide las palabras y la región decide las cifras. Se exporta **`useLocale()`** para quien formatee por su cuenta.

- Piezas nuevas: **`Conversation`**, **`ListRow`**, **`TextAction`**, **`SheetHeader`**.

### Cambiado

- **Una serie deja de distinguirse solo por color** (fc-8). Cada serie lleva además su trazo (líneas), su símbolo (dispersión) o su trama (barras, sectores, áreas, treemap). Con una sola serie no se pone nada.

- **Se retocan las paletas de serie y de identidad.** El piso de separación bajo dicromacia simulada pasa de **ΔE 3.0 a 16**: en oscuro, cinco de las ocho series eran pasos de rampa de marca prestados, así que la paleta repetía matiz consigo misma. Cada color se movió ΔE 8 como mucho y el matiz quedó acotado a ±20°, de modo que los alias semánticos (`--viz-combustible` naranja, `--viz-electro` verde) siguen diciendo la verdad.

- **Las fechas y las cifras se formatean en el idioma del provider.** Cuatro formateadores llevaban `'es'` escrito a mano y uno no llevaba ninguno —ahí mandaba el navegador—, así que una app en inglés enseñaba los meses en español.

- **Las 88 claves que faltaban están traducidas** a los tres idiomas: hasta ahora un consumidor con locale `en` recibía el `defaultMessage`, que está en español.

### Deprecado

- **`BulkActionsTable` y `FilterableEditableTable`** (RFC 0004, aceptado el 1-oct-2026). Siguen exportadas y funcionando; se retiran en **4.0**. El destino de las dos es `DataTable` —con `selectable` + `bulkActions`, o con columnas `editable` + `onCellEdit`—.

### Arreglado

- **La búsqueda controlada de `DataTable` seguía filtrando en local**: con `query` controlada, una búsqueda servida que casara por un campo fuera de `searchKeys` se volvía a esconder. Con `manual` ya no.
- **`accept` de `FileUpload` solo se validaba al soltar.** El selector del sistema deja cambiar el filtro a «todos los archivos», así que por esa puerta entraba cualquier cosa.
- **El `<input>` de `FileUpload` no se restablecía**, así que quitar un archivo y volver a elegir el mismo no disparaba `onChange`.
- **Seis capas modales salían sin nombre accesible**, tres de ellas renderizando su título delante.
- **Los gráficos no emitían sus tramas**: `aria.decal` se ignoraba en silencio porque faltaba registrar su componente de ECharts.

### Cambiado — rompe

- **La paleta de identidad se llama `--identity-*`** (RFC 0007). Eran `--avatar-1..6`, que nombraban a una de sus dos piezas consumidoras y no a lo que hacen: seis matices para decir que dos instancias no son la misma. Los consume `Avatar` por hash del nombre y `OnboardingCarousel` por índice de diapositiva.

  `--avatar-1..6` siguen valiendo como **alias hasta 4.0**, con el mismo valor. `--avatar-offline` no cambia de nombre: cambia con el modo, y un valor que depende del modo es una decisión semántica, no una constante de paleta.

  Medido, por si te lo preguntas: `--ref-viz-*` no comparte **ni un valor** con esta paleta. No era una paleta con dos nombres, son dos paletas distintas — y por eso el nombre no es `--categorical-*`, que además es el término de dataviz para los colores de serie.

- **La escala de opacidad se llama `--ref-alpha-*`** (RFC 0007). Eran `--alpha-white-*` y `--alpha-black-*` en la capa `sys`, y no lo eran: son rgba crudos sobre blanco y negro puros, familia entera, sin ninguna decisión semántica encima. Con el prefijo correcto, la reja del modo oscuro los salta por construcción.

  Los nombres viejos siguen valiendo como **alias hasta 4.0**, con el mismo valor.

- **`--illustration-1` deja de ser el rojo de marca.** Era `var(--flow-red-500)`, el mismo valor que `--brand`, usado como fondo decorativo — lo que el punto 2 del checklist por pantalla prohíbe y `col-4` ya vigila. Ahora es `--identity-1`, que **ya era un rojo**: ΔE76 de 10.2 a plena fuerza y de **1.2 en el velo al 10%**, que es como `OnboardingCarousel` pinta el fondo. El cambio se ve en el blob interior de la primera diapositiva y no en el velo que lo rodea.

  El orden de `--illustration-*` **se conserva**: son dos transposiciones deliberadas (2↔3, 4↔5) sobre la paleta, y colapsarlas no ganaba nada porque los dos consumidores indexan por cosas distintas.

## [3.0.0-beta.5] — 2026-09-27

### Cambiado — rompe

- **`Switch` se anuncia como interruptor, no como casilla** — su input nativo lleva `role="switch"` (sw-3). Rompe los tests que lo buscaban con `getByRole('checkbox')`: son `getByRole('switch')`. Rompió cinco de los nuestros, y uno se llamaba literalmente «renders a checkbox role», o sea que el test afirmaba el defecto.

  La ficha prometía `role=switch nativo` desde siempre y nadie contrastaba el campo `a11y` con el código. `Switch` no alcanza su input —lo monta `ToggleControl`— y el role no se deriva de `type`, porque Checkbox y Switch comparten `type="checkbox"`: de ahí el miembro nuevo.

- **Se retiran `--card-dim-on-ink` y `--card-dim-on-accent`** — medido: cero usos en el paquete y cero en el banco. Viajaban en el CSS publicado y en el diccionario, y se llevaban dos excepciones escritas a mano en la reja de contraste. Si los usabas, el equivalente es `--card-fg-on-ink` / `--card-fg-on-accent` con la opacidad que necesites.

- **`Flag` sale del barrel principal y estrena entry** (#20). Se importa desde `@er-mobility-mx/design-system/flag`.

  `flag-icons` entra como hoja `.css` global, y **un import de CSS es un efecto secundario que ningún bundler descarta** aunque el JS sí se sacuda. Con `Flag` colgando del barrel, toda app pagaba las 142 banderas. Medido con una app que solo importa `Button`:

  ```
  antes   dist 4.0 MB · 142 SVG que nunca usa
  después dist 192 KB · 0 SVG
  ```

  La migración es una línea: `import { Flag } from '@er-mobility-mx/design-system/flag'`. Es el mismo trato que ya tenía `./specimens` (spm-2), y por el mismo motivo.

### Añadido

- **`ToggleControl.role`** — rol ARIA del input nativo. Solo `Switch` lo pasa; `Checkbox` y `Radio` no lo llevan.

- **`--ref-radius-600`, `--ref-size-border` y `--ref-size-border-strong`** — los tres valores de forma que vivían como literales sin token de referencia debajo. `--radius-xl` en densidad `comfortable` era el único override de densidad que no apuntaba a un paso ref.

- **`BulkBar`, la franja que corona una tabla** (#89). Es **una** franja con dos estados: sin selección hace de barra de herramientas de la tabla —lo que le pase `rest`—, y al seleccionar el lote se **añade** a su derecha sin tragársela. Por eso no aparece ni desaparece y la tabla no salta al marcar la primera casilla.

  El primer intento sí sustituía una cosa por otra, y con filas marcadas no se podía filtrar. Lo cazó una prueba, no la lectura del código.

- **Selección múltiple en `DataGrid` y `Table`** (#89): `selectable`, `selectedKeys`, `defaultSelectedKeys`, `onSelectionChange`, `selectAllLabel`. La mecánica vive en la rejilla, una sola vez; quien la envuelve la consume y no la reimplementa.

- **`surface` y `attachedTop` en `DataGrid` y `Table`** (#89). `surface="none"` para cuando la tabla ya vive dentro de una carcasa ajena —un `Card`, un `WidgetFrame`— y dibujar la suya daría dos superficies anidadas.

- **`DataTable` es la tabla de trabajo completa** (#89): `title`, `description`, `onCellEdit` con columnas `editable`, `sortable`, `paginated`, además de la selección y el lote. **Sus nueve partes se encienden y se apagan por separado**: una regla absoluta que obligue a tragarse maquinaria que no hace falta es lo que empuja a usar la pieza equivocada.

- **`onKeyDown` y `autoFocus` en `Input`** (#89). Sin ellos, una celda que se edita en línea acababa montando un `<input>` crudo y redeclarando foco, altura y tokens.

- **`description` y `variant` en `WidgetFrame`** (#89): una línea bajo el título, y dos pesos de cabecera —`chrome` para el marco discreto de un widget, `panel` para titularlo como tarjeta— sin duplicar la pieza.

### Cambiado

- **`onOpenChange` es el nombre para overlays y capas, no `onClose`** (#88). El alias sigue funcionando toda la 3.x, pero **la tabla de convenciones de la guía enseñaba el nombre deprecado**, así que quien la seguía escribía API en retiro. Corregida.

- **El `platforms` del canon pasa a `adopcion`** (#88, [RFC 0006](../../docs/rfcs/0006-tres-cosas-llamadas-platforms.md)). Había **tres** campos llamados `platforms` midiendo tres cosas distintas —madurez de la implementación, alcance de adopción y el registro de familias que emiten tokens—, y la colisión ya había costado dos errores reales.

  No afecta a quien consume el paquete: el `platforms` de la ficha, que es el que se exporta, no cambia. Afecta a los codebases destino cuando adopten piezas.

- **Una pieza declara su madurez en un solo sitio** (#88, [RFC 0005](../../docs/rfcs/0005-un-estado-una-escala.md)). El `status` por pieza de la ficha se retira: era un segundo campo con su propio vocabulario —aceptaba `proposed`, que la escala oficial no tiene, y un vacío que significaba «estable» en silencio— y se contradecía con `platforms` en 39 piezas. Ahora `contract-truth` exige que toda ficha declare su `platforms.web`.

- **El peso de un título ya no cambia con la densidad** (#89). `--type-title-lg` y `--type-title-md` se aligeraban al pasar a `comfortable` —de black a bold y a regular—, así que **un título de card cambiaba de nivel tipográfico según el subárbol donde cayera**. La densidad cambia el tamaño, nunca el peso; lo vigila `typ-6`.

  Los dos pasan a black en las tres densidades, que es lo que ya se veía en el 100% de las pantallas. Esta guía los documentaba con el peso equivocado.

- **`--bp-medium` (768px), el tercer corte** (#59, [RFC 0003](../../docs/rfcs/0003-el-tercer-corte.md)). El sistema declaraba dos cortes y usaba tres: 768px aparecía **once veces** entre el paquete, las pantallas del banco y tres plantillas portables que además lo documentan en prosa. La escala se nombra ahora `--bp-compact` 576 · `--bp-medium` **768** · `--bp-expanded` 982.

  **Nada cambia de valor.** `--bp-sm` (576) y `--bp-md` (982) siguen valiendo exactamente lo mismo; quedan deprecados y se retiran en 4.0. El vocabulario es nuevo porque no podía no serlo: esta guía promete que _un token `sys` nunca cambia de significado sin cambiar de nombre_, y llamar `--bp-md` a 768 la habría roto en silencio. Se puede deprecar un nombre, no un valor.

### Deprecado

- **`BulkActionsTable` → `DataTable` con `selectable` + `bulkActions`** y **`FilterableEditableTable` → `DataTable` con columnas `editable` + `onCellEdit`** (#90, [RFC 0004](../../docs/rfcs/0004-retiro-de-las-tablas-parciales.md)). Se retiran en 4.0.

  Cada una nombraba un **trozo** del flujo que `DataTable` hace completo, y el precio no era teórico: quien usaba la primera renunciaba a búsqueda, filtros y paginación —un revisor con cuarenta documentos no tenía cómo buscar—; quien usaba la segunda tenía que **elegir entre filtrar o editar**. Por R2 eso no es una pieza, es un juego de props.

  Los filtros por columna de `FilterableEditableTable` no tienen traducción mecánica: pasan a `searchKeys`, o a un `FilterSet` en el slot `filters`.

- **`--bp-sm` → `--bp-compact`** y **`--bp-md` → `--bp-expanded`** (RFC 0003). Mismos valores, nombres nuevos. Funcionan toda la línea 3.x.

### Añadido

- **`check:breakpoints`** (#35) — ningún `@media` inventa un corte. Lee los cortes del diccionario, no de una lista a mano, así que declarar uno nuevo actualiza la reja sola. Entró con ratchet en 9 —768px ocho veces y 1024px una, sin declarar— y **cierra en 0**: el RFC 0003 declaró 768 y el 1024 suelto cayó a `--bp-lg`.
- **`ref.bp.sm`, `ref.bp.md` y `ref.bp.lg`** — los breakpoints eran los únicos tokens `sys` sin cadena a `ref`. Ahora `--bp-sm`, `--bp-md` y `--bp-lg` cuelgan de `--ref-bp-*`, como todos sus vecinos. Paridad en 408 tokens por modo.

### Arreglado

- **`Button` no exponía `aria-busy` con `loading`**, y su ficha decía que sí. Ahora lo lleva.

- **`IconButton` tenía `selected` sin `aria-pressed`** — un toggle que no decía que estaba pulsado.

- **`ChatMessage` prometía `aria-live` polite y solo tenía `role="status"`** — ahora lo lleva explícito.

- **`Spinner` y `Progress` compartían una frase de accesibilidad copiada**, así que cada ficha prometía el role del otro: Spinner decía `role=progressbar` y monta `role=status`, Progress al revés.

- **`Input` y `OTPInput` se atribuían un `role=alert` que pinta `Field`**, su envoltorio. Las fichas ya no lo dicen.

- **Seis tokens copiaban a mano el RGB de otro token** y ahora se derivan con `color-mix`, con el mismo valor: los cuatro fondos de estado del modo oscuro —`rgba(0, 120, 64, 0.16)` donde `--status-success` es `#007840`—, `--surface-backdrop` en claro y `--surface-accent-subtle` en oscuro. Estaban escritos dos veces, en el CSS y en el diccionario, así que un cambio de color se desfasaba en ocho sitios.

- **`Wizard` y `OnboardingCarousel` pasan a `patterns`; `NavCard` pasa a `primitives`.** El import público no cambia —el paquete exporta un solo entry y no tiene subrutas por capa—, solo la capa que declara el contrato. Los dos primeros gobiernan un flujo (`current`/`index` más `onNext`/`onSubmit`/`onDone`) y eso es un pattern; `NavCard` no compone nada ni tiene estado, así que le sobraba capa.

- **`fleet-dashboard-t` apuntaba a la pantalla equivocada** — su ficha describe «shell desktop con sidebar y 4 módulos» y señalaba a uno de esos módulos, el mismo archivo que `dashboards-6`. El sitio de docs publicaba dos entradas que renderizaban la misma pantalla.

- **El JSDoc de `GridColumn.priority` decía lo contrario que el CSS** (#10) — afirmaba que `2` se retira bajo `--bp-md` y `3` bajo `--bp-lg`, cuando el CSS retira `3` primero (982px) y `2` después (576px). En ese momento `--bp-lg` no existía; desde el RFC 0003 existe y vale 982, así que el JSDoc ahora lo nombra.

### Añadido

- **`open` y `onOpenChange` en `Select`, `DatePicker`, `Menu`, `NotificationCenter` y `Tooltip`** (#33, RFC 0002 fase D) — las cinco guardaban su apertura sin exponerla, así que no se podían abrir por deep-link, por onboarding ni desde una prueba. `ARQUITECTURA.md` publica esa convención como estable desde hace tiempo y hasta ahora solo `Popover` la cumplía. **Nadie tiene que cambiar nada**: sin la prop, cada pieza se abre sola exactamente como antes (`cst-3`).

### Añadido

- **`check:canon`** (#54) — dice **qué pasará en el repo si empujas ese canon**, antes de empujarlo. El canon alimenta tres rejas y nada lo validaba: un push podía dejar `main` en rojo para todas las ramas, con el síntoma apareciendo lejos de la causa. No prohíbe, avisa — parte del rojo es contrato-primero y es correcto. Separa lo estructural (un item que apunta a un contrato inexistente: nunca se empuja) de lo pendiente (el repo tiene que alcanzarlo) y de la deriva de esquema, que entra como ratchet.

### Arreglado

- **El esquema del canon declara `kind`, y sus ramas `allOf` exigen `layer`** — `kind` ya existía con valor `receta` en cinco contratos y el esquema no lo declaraba, pese a `additionalProperties: false`: nadie lo había notado porque nada validaba el canon. Y las cuatro ramas por capa preguntaban por `layer` sin exigirlo, lo que en JSON Schema pasa en vacío: un contrato sin capa caía en las cuatro a la vez.

### Añadido

- **`IconButton` acepta `type`** (#31) — no declaraba la prop ni esparcía `...rest`, así que dentro de un `<form>` enviaba **y no había forma de impedirlo**. Default `'button'`.

### Cambiado

- **`Button` e `IconButton` renderizan `type="button"` por defecto** (#31) — **es un cambio de comportamiento, no solo una prop nueva.** El default del HTML es `submit`: hasta ahora, un `<Button>Guardar</Button>` dentro de un `<form>` lo enviaba. Ahora no, salvo que se pida `type="submit"` explícitamente. Quien dependiera del envío implícito tiene que añadirlo — una línea, y el tipo ya lo aceptaba en `Button`. Se anuncia aquí porque la política de compatibilidad promete que ningún cambio que rompa entra en silencio, ni siquiera en `beta`.

### Arreglado

- **Un overlay sin nada focusable dentro dejaba el foco detrás** (#50) — `OverlayShell` buscaba el primer focusable del panel y, si no había ninguno, nadie recibía el foco: el panel llevaba `role="dialog"` y `aria-modal="true"` pero no `tabIndex={-1}`, así que no podía recibirlo él mismo. Un `Dialog` de aviso sin acciones quedaba con el foco fuera, sin Escape —el handler vive en el panel— y sin trampa de Tab, mientras `aria-modal` decía lo contrario. Rompía `ov-1`, `ov-2` y `a11y-4` a la vez. Ahora el panel es focusable, recibe el foco cuando no hay nada dentro que lo tome, y Tab no se escapa cuando no hay adónde ir. `Drawer` y `BottomSheet` no lo sufrían por traer botón de cierre propio.

### Añadido

- **`check:controlled-state`** (RFC 0002, fase C) — criterio `cst-2`: ninguna pieza replica una prop en estado sin sincronizarla después. `useState(prop)` solo se lee en el primer render, así que un cambio posterior no se ve nunca y el dueño cree que controla algo que no controla. **Entra en cero y con cero excepciones**: no nace para remediar deuda, nace para que el primer caso futuro rompa `verify` en vez de colarse.

### Añadido

- **`onOpenChange` en `Dialog`, `Drawer` y `BottomSheet`** (RFC 0002, fase B) — la apertura se reporta al dueño: `onOpenChange(false)` al cerrarse, venga de Escape, del backdrop o del botón de cierre. Es la convención única del sistema desde la decisión A del RFC, y lo que `ARQUITECTURA.md` ya prometía.

### Deprecado

- **`onClose` en los tres overlays** — sigue funcionando toda la línea 3.x y se retira en 4.0, junto a `error` (alias de `invalid`) y `DateRangePicker`. Quien lo use hoy no tiene que cambiar nada: `onOpenChange` y `onClose` se emiten ambos, en ese orden.

### Añadido

- **El canon aprende a expresar reglas transversales** (RFC 0002, fase A) — `_schema.json` gana `kind`: `item` (default) o `architecture`. Hasta ahora todo contrato ocupaba una capa de la cascada, porque todo contrato era una pieza: los seis shells encajaban porque cada uno **es** una pieza con su archivo. `controlled-state` no tiene archivo ni capa —es una regla que otras cumplen— y meterlo como primitive habría sido mentirle al esquema para que pasara. Los 164 contratos existentes siguen válidos sin tocarlos: `layer` sale de `required` arriba y vuelve en la rama `else`.
- **Contrato `controlled-state`** con seis criterios `cst-*`, cinco automatizados. `cst-6` fija la decisión A del RFC 0002: `open` con `onOpenChange`, y `onClose` como alias deprecado hasta 4.0. Los criterios ya los cuenta `check:conformance` — 426 en total, 416 cubiertos — así que la regla nace medida aunque su barrido esté por hacer.

### Cambiado

- **`check:inventory-sync` conoce los contratos transversales** — están en `items` para que su conformance se cuente, pero no se les exige ficha: pedir documentación de algo que nadie importa sería documentar un fantasma.

### Documentado

- **La tabla «Archivos ref» de CLAUDE.md listaba cuatro de los ocho archivos** de `tokens/ref/` — faltaban `colors`, `elevation`, `motion` e `iconography`, o sea la mitad del diccionario de referencia. Ahora los lista y `check:readme` (rdm-5) lo comprueba en los dos sentidos.

- **El nivel `comp` de la cadena de tokens deja de ser «(futuro)»** y dice lo que es: un override sobre un token de `sys`, nunca un `var(--ref-*)` — eso lo rechaza `col-1`, porque un componente no alcanza la capa de referencia.

- **R1 declara que se miden sus dos mitades.** Hacia arriba hay 0 en 135 archivos; hacia el lado —importar de tu propia capa— es `cmp-7`, con trinquete en 8, y la excepción declarada son las carcasas.

- **El rojo de marca deja de ser solo checklist.** `col-4` mide que ningún token de serie o adorno resuelva al rojo, y que todo `var(--brand)` fuera de una pieza de marca declare su motivo.

- **RFC 0002: contrato de estado controlado — aceptado** (#38) — un contrato arquitectónico `controlled-state`, séptimo hermano de los de shells, que fija cómo una pieza expone el estado de interfaz que guarda. La medición corrige al informe que lo motivó: el antipatrón `useState(prop)` tiene **cero** casos y las piezas que tragan estado son **10 de 39**, no 25. El problema que sí resiste la medición es otro — `ARQUITECTURA.md` publica `open` con `onOpenChange` como convención del sistema y **una de doce piezas la cumple**. **Decisión del 22-sep: opción A** — `onOpenChange` es la convención única y `onClose` queda como alias deprecado en `Dialog`, `Drawer` y `BottomSheet`, con retiro en 4.0.
- **La línea 3.x dice qué promete** — faltaba lo más básico para que alguien construya encima: qué superficie cubre SemVer (lo que exportan los barrels y sus `Props`, los tokens `sys`, las rutas de `exports`) y qué es privado y cambia sin aviso (class names de los CSS Modules, tokens `ref`, la composición interna de una pieza). Va en `USUARIO.md`, que viaja en el paquete, y en detalle en la governance.
- **El contrato de deprecación, escrito** — lo deprecado sigue funcionando toda la línea mayor, se marca `@deprecated` en los tipos para que avise el editor, se anuncia dos veces en el CHANGELOG (al deprecar y al retirar) y se retira solo en el siguiente MAJOR.
- **Incluso en `beta` hay promesas** — ningún cambio que rompa entra en silencio, nada se retira sin pasar por deprecado, y un token `sys` nunca cambia de significado sin cambiar de nombre: desaparecer avisa, cambiar de sentido no.
- **Cuándo 3.x pasa a `rc`, por evidencia y no por calendario** — cuando un consumidor real corra en producción sobre la línea **y** no quede RFC de nivel 3 aceptado sin implementar. Hoy no se cumple ninguna de las dos, y queda dicho por qué sigue en beta.

### Documentado

- **La receta del envoltorio de icono, con su restricción** (regla 7 de `USUARIO.md`) — repetir el `<span className="flow-symbol">` invita a olvidar el `aria-hidden`, así que un envoltorio fino en la app del consumidor es legítimo. Lo que la receta fija es lo que **no** lleva: sin prop `color`, sin `style`, sin SVG. El color se hereda por `currentColor`, y esa ausencia es lo que lo hace seguro — si no hay puerta para un hex, nadie mete un hex. Sale de un caso real: un envoltorio con `color` acabó con hex crudos repartidos por las vistas y 25 paths SVG incrustados a mano.

### Añadido

- **El diccionario de tokens declara su versión** — `flow.tokens.json` gana `$version`. Una vez fuera de npm el JSON era anónimo: quien lo descargara para Figma, para un build de Flutter o para una herramienta de diseño no podía saber qué tenía. Lo vigila `check:package-files` (regla `P4` nueva): si falta o no coincide con `package.json`, `verify` falla.

### Documentado

- **RFC 0001 se queda sin preguntas abiertas** — las cuatro que seguían vivas quedan resueltas con su motivo: el registro de plataformas vive en el paquete (lo decidió la fase B), Angular consume el diccionario como React y Flutter —SCSS y `var()` son targets del mismo Style Dictionary—, el Core Team de una persona es dueño de todas, y el diccionario se versiona **con el paquete**, sellado y con condición de reapertura escrita: se separa cuando una segunda plataforma tenga consumidor real y cadencia distinta, las dos cosas.

### Arreglado

- **`FlowChart` construía el tooltip del radar desde una cadena (#32)** — `ind.name`, que es el nombre de serie que pasa el consumidor, se concatenaba dentro de `innerHTML`: cualquier marcado que vinieran en esos datos se ejecutaba. Ahora el tooltip se arma con `createElement` y `textContent`, que escapa por definición. Mismo aspecto, mismo comportamiento.

### Añadido

- **`check:dom-safety`** — el sistema nunca construye DOM desde una cadena: ninguna fuente asigna `innerHTML` u `outerHTML`, llama a `insertAdjacentHTML` o `document.write`, ni usa `dangerouslySetInnerHTML`. El defecto de arriba no era un descuido de una línea, era que nada vigilaba la clase. 203 fuentes revisadas en cada `verify`.

### Documentado

- **La guía de migración cubre las 20 piezas que usa el piloto de eOne** (#40) — antes documentaba 7. Sección nueva «Sin cambio salvo el prefijo» con las 11 que solo pierden el `Flow` (`FlowCard`→`Card`, `FlowButton`→`Button`…), que son el grueso del uso real: 152 usos en `main` y 193 en `aig/main`. Más `FlowDataTable`, `FlowDateRangePicker` y el theming, que vivían solo en el README y no en la guía que viaja en el paquete.
- **`FlowBadge` se parte en sus tres casos reales** — punto sobre un control (contador de `IconButton`/`TabBar`), estado con texto (`StatusPill`) y cifra con tono (`Badge` con `tone`). El piloto usa la misma pieza para las tres cosas, que es justo lo que Flow 3 separó; documentar solo una dejaba siete usos mal migrados.
- **Valores de prop que cambian** — `status="error"` no existe: la escala es `success|warning|danger|info|neutral` y el mapeo es `error`→`danger`. Y el significado no va dentro del texto: «Aprobado ✓» lo dice el `tone` más un icono, no un glifo en el label.
- **Sección «Piezas propias de tu app»** — qué hacer con los envoltorios que trae el consumidor, con `FlowIcon` como caso medido: su destino es la ligadura `flow-symbol`, **no `IconButton`** (glifo inerte contra control con `onClick` y objetivo de 44 px), y su `color` se revisa uso por uso porque trae hex crudos que rompen el modo oscuro.

### Cambiado

- **`check:migration-map` también vigila la tabla nueva** y lee la columna de destino por posición en vez de tomar la última, porque «Sin cambio salvo el prefijo» declara además la capa. Sube de 37 a 58 destinos verificados.

### Arreglado

- **Cinco cifras publicadas estaban desfasadas** — el README decía «190 contratos» en dos sitios y `USUARIO.md` «190 fichas» cuando el export `./contracts` (que es `items.json`) tiene 196; `CLAUDE.md` y `USUARIO.md` citaban «415 criterios» cuando la reja medía 416/421. `USUARIO.md` viaja en el paquete: quien migra decide con esos números.

### Arreglado

- **La guía de migración mandaba a dos piezas que no existen** — `FlowSegmentedControl` apuntaba a `Segmented` (es `SegmentedControl`, #39) y `FlowToolbar` a `BulkActionsPattern` (es `BulkActionsTable`). `MIGRACION-1x.md` viaja en el paquete: quien siguiera cualquiera de las dos se llevaba un error de import.

### Quitado

- **`publish.yml`** — nunca se ejecutó y había divergido del camino real (`scripts/release.mjs`): corría 2 de los 24 pasos, no conocía el MCP, no pasaba `--tag` (una beta habría quedado como `latest`) y no creaba el GitHub Release. Además disparaba con `on: push: tags: v*`, el mismo tag que `release.mjs` empuja — con Actions encendido, cada release habría intentado publicar dos veces. Sus tres motivos de retiro quedan escritos en la cabecera de `release.mjs`, para quien piense en recrearlo.

### Cambiado

- **`ci.yml` deja de repetir la lista de pasos** — llamaba a las 24 rejas una por una, duplicando lo que ya declara `scripts/verify.mjs`; añadir una reja obligaba a editar los dos archivos y olvidarse de uno no rompía nada. Ahora el workflow es `npm run verify` y la lista vive en un solo sitio. La organización no tiene Actions habilitado, así que el archivo no se ejecuta hoy — razón de más para que no tenga nada propio que envejecer.

### Añadido

- **`check:migration-map`** — cada destino que las tablas de Renombres y Absorciones citan tiene que exportarse desde un barrel. Nadie comprobaba el «ahora se llama así». La reja lo caza el día que se escribe, y encontró el segundo de los dos errores de arriba, que la revisión a ojo no vio.
- **`check:docs-numbers`** — toda cifra publicada en la documentación sale de su fuente, o no se publica. Las cifras estables (fichas, piezas, foundations) se comparan contra el código; las de conformance quedan **prohibidas en prosa**, porque son un ratchet que se mueve en cada commit y envejece en silencio. Añadir una cifra vigilada es añadir una fila a la tabla, no tocar el motor.

## [3.0.0-beta.4] — 2026-09-22

### Añadido

- **Tres plantillas más** — Alta en pasos (`wizard-t`), Onboarding de cuenta (`onboarding-fm`) y Consola interna (`internal-tools-t`), en el mismo formato: cuándo usarla, layout, piezas, código completo, personalización y responsive. Son las que piden los equipos de flota e internal tools.
- **`USUARIO.md` gana «Modo prototipo»** — la ruta corta para quien arma una pantalla para enseñar: partir de una plantilla, cambiar los datos, no tocar los interiores y pasar el checklist.

## [3.0.0-beta.3] — 2026-09-21

### Añadido

- **`docs/ARQUITECTURA.md` viaja en el paquete** — la cascada, las cuatro reglas, lo que el sistema ya resuelve y las convenciones de props, escrito para quien usa Flow. Es lo que sirve el servidor MCP cuando corre desde `node_modules` (antes leía el `CLAUDE.md` del repo, que no viaja).

### Arreglado

- **Dos tokens de densidad llevaban sintaxis de CSS dentro del diccionario** — `density.controlX/Y` valían `var(--pad-control-x/y)` en vez de referenciar el token de padding como sus hermanos. El CSS no cambia (sigue emitiendo `var(--pad-control-x)`), pero el SCSS que consumiría Angular emitía una variable de Sass con una custom property dentro, que sin el CSS cargado no resuelve a nada. Ahora emite `20px` y `12px`. Lo cazó la reja nueva.

### Cambiado

- **Registro de plataformas (RFC 0001, fase B)** — `tokens/platforms.json` declara cada plataforma con su prioridad, estado, consumidor y reja: React (soportada), Flutter (vuelve con su equipo), Angular (experimental) y Swift (**retirada**, su salida ya no se emite). La reja `check:platforms` lo hace cumplir y compara el SCSS contra el CSS token a token.

## [3.0.0-beta.2] — 2026-09-10

### Arreglado

- **`styles.css` ya no arrastra las banderas (#1)** — pesaba 4.9 MB: 4.7 MB eran 542 reglas de flag-icons con SVG incrustado, pagadas por toda app aunque no usara `Flag`. Ahora la hoja la importa el propio `Flag` y viaja como import externo: solo la paga quien usa `Flag`, y la procesa el bundler de tu app. `styles.css` baja a 152 KB. Si ya usabas `Flag`, no tienes que cambiar nada. La reja `check:lib-css` fija el presupuesto.

### Añadido

- **El diccionario de tokens viaja en el paquete** — `tokens/flow.tokens.json` (formato W3C, 490 tokens) se exporta como `@er-mobility-mx/design-system/tokens`: cualquier plataforma o herramienta de diseño lo consume sin clonar el repo. La reja `check:package-files` vigila que él, las fichas, los tipos y las guías sigan viajando.
- **Plantillas documentadas (#2)** — `docs/templates/` viaja en el paquete con cuatro pantallas para copiar: Auth, Dashboard, Ajustes y Explorador de datos. Cada una trae cuándo usarla, layout, piezas, código completo, puntos de personalización y comportamiento responsive. El servidor MCP las sirve con `list_templates` y `get_template`, y `check:templates` las compila contra la API en cada `verify`.

### Documentado

- **Foundations en el inventario** — el README nombra las 7 foundations (color, tipografía, espaciado y layout, forma y elevación, motion, iconografía y marca, accesibilidad) en «Qué hay en la caja», y `list_inventory` del MCP también las lista. Los conteos se corrigieron (128 piezas; faltaba `ScaleLegend`) y `check:readme` los mantiene iguales a los barrels.

## [3.0.0-beta.1] — 2026-09-10

### Cambiado

- **El paquete continúa la línea de la org: `@er-mobility-mx/design-system`** — Flow 3.0 sucede a la 1.x (`1.0.0-rc.x`, publicada desde `ER-Mobility-MX/flow`). Es una versión mayor: la API cambia respecto de 1.x y la ruta está en `docs/MIGRACION-1x.md`. Mientras sea beta se instala con la etiqueta `beta`: `npm install @er-mobility-mx/design-system@beta`.
- **Los deprecados se retiran en 4.0** — `error` (alias de `invalid`) y `DateRangePicker`. Antes decían 1.0, un número que ya ocupa la línea anterior.

### Arreglado

- **MapCanvas: el icono de recentrar usa la clase de tamaño** (`flow-symbol--sm`) en lugar de `fontSize` inline — mismos 16 px, dentro de la escala que vigila compliance.
- **ScaleLegend: radios con `--radius-mark`** en lugar de literales (shp-2). La base de cada paso pasa de 2 a 3 px.
- **`--viz-scale-1…5` entran al diccionario de tokens**, en claro y en oscuro: existían solo en el CSS y rompían la paridad.

### Documentado

- **Fichas y contratos de las props que nacieron sin ellos en 0.6.x** — StatTile `deltaTone`, `deltaArrow`, `action` y `bare`; LimitBar `kind`, `stacked`, `bare` y `format`; WidgetFrame `actions`; DataTable `searchable` y `pageSizeOptions`; TableTree `defaultExpanded`; MapCanvas `fitBounds`. ScaleLegend gana ficha y contrato (scl-1), y AuthForm `sso` y `submitIcon` entran al canon.

## [0.6.35] — 2026-09-09

### Añadido

- **AuthForm: modo `sso` — el traspaso a un proveedor (auth-1)** — el patrón cubría ingreso, registro y recuperación: las tres cajas que RECOGEN credenciales. Una pantalla que delega en un IdP no tenía cómo usarlo —o pintaba campos que no puede tener, o se escribía a mano—, y eso es la forma en que entra media empresa (cazado en eOne, cuyo único acceso es un traspaso a Edenred Connect bajo el contrato de que la app nunca ve la contraseña). En `sso` la caja se queda sin campos, no hay nada que validar y el botón de envío ES el traspaso; `submitIcon` le pone su candado. El segundo factor sigue fuera a propósito: es `OTPInput` o `BiometricPrompt` compuestos en la misma carcasa, como dice el canon.

## [0.6.34] — 2026-09-08

### Añadido

- **StatTile sin tarjeta (stt-8)** — `bare` pinta la cifra con su rótulo y su nota, pero SIN la superficie del Card, para composiciones que ya tienen la suya: una fila de cifras dentro de un panel, una ficha dentro de una lámina. Sin esta salida el consumidor tenía dos caminos malos —anidar tarjeta dentro de tarjeta, o copiar a mano rótulo+cifra+nota—, y eOne tomó el segundo cinco veces en su organigrama y otras tantas en la ficha de estación, calcando declaración por declaración lo que ya vivía aquí. Mismo escape que `LimitBar.bare`.

## [0.6.33] — 2026-09-08

### Arreglado

- **SegmentedControl: la píldora sigue a su casilla (sgc-1)** — la medida se tomaba una sola vez por cambio de valor o de número de casillas, y la geometría cambia por más motivos: reetiquetar (otro idioma, una cifra viva en la etiqueta) mueve el ancho sin mover la cuenta, y el contenedor puede estrecharse o la tipografía cargar tarde. La píldora se quedaba con la medida vieja y desbordaba sobre la casilla vecina (cazado en eOne, migrando Conductores: indicador de 119 px sobre una casilla de 98). Ahora un `ResizeObserver` sobre la casilla activa y la raíz la mantiene medida.

## [0.6.32] — 2026-09-08

### Cambiado

- **Pagination: el bloque de páginas se centra (pag-9)** — con el nav estirado, las páginas quedaban pegadas al selector de tamaño; ahora el espacio libre se reparte por igual a ambos lados y el bloque queda centrado entre el contador y el selector. En uso compacto los autos colapsan y nada cambia. Pedido por el dueño de eOne para el directorio de estaciones.

## [0.6.31] — 2026-09-08

### Arreglado

- **Pagination: la cifra grande era el contador de rango (pag-8 corregido)** — en 0.6.30 la subida a `--type-data-md` cayó en los números de página; el dueño se refería al contador «X–Y de Z». Los numerales regresan a su talla de control (`--type-data`) y el rango pasa a dato grande en mono: es LA cifra del pie. Las 5 páginas por extremo se quedan como estaban.

## [0.6.30] — 2026-09-08

### Cambiado

- **Pagination: 5 páginas por extremo y numerales en cifra grande (pag-8)** — la elipsis ya no desemboca en un número suelto: los DOS extremos enseñan 5 páginas (ventana constante de 15 casillas; con 15 páginas o menos se ven todas). Y los números de página suben a `--type-data-md` — son solo numerales, la voz mono a 20px los hace legibles de un vistazo. Pedido por el dueño de eOne para el directorio de estaciones.

## [0.6.29] — 2026-09-08

### Cambiado

- **Pagination: ventana de ancho constante (pag-7)** — la vecindad `±1 + extremos` encogía la fila en los bordes (en la página 1 de 582 quedaban solo «1 2 … 582»). Ahora la ventana son SIEMPRE 7 casillas cuando hay más de 7 páginas: cerca de los bordes la vecindad se ensancha en vez de encoger, así la fila no cambia de ancho ni las flechas se mueven bajo el cursor al navegar.

### Añadido

- **Pagination: primera/última página (pag-7)** — botones de salto a los extremos (`first_page`/`last_page`), solo cuando la lista se trunca: con todos los números visibles el salto ya está a un clic y las flechas extra estorban. Pedido por el dueño de eOne para el directorio de estaciones.

## [0.6.28] — 2026-09-08

### Añadido

- **DataTable usa la Paginación completa (dtb-7)** — el pie pasa de páginas peladas al contrato entero que Pagination ya tenía: rango «X–Y de Z», páginas y selector de tamaño (`pageSizeOptions`). El nav se estira al ancho del pie y el rango empuja a la izquierda — páginas y selector cierran por la derecha; en uso compacto nada cambia. Pedido por el dueño de eOne para el directorio de estaciones.

## [0.6.27] — 2026-09-08

### Arreglado

- **MapCanvas: el zoom conserva el lugar (mpc-5)** — el offset del paneo vive en píxeles de mundo y el mundo duplica su tamaño por nivel: los botones ± cambiaban de nivel sin reescalarlo y la rueda además reseteaba el paneo a cero, así que zoomear estando paneado «teletransportaba» (cazado en eOne: «el zoom está súper buggy»). Ahora todo cambio de nivel reescala el offset y el lugar bajo el cursor se queda donde estaba.

### Añadido

- **MapCanvas: botón de centrar (mpc-5)** — junto al zoom, vuelve al encuadre: del conjunto de `fitBounds` si lo hay, del centro declarado si no. El pan y el zoom manual siempre tienen regreso.

## [0.6.26] — 2026-09-08

### Añadido

- **MapCanvas: el tooltip lista sus atributos y el punto lleva glifo (mpc-4)** — `MapPin.details` pinta los atributos como LISTA en la burbuja (una fila por dato; `subtitle` queda como forma corta de una fila), y el modo punto acepta `icon`: el glifo a escala del punto, como textura de identidad. Pedido por el dueño de eOne para las estaciones de su red.

## [0.6.25] — 2026-09-08

### Cambiado

- **MapCanvas: el pin es una GOTA y el tooltip habla el idioma del sistema (mpc-3)** — el pin chip pasa a la anatomía clásica de «aquí»: cabeza circular con su icono y cola que toca la coordenada exacta (el círculo flotante tapaba el lugar que decía señalar); aro `--surface-card`, halo y sombra como estaban. Y el tooltip del mapa deja la tarjeta blanca con mono: es la burbuja INVERSA del sistema —`surface-inverse`, texto claro, `radius-sm`, `shadow-float`—, la misma voz que el Tooltip de UI y los tooltips de las gráficas. Pedido por el dueño de eOne para su red de afiliados.

## [0.6.24] — 2026-09-08

### Arreglado

- **ScaleLegend: el icono grande antes de su etiqueta** — icono→texto en los dos extremos, no en espejo (dueño de eOne, 8-sep): «$ Más barato … $ Más caro».

## [0.6.23] — 2026-09-08

### Añadido

- **MapCanvas: encuadre y centro controlado (mpc-2)** — `fitBounds` recibe los puntos a encuadrar: cuando el conjunto cambia, el mapa se centra y elige el zoom que los contiene con margen; entre cambios, el pan del usuario manda. Y el `center` pasa a ser controlado de verdad: al cambiarlo, el mapa va ahí y suelta el pan acumulado — sin esto, seguir una selección tras un encuadre sumaba el desplazamiento viejo y centraba en otro sitio. Cazado en eOne: al filtrar por estado el mapa viaja a ese estado, al soltar el filtro vuelve al país. Era la pérdida asumida del 0.6.21 (el fitBounds de Leaflet); dejó de ser asumible cuando el dueño la pidió.

## [0.6.22] — 2026-09-08

### Añadido

- **ScaleLegend (scl-1)** — la leyenda de una ESCALA: un rango continuo cortado en tramos, de menor a mayor. Tres decisiones de nacimiento (dueño de eOne, la escala de precio de su red de afiliados): tonos de un mismo color y no un semáforo —verde→rojo dice bueno/malo y un rango no juzga—; la geometría CRECE con el valor, así la dirección se lee sin distinguir tonos; iconografía de refuerzo opcional, chica en el mínimo y grande en el máximo. La casilla de ausencia de dato va aparte: «sin dato» no es un tramo del rango.
- **Tokens `--viz-scale-1..5`** — escala de color para rangos SOBRE IMAGEN (azules claro→oscuro): la rampa gris de heatmaps desaparece sobre los tiles grises de un mapa. En oscuro evita los extremos que se funden con el fondo.

## [0.6.21] — 2026-09-08

### Añadido

- **MapCanvas: modo de red densa (mpc-1)** — `MapPin.size` pinta el pin como PUNTO: relleno + aro fino, sin sombra ni halo, y SIN botón DOM propio (miles de marcas de dato harían el grupo intransitable a teclado; su superficie accesible es la tabla que las lista, como en una gráfica). El punto elegido u hovered crece y gana aro de tinta; su tooltip de label/subtitle sigue vivo. Cazado en eOne: 6 977 estaciones ahogaban el chip de 24px y sus 6 977 botones.
- **MapCanvas: la ruta acepta TRAMOS (mpc-1)** — `route` admite `[lat,lon][][]` además de la polilínea simple. Una ruta real llega a menudo como MultiLineString con tramos que no se tocan (el ruteo del INEGI); unirlos trazaría rectas que cruzan un golfo y que nadie puede conducir.
- **DataTable: `searchable` (dtb-6)** — `false` oculta el buscador, para tablas cuyo dueño ya filtra aguas arriba: dos cajas de búsqueda pegadas confunden sobre cuál filtra qué (cazado en eOne: el directorio de estaciones ya tiene «Buscar estación» en los filtros de la pantalla).

## [0.6.20] — 2026-09-08

### Eliminado

- **Muere el modo por niveles de RoleMatrix (rmx-1, 0.6.19)** — vivió un día. Nació para acomodar el vocabulario compuesto del RBAC legado de eOne (completo/lectura/gestión con nota por celda) y el dueño lo señaló como lo que era: preferir el legado antes que adoptar Flow. Un «nivel» no pide celdas nuevas: pide DESCOMPONERSE en las acciones booleanas que concede —ver, escribir, administrar—, cada una en su fila, que es exactamente lo que la matriz booleana ya expresaba. `Permission.hint` sobrevive como rmx-2: el matiz bajo el nombre del permiso es anatomía legítima de la fila, no herencia del legado.

## [0.6.19] — 2026-09-08

### Añadido

- **RoleMatrix por niveles (rmx-1)** — una matriz de permisos no siempre es booleana: un RBAC real concede NIVELES (completo, lectura, gestión…) con un alcance por celda. Con `levels` declarado, la celda es `{ level, note? }` y se pinta como badge del tono del nivel con su nota; la celda vacía es una denegación explícita y se dice con «—», no con hueco. `Permission.hint` lleva el matiz bajo el nombre («módulo pendiente de construcción»). Cazado en eOne: la matriz de ADR-001, la fuente de verdad de su control de acceso.

## [0.6.18] — 2026-09-08

### Arreglado

- **i18n: los valores viajan por `formatMessage`, no por `.replace()` (i18n-2)** — `useT` acepta valores y DataTable, Pagination, CardCarousel y BulkActionsTable los usan. Formatear «Buscar en {caption}» sin la variable revienta con `FORMAT_ERROR` en consola en cada render (cazado en eOne: 100+ errores al abrir el desglose del ranking de consumos). Sin provider, la interpolación cae al reemplazo simple.

## [0.6.17] — 2026-09-08

### Cambiado

- **La familia title pasa a Edenred Black** — `--type-title-lg` y `--type-title-md` suben de Bold/Regular a Black 900 (decisión del dueño, análisis de jerarquía en eOne): un título de sección o de card debe pesar MÁS que el contenido destacado que vive dentro, y en regular el título de card competía —y perdía— contra los `body-md-strong` del cuerpo. Entra `--ref-type-wt-black` (900) al catálogo de pesos y el corte real `edenred_black-webfont.woff2` a `public/fonts` (existía en eOne; el DS solo había vendoreado Regular y Bold — nada de bold sintético).

## [0.6.16] — 2026-09-07

### Arreglado

- **Popover/Select: el control ya convive en fila (pp-4)** — `.root[data-fill]` llevaba `width: 100%`, y un flex item con width 100% dentro de una fila que envuelve se queda SIEMPRE su línea entera: ningún Select podía sentarse junto a un botón. En flujo de bloque un `display: block` llena su contenedor igual, así que los formularios no cambian. Cazado en eOne (la cabecera del organigrama partía selector y botón en dos filas); el grid de su barra de filtros era un workaround de este mismo defecto y el diagnóstico anotado entonces —«el panel oculto infla el max-content»— era incorrecto: el panel vive en portal desde pp-1.

## [0.6.15] — 2026-09-07

### Añadido

- **`TableTree.defaultExpanded` (tt-1)** — claves abiertas al montar. Un árbol que nace todo colapsado no puede enseñar su primer nivel ni revelar una selección restaurada. Cazado en eOne: la vista de organigrama abre con las divisiones a la vista, y el nodo elegido en una sesión anterior no puede quedar escondido tras un chevron.
- **`TableTreeRow` y `TableTreeColumn` salen al barrel** — un consumidor con filas tipadas (celdas compuestas vía `render`) no podía nombrar el tipo que ya usaba.

## [0.6.14] — 2026-09-07

### Añadido

- **FlowChart `bar`: superposición de línea (fc-6)** — una serie que declara `type: 'line'` se pinta como línea del sistema sobre las barras, con sus extras respetados (el mismo mecanismo que scatter). Nació de eOne: la línea de «ayer a esta hora» sobre las barras de consumo — sin ella, «hemos consumido 18 000 L» no dice si es mucho o poco.

### Arreglado

- **FlowChart `bar`: la barra negativa redondea su extremo libre (fc-6)** — el remate redondeado quedaba contra la línea de cero y la barra parecía rota. Cazado en eOne: los litros de un tramo salen negativos cuando los abonos superan a las cargas, y ese tramo es justo el que no se puede esconder.

## [0.6.13] — 2026-09-07

### Arreglado

- **Input `type="number"`: muere el stepper nativo** — el spinner del navegador (▲▼) aparecía al enfocar, cromo del sistema operativo sin diseñar dentro de un control que el DS promete poseer (cazado en eOne: el diálogo de objetivos con foco y sin foco no eran el mismo control). `appearance: textfield` + supresión webkit.

## [0.6.12] — 2026-09-07

### Añadido

- **`StatTile.action`**: acción de la tarjeta en la esquina del encabezado — un IconButton (ajustar, abrir detalle). Nació de eOne: sus objetivos editables se disuelven en StatTiles con el engrane a la vista, en la misma familia que el resto de sus KPIs.

## [0.6.11] — 2026-09-07

### Arreglado

- **CardMedia compone Card** — dibujaba su propia superficie con el híbrido borde+sombra que no existe en el vocabulario del Card (el mismo retirado de StatTile en 0.6.8). El modo `interactive` (foco, teclado, hover lift) también pasa a ser del Card (crd-1). Hallazgo de la auditoría de superficies pedida por el dueño de eOne al inventariar la familia de tarjetas.
- Pendiente anotado de la misma auditoría: **NavCard** usa surface-card+radius-lg sin sombra ni borde — desviación menor en pieza de docs; se decidirá con su pantalla.

## [0.6.10] — 2026-09-07

### Arreglado

- **WidgetFrame compone Card — muere la cuarta superficie.** La pieza llegó PORTADA del registro de eOne con su piel legada (radius-md + borde, sin sombra), que no existe en el vocabulario del Card (elevated/outlined/inverse, todas radius-lg). El dueño de eOne lo cazó comparando tarjetas vecinas: el marco de widget desentonaba con todo Card/StatTile por construcción. Mismo tratamiento que StatTile en 0.6.8; el banco hereda el cambio (widgets pasan de borde+16 a sombra+20).

## [0.6.9] — 2026-09-07

### Añadido

- **`WidgetFrame.actions`**: acciones del widget en su cabecera, a la derecha del título y antes del toggle de personalización. Nació de eOne: sus widgets con escritura (Objetivos del periodo — Ajustar/Restaurar) necesitan actuar desde el marco, no inventarse una cabecera propia dentro del cuerpo.

## [0.6.8] — 2026-09-07

### Arreglado

- **StatTile compone Card — una sola superficie de tarjeta en el sistema.** Dibujaba la suya propia con un híbrido que no existe en el vocabulario del Card (borde Y sombra; elevated es sombra sin borde, outlined es borde sin sombra), así que cualquier Card vecino desentonaba por construcción (cazado en eOne: sus tarjetas-medidor en Card real nunca podían igualar a los StatTile). Cambio visible: el StatTile pierde el borde de 1px y pasa al padding del Card (--pad-card, sensible a densidad).

## [0.6.7] — 2026-09-07

### Añadido

- **`LimitBar.bare`**: solo la pista, sin encabezado — para composiciones que ya dicen etiqueta y valores en su propio lenguaje. Conserva `kind` y el estado over/met del relleno. (Las tarjetas-medidor de eOne hablan en el idioma del StatTile — cabecera con icono y numerales en familia de dato grande — y la pista es el refuerzo.)

## [0.6.6] — 2026-09-07

### Añadido

- **`StatTile.deltaArrow`** (default `true`): permite retirar el glifo de tendencia del delta. Con `deltaTone` en juego, `trending_up` (culturalmente «mejora») junto a un danger rojo manda dos señales opuestas — cazado en eOne: «↗ +325 %» en rojo leía como contradicción. El signo del texto ya dice la dirección (stt-2 se cumple con texto); sin glifo quedan signo = dirección y color = juicio.

## [0.6.5] — 2026-09-07

### Añadido

- **`LimitBar.stacked`**: etiqueta arriba y valores abajo, en dos filas — para tarjetas estrechas donde la fila única envolvía ambos lados en un dos-columnas apretado. En apilada, los valores hablan a tamaño de estadística (`--type-data-md`, en primary; over/met conservan su color).

### Arreglado

- **LimitBar: las cifras entran a la familia de dato** (`--type-data-sm`, tabular) — iban en `body-md`, fuera del idioma numérico del sistema (stt-1 lo exige para StatTile; la misma regla vale aquí). Cazado en eOne: sus tarjetas-medidor desentonaban con los KPIs vecinos.

## [0.6.4] — 2026-09-07

### Añadido

- **`StatTile.deltaTone`**: el color del delta deja de deducirse SOLO del signo. «+» pintaba success siempre — y en un KPI de gasto o consumo, subir es malo (cazado en eOne: «+330 % de gasto» en verde). La flecha sigue diciendo la dirección; `deltaTone` dice si es buena. Sin la prop, el comportamiento de siempre.

## [0.6.3] — 2026-09-07

### Añadido

- **`LimitBar.kind`** (`cap` | `goal`): cruzar el 100% de un techo es danger; cruzar un OBJETIVO es la meta cumplida — success. La pieza solo conocía techos y el objetivo de unidades de eOne (≥ 92%) pintaba danger justo al cumplirse. El «en peligro» de V1, completado por la segunda pantalla que lo pidió.

## [0.6.2] — 2026-09-07

### Añadido

- **`LimitBar.format`**: los valores del encabezado aceptan formateador propio — el default sigue siendo moneda con `$` (el origen wallet de la pieza), pero un techo de litros o un objetivo en % ya no se disfrazan de dinero (cazado en eOne: «$70.952,8» para 70 952,8 L).

### Arreglado

- **LimitBar: el relleno se acota al 100%** — sin tope, un 111% desbordaba la pista redondeada. Pasarse del límite ahora se dice con color (`data-over`: relleno y valores en danger), no saliéndose del carril — el «en peligro» que V1 dejaba pendiente de pantalla, decidido por la primera pantalla que lo pidió.

## [0.6.1] — 2026-09-07

### Arreglado

- **Calendar: la última columna desbordaba el panel** — el ancho de `.root` era un 20rem a mano que dejaba 296px útiles para 308px de celdas (7 × hit-target); la banda de rango sangraba por el borde derecho. El ancho ahora se calcula del contenido, y el hueco horizontal del grid muere: la continuidad del rango la da el contacto entre celdas, no el desborde accidental.
- **Anillo de foco doblado en triggers-span** (Select, DatePicker): el supresor del anillo interior de ControlShell solo cubría `input/textarea/button`; los spans con `tabindex` recibían el anillo global ENCIMA del `focus-within` de la carcasa. El `:where()` gana `[tabindex]`. (Ambos cazados en la migración de eOne.)

## [0.6.0] — 2026-09-05

### Añadido

- **Demos móviles homogéneas**: los 8 CTAs de flujo que quedaban en md (Aceptar/Pasar/Finalizar del Driver, Disputar/Cerrar de Wallet y CardDetail, el submit de Auth) pasan a lg — y una reja nueva del banco lo vigila (todo Button fullWidth de pages/mobile declara lg).
- **`InputPhone.size` gana `lg`**: las pantallas de alta hablan lg — un campo md entre controles lg desentona. El paso de teléfono del onboarding queda homogéneo (Select lg + InputPhone lg, 52px medidos iguales).
- **Select**: lo elegido no pierde su cara — en single, el trigger viste el valor con el mismo `renderOption` de las filas (la bandera del país sigue ahí tras elegir; en multiple resume con texto).
- **`InputPhone.prefix` admite ReactNode**: bandera compacta + lada como adorno de la carcasa, sincronizada al selector de país — sigue fuera del valor y no borrable (tel-1). El onboarding del banco ahora usa la pieza real (antes un Input genérico con la lada al lado equivocado). Specimen `input-phone` registrado (ratchet 37).

- **`Card.selected`** (decisión 5-sep): anillo inset `--border-focus` + superficie `--surface-accent-subtle` — seleccionado legible sin color (crd-3, ahora automated). `aria-pressed` cuando la tarjeta es operable.
- **NotificationCenter**: estado vacío real («Sin notificaciones — todo al día») en vez de panel en blanco (ntf-6).
- 7 especímenes más (DataTable, ToastHost, Sidebar con grupos, TransactionGroup, DocumentViewer, HelpCenter, NotificationCenter) — ratchet spm-1 en 36.

### Arreglado (cierre visual, 5-sep)

- **Las banderas no pintaban — en ninguna parte, desde 0.4.0**: el `@import` de flag-icons vivía dentro de un CSS Module y lightningcss hasheaba sus clases (`.Xxx_fi-mx`) mientras el componente ponía las globales (`fi fi-mx`). Ahora entra global desde `styles.css` (SVGs inlineados como data-URI en `flow.css`, +~1.7 MB autocontenidos) y hay test de regresión que lo vigila.
- **DataTable**: la zona de filas ancla su altura a la de una página completa — la última página corta ya no encoge la tabla (dtb-5).
- **Card**: la franja de `status` ya no la pisa el borde de la piel outlined (cascada corregida).
- **TransactionGroup**: el label de fecha va en mono como manda trg-1.
- **Banco**: la cola casera de toasts (AppLayout) reemplazada por ToastHost/useToast; receta de país con bandera en el onboarding (pai-p1..p4, sin componente nuevo — pai-p5); pantallas Driver y Rutas ruteadas.

- **Registro de especímenes** (`@er-mobility-mx/design-system/specimens`): la tercera pata de cada pieza — el contrato promete, la ficha describe, el specimen demuestra. 29 piezas con render vivo y sus variantes, typechequeado contra las interfaces reales (spm-1), como entry propio que el principal no arrastra (spm-2, verificado en dist), consumido genéricamente por Component Detail (spm-3). Contrato canónico `specimen-registry` nuevo.

### Arreglado (pasada visual, 5-sep)

- **ChipGroup** apaga el borde individual de los chips hijos (cg-1).
- **Breadcrumb** colapsa rutas largas por el medio conservando el primero y el actual (brc-3).
- **Calendar** en rango: los extremos redondean solo por su lado exterior (dp-6).
- **`MarkLineComponent` de ECharts nunca estuvo registrado**: toda línea de referencia (`markLine`) del sistema era invisible en silencio. Registrado; con ello el Pareto dibuja su umbral (prt-3, nueva prop `threshold` de FlowChart) y el scatter sus cuadrantes (sct-2, ahora en tinta `--viz-label` distinguible de la rejilla).
- **Treemap**: la etiqueta de un nodo demasiado pequeño para ella ya no se trunca («Manten…») — se oculta y el tooltip la conserva (tmp-2).
- **Flag**: anillo interior `--border-subtle` — una bandera con blanco al borde ya no se desvanece (flag-2).
- **TabBar**: respeta `env(safe-area-inset-bottom)` (tbr-5).
- **Banco**: el passcode fallido dice cuántos intentos quedan y la pantalla de Auth quedó ruteada como tercer demo móvil (ao-3).

## [0.5.0] — 2026-09-04

### Añadido

- **DataTable** (patrón nuevo): búsqueda, orden y paginación coordinados sobre Table — la consulta filtra, el orden se aplica al conjunto filtrado completo y la paginación recorta al final; buscar devuelve a la primera página y el recuento se anuncia en `aria-live` (dtb-1..dtb-5).
- **Table / DataGrid** `caption`: la tabla se nombra para el lector con `<caption>` visualmente oculto (tb-5).
- **StatTile** `description` (contexto bajo el delta) y `loading` (esqueleto con `aria-busy`, sin cifras falsas) (stt-6, stt-7).
- **Sidebar**: grupos con `caption: true` — rótulo no interactivo con hijos siempre listados; colapsado se reduce a separador (sbr-6).
- **Tooltip**: el disparador recibe `aria-describedby` hacia el globo mientras está visible (tip-6).
- **Card** `status` ('success' | 'warning' | 'danger' | 'info'): franja de estado con tokens `--status-*` (crd-6) — y escala de `padding` ('none' | 'sm' | 'md' | 'lg'); el valor libre sigue aceptado como puente de migración.
- **Pagination** `total` + `pageSize` (rótulo «X–Y de Z»), `pageSizeOptions` + `onPageSizeChange` (selector de tamaño; cambiar el tamaño emite `onChange(1)`) (pag-6).
- **SectionHeader** `description`: bajada en muted fuera del heading — el outline queda limpio (sh-3).
- **Escala de capas** `--z-*` en tokens (base/sticky/header/overlay/popover/toast/tooltip): los diez z-index globales de la librería salen de la escala; el diccionario y el CSS mantienen paridad (398/398).

### Añadido (shells)

- **ToastHost + useToast**: la cola de avisos vive una sola vez — apila con tope FIFO (`max`, default 3), `show()` devuelve id, `dismiss(id)` retira, la acción del aviso también lo retira, y cada aviso vive su `duration` propia (default 5000 ms, `null` = persistente). `useToast` fuera del host truena con mensaje claro (th-1..th-3).
- **D5 (i18n)**: los strings hardcodeados de Calendar («Mes anterior/siguiente»), Select («Limpiar»), ChatMessage («Escribiendo»), Toast y Drawer («Cerrar») pasan por intl con default en español — sin provider nada cambia.
- **Popover en portal** con colisión completa (pp-1/pp-2): ningún overflow o transform del ancestro lo recorta; voltea al lado opuesto solo si allí cabe mejor, se recorta contra la ventana con 8px en el eje cruzado y, si no cabe en ningún lado, limita su altura con scroll interno en vez de deslizarse sobre el ancla. Sigue al ancla en scroll/resize y el origen de la animación sale del lado real.
- **OverlayShell en portal** + `dismissOnBackdrop` (false para diálogos que exigen decisión).
- **Listbox**: `aria-activedescendant` en la lista, Home/End y typeahead (lb-2/lb-3).
- **ControlShell** `invalid` (canónico; `error` queda como alias `@deprecated`) + `filled` documentado.
- Los cinco contratos de shells (control-shell, listbox, overlay-shell, popover, toggle-control) entran a la arquitectura del canon y sus 24 criterios automatizados quedan medidos.

### Añadido (deuda saldada)

- **Barrido i18n completo**: los ~25 aria-labels y textos en español duro que quedaban (TopBar, Sidebar, BulkActionsTable, FilterableEditableTable, GlobalSearch, MapCanvas, PasscodeKeypad, KanbanBoard, CardCarousel, NipReveal, Breadcrumb, PageHeader, HelpCenter, ChatComposer, NavBar, RouteBanner, Treemap, CodeBlock…) pasan por intl con default en español. `CodeBlock` ahora dice «Copiar código» (antes «Copy code»).
- **Banco documental con dientes**: 13 criterios automatizados nuevos para las piezas de documentación (AnatomyView, BalanceDisplay, CardCarousel, DocFooter, DownloadCard, GuidanceCard, InstallCard, NipReveal, PageHeader, PlaygroundCanvas, ProfileMenu, ProposalCard) + `nr-1` promovido de manual a automated. El id `tg-1` de transaction-group pasa a `trg-1` (colisión con toggle-control).
- **GanttChart**: cada tarea dice sus fechas en texto («14 ago – 17 ago») bajo su nombre (gnt-1 — antes solo geometría).
- **Auditoría visual con acta** (`docs/audits/visual-2026-09-04.md`): recorrido del banco contra los 181 criterios `visual`; 46 verificados, 2 defectos corregidos (gnt-1 y el treemap de Finanzas que pintaba por categoría en vez de por desvío, tmp-1), y la cola restante enumerada con causa.

### Cambiado

- El contrato canónico de `data-grid` deja de ser huérfano: reescrito al API real del primitivo, registrado en la arquitectura y medido (dg-1/2/3/9/10). Selección masiva, edición y árbol siguen en sus propias piezas, como decide el paquete.
- El nombre accesible de Pagination es «Paginación» (antes «Paginacion»), y sus textos pasan por `useT` (caen a español sin provider).
- Popover ahora se apila por encima del backdrop de overlay (`--z-popover` > `--z-overlay`): un popover abierto dentro de un modal ya no queda debajo.

## [0.4.0] — 2026-09-04

### Añadido

- Primera publicación en **GitHub Packages**; la instalación por git queda retirada (registry o `.tgz` de respaldo vía `npm pack -w packages/flow-react`).
- `docs/USUARIO.md` viaja en el paquete: las reglas del repo consumidor para humanos y agentes.
- Servidor MCP con `get_contract` y `get_user_guide` (además de inventario, APIs, tokens y reglas de arquitectura).
- `Toast.duration` con pausa en hover/foco — el timeout deja de ser de la app (tst-2).
- FileUpload valida `accept` también al soltar, y su zona es botón (teclado ✓).
- Teclado sobre canvas: MapCanvas con pines-botón; ScatterPlot/Treemap con listbox paralelo (`aria-activedescendant`).

### Cambiado

- El repo es workspace: `packages/flow-react` (publicable) + `apps/banco` (banco de plantillas, privado). El tarball no lleva banco.
- `Input.invalid` es el nombre canónico; `error` queda como alias `@deprecated` hasta 1.0.
- ToggleControl se reescribe a composición por children (Radio queda fuera a propósito).

## [0.3.0] — 2026-09-04

### Añadido

- Programa de conformance completo: 355/355 criterios automatizados del canon citados por test o check (`check:conformance` con ratchet).
- Triángulo de API cerrado: `check:api-drift` (canon ↔ ficha) en cero, sin divergencias declaradas.
- Rejas de CI: catálogo, inventario, foundations, targets, color, iconos, a11y estática, paridad de tokens.
- Lazy ECharts con degradación; ~60 defectos reales corregidos (anillo de foco global, Escape por capas, trampa de Tab en diálogos, sparklines NaN, AuthForm sin autocomplete, entre otros).

## [0.1.0] — 2026-09-02

- Arranque del paquete: 126 piezas (50 primitives, 59 components, 17 patterns), tokens ref→sys→comp con Style Dictionary, catálogo con fichas (`items.json`).
